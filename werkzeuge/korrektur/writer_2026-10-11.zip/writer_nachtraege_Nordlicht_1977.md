# Nachträge zu den Vorschlagslisten: Nordlicht 1977

Stand 11.10.2026, ODIN Writer. Hier stehen die Stellen, die das Vorschlagswerkzeug nicht abdeckt: Sätze, die im Band neu dazugekommen sind, und Sätze, die im Band weggefallen sind. Ermittelt aus dem Vergleich der Buchquellen vor und nach der Durchsicht (Listen in writer_2026-10-11), abzüglich aller Sätze, die in den Vorschlagslisten schon mit „ja“ stehen. Je Stelle der ganze Absatz alt und neu; „ergänzen“ und „streichen“ nennen die Sätze, die nach dem Übernehmen der Vorschläge noch fehlen oder übrig sind.

## Deutsch

### Zeile 17, Feste Punkte und offene Punkte

**alt:** Der Preis. Der Tisch kann das Wie eines festen Punktes ändern, wenn er bereit ist, dafür zu zahlen. Ein Agent, der in Kiruna einen Mann rettet, der eigentlich fallen sollte, rettet ihn. Aber jemand anderes geht an seiner Stelle. Oder der Agent trägt von da an eine Belastung. Oder ein Schützling kommt zu früh zum Einsatz. Der Preis ist nie eine Regelstrafe. Der Preis ist eine Geschichte.

**neu:** Der Preis. Der Tisch kann das Wie eines festen Punktes ändern, wenn er bereit ist, dafür zu zahlen. Ein Agent, der in Kiruna einen Mann rettet, der eigentlich fallen sollte, rettet ihn. Aber jemand anderes geht an seiner Stelle. Oder der Agent trägt von da an eine Belastung. Oder ein Schützling kommt zu früh zum Einsatz. Der Preis ist nie eine Regelstrafe. Der Preis ist eine Geschichte. Nennt ein Einsatz als Preis „Vertrauen“, meint er das Verhältnis zu dieser Figur, nicht den Vertrauenswert der Gruppe.

- ergänzen: Nennt ein Einsatz als Preis "Vertrauen", meint er das Verhältnis zu dieser Figur, nicht den Vertrauenswert der Gruppe.

### Zeile 49, Die Gruppe Frachtbrief

**alt:** Die Verbindungen der Gruppe sind die Figuren der Zeit. Evelyn Marsh gibt die Einsätze des Operativen Zweigs. Sie rekrutiert nach Geschichten, nicht nach Akten. Ashgrove gibt die Einsätze der Eskorte und später des Taktischen Zweigs. Er mag den Spitznamen Hammer nicht, aber er erträgt ihn. Hallström gibt ab 1948 die Einsätze der Registratur, ab 1961 des Ermittlungszweigs. 1947 ist er selbst Ziel von Einsatz 1. Er stellt Fragen, die niemand beantworten will. Marek gibt die Einsätze der Psionen, nur bis 1970. Sie besteht auf der Kappe und sagt nicht, warum. Die Siegelwahrerinnen geben die Einsätze des Kollegiums. Sie sprechen selten, und wenn sie sprechen, dann in Kreisen.

**neu:** Die Verbindungen der Gruppe sind die Figuren der Zeit. Evelyn Marsh gibt die Einsätze des Operativen Zweigs. Sie rekrutiert nach Geschichten, nicht nach Akten. Ashgrove gibt die Einsätze der Eskorte und später des Taktischen Zweigs. Den Spitznamen Hammer, den der Flurfunk ab 1954 seinem Zweig gibt, mag er nicht, aber er erträgt ihn. Hallström gibt ab 1948 die Einsätze der Registratur, ab 1961 des Ermittlungszweigs. 1947 ist er selbst Ziel von Einsatz 1. Er stellt Fragen, die niemand beantworten will. Marek gibt die Einsätze der Psionen, nur bis 1970. Sie besteht auf der Kappe und sagt nicht, warum. Die Siegelwahrerinnen geben die Einsätze des Kollegiums. Sie sprechen selten, und wenn sie sprechen, dann in Kreisen.

- ergänzen: Den Spitznamen Hammer, den der Flurfunk ab 1954 seinem Zweig gibt, mag er nicht, aber er erträgt ihn.
- streichen oder ersetzen: Er mag den Spitznamen Hammer nicht, aber er erträgt ihn.

### Zeile 63, Zeitsprünge und Zwischenjahre

**alt:** 1950 | Sundqvist kommt; Wendland hängt das Protokoll der Apothekerin auf | Sundqvist fragt nach den Kreisen von Kiruna

**neu:** 1950 | Sundqvist kommt; Wendland hängt das Protokoll der Apothekerin auf | Sundqvist fragt nach den Kreisen von Solberg

- ergänzen: 1950 Sundqvist kommt; Wendland hängt das Protokoll der Apothekerin auf Sundqvist fragt nach den Kreisen von Solberg
- streichen oder ersetzen: 1950 Sundqvist kommt; Wendland hängt das Protokoll der Apothekerin auf Sundqvist fragt nach den Kreisen von Kiruna

### Zeile 73, Zeitsprünge und Zwischenjahre

**alt:** 1968 | Lüttich; Adeyemi; Dorje stirbt; Sonderzug des Uhrmachers; die Erleuchteten | Druckerei lässt hundert Siegelringe anfertigen (GA „Zweites Licht“)

**neu:** 1968 | Lüttich; Adeyemi; Dorje stirbt; Sonderzug des Uhrmachers; die Erleuchteten | Druckerei lässt hundert Siegelringe anfertigen (GA, Akte 8 „Das Zweite Licht“)

- ergänzen: 1968 Lüttich; Adeyemi; Dorje stirbt; Sonderzug des Uhrmachers; die Erleuchteten Druckerei lässt hundert Siegelringe anfertigen (GA, Akte 8 "Das Zweite Licht")
- streichen oder ersetzen: 1968 Lüttich; Adeyemi; Dorje stirbt; Sonderzug des Uhrmachers; die Erleuchteten Druckerei lässt hundert Siegelringe anfertigen (GA "Zweites Licht")

### Zeile 107, Das Nachfolger-System

**alt:** Übergabe. Der Schützling übernimmt, wenn der Agent stirbt, hinübergeht, ausbrennt, in eine Stille muss, zu den Offenen wechselt, in einer Legende verschwindet oder abtritt. Seine EP sind die gesammelten Schützlings-EP, mindestens aber die Mindest-EP des laufenden Abschnitts. Dazu bekommt er ein Vermächtnis. Das Vermächtnis ist plus 1 auf eine Fertigkeit des Mentors, wenn diese auf 4 oder höher ist. Oder ein Gegenstand: ein Stück Aschesilber, auf dessen Innenseite der Name des Mentors kommt. Ein Notizbuch. Eine Kappe oder ein Helm. Ein Kristall nur mit Zustimmung des Kollegiums. Oder ein Kontakt. Oder, nach Tod oder Ruhestand, der Codename als Reihe, also Salz-2, nach dem Vorbild der Folio-Reihe. Die Übergabe ist eine Szene. Sie wird gespielt, nicht abgehakt.

**neu:** Übergabe. Der Schützling übernimmt, wenn der Agent stirbt, hinübergeht, ausbrennt, in eine Stille muss, zu den Offenen wechselt, in einer Legende verschwindet oder abtritt. Seine EP sind die gesammelten Schützlings-EP, mindestens aber die Mindest-EP des laufenden Abschnitts. Dazu bekommt er ein Vermächtnis. Das Vermächtnis ist plus 1 auf eine Fertigkeit des Mentors, wenn diese auf 4 oder höher ist. Oder ein Gegenstand: ein Stück Aschesilber, auf dessen Innenseite der Name des Mentors kommt. Ein Notizbuch. Eine Kappe oder ein Helm. Ein Kristall nur mit Zustimmung des Kollegiums. Oder ein Kontakt. Oder, nach Tod oder Ruhestand, der Codename als Reihe, also Salz-2, nach dem Vorbild der Folio-Reihe; im Ermittlungszweig wird nur Folio vererbt. Die Übergabe ist eine Szene. Sie wird gespielt, nicht abgehakt.

- ergänzen: Oder, nach Tod oder Ruhestand, der Codename als Reihe, also Salz-2, nach dem Vorbild der Folio-Reihe; im Ermittlungszweig wird nur Folio vererbt.
- streichen oder ersetzen: Oder, nach Tod oder Ruhestand, der Codename als Reihe, also Salz-2, nach dem Vorbild der Folio-Reihe.

### Zeile 125, Das Nachfolger-System

**alt:** 

**neu:** Für neue Agenten und Schützlinge liegen im Heft „Nordlicht 1977: Handouts“ drei leere Vordrucke, je einer für eine Zeit: die Karteikarte von 1948 (Handout N55), der Personalbogen des Rates von 1961 (N56) und der Rechnerausdruck von 1977 (N57).

- ergänzen: Für neue Agenten und Schützlinge liegen im Heft "Nordlicht 1977: Handouts" drei leere Vordrucke, je einer für eine Zeit: die Karteikarte von 1948 (Handout N55), der Personalbogen des Rates von 1961 (N56) und der Rechnerausdruck von 1977 (N57).

### Zeile 177, Regeln am Tisch

**alt:** Proben werden immer genannt als Fertigkeit gegen Schwierigkeit, mit einer Zahl in Klammern. Die Namen kommen aus dem Grundregelwerk. Die Schwierigkeiten sind Stufen von Einfach (1) bis Unmöglich (5). Wahrnehmung gegen Machbar (2). Athletik gegen Schwer (3). Okkultismus gegen Sehr schwer (4). Keine neuen Regeln.

**neu:** Proben werden immer genannt als Fertigkeit gegen Schwierigkeit, mit einer Zahl in Klammern. Die Namen kommen aus dem Grundregelwerk. Die Schwierigkeiten sind Stufen von Einfach (1) bis Unmöglich (5). Wahrnehmung gegen Machbar (2). Athletik gegen Schwer (3). Okkultismus gegen Sehr schwer (4). Keine neuen Probenregeln.

- ergänzen: Keine neuen Probenregeln.
- streichen oder ersetzen: Keine neuen Regeln.

### Zeile 116, Brandmunition ab 1953

**alt:** Vor der ersten Charge im Herbst 1953 gilt die Kiruna-Regel. Danach gibt der Rüstmeister ein Magazin je Einsatz aus. Brandmunition wirkt gegen die Stimme, nicht gegen Tote oder Fremde. Gegen Tote hilft sie so wenig wie gewöhnliche Munition. Gegen Fremde hilft nur, was die Spielleitung für den einzelnen Fremden festlegt.

**neu:** Vor der ersten Charge im Herbst 1953 gilt die Kiruna-Regel. Danach gibt der Rüstmeister ein Magazin je Einsatz aus. Brandmunition wirkt gegen die Stimme, nicht gegen Tote oder Fremde. Gegen Tote hilft sie so wenig wie gewöhnliche Munition. Gegen Fremde wirken gewöhnliche Waffen voll; Brandmunition hilft nicht besser.

- ergänzen: Gegen Fremde wirken gewöhnliche Waffen voll; Brandmunition hilft nicht besser.
- streichen oder ersetzen: Gegen Fremde hilft nur, was die Spielleitung für den einzelnen Fremden festlegt.

### Zeile 119, Brandmunition ab 1953

**alt:** Vor der ersten Charge Brandmunition im Herbst 1953 verursachen gewöhnliche Waffen gegen Wesen aus Rissen keinen Schaden. Schutz bieten nur Bannkreise, Zauber und Rückzug. Salz hält vielleicht auf. Niemand weiß, ob es nicht doch geholfen hat. Wer in Kiruna dabei war, sagt nichts. Wer überlebt hat, zählt die Namen.

**neu:** Vor der ersten Charge Brandmunition im Herbst 1953 verursachen gewöhnliche Waffen gegen Wesen aus Rissen keinen Schaden. Schutz bieten nur Bannkreise, Zauber und Rückzug. Salz hält vielleicht auf. Niemand weiß, ob es nicht doch geholfen hat. Wer in Kiruna dabei war, sagt nichts. Wer überlebt hat, zählt die Namen. Ab Herbst 1953 gelten für gewöhnliche Waffen die Werte des Bedrohungsatlas.

- ergänzen: Ab Herbst 1953 gelten für gewöhnliche Waffen die Werte des Bedrohungsatlas.

### Zeile 163, Tauschliste für die Startausrüstung

**alt:** 

**neu:** Sturmgewehr, Kampfanzug mit Helm, Hochexplosiv-Granaten | Karabiner oder Maschinenpistole, Stahlhelm, Handgranaten der Zeit | Sturmgewehre erst 1977 Leichte Rüstung, Schleichrüstung | Wie Schutzweste | Je nach Jahr Bio-Scanner, tragbarer Scanner | Mikroskop, Lupe, Spurensicherungskoffer | Kein Scanner im Feld Dokumentenscanner | Minox oder Kleinbildkamera | Fotografiert auf Film Verstärktes Kommunikationsgerät | Feldtelefon oder Kurzwellenfunk | Je nach Einsatzort Vorhersagegerät, Datenkristall | Entfällt | Existiert vor 1977 nicht

- ergänzen: Sturmgewehr, Kampfanzug mit Helm, Hochexplosiv-Granaten Karabiner oder Maschinenpistole, Stahlhelm, Handgranaten der Zeit Sturmgewehre erst 1977 Leichte Rüstung, Schleichrüstung Wie Schutzweste Je nach Jahr Bio-Scanner, tragbarer Scanner Mikroskop, Lupe, Spurensicherungskoffer Kein Scanner im Feld Dokumentenscanner Minox oder Kleinbildkamera Fotografiert auf Film Verstärktes Kommunikationsgerät Feldtelefon oder Kurzwellenfunk Je nach Einsatzort Vorhersagegerät, Datenkristall Entfällt Existiert vor 1977 nicht

### Zeile 191, Tauschliste für die Startausrüstung

**alt:** Mental-Fokusgerät | Kappe oder Helm | Je nach Jahr

**neu:** Mental-Fokusgerät, Neuro-Helm | Vor 1949 keiner, jede Psi-Probe ist dann eine Stufe schwerer; ab 1949 Kappe, ab 1963 Mk. I, ab 1972 Mk. II | Die Kappe schützt nicht gegen psionische Angriffe

- ergänzen: Mental-Fokusgerät, Neuro-Helm Vor 1949 keiner, jede Psi-Probe ist dann eine Stufe schwerer; ab 1949 Kappe, ab 1963 Mk.
- ergänzen: I, ab 1972 Mk.
- ergänzen: II Die Kappe schützt nicht gegen psionische Angriffe
- streichen oder ersetzen: Mental-Fokusgerät Kappe oder Helm Je nach Jahr

### Zeile 206, Geld und Spesen

**alt:** Sold und Spesen folgen den Regeln des Grundregelwerks, angepasst an die Zeit. Vor 1961 gibt es keine Rangleiter, der Sold richtet sich nach Abschnitt: im ersten Abschnitt der Sold eines Agenten, 4.500 Euro im Monat, im zweiten bis 1961 der eines Senior-Agenten, 6.000 Euro. Ab 1961 gilt der Sold nach Rang wie im Grundregelwerk. Spesen gibt kein Führungsoffizier frei, sondern Marsh, Ashgrove, Hallström oder der Rat. Spesen für eine Weiße Akte betragen 500 Euro, für eine Graue 2.000, für eine Rote 10.000. Für eine Schwarze Akte gilt: So viel wie nötig. Jede Quittung landet bei der Revision.

**neu:** Sold und Spesen folgen den Regeln des Grundregelwerks, angepasst an die Zeit. Vor 1961 gibt es keine Rangleiter, der Sold richtet sich nach Abschnitt: im ersten Abschnitt der Sold eines Agenten, 4.500 Euro im Monat, im zweiten bis 1961 der eines Senior-Agenten, 6.000 Euro. Ab 1961 gilt der Sold nach Rang wie im Grundregelwerk. Freigaben und Anforderungen richten sich auch vor 1961 nach den gesammelten EP wie im Grundregelwerk; es fehlen nur Titel und Anrede. Spesen gibt kein Führungsoffizier frei, sondern Marsh, Ashgrove, Hallström oder der Rat. Spesen für eine Weiße Akte betragen 500 Euro, für eine Graue 2.000, für eine Rote 10.000. Für eine Schwarze Akte gilt: So viel wie nötig. Jede Quittung landet bei der Revision.

- ergänzen: Freigaben und Anforderungen richten sich auch vor 1961 nach den gesammelten EP wie im Grundregelwerk; es fehlen nur Titel und Anrede.

### Zeile 83, Thomas Ashgrove

**alt:** Ashgrove ist ein Mann des Befehls. Er trägt Uniform, auch wenn es keine gibt. Seine Stimme ist ruhig, tief, ohne Eile. Er spricht selten über Gefühle, nie über Angst. Er nennt die Männer beim Namen, nicht beim Rang. Er isst mit ihnen, schläft neben ihnen, trägt die Verwundeten selbst. Er mag den Spitznamen „Hammer“ nicht. Er sagt: „Ein Hammer zerbricht. Ich will nicht zerbrechen.“ 1955 bekommt er das Messer Nr. 1 aus Aschesilber. Er trägt es bis 1988. Er sagt, es ist warm. Er sagt, das gibt sich. Es hat sich nicht gegeben.

**neu:** Ashgrove ist ein Mann des Befehls. Er trägt Uniform, auch wenn es keine gibt. Seine Stimme ist ruhig, tief, ohne Eile. Er spricht selten über Gefühle, nie über Angst. Er nennt die Männer beim Namen, nicht beim Rang. Er isst mit ihnen, schläft neben ihnen, trägt die Verwundeten selbst. Er mag den Spitznamen nicht, den der Flurfunk ab 1954 seinem Zweig gibt: „Hammer“. Er sagt: „Ein Hammer kennt nur ein Problem.“ 1955 bekommt er das Messer Nr. 1 aus Aschesilber. Er trägt es bis 1988. Er sagt, es ist warm. Er sagt, das gibt sich. Es hat sich nicht gegeben.

- ergänzen: Er mag den Spitznamen nicht, den der Flurfunk ab 1954 seinem Zweig gibt: "Hammer".
- ergänzen: Er sagt: "Ein Hammer kennt nur ein Problem." 1955 bekommt er das Messer Nr. 1 aus Aschesilber.
- streichen oder ersetzen: Er mag den Spitznamen "Hammer" nicht.
- streichen oder ersetzen: Er sagt: "Ein Hammer zerbricht.
- streichen oder ersetzen: Ich will nicht zerbrechen." 1955 bekommt er das Messer Nr. 1 aus Aschesilber.

### Zeile 117, Evelyn Marsh

**alt:** Marsh gibt der Gruppe die Tarnung. Sie zeigt, wie man verschwindet, wie man lügt, wie man überlebt. Sie nimmt den Spielern die Naivität, indem sie zeigt, was Tarnung kostet. Sie nimmt ihnen die Sicherheit, indem sie zeigt, dass niemand die ganze Wahrheit kennt. Sie tritt auf in den Einsätzen 1, 3, 7, 8, 9 und 11. Meist als Stimme, als Brief, als Frau, die am Rand steht und zuschaut.

**neu:** Marsh gibt der Gruppe die Tarnung. Sie zeigt, wie man verschwindet, wie man lügt, wie man überlebt. Sie nimmt den Spielern die Naivität, indem sie zeigt, was Tarnung kostet. Sie nimmt ihnen die Sicherheit, indem sie zeigt, dass niemand die ganze Wahrheit kennt. Sie tritt auf in den Einsätzen 1, 3, 7, 8, 9, 10 und 11. Meist als Stimme, als Brief, als Frau, die am Rand steht und zuschaut.

- ergänzen: Sie tritt auf in den Einsätzen 1, 3, 7, 8, 9, 10 und 11.
- streichen oder ersetzen: Sie tritt auf in den Einsätzen 1, 3, 7, 8, 9 und 11.

### Zeile 217, Astrid Solheim

**alt:** 1947 ist Astrid dreizehn. Sie lebt in Bergen, lernt das Uhrmacherhandwerk. 1954 findet sie den Kristall. 1956 tritt sie ins Kollegium ein. Penhallow stellt die Regel auf: jeder Chronomancer nur unter Aufsicht eines zweiten. Astrid hält sich daran, meistens. In den Sechzigern wird sie zur Lehrerin. Sie bildet eine Handvoll Schüler aus, alle Chronomancer. Sie entwirft die Zeitmessanlage für Nordlicht. Sie arbeitet für den Stützpunkt, ist aber nicht stationiert. Sie steht nicht auf dem Dienstplan. 1977, am 14. Februar, sitzt sie mit Ingrid im verspäteten Zug nach Narvik. Um 22:10 läuft Ingrids Taschenuhr in unter einer Minute eine ganze Nacht ab. Astrid kommt gut drei Stunden zu spät.

**neu:** 1947 ist Astrid dreizehn. Sie lebt in Bergen, lernt das Uhrmacherhandwerk. 1954 findet sie den Kristall. 1956 tritt sie ins Kollegium ein. Penhallow stellt die Regel auf: jeder Chronomancer nur unter Aufsicht eines zweiten. Astrid hält sich daran, meistens. In den Sechzigern wird sie zur Lehrerin. Sie bildet eine Handvoll Schüler aus, alle Chronomancer. Sie entwirft die Zeitmessanlage für Nordlicht. Sie arbeitet für den Stützpunkt, ist aber nicht stationiert. Sie steht nicht auf dem Dienstplan. 1977, am 14. Februar, sitzt sie mit Ingrid im verspäteten Zug nach Narvik. Um 22:10 läuft die Taschenuhr in Ingrids Hand in unter einer Minute eine ganze Nacht ab. Astrid kommt gut drei Stunden zu spät.

- ergänzen: Um 22:10 läuft die Taschenuhr in Ingrids Hand in unter einer Minute eine ganze Nacht ab.
- streichen oder ersetzen: Um 22:10 läuft Ingrids Taschenuhr in unter einer Minute eine ganze Nacht ab.

### Zeile 239, Weitere Figuren

**alt:** [table Name | Rolle | Einsätze @ 30 40 30]

**neu:** [table Name | Rolle | Passt in Einsatz @ 30 40 30]

- ergänzen: [table Name Rolle Passt in Einsatz @ 30 40 30]
- streichen oder ersetzen: [table Name Rolle Einsätze @ 30 40 30]

### Zeile 249, Weitere Figuren

**alt:** Martin Hofer | Ingenieur, baut Prototyp 0417 | 9, 10, 11, 12

**neu:** Dr. Martin Hofer | Physicist des Instituts, baut den Detektor 0417 | 9, 10, 11, 12

- ergänzen: Dr.
- ergänzen: Martin Hofer Physicist des Instituts, baut den Detektor 0417 9, 10, 11, 12
- streichen oder ersetzen: Martin Hofer Ingenieur, baut Prototyp 0417 9, 10, 11, 12

### Zeile 272, Weitere Figuren

**alt:** Diese Figuren sind keine festen Größen wie die Porträts. Sie können in den Einsätzen auftreten, Informationen geben, die Gruppe begleiten oder behindern. Ihre Schicksale stehen im Kanon. Die Spielleitung nutzt sie als Nebenfiguren, als Zeugen, als Stimmen am Rand. Sie füllen die Welt, ohne sie zu tragen.

**neu:** Diese Figuren sind keine festen Größen wie die Porträts. Sie können in den Einsätzen auftreten, Informationen geben, die Gruppe begleiten oder behindern. Ihre Schicksale stehen im Kanon. Die Spielleitung nutzt sie als Nebenfiguren, als Zeugen, als Stimmen am Rand. Sie füllen die Welt, ohne sie zu tragen. Die Spalte nennt Einsätze, in die eine Figur passt; in den Einsatztexten steht sie nicht immer.

- ergänzen: Die Spalte nennt Einsätze, in die eine Figur passt; in den Einsatztexten steht sie nicht immer.

### Zeile 60, Was wirklich geschah

**alt:** - **Wie die Kiste reist.** Per Lastwagen, Schiff oder Zug. Entscheidet die Gruppe, den Landweg über Dänemark und Schweden zu nehmen, mit der Fähre von Harwich nach Esbjerg, verlängert sich der Einsatz und der Sammler hat mehr Chancen. Entscheidet sie die Seeroute, spielt die Überfahrt über Nordsee und Skagerrak. Dienstbucheintrag: Transportweg, Zwischenfälle.

**neu:** - **Wie die Kiste reist.** Per Lastwagen, Schiff oder Zug. Entscheidet die Gruppe, den Landweg über Dänemark und Schweden zu nehmen, mit der Fähre von Harwich nach Esbjerg, verlängert sich der Einsatz und der Sammler hat mehr Chancen. Beim Landweg spielt Knoten 4 auf der Fähre nach Esbjerg, den Zollbegleitschein (N4) stellt der schwedische Zoll in Helsingborg aus, und die Konfrontation findet nachts im Fährhafen von Helsingborg statt. Entscheidet sie die Seeroute, spielt die Überfahrt über Nordsee und Skagerrak. Dienstbucheintrag: Transportweg, Zwischenfälle.

- ergänzen: Beim Landweg spielt Knoten 4 auf der Fähre nach Esbjerg, den Zollbegleitschein (N4) stellt der schwedische Zoll in Helsingborg aus, und die Konfrontation findet nachts im Fährhafen von Helsingborg statt.

### Zeile 202, Söldner des Sammlers

**alt:** [entry - | Söldner des Sammlers | Profi · Menschen]

**neu:** [entry - | Söldner des Sammlers | Handlanger · Menschen]

- ergänzen: [entry - Söldner des Sammlers Handlanger · Menschen]
- streichen oder ersetzen: [entry - Söldner des Sammlers Profi · Menschen]

### Zeile 339, Knoten 1: Die Grube und der Hohlraum

**alt:** November 1947, Polarnacht. Ein Förderkorb fährt in die Tiefe, der Grubenleiter führt die Gruppe durch nasse Strecken zu Sohle 5, Ort 12 (Karte K3). In seinen Papieren liegt die Meldung an das Bergamt (Handout N5). Bergleute mit Karbidlampen warten vor dem Hohlraum, ein Grubenhund liegt davor. Dahinter eine runde Höhle mit mattgrauen Wänden, auf einem Stein eine stehengebliebene Taschenuhr.

**neu:** November 1947, kurz vor der Polarnacht. Ein Förderkorb fährt in die Tiefe, der Grubenleiter führt die Gruppe durch nasse Strecken zu Sohle 5, Ort 12 (Karte K3). In seinen Papieren liegt die Meldung an das Bergamt (Handout N5). Bergleute mit Karbidlampen warten vor dem Hohlraum, ein Grubenhund liegt davor. Dahinter eine runde Höhle mit mattgrauen Wänden, auf einem Stein eine stehengebliebene Taschenuhr.

- ergänzen: November 1947, kurz vor der Polarnacht.
- streichen oder ersetzen: November 1947, Polarnacht.

### Zeile 613, Knoten 3: Der Hof in Leipzig

**alt:** - **Hinweis:** Der Schuster trägt einen Lederbeutel um den Hals, der bei Berührung warm ist. Ein Scientist erkennt mit Physik gegen Schwer (3), dass der Splitter darin leichter ist, als er sein dürfte. (führt zu: der verlorene Kristall des Kollegiums)

**neu:** - **Hinweis:** Der Schuster trägt einen Lederbeutel um den Hals, der bei Berührung warm ist. Ein Scientist erkennt mit Physik gegen Schwer (3), dass der Splitter darin leichter ist, als er sein dürfte. (führt zu: der verlorene Kristall des Kollegiums; Der Splitter hält den Namensfresser)

- ergänzen: (führt zu: der verlorene Kristall des Kollegiums; Der Splitter hält den Namensfresser)
- streichen oder ersetzen: (führt zu: der verlorene Kristall des Kollegiums)

### Zeile 636, Knoten 5: Die junge Staatssicherheit

**alt:** - **Hinweis:** In seiner Kartei liegt ein Foto der Gruppe, aufgenommen vom Beobachtungsposten. (führt zu: der Beobachtungsposten) Ein Agent findet das mit Wahrnehmung gegen Schwer (3).

**neu:** - **Hinweis:** In seiner Kartei liegt ein Foto der Gruppe, aufgenommen vom Beobachtungsposten. (führt zu: Die junge Staatssicherheit beobachtet den Hof) Ein Agent findet das mit Wahrnehmung gegen Schwer (3).

- ergänzen: (führt zu: Die junge Staatssicherheit beobachtet den Hof) Ein Agent findet das mit Wahrnehmung gegen Schwer (3).
- streichen oder ersetzen: (führt zu: der Beobachtungsposten) Ein Agent findet das mit Wahrnehmung gegen Schwer (3).

### Zeile 646, Knoten 6: Westberlin, Notaufnahmestelle

**alt:** - **Hinweis:** Der Onkel aus Salzgitter hat einen Vordruck für neue Papiere bei sich. Das Feld für den Namen ist noch leer. (führt zu: der Name wird abgelegt) Ein Agent findet das mit Wahrnehmung gegen Schwer (3) oder mit Fingerfertigkeit gegen Schwer (3), ein Investigator mit Wahrnehmung gegen Machbar (2). - **Hinweis:** Die Frau am Schalter sagt: „Die Familie ist nach Niedersachsen geschickt worden. Wohin genau, steht nicht in meiner Kartei.“ (führt zu: die Spur endet) Ein Agent findet das mit Überzeugen gegen Machbar (2).

**neu:** - **Hinweis:** Der Onkel aus Salzgitter hat einen Vordruck für neue Papiere bei sich. Das Feld für den Namen ist noch leer. (führt zu: Die Spur des Mädchens endet in Westberlin) Ein Agent findet das mit Wahrnehmung gegen Schwer (3) oder mit Fingerfertigkeit gegen Schwer (3), ein Investigator mit Wahrnehmung gegen Machbar (2). - **Hinweis:** Die Frau am Schalter sagt: „Die Familie ist nach Niedersachsen geschickt worden. Wohin genau, steht nicht in meiner Kartei.“ (führt zu: Die Spur des Mädchens endet in Westberlin) Ein Agent findet das mit Überzeugen gegen Machbar (2).

- ergänzen: (führt zu: Die Spur des Mädchens endet in Westberlin) Ein Agent findet das mit Wahrnehmung gegen Schwer (3) oder mit Fingerfertigkeit gegen Schwer (3), ein Investigator mit Wahrnehmung gegen Machbar (2).
- streichen oder ersetzen: (führt zu: der Name wird abgelegt) Ein Agent findet das mit Wahrnehmung gegen Schwer (3) oder mit Fingerfertigkeit gegen Schwer (3), ein Investigator mit Wahrnehmung gegen Machbar (2).

### Zeile 655, Knoten 6: Westberlin, Notaufnahmestelle

**alt:** 

**neu:** - **Der Splitter hält den Namensfresser im Hof; in Blei verschlossen, verliert er den Halt.** Hinweise: Der Schuster trägt einen warmen Splitter im Lederbeutel (Knoten 3). Die Schusterkinder, die dem Beutel am nächsten sind, verloren ihre Namen zuerst (Knoten 3). Marsh gibt das Bleikästchen „für alles, was flüstert“ mit (Briefing).

- ergänzen: Der Splitter hält den Namensfresser im Hof; in Blei verschlossen, verliert er den Halt.
- ergänzen: Hinweise: Der Schuster trägt einen warmen Splitter im Lederbeutel (Knoten 3).
- ergänzen: Die Schusterkinder, die dem Beutel am nächsten sind, verloren ihre Namen zuerst (Knoten 3).
- ergänzen: Marsh gibt das Bleikästchen "für alles, was flüstert" mit (Briefing).

### Zeile 667, Eskalation

**alt:** **Stufe 3: Vorladung.** Der Verbindungsoffizier der jungen Staatssicherheit lädt die Gruppe in sein Büro in der Leipziger Innenstadt, Tür ohne Schild, zwei Stockwerke, ein Raum mit Kartei. Er fragt nach dem Zweck der Reise, dem Interesse am Hof, der Familie. Wer sich in Widersprüche verwickelt, bleibt 48 Stunden in einer Zelle im Polizeipräsidium. Danach wird die Gruppe ausgewiesen. Die Kamera und die Filme sind beschlagnahmt. Das Foto gibt es trotzdem: Ein Agent hat den ersten Film nach dem ersten Besuch aus der Leica genommen und im Mantelfutter versteckt, die Volkspolizei findet nur den zweiten (Umweg).

**neu:** **Stufe 3: Vorladung.** Der Verbindungsoffizier der jungen Staatssicherheit lädt die Gruppe in sein Büro in der Leipziger Innenstadt, Tür ohne Schild, zwei Stockwerke, ein Raum mit Kartei. Er fragt nach dem Zweck der Reise, dem Interesse am Hof, der Familie. Wer sich in Widersprüche verwickelt, bleibt 48 Stunden in einer Zelle im Polizeipräsidium. Danach wird die Gruppe mit der Auflage entlassen, die DDR binnen einer Woche zu verlassen; ausgewiesen wird sie erst nach der Konfrontation im Hof. Die Kamera und die Filme sind beschlagnahmt. Das Foto gibt es trotzdem: Ein Agent hat den ersten Film nach dem ersten Besuch aus der Leica genommen und im Mantelfutter versteckt, die Volkspolizei findet nur den zweiten (Umweg).

- ergänzen: Danach wird die Gruppe mit der Auflage entlassen, die DDR binnen einer Woche zu verlassen; ausgewiesen wird sie erst nach der Konfrontation im Hof.
- streichen oder ersetzen: Danach wird die Gruppe ausgewiesen.

### Zeile 718, Verbindungsoffizier eines Partnerdienstes

**alt:** **Initiative** | 4

**neu:** **Initiative** | 3

- streichen oder ersetzen: Initiative 4

### Zeile 1016, Kristallwächter von Kiruna

**alt:** **Schwäche** | Gewöhnliche Waffen verursachen keinen Schaden (Kiruna-Regel). Die Stimmgabel von Wales lässt sie für eine Runde erstarren

**neu:** **Schwäche** | Gewöhnliche Waffen verursachen keinen Schaden (Kiruna-Regel). Die Stimmgabel von Wales lässt sie für eine Runde erstarren; sie liegt 1953 in der Kammer und kommt nur mit, wenn ein Thaumaturg sie beim Kollegium anfordert (Preis: jeder Psion in 100 m erleidet 2 Belastung)

- ergänzen: Die Stimmgabel von Wales lässt sie für eine Runde erstarren; sie liegt 1953 in der Kammer und kommt nur mit, wenn ein Thaumaturg sie beim Kollegium anfordert (Preis: jeder Psion in 100 m erleidet 2 Belastung)
- streichen oder ersetzen: Die Stimmgabel von Wales lässt sie für eine Runde erstarren

### Zeile 1029, Nachspiel

**alt:** **Erfahrung:** Rote Akte: 5 EP, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, plus 1 für jeden aufgenommenen Faden. Dauer: zwei bis drei Sitzungen.

**neu:** **Erfahrung:** Rote Akte: 5 EP, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, plus 1 für jeden aufgenommenen Faden. Aufgenommene Fäden sind: die Maske, Ashgroves Kompass, der Name Solheim (Narvik). Dauer: zwei bis drei Sitzungen.

- ergänzen: Aufgenommene Fäden sind: die Maske, Ashgroves Kompass, der Name Solheim (Narvik).

### Zeile 1071, 1950: Sundqvist und das Protokoll

**alt:** Sundqvist fragt nach den Kreisen von Kiruna. Sie will wissen, ob die Anordnung der Plättchen auf der Kappe mit den Kreisen an der Wand von Solberg übereinstimmt.

**neu:** Sundqvist fragt nach den Kreisen von Solberg. Sie will wissen, ob die Anordnung der Plättchen auf der Kappe mit den Kreisen an der Wand von Solberg übereinstimmt.

- ergänzen: Sundqvist fragt nach den Kreisen von Solberg.
- streichen oder ersetzen: Sundqvist fragt nach den Kreisen von Kiruna.

### Zeile 151, Eskalation

**alt:** Wenn die Gruppe zu langsam ist, passiert nichts Spektakuläres. Die Wartende wartet. Aber die Rufer werden lauter. Jede Nacht, die die Gruppe im Tal verbringt, erhöht den Druck: Alle Agenten, die den Ruf hören, machen eine Grauen-Probe gegen **Unheimlich (1)**. Wer antwortet, erleidet 1 Belastung und hört eine Woche lang den eigenen Namen im Schlaf.

**neu:** Wenn die Gruppe zu langsam ist, passiert nichts Spektakuläres. Die Wartende wartet. Aber die Rufer werden lauter. Jede Nacht, die die Gruppe im Tal verbringt, erhöht den Druck: Wer die Rufer zum ersten Mal hört, macht eine Grauen-Probe gegen **Unheimlich (1)**. Jede weitere Nacht verlangt von jedem, der den Ruf hört, WK + Geistige Widerstandskraft gegen Machbar (2), sonst 1 Belastung. Wer antwortet, erleidet 1 Belastung und hört eine Woche lang den eigenen Namen im Schlaf.

- streichen oder ersetzen: Jede Nacht, die die Gruppe im Tal verbringt, erhöht den Druck: Alle Agenten, die den Ruf hören, machen eine Grauen-Probe gegen Unheimlich (1).

### Zeile 170, Ablauf in nummerierten Schritten

**alt:** 6. Das Silberstück bleibt warm und ruhig. Es trägt fortan den Namen des Toten.

**neu:** 6. Das Silberstück bleibt warm und ruhig. Einen Namen trägt es nur, wenn die Gruppe ihn selbst einritzt.

- ergänzen: Einen Namen trägt es nur, wenn die Gruppe ihn selbst einritzt.
- streichen oder ersetzen: Es trägt fortan den Namen des Toten.

### Zeile 337, Knoten 2: Der Strand und die Bucht

**alt:** 

**neu:** - **Hinweis:** Pennington beschriftet am Strand ein Etikett von Hand: K-1957-003 (Handout N21). (führt zu Knoten 5)

- ergänzen: Hinweis: Pennington beschriftet am Strand ein Etikett von Hand: K-1957-003 (Handout N21).
- ergänzen: (führt zu Knoten 5)

### Zeile 366, Knoten 6: Uppsala, Dezember 1957

**alt:** Ein Kellerraum unter einem Haus in Uppsala, das der Loge gehört. Hallström führt den Investigator nachts dorthin. Was dort ist: ein Mann im weißen Kittel, eine runde Brille, ein Besucherbuch.

**neu:** Ein Kellerraum im Landesarchiv Uppsala, dort, wo das Kirchenbuch von Solberg liegt. Hallström führt den Investigator nachts dorthin. Was dort ist: ein Mann im weißen Kittel, eine runde Brille, das Besucherbuch des Landesarchivs.

- ergänzen: Ein Kellerraum im Landesarchiv Uppsala, dort, wo das Kirchenbuch von Solberg liegt.
- streichen oder ersetzen: Ein Kellerraum unter einem Haus in Uppsala, das der Loge gehört.

### Zeile 1017, Nachspiel

**alt:** **Bis zum nächsten Einsatz:** 1960: Von den Einunddreißig leben noch 22. Die Lavigne, die sich Margot nennt, heiratet. 1961: Die Setzerin beginnt im Kinderzimmer. Hort-4 Oxford entsteht. Im September springen in Lima die ersten Shadow Paratroopers („Ich will Männer, die fallen können.“). Ekberg verlässt das Institut ohne Abschied. 1962: Nachtigall in Wien, Britt Holm fährt am 21. Dezember in den Harz und kommt nicht zurück. 1963: Berglund, Neuro-Helm Mk. I, Helmtag. 1964 bis 1966: Hort-5 Wien, Lehrhelm, Hort-6 Lagos. 1968: Lüttich, Adeyemi, Dorje stirbt. 1969: Einsatz 9, „Elster“.

**neu:** **Bis zum nächsten Einsatz:** 1960: Von den Einunddreißig leben noch 22. Die Lavigne, die sich Margot nennt, heiratet. 1961: Die Setzerin beginnt im Kinderzimmer. Hort-4 Oxford entsteht. Im September braucht ein Trupp bei Lima drei Tage zu Fuß zu einem Riss, der danach zu ist; Ashgrove schreibt: „Ich will Männer, die fallen können.“ Noch 1961 bildet der Zweig die ersten Shadow Paratroopers aus. Ekberg verlässt das Institut ohne Abschied. 1962: Nachtigall in Wien, Britt Holm fährt am 21. Dezember in den Harz und kommt nicht zurück. 1963: Berglund, Neuro-Helm Mk. I, Helmtag. 1964 bis 1966: Hort-5 Wien, Lehrhelm, Hort-6 Lagos. 1968: Lüttich, Adeyemi, Dorje stirbt. 1969: Einsatz 9, „Elster“.

- ergänzen: Im September braucht ein Trupp bei Lima drei Tage zu Fuß zu einem Riss, der danach zu ist; Ashgrove schreibt: "Ich will Männer, die fallen können." Noch 1961 bildet der Zweig die ersten Shadow Paratroopers aus.
- streichen oder ersetzen: Im September springen in Lima die ersten Shadow Paratroopers ("Ich will Männer, die fallen können.").

### Zeile 1033, 1954

**alt:** In Lissabon findet eine geschlossene Auktion statt. Kein Auktionshaus. Keine Kataloge. Ein Saal in einem Privathaus, drei Dolmetscher, zehn Bieter aus sechs Ländern. Angeboten werden drei Kristalle aus altem europäischem Privatbesitz. Das Kollegium hat die Gruppe gebeten, für es zu bieten. Die Beteiligten nennen die Veranstaltung nur „der Abend“.

**neu:** In Lissabon findet eine geschlossene Auktion statt. Kein Auktionshaus. Keine Kataloge. Ein Saal im Hinterhaus eines Antiquitätenhändlers, nach Einbruch der Dunkelheit, drei Bieter: zwei Privatsammler und ein Agent der Gruppe, der für das Kollegium bietet. Angeboten werden drei Kristalle aus Anatolien. Weil die Versteigerung erst nach Einbruch der Dunkelheit beginnt, nennt der Händler sie „den Abend“.

- ergänzen: Ein Saal im Hinterhaus eines Antiquitätenhändlers, nach Einbruch der Dunkelheit, drei Bieter: zwei Privatsammler und ein Agent der Gruppe, der für das Kollegium bietet.
- ergänzen: Angeboten werden drei Kristalle aus Anatolien.
- ergänzen: Weil die Versteigerung erst nach Einbruch der Dunkelheit beginnt, nennt der Händler sie "den Abend".
- streichen oder ersetzen: Ein Saal in einem Privathaus, drei Dolmetscher, zehn Bieter aus sechs Ländern.
- streichen oder ersetzen: Angeboten werden drei Kristalle aus altem europäischem Privatbesitz.
- streichen oder ersetzen: Das Kollegium hat die Gruppe gebeten, für es zu bieten.
- streichen oder ersetzen: Die Beteiligten nennen die Veranstaltung nur "der Abend".

### Zeile 1035, 1954

**alt:** Mögliche Szene: Ein Agent der Gruppe sitzt im Saal. Er trägt einen unauffälligen Anzug und eine Nummer aus Pappe. Die Kristalle liegen in Bleikästen auf einem Tisch aus Nussbaum. Der Auktionator spricht leise. Die Gebote steigen in kleinen Schritten. Bei einem Kristall bleibt der Raum still. Er ist milchig und klein. Zwei Bieter heben die Hand. Ob der Agent der Gruppe den Zuschlag bekommt, entscheidet der Tisch. Was er auf dem Weg zum Hafen erlebt und wem er den Koffer übergibt, erzählt der Spieler.

**neu:** Mögliche Szene: Ein Agent der Gruppe sitzt im Saal. Er trägt einen unauffälligen Anzug und eine Nummer aus Pappe. Die Kristalle liegen in Bleikästen auf einem Tisch aus Nussbaum. Der Auktionator spricht leise. Die Gebote steigen in kleinen Schritten. Bei einem Kristall bleibt der Raum still. Er ist milchig und klein. Zwei Bieter heben die Hand. Jeder der drei Bieter bekommt einen Stein; welchen der Agent ersteigert und was er dafür zahlt, entscheidet der Tisch. Was er auf dem Weg zum Hafen erlebt und wem er den Koffer übergibt, erzählt der Spieler.

- ergänzen: Jeder der drei Bieter bekommt einen Stein; welchen der Agent ersteigert und was er dafür zahlt, entscheidet der Tisch.
- streichen oder ersetzen: Ob der Agent der Gruppe den Zuschlag bekommt, entscheidet der Tisch.

### Zeile 1061, 1962

**alt:** Nachtigall liest in Wien hundertvierzig Gäste. Sie trägt ein schwarzes Kleid. Sie spricht nicht. Sie steht am Rand des Saals und hört. Danach schreibt sie vierzehn Seiten. Der Ermittlungszweig schickt die Gruppe. Ein Agent liest die Seiten. Sie enthalten Namen, Ängste, Lügen. Ein Name ist dreimal unterstrichen. Der Agent fragt nicht, wer ihn unterstrichen hat. Er legt die Seiten in einen grauen Umschlag. Der Umschlag geht an Hallström. Im Institut beginnt die Beryllium-Isolierung. Greta Sundqvist beendet nach zwölf Jahren ihre Arbeit an den Kreisen: kein Code, sondern eine Sprache.

**neu:** Nachtigall liest auf einem Botschaftsempfang in Wien hundertvierzig Gäste. Sie trägt ein schwarzes Kleid und sitzt als Pianistin am Flügel, zwischen Chopin und Schubert. Sie spricht nicht. Sie spielt und hört. Danach schreibt sie vierzehn Seiten. Der Ermittlungszweig schickt die Gruppe. Ein Agent liest die Seiten. Sie enthalten Namen, Ängste, Lügen. Ein Name ist dreimal unterstrichen. Der Agent fragt nicht, wer ihn unterstrichen hat. Er legt die Seiten in einen grauen Umschlag. Der Umschlag geht an Hallström. Im Institut beginnt die Beryllium-Isolierung. Greta Sundqvist beendet nach zwölf Jahren ihre Arbeit an den Kreisen: kein Code, sondern eine Sprache.

- ergänzen: Sie trägt ein schwarzes Kleid und sitzt als Pianistin am Flügel, zwischen Chopin und Schubert.
- ergänzen: Sie spielt und hört.
- streichen oder ersetzen: Sie trägt ein schwarzes Kleid.
- streichen oder ersetzen: Sie steht am Rand des Saals und hört.

### Zeile 1087, 1968

**alt:** Dorje stirbt. Er war einer der Gründer des Kollegiums. Er hat 1923 Kristalle im Himalaya gefunden. Er hat 1940 „rufen können“. Jetzt ist er tot. Die Kammer schweigt einen Tag. Dann lesen die Archivare die Kreise weiter. Das Kollegium trauert nicht. Es arbeitet. Das ist seine Trauer.

**neu:** Dorje stirbt. Er hatte den Kristall aus dem verlassenen Kloster im Himalaya nach London gebracht, an dem das Kollegium begann. Er hat 1940 „rufen können“. Jetzt ist er tot. Die Kammer schweigt einen Tag. Dann lesen die Archivare die Kreise weiter. Das Kollegium trauert nicht. Es arbeitet. Das ist seine Trauer.

- ergänzen: Er hatte den Kristall aus dem verlassenen Kloster im Himalaya nach London gebracht, an dem das Kollegium begann.
- streichen oder ersetzen: Er war einer der Gründer des Kollegiums.
- streichen oder ersetzen: Er hat 1923 Kristalle im Himalaya gefunden.

### Zeile 53, Was wirklich geschah

**alt:** **Der offene Faden:** Die Gruppe kann herausfinden, dass die Zahlen Antworten sind, nicht Fragen. Wer die Fünfergruppen mit den alten Mitschriften von 1961 vergleicht, sieht, dass sie sich ändern, wenn jemand an das Haus ohne Nummer schreibt. Das führt nach 1971, als die Sendung endet, und nach 2026, wenn die Grauen Akten Kessler und die Tür M7 Basel Elsters Code brauchen.

**neu:** **Der offene Faden:** Die Gruppe kann herausfinden, dass die Zahlen Antworten sind, nicht Fragen. Wer die Fünfergruppen mit den alten Mitschriften von 1961 vergleicht, sieht, dass sie sich ändern, wenn jemand an das Haus ohne Nummer schreibt. Das führt nach 1971, als die Sendung endet, und nach 2026, wenn Elster in der Grauen Akte Kessler und in der Tür, M7 Basel, wieder auftaucht.

- ergänzen: Das führt nach 1971, als die Sendung endet, und nach 2026, wenn Elster in der Grauen Akte Kessler und in der Tür, M7 Basel, wieder auftaucht.
- streichen oder ersetzen: Das führt nach 1971, als die Sendung endet, und nach 2026, wenn die Grauen Akten Kessler und die Tür M7 Basel Elsters Code brauchen.

### Zeile 128, Knoten 2: Elsters Wohnung in Charlottenburg

**alt:** - **Hinweis:** Ihre Wohnungstür ist mit Salz bestrichen, das sie nicht selbst dorthin getan hat. Probe: Okkultismus gegen Einfach (1), um zu erkennen: Jemand schützt sie, die Telefonistin, die die Zahlen an ihre eigene Tür schreibt. (führt zu K4, Schlussfolgerung 2)

**neu:** - **Hinweis:** Auf Elsters Türschwelle liegt Salz, das sie nicht gestreut hat. Probe: Okkultismus gegen Einfach (1). Elster sagt, ihre Kollegin, die Hörerin, war nachts hier, streute es und schrieb dieselben Zahlen an ihre eigene Tür, ohne sich zu erinnern. (führt zu K4, Schlussfolgerung 2)

- ergänzen: Hinweis: Auf Elsters Türschwelle liegt Salz, das sie nicht gestreut hat.
- ergänzen: Probe: Okkultismus gegen Einfach (1).
- ergänzen: Elster sagt, ihre Kollegin, die Hörerin, war nachts hier, streute es und schrieb dieselben Zahlen an ihre eigene Tür, ohne sich zu erinnern.
- streichen oder ersetzen: Hinweis: Ihre Wohnungstür ist mit Salz bestrichen, das sie nicht selbst dorthin getan hat.
- streichen oder ersetzen: Probe: Okkultismus gegen Einfach (1), um zu erkennen: Jemand schützt sie, die Telefonistin, die die Zahlen an ihre eigene Tür schreibt.

### Zeile 171, Knoten 6: Marshs Hotelzimmer am Zoo

**alt:** - **Hinweis:** Hallströms Mitschrift von 1961 liegt auf dem Tisch. Probe: Kryptografie gegen Machbar (2), um zu erkennen: Die Sendung antwortet, nicht fragt. (führt zum offenen Faden „Zahlenstation: Antworten, keine Fragen“)

**neu:** - **Hinweis:** Fragt die Gruppe Hallström nach 1961, legt er seine Mitschrift auf den Tisch. Probe: Kryptografie gegen Machbar (2), um zu erkennen: Die Sendung antwortet, nicht fragt. (führt zum offenen Faden „Zahlenstation: Antworten, keine Fragen“)

- ergänzen: Hinweis: Fragt die Gruppe Hallström nach 1961, legt er seine Mitschrift auf den Tisch.
- streichen oder ersetzen: Hinweis: Hallströms Mitschrift von 1961 liegt auf dem Tisch.

### Zeile 265, Nachspiel

**alt:** Die Zahlen sind Antworten. Wer an das Haus ohne Nummer schreibt, bekommt eine Sendung. Das führt nach Einsatz 10, wenn die letzte Sendung läuft, und nach 2026, wenn die Graue Akte Kessler und die Tür M7 Basel Elsters Code brauchen.

**neu:** Die Zahlen sind Antworten. Wer an das Haus ohne Nummer schreibt, bekommt eine Sendung. Das führt nach Einsatz 10, wenn die letzte Sendung läuft, und nach 2026, wenn Elster in der Grauen Akte Kessler und in der Tür, M7 Basel, wieder auftaucht.

- ergänzen: Das führt nach Einsatz 10, wenn die letzte Sendung läuft, und nach 2026, wenn Elster in der Grauen Akte Kessler und in der Tür, M7 Basel, wieder auftaucht.
- streichen oder ersetzen: Das führt nach Einsatz 10, wenn die letzte Sendung läuft, und nach 2026, wenn die Graue Akte Kessler und die Tür M7 Basel Elsters Code brauchen.

### Zeile 303, Was wirklich geschah

**alt:** Im September 1971 schreibt Uhrwerk, eine Präkognitive mit Neuro-Helm Mk. II in Wien, eine Warnung auf eine Karteikarte. Sie schickt sie an den Kern. Kantor liest sie und legt sie beiseite. Er hält Uhrwerk für eine Frau, die nie im Kreis saß und deshalb nicht versteht, was der Kreis bedeutet.

**neu:** Im September 1971 schreibt Uhrwerk, eine Präkognitive mit Neuro-Helm Mk. I in Wien, eine Warnung auf eine Karteikarte. Sie schickt sie an den Kern. Kantor liest sie und legt sie beiseite. Er hält Uhrwerk für eine Frau, die nie im Kreis saß und deshalb nicht versteht, was der Kreis bedeutet.

- ergänzen: I in Wien, eine Warnung auf eine Karteikarte.
- streichen oder ersetzen: II in Wien, eine Warnung auf eine Karteikarte.

### Zeile 313, Was wirklich geschah

**alt:** **Der offene Faden:** Die Zahlenstation verstummt am 14. Oktober 1971 um 3 Uhr. Die letzte Mitschrift ist ein Dokument, das die Gruppe in den Händen halten kann. Die Röhre eines Kurzwellensenders wird am 20. Oktober in einem ausgebrannten Bauernhaus in Schweden gefunden. Das Haus steht, die Nummer fehlt. Dieser Faden führt zu den späteren Einsätzen und nach 2026 zu „Die Tür“ und „Graue Akten“.

**neu:** **Der offene Faden:** Die Zahlenstation verstummt am 14. Oktober 1971 um 3 Uhr. Die letzte Mitschrift ist ein Dokument, das die Gruppe in den Händen halten kann. Die Röhre eines Kurzwellensenders wird im Oktober in einem ausgebrannten Bauernhaus in Schweden gefunden. Am 20. Oktober geht Hallström in Vasastan an dem Haus vorbei, an das Kantor geschrieben hat: Das Haus steht, die Nummer fehlt. Dieser Faden führt zu den späteren Einsätzen und nach 2026 zu „Die Tür“ und „Graue Akten“.

- ergänzen: Die Röhre eines Kurzwellensenders wird im Oktober in einem ausgebrannten Bauernhaus in Schweden gefunden.
- ergänzen: Am 20.
- ergänzen: Oktober geht Hallström in Vasastan an dem Haus vorbei, an das Kantor geschrieben hat: Das Haus steht, die Nummer fehlt.
- streichen oder ersetzen: Die Röhre eines Kurzwellensenders wird am 20.
- streichen oder ersetzen: Oktober in einem ausgebrannten Bauernhaus in Schweden gefunden.
- streichen oder ersetzen: Das Haus steht, die Nummer fehlt.

### Zeile 349, Uhrwerk, 41

**alt:** Ottilie Brandauer, geboren 1930. Sie lebt in Wien und ist eine Präkognitive des Chors mit Neuro-Helm Mk. II. Sie hat die Warnung geschrieben, weil sie eine Vorahnung hatte: drei Tote, sieben Ausgebrannte, einen Satz. Sie will die Kaskade verhindern, aber sie hat keine Beweise. Sie verschweigt, dass sie seit der Vorahnung kaum schläft. Sie redet präzise, wie jemand, der gewohnt ist, Datum und Uhrzeit zu notieren. Sprache der Zeit: „Die Stimme lügt nicht. Sie wiederholt nur, was sie hört.“

**neu:** Ottilie Brandauer, geboren 1930. Sie lebt in Wien und ist eine Präkognitive des Chors mit Neuro-Helm Mk. I. Sie hat die Warnung geschrieben, weil sie eine Vorahnung hatte: drei Tote, sieben Ausgebrannte, einen Satz. Sie will die Kaskade verhindern, aber sie hat keine Beweise. Sie verschweigt, dass sie seit der Vorahnung kaum schläft. Sie redet präzise, wie jemand, der gewohnt ist, Datum und Uhrzeit zu notieren. Sprache der Zeit: „Die Stimme lügt nicht. Sie wiederholt nur, was sie hört.“

- streichen oder ersetzen: II.

### Zeile 400, Knoten 2: Stockholm, Ermittlungszweig, Hallströms Büro

**alt:** - **Hinweis:** Hallström zeigt der Gruppe die Mitschriften der Sommersendungen und erklärt, wie die Zahlen Koordinaten sind. Die letzte Sendung vom 14. Oktober lässt er der Gruppe durch einen Kurier nach Wales bringen. (führt zu: Schlussfolgerung 2)

**neu:** - **Hinweis:** Hallström zeigt der Gruppe die Mitschriften der Sommersendungen und erklärt, wie die Zahlen Koordinaten sind. Die letzte Sendung vom 14. Oktober lässt er der Gruppe durch einen Kurier nach Wales bringen. Der Agent, der 1961 die erste Sendung mitschrieb (Handout N27), erkennt die letzte als Erster, ohne Probe: Er legt N27 neben N33 und sieht, dass die Stimme verstummt, wo sie damals begann. (führt zu: Schlussfolgerung 2)

- ergänzen: Der Agent, der 1961 die erste Sendung mitschrieb (Handout N27), erkennt die letzte als Erster, ohne Probe: Er legt N27 neben N33 und sieht, dass die Stimme verstummt, wo sie damals begann.

### Zeile 407, Knoten 3: Wien, Uhrwerks Wohnung

**alt:** Eine kleine Wohnung in der Nähe des Westbahnhofs. Überall liegen Karteikarten, mit Bleistift beschrieben, jede mit Datum und Uhrzeit. Uhrwerk sitzt an einem Tisch, den Mk. II neben sich, und schreibt ihre Vorahnungen auf.

**neu:** Eine kleine Wohnung in der Nähe des Westbahnhofs. Überall liegen Karteikarten, mit Bleistift beschrieben, jede mit Datum und Uhrzeit. Uhrwerk sitzt an einem Tisch, den Mk. I neben sich, und schreibt ihre Vorahnungen auf.

- ergänzen: I neben sich, und schreibt ihre Vorahnungen auf.
- streichen oder ersetzen: II neben sich, und schreibt ihre Vorahnungen auf.

### Zeile 501, Psion des Kreises

**alt:** Für Kantor, Rees, Ashgrove, Pryce, Hallström und Uhrwerk gilt: Sie sind in diesem Einsatz keine Kämpfer. Kantor ist bewusstlos. Rees trägt, Ashgrove sichert, Pryce wartet in der Werkstatt. Sie brauchen keine Werte. Uhrwerk ist eine Präkognitive mit Mk. II und bleibt in Wien.

**neu:** Für Kantor, Rees, Ashgrove, Pryce, Hallström und Uhrwerk gilt: Sie sind in diesem Einsatz keine Kämpfer. Kantor ist bewusstlos. Rees trägt, Ashgrove sichert, Pryce wartet in der Werkstatt. Sie brauchen keine Werte. Uhrwerk ist eine Präkognitive mit Mk. I und bleibt in Wien.

- ergänzen: I und bleibt in Wien.
- streichen oder ersetzen: II und bleibt in Wien.

### Zeile 509, Nachspiel

**alt:** **Erfahrung:** Rote Akte: 5 EP, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, plus 1 EP für jeden aufgenommenen Faden. Mögliche Fäden: die Tonbänder, Uhrwerks Warnung, die einundvierzigste Stimme, die Frage nach Märta, die letzte Mitschrift der Zahlenstation.

**neu:** **Erfahrung:** Rote Akte, die schwarz wird: 7 EP wie eine Schwarze Akte, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, plus 1 EP für jeden aufgenommenen Faden. Mögliche Fäden: die Tonbänder, Uhrwerks Warnung, die einundvierzigste Stimme, die Frage nach Märta, die letzte Mitschrift der Zahlenstation.

- ergänzen: Erfahrung: Rote Akte, die schwarz wird: 7 EP wie eine Schwarze Akte, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, plus 1 EP für jeden aufgenommenen Faden.

### Zeile 649, Knoten 3: Der alte Weinkeller in Wien

**alt:** Ein Keller unter dem Nachbarhaus von Hort-5. Feucht, dunkel, Stimmen von irgendwo. Die Wände sind mit Salz bestrichen. Keine Betten, keine Kinder. Nur Stimmen, die im Schlaf singen.

**neu:** Ein alter Weinkeller zwei Häuser weiter, nicht der Botschaftskeller von Hort-5. Feucht, dunkel, Stimmen von irgendwo. Die Wände sind mit Salz bestrichen. Keine Betten, keine Kinder. Nur Stimmen, die im Schlaf singen.

- ergänzen: Ein alter Weinkeller zwei Häuser weiter, nicht der Botschaftskeller von Hort-5.
- streichen oder ersetzen: Ein Keller unter dem Nachbarhaus von Hort-5.

### Zeile 671, Zwischenspiel: Dezember 1974 bis Februar 1976

**alt:** Zwischen Teil A und Teil B liegt ein Zwischenjahr. Es verbindet die beiden Teile, einen Hinweis auf das Kloster gibt es darin nicht. Jeder Spieler erzählt eine Sache, die sein Agent in dieser Zeit tat; die Spielleitung erzählt die festen Ereignisse. Danach Alterung und Übergaben nach Kapitel 2.

**neu:** Zwischen Teil A und Teil B liegt ein Zwischenjahr. Es verbindet die beiden Teile, einen Hinweis auf das Kloster gibt es darin nicht. Jeder Spieler erzählt eine Sache, die sein Agent in dieser Zeit tat; die Spielleitung erzählt die festen Ereignisse. Danach Übergaben nach Kapitel 2. Die Alterung gilt erst zu Beginn von Abschnitt IV.

- ergänzen: Die Alterung gilt erst zu Beginn von Abschnitt IV.

### Zeile 732, Ablauf

**alt:** 4. Mercier gibt das Zeichen. Die Geräte schalten sich ein. Ein tiefer Ton, der nicht laut ist, aber alle im Raum spüren. Die Offenen fallen in Ohnmacht, einer nach dem anderen, ohne Schuss, ohne Gegenwehr. Der Fünfzehnjährige sieht Mercier an, bevor er umfällt. Ein Spielerpsion mit Mk. II wird von der Überlagerung mit getroffen: Er würfelt WK + Geistige Widerstandskraft gegen Schwer (3), sonst verliert er eine Runde das Bewusstsein.

**neu:** 4. Mercier gibt das Zeichen. Die Geräte schalten sich ein. Ein tiefer Ton, der nicht laut ist, aber alle im Raum spüren. Die Offenen fallen in Ohnmacht, einer nach dem anderen, ohne Schuss, ohne Gegenwehr. Der Fünfzehnjährige sieht Mercier an, bevor er umfällt. Ein Spielerpsion mit Mk. II wird von der Überlagerung mit getroffen: Vorgewarnt würfelt er drei Runden lang alle Psi-Proben mit −1 Würfel.

- ergänzen: II wird von der Überlagerung mit getroffen: Vorgewarnt würfelt er drei Runden lang alle Psi-Proben mit −1 Würfel.
- streichen oder ersetzen: II wird von der Überlagerung mit getroffen: Er würfelt WK + Geistige Widerstandskraft gegen Schwer (3), sonst verliert er eine Runde das Bewusstsein.

### Zeile 9, Der Stützpunkt

**alt:** Wenn die Gruppe am 7. Februar ankommt, sieht sie zuerst den Dienstplan. 41 Namen, mit Bleistift, in ordentlichen Spalten. Die Spalte für den 14. Februar ist noch leer. Die Spielleitung zeigt das Handout N42; die Radierspuren gibt es erst ab Samstag, die Haken erst beim Appell am 14. Februar. Die Agenten sehen die Kantine mit der Wanduhr und dem Küchenradio auf der Durchreiche. Sie sehen die Werkstatt, in der Gunnar einen Generator repariert, der nicht fertig wird. Sie sehen die Krankenstation mit dem Zettel: Aspirin wird knapp. Sie sehen die Stahltür im Keller mit zwei Schlüsseln. Hat der Scientist der Gruppe im Januar die Sonde aufgestellt, sehen sie die Sonde am Treppenabgang. Sie sehen 212 Bleikästchen. Sie hören das Flüstern. Mehr nicht.

**neu:** Wenn die Gruppe am 7. Februar ankommt, sieht sie zuerst den Dienstplan. 41 Namen, mit Bleistift, in ordentlichen Spalten. Die Spalte für den 14. Februar ist noch leer. Die Spielleitung zeigt das Handout N42; die Radierspuren gibt es erst ab Samstag, die Haken erst beim Appell am 14. Februar. Die Agenten sehen die Kantine mit der Wanduhr und dem Küchenradio auf der Durchreiche. Sie sehen die Werkstatt, in der Gunnar einen Generator repariert, der nicht fertig wird. Sie sehen die Krankenstation mit dem Zettel: Aspirin wird knapp. Sie sehen die Stahltür im Keller mit zwei Schlüsseln. Sie sehen die Sonde am Treppenabgang, die das Institut seit Dezember betreibt. Sie sehen 212 Bleikästchen. Sie hören das Flüstern. Mehr nicht.

- ergänzen: Sie sehen die Sonde am Treppenabgang, die das Institut seit Dezember betreibt.
- streichen oder ersetzen: Hat der Scientist der Gruppe im Januar die Sonde aufgestellt, sehen sie die Sonde am Treppenabgang.

### Zeile 84, Was wirklich geschah

**alt:** - **Ob der Scientist der Gruppe im Januar die Nordlicht-Sonde aufstellt.** Folge: Rask oder ein Scientist-Spieler darf die Sonde im Januar testen. Wer sie aufstellt, schreibt den Messstreifen vom 14. Februar mit. Wer sie nicht aufstellt, kommt zu spät und sieht nur den Ausdruck. - **Was die Gruppe Gunnar über seinen Vater sagt.** Folge: Gunnar trägt es in die Nacht. Haugen kennt später zwei Namen: Rønning und Gunnar. Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, ersetzt er einen der beiden.

**neu:** - **Ob der Scientist der Gruppe im Januar an der Nordlicht-Sonde mitarbeitet.** Folge: Rask oder ein Scientist-Spieler darf die Sonde im Januar testen. Wer mitgearbeitet hat und bleibt, steht am 14. Februar an der Sonde. Wer fährt, sieht später nur den Ausdruck. - **Was die Gruppe Gunnar über seinen Vater sagt.** Folge: Gunnar trägt es in die Nacht. Haugen kennt später zwei Namen: Rønning und Gunnar. Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, ersetzt er Rønning.

- ergänzen: Wer mitgearbeitet hat und bleibt, steht am 14.
- ergänzen: Februar an der Sonde.
- ergänzen: Wer fährt, sieht später nur den Ausdruck.
- streichen oder ersetzen: Wer sie aufstellt, schreibt den Messstreifen vom 14.
- streichen oder ersetzen: Februar mit.
- streichen oder ersetzen: Wer sie nicht aufstellt, kommt zu spät und sieht nur den Ausdruck.

### Zeile 155, Knoten 3: Stockholm

**alt:** 

**neu:** - **Hinweis:** Haugen lässt neben den 26 Kisten weitere, gleich schwere Kisten verladen. (führt zur Konfrontation)

- ergänzen: Hinweis: Haugen lässt neben den 26 Kisten weitere, gleich schwere Kisten verladen.
- ergänzen: (führt zur Konfrontation)

### Zeile 159, Knoten 4: Der Nachtzug auf der Erzbahn

**alt:** #### Knoten 4: Der Nachtzug auf der Ofotbanen

**neu:** #### Knoten 4: Der Nachtzug auf der Erzbahn

- ergänzen: #### Knoten 4: Der Nachtzug auf der Erzbahn
- streichen oder ersetzen: #### Knoten 4: Der Nachtzug auf der Ofotbanen

### Zeile 203, Eskalation

**alt:** Wenn ein Agent in Kiruna aussteigt und den Stimmen folgt, verpasst er den Zug. Die Ofotbanen wartet nicht. Eine Straße von Kiruna nach Narvik gibt es nicht. Er nimmt den nächsten Zug oder einen Erzzug, um in Narvik wieder zur Gruppe zu stoßen. Die Stimmen wollen ihn nicht aufhalten. Sie rufen ihn an. Wer bleibt, hört länger, als er wollte.

**neu:** Wenn ein Agent in Kiruna aussteigt und den Stimmen folgt, verpasst er den Zug. Die Erzbahn wartet nicht. Eine Straße von Kiruna nach Narvik gibt es nicht. Er nimmt den nächsten Zug oder einen Erzzug, um in Narvik wieder zur Gruppe zu stoßen. Die Stimmen wollen ihn nicht aufhalten. Sie rufen ihn an. Wer bleibt, hört länger, als er wollte.

- ergänzen: Die Erzbahn wartet nicht.
- streichen oder ersetzen: Die Ofotbanen wartet nicht.

### Zeile 221, Der Schauplatz

**alt:** Die Strecke zeigt die Karte der Ofotbanen (Karte K10).

**neu:** Die Strecke zeigt Karte K10.

- ergänzen: Die Strecke zeigt Karte K10.
- streichen oder ersetzen: Die Strecke zeigt die Karte der Ofotbanen (Karte K10).

### Zeile 236, Lösungen

**alt:** **Ohne Kampf:** Die Gruppe lässt die Jäger die Kisten nehmen und verfolgt sie. Die Kisten sind nicht die echten. Ashgrove hat in Stockholm Scheinkisten mit Sand und Gewichten verladen lassen, die auf den Frachtpapieren stehen. Die echten Kisten stehen in einem zweiten Wagen, der in Kiruna umgeladen wurde. Die Gruppe fährt weiter nach Narvik und holt die echten Kisten aus dem Lagerhaus. Haugen lernt, dass Rückzug kein Verlust ist. Der Preis: Die Abteilung weiß jetzt, dass O.D.I.N. sie erwartet hat. Der nächste Versuch wird leiser.

**neu:** **Ohne Kampf:** Die Gruppe lässt die Jäger die Kisten nehmen und verfolgt sie. Die Kisten sind nicht die echten. Auf Ashgroves Anweisung hat Haugen in Stockholm Scheinkisten mit Sand und Gewichten in den Güterwagen stellen lassen; sie stehen so auf den Frachtpapieren. Die echten Kisten laufen in einem zweiten Güterwagen, den Haugen in Kiruna abhängen ließ und der mit dem nächsten Erzzug nach Narvik kommt. Die Gruppe fährt weiter und holt die echten Kisten am nächsten Tag aus dem Lagerhaus. Greift Abteilung 13 schon vor Kiruna an, entfällt diese Lösung. Haugen lernt, dass Rückzug kein Verlust ist. Der Preis: Die Abteilung weiß jetzt, dass O.D.I.N. sie erwartet hat. Der nächste Versuch wird leiser.

- ergänzen: Die echten Kisten laufen in einem zweiten Güterwagen, den Haugen in Kiruna abhängen ließ und der mit dem nächsten Erzzug nach Narvik kommt.
- ergänzen: Greift Abteilung 13 schon vor Kiruna an, entfällt diese Lösung.
- streichen oder ersetzen: Die echten Kisten stehen in einem zweiten Wagen, der in Kiruna umgeladen wurde.

### Zeile 295, Nachspiel

**alt:** **Übergabe:** Ein Soldier-Schützling, der in Einsatz 12 dabei war, übernimmt die Armschiene Nr. 114, wenn sein Mentor abtritt. Ein Thaumaturg-Schützling, der das Kristallbuch geführt hat, trägt in Nordlicht die Eingänge mit ein und kennt danach jede Position bis 212.

**neu:** **Übergabe:** Haugen behält die Armschiene Nr. 114; sie geht erst 1990 weiter. Ein Soldier-Schützling, der in Einsatz 12 dabei war, kennt danach Haugen und die Strecke. Ein Thaumaturg-Schützling, der das Kristallbuch geführt hat, trägt in Nordlicht die Eingänge mit ein und kennt danach jede Position bis 212.

- ergänzen: Übergabe: Haugen behält die Armschiene Nr. 114; sie geht erst 1990 weiter.
- ergänzen: Ein Soldier-Schützling, der in Einsatz 12 dabei war, kennt danach Haugen und die Strecke.
- streichen oder ersetzen: Übergabe: Ein Soldier-Schützling, der in Einsatz 12 dabei war, übernimmt die Armschiene Nr. 114, wenn sein Mentor abtritt.

### Zeile 305, Nachspiel

**alt:** Karte: K10, die Ofotbanen von Stockholm über Kiruna nach Narvik.

**neu:** Karte: K10, der Nachtzug von Stockholm über Kiruna nach Narvik.

- ergänzen: Karte: K10, der Nachtzug von Stockholm über Kiruna nach Narvik.
- streichen oder ersetzen: Karte: K10, die Ofotbanen von Stockholm über Kiruna nach Narvik.

### Zeile 428, Knoten 2: Kantine mit Küche und Durchreiche

**alt:** Proben: Ritualismus, Telepathie, Menschenkenntnis, Wahrnehmung. Klassen: Thaumaturg, Psion, Agent, Scientist.

**neu:** Proben: Ritualismus, Telepathie, Menschenkenntnis, Wahrnehmung, Überzeugen. Klassen: Thaumaturg, Psion, Agent, Scientist.

- ergänzen: Proben: Ritualismus, Telepathie, Menschenkenntnis, Wahrnehmung, Überzeugen.
- streichen oder ersetzen: Proben: Ritualismus, Telepathie, Menschenkenntnis, Wahrnehmung.

### Zeile 468, Knoten 6: Krankenstation und Post

**alt:** - **Hinweis:** Der Brief der Frau des Funkers aus Tromsø: Sie fragt, wann er nach Hause kommt. Sie kennt nur die Wetterstation einer Firma mit Briefkasten in Oslo. (führt zu: die 41) Ein Agent liest ihn mit Fingerfertigkeit gegen Einfach (1). - **Hinweis:** Ingrids Zeichnung „Ingrid, 3 Jahre. Für Papa.“ liegt auf dem Tisch. (führt zu: Gunnar Solheim) Ein Soldier sieht sie mit Wahrnehmung gegen Einfach (1).

**neu:** - **Hinweis:** Der Brief der Frau des Funkers aus Tromsø: Sie fragt, wann er nach Hause kommt. Sie kennt nur die Wetterstation einer Firma mit Briefkasten in Oslo. (Handout N43, führt zu: die 41) Ein Agent liest ihn mit Fingerfertigkeit gegen Einfach (1). - **Hinweis:** Ingrids Zeichnung „Ingrid, 3 Jahre. Für Papa.“ liegt auf dem Tisch. (Handout N44, führt zu: Gunnar Solheim) Ein Soldier sieht sie mit Wahrnehmung gegen Einfach (1).

- ergänzen: (Handout N43, führt zu: die 41) Ein Agent liest ihn mit Fingerfertigkeit gegen Einfach (1).
- ergänzen: (Handout N44, führt zu: Gunnar Solheim) Ein Soldier sieht sie mit Wahrnehmung gegen Einfach (1).
- streichen oder ersetzen: (führt zu: die 41) Ein Agent liest ihn mit Fingerfertigkeit gegen Einfach (1).
- streichen oder ersetzen: (führt zu: Gunnar Solheim) Ein Soldier sieht sie mit Wahrnehmung gegen Einfach (1).

### Zeile 486, Eskalation

**alt:** - **Donnerstag, 10. Februar:** Die Schulklasse im Tal. Ein Junge fragt nach dem Lied, das er nachts gehört hat. Wenn die Gruppe nicht da ist, hört sie am Freitag davon. Grauen-Probe: Verstörend (2), wenn sie erkennt, dass das Lied nicht von hier ist.

**neu:** - **Donnerstag, 10. Februar:** Eine deutsche Schulklasse bezieht die Hütte im Tal. Ein Junge fragt nach der Station mit den Antennen. Wenn die Gruppe nicht da ist, hört sie am Freitag davon.

- ergänzen: Februar: Eine deutsche Schulklasse bezieht die Hütte im Tal.
- ergänzen: Ein Junge fragt nach der Station mit den Antennen.
- streichen oder ersetzen: Februar: Die Schulklasse im Tal.
- streichen oder ersetzen: Ein Junge fragt nach dem Lied, das er nachts gehört hat.
- streichen oder ersetzen: Grauen-Probe: Verstörend (2), wenn sie erkennt, dass das Lied nicht von hier ist.

### Zeile 495, Der Schauplatz

**alt:** Die Kantine von Nordlicht, Montag, 14. Februar 1977, 21:45 bis 22:10 Uhr. Der lange Tisch, die elf Thaumaturgen, der Kreidekreis auf der Platte, elf Tassen Kaffee. Das Küchenradio spielt Schlager. Die Wanduhr über der Tür. Für alle, die fahren: der Nachtzug von Stockholm nach Narvik, hinter Kiruna, um 22:10 Uhr. (Karte K12)

**neu:** Die Kantine von Nordlicht, Montag, 14. Februar 1977, 21:45 bis 22:10 Uhr. Der lange Tisch, die elf Thaumaturgen, der Kreidekreis auf der Platte, elf Tassen Kaffee. Das Küchenradio spielt Schlager. Die Wanduhr über der Tür (Karte K12). Für alle, die fahren: der Nachtzug von Stockholm nach Narvik, hinter Kiruna, um 22:10 Uhr.

- ergänzen: Die Wanduhr über der Tür (Karte K12).
- streichen oder ersetzen: Die Wanduhr über der Tür.
- streichen oder ersetzen: (Karte K12)

### Zeile 518, Kjell Haugen

**alt:** [entry - | Kjell Haugen | Profi · Menschen]

**neu:** [entry - | Kjell Haugen | Elite · Menschen]

- ergänzen: [entry - Kjell Haugen Elite · Menschen]
- streichen oder ersetzen: [entry - Kjell Haugen Profi · Menschen]

### Zeile 523, Kjell Haugen

**alt:** **Verteidigung / Rüstung / LP** | 3 / 2 / 15 **Grauen** | Verstörend (2), wenn er den Chor im Radio hört

**neu:** **Verteidigung / Rüstung / LP** | 3 / 2 / 14 **Grauen** | Keines. Hört er den Chor im Radio, legt er selbst eine Grauen-Probe gegen Verstörend (2) ab

- ergänzen: Verteidigung / Rüstung / LP 3 / 2 / 14 Grauen Keines.

### Zeile 536, Nachspiel

**alt:** **Was O.D.I.N. bekommt:** Haugens Bericht SA-1977-02. Die Wanduhr aus der Kantine, stehen geblieben um 22:10 Uhr. Das Küchenradio, das am Morgen einen Chor spielt. Die 212 grauen Kristalle. Die Sonde, die 41 Menschen drüben misst. Die elf Akten des Nachtarbeiters. Die Schwarze Akte Nordlicht.

**neu:** **Was O.D.I.N. bekommt:** Haugens Bericht SA-1977-02. Die Wanduhr aus der Kantine, stehen geblieben um 22:10 Uhr. Das Küchenradio, das am Morgen einen Chor spielt. Die 212 grauen Kristalle. Die Sonde, die 41 Menschen drüben misst. Die Personalakten der elf Thaumaturgen (2014 die elf Akten des Nachtarbeiters). Die Schwarze Akte Nordlicht.

- ergänzen: Die Personalakten der elf Thaumaturgen (2014 die elf Akten des Nachtarbeiters).
- streichen oder ersetzen: Die elf Akten des Nachtarbeiters.

### Zeile 63, Der Dienstplan

**alt:** **Wie ein Spieleragent auf den Plan kommt.** Am Samstag, 12. Februar, entscheidet jeder Spieler einzeln, ob sein Agent bleibt oder fährt. Wer bleibt, übernimmt einen Tauschplatz passender Funktion: T1 Verbindung, T2 Thaumaturg, T3 Archivgehilfin, T4 Physiker, T5 Funkerin, T6 Wache, T7 Horcherin. Ein Spielerthaumaturg auf T2 gehört zu den elf und liest mit. Wer bleiben, aber nicht lesen will, nimmt T3. Stehen mehr Spieleragenten derselben Funktion bereit als Tauschplätze, ersetzen sie weitere Namen passender Funktion. Die Zahl 41 bricht nicht.

**neu:** **Wie ein Spieleragent auf den Plan kommt.** Am Samstag, 12. Februar, entscheidet jeder Spieler einzeln, ob sein Agent bleibt oder fährt. Wer bleibt, übernimmt einen Tauschplatz passender Funktion: T1 Verbindung, T2 Thaumaturg, T3 Archivgehilfin, T4 Physiker, T5 Funkerin, T6 Wache, T7 Horcherin. Ein Spielerthaumaturg auf T2 gehört zu den elf und liest mit. Wer bleiben, aber nicht lesen will, nimmt T3. Stehen mehr Spieleragenten derselben Funktion bereit als Tauschplätze, ersetzen sie weitere Namen passender Funktion, nie aber Einar Vatne und Arne Kvalvik. Die Zahl 41 bricht nicht.

- ergänzen: Stehen mehr Spieleragenten derselben Funktion bereit als Tauschplätze, ersetzen sie weitere Namen passender Funktion, nie aber Einar Vatne und Arne Kvalvik.
- streichen oder ersetzen: Stehen mehr Spieleragenten derselben Funktion bereit als Tauschplätze, ersetzen sie weitere Namen passender Funktion.

### Zeile 194, 22:10 Uhr, hinter Kiruna

**alt:** Ingrid schläft. Sie wacht nicht auf.

**neu:** Ingrid schläft weiter. Sie merkt nichts.

- ergänzen: Ingrid schläft weiter.
- ergänzen: Sie merkt nichts.
- streichen oder ersetzen: Ingrid schläft.
- streichen oder ersetzen: Sie wacht nicht auf.

### Zeile 226, Im Stützpunkt

**alt:** Haugen zählt seine Rücken zweimal. Im Büro des Stationsleiters liest er den Dienstplan, die 41 Namen, einen nach dem anderen, jeden mit Haken. Zwei kennt er: Magnus Rønning aus dem Lager Ashgrove und Gunnar Solheim aus Narvik, Dezember 1976. Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, steht dessen Name an der Stelle eines der beiden.

**neu:** Haugen zählt seine Rücken zweimal. Im Büro des Stationsleiters liest er den Dienstplan, die 41 Namen, einen nach dem anderen, jeden mit Haken. Zwei kennt er: Magnus Rønning aus dem Lager Ashgrove und Gunnar Solheim aus Narvik, Dezember 1976. Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, steht dessen Name an der Stelle Rønnings.

- ergänzen: Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, steht dessen Name an der Stelle Rønnings.
- streichen oder ersetzen: Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, steht dessen Name an der Stelle eines der beiden.

### Zeile 17, Hallström, 16. Februar 1977

**alt:** Wer als Spieleragent in der Registratur arbeitet, kann in dieser Szene anwesend sein. Hallström erklärt nichts. Wer fragt, bekommt die Antwort: „Schreiben Sie auf, was Sie gesehen haben. In Ihren eigenen Worten. Nicht für die Akte.“ Das ist die einzige Probe der Szene: keine Fertigkeit, nur die Entscheidung, was der Agent aufschreibt und was nicht.

**neu:** Wer als Spieleragent in der Registratur arbeitet und zu spät kam, erlebt die Szene nach der Rückkehr aus dem Norden: Hallström hat die Seite noch aufgeschlagen, als der Agent sein Büro betritt. Hallström erklärt nichts. Wer fragt, bekommt die Antwort: „Schreiben Sie auf, was Sie gesehen haben. In Ihren eigenen Worten. Nicht für die Akte.“ Das ist die einzige Probe der Szene: keine Fertigkeit, nur die Entscheidung, was der Agent aufschreibt und was nicht.

- ergänzen: Wer als Spieleragent in der Registratur arbeitet und zu spät kam, erlebt die Szene nach der Rückkehr aus dem Norden: Hallström hat die Seite noch aufgeschlagen, als der Agent sein Büro betritt.
- streichen oder ersetzen: Wer als Spieleragent in der Registratur arbeitet, kann in dieser Szene anwesend sein.

### Zeile 51, Harald Ness, „Salz“

**alt:** **Fertigkeiten 1947:** Schusswaffen 4, Ausdauer 4, Taktik 3, Überleben 3, Athletik 2, Nahkampf 2, Wahrnehmung 2, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 2, Fahren 1, Handwerk 1, Heimlichkeit 1, Medizin 1.

**neu:** **Fertigkeiten 1947:** Schusswaffen 5, Ausdauer 4, Taktik 3, Überleben 3, Athletik 2, Nahkampf 3, Wahrnehmung 3, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 2, Heimlichkeit 2, Medizin 2, Fahren 1, Handwerk 1.

- ergänzen: Fertigkeiten 1947: Schusswaffen 5, Ausdauer 4, Taktik 3, Überleben 3, Athletik 2, Nahkampf 3, Wahrnehmung 3, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 2, Heimlichkeit 2, Medizin 2, Fahren 1, Handwerk 1.
- streichen oder ersetzen: Fertigkeiten 1947: Schusswaffen 4, Ausdauer 4, Taktik 3, Überleben 3, Athletik 2, Nahkampf 2, Wahrnehmung 2, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 2, Fahren 1, Handwerk 1, Heimlichkeit 1, Medizin 1.

### Zeile 53, Harald Ness, „Salz“

**alt:** **Fertigkeiten 1977:** Schusswaffen 5, Taktik 5, Ausdauer 4, Überleben 4, Wahrnehmung 3, Geistige Widerstandskraft 3, Ausweichen 3, Zähigkeit 2, Athletik 2, Nahkampf 2, Führung 4, Fahren 1, Handwerk 1, Heimlichkeit 1, Medizin 1.

**neu:** **Fertigkeiten 1977:** Schusswaffen 6, Taktik 5, Ausdauer 4, Überleben 4, Wahrnehmung 4, Führung 4, Geistige Widerstandskraft 3, Ausweichen 3, Nahkampf 3, Zähigkeit 2, Athletik 2, Heimlichkeit 2, Medizin 2, Fahren 1, Handwerk 1.

- ergänzen: Fertigkeiten 1977: Schusswaffen 6, Taktik 5, Ausdauer 4, Überleben 4, Wahrnehmung 4, Führung 4, Geistige Widerstandskraft 3, Ausweichen 3, Nahkampf 3, Zähigkeit 2, Athletik 2, Heimlichkeit 2, Medizin 2, Fahren 1, Handwerk 1.
- streichen oder ersetzen: Fertigkeiten 1977: Schusswaffen 5, Taktik 5, Ausdauer 4, Überleben 4, Wahrnehmung 3, Geistige Widerstandskraft 3, Ausweichen 3, Zähigkeit 2, Athletik 2, Nahkampf 2, Führung 4, Fahren 1, Handwerk 1, Heimlichkeit 1, Medizin 1.

### Zeile 88, Colette Marchais, „Garn“

**alt:** **Fertigkeiten 1947:** Täuschung 4, Verkleidung 3, Etikette 3, Heimlichkeit 3, Wahrnehmung 2, Schusswaffen 2, Überzeugen 2, Ausweichen 1, Geistige Widerstandskraft 1, Menschenkenntnis 2, Fahren 1, Kryptografie 1, Auftreten 1, Hacking 1 (Subklassenbonus, im Band ohne Nutzen).

**neu:** **Fertigkeiten 1947:** Täuschung 4, Menschenkenntnis 4, Verkleidung 3, Etikette 3, Heimlichkeit 3, Überzeugen 3, Schusswaffen 3, Wahrnehmung 2, Fingerfertigkeit 2, Kryptografie 2, Fahren 2, Ausweichen 1, Geistige Widerstandskraft 1, Auftreten 1, Hacking 1 (Subklassenbonus, im Band ohne Nutzen).

- ergänzen: Fertigkeiten 1947: Täuschung 4, Menschenkenntnis 4, Verkleidung 3, Etikette 3, Heimlichkeit 3, Überzeugen 3, Schusswaffen 3, Wahrnehmung 2, Fingerfertigkeit 2, Kryptografie 2, Fahren 2, Ausweichen 1, Geistige Widerstandskraft 1, Auftreten 1, Hacking 1 (Subklassenbonus, im Band ohne Nutzen).
- streichen oder ersetzen: Fertigkeiten 1947: Täuschung 4, Verkleidung 3, Etikette 3, Heimlichkeit 3, Wahrnehmung 2, Schusswaffen 2, Überzeugen 2, Ausweichen 1, Geistige Widerstandskraft 1, Menschenkenntnis 2, Fahren 1, Kryptografie 1, Auftreten 1, Hacking 1 (Subklassenbonus, im Band ohne Nutzen).

### Zeile 90, Colette Marchais, „Garn“

**alt:** **Fertigkeiten 1977:** Täuschung 6, Menschenkenntnis 4, Kryptografie 3, Verkleidung 4, Etikette 4, Heimlichkeit 4, Wahrnehmung 3, Ausweichen 2, Geistige Widerstandskraft 2, Schusswaffen 2, Überzeugen 2, Fahren 1, Auftreten 1, Hacking 1.

**neu:** **Fertigkeiten 1977:** Täuschung 6, Menschenkenntnis 6, Kryptografie 4, Verkleidung 4, Etikette 4, Heimlichkeit 4, Wahrnehmung 3, Überzeugen 3, Schusswaffen 3, Fingerfertigkeit 2, Fahren 2, Ausweichen 2, Geistige Widerstandskraft 2, Auftreten 1, Hacking 1.

- ergänzen: Fertigkeiten 1977: Täuschung 6, Menschenkenntnis 6, Kryptografie 4, Verkleidung 4, Etikette 4, Heimlichkeit 4, Wahrnehmung 3, Überzeugen 3, Schusswaffen 3, Fingerfertigkeit 2, Fahren 2, Ausweichen 2, Geistige Widerstandskraft 2, Auftreten 1, Hacking 1.
- streichen oder ersetzen: Fertigkeiten 1977: Täuschung 6, Menschenkenntnis 4, Kryptografie 3, Verkleidung 4, Etikette 4, Heimlichkeit 4, Wahrnehmung 3, Ausweichen 2, Geistige Widerstandskraft 2, Schusswaffen 2, Überzeugen 2, Fahren 1, Auftreten 1, Hacking 1.

### Zeile 125, Dr. Ingeborg Rask, „Lot“

**alt:** **Fertigkeiten 1947:** Physik 4, Technik 3, Akademisches Wissen 3, Navigation 2, Wahrnehmung 2, Chemie 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Ingenieurwesen 2, Energiemanipulation 1, Handwerk 1.

**neu:** **Fertigkeiten 1947:** Physik 4, Technik 4, Akademisches Wissen 4, Chemie 3, Ingenieurwesen 3, Navigation 3, Wahrnehmung 3, Energiemanipulation 2, Medizin 2, Handwerk 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Ermittlung 1, Fahren 1.

- ergänzen: Fertigkeiten 1947: Physik 4, Technik 4, Akademisches Wissen 4, Chemie 3, Ingenieurwesen 3, Navigation 3, Wahrnehmung 3, Energiemanipulation 2, Medizin 2, Handwerk 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Ermittlung 1, Fahren 1.
- streichen oder ersetzen: Fertigkeiten 1947: Physik 4, Technik 3, Akademisches Wissen 3, Navigation 2, Wahrnehmung 2, Chemie 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Ingenieurwesen 2, Energiemanipulation 1, Handwerk 1.

### Zeile 127, Dr. Ingeborg Rask, „Lot“

**alt:** **Fertigkeiten 1977:** Physik 6, Technik 5, Energiemanipulation 3, Akademisches Wissen 4, Navigation 3, Chemie 3, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Ingenieurwesen 3, Handwerk 1, Wahrnehmung 3.

**neu:** **Fertigkeiten 1977:** Physik 6, Technik 6, Akademisches Wissen 5, Energiemanipulation 4, Chemie 4, Ingenieurwesen 4, Navigation 4, Wahrnehmung 4, Medizin 2, Handwerk 2, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Ermittlung 1, Fahren 1.

- ergänzen: Fertigkeiten 1977: Physik 6, Technik 6, Akademisches Wissen 5, Energiemanipulation 4, Chemie 4, Ingenieurwesen 4, Navigation 4, Wahrnehmung 4, Medizin 2, Handwerk 2, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Ermittlung 1, Fahren 1.
- streichen oder ersetzen: Fertigkeiten 1977: Physik 6, Technik 5, Energiemanipulation 3, Akademisches Wissen 4, Navigation 3, Chemie 3, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Ingenieurwesen 3, Handwerk 1, Wahrnehmung 3.

### Zeile 164, Ilga Ozola, „Möwe“

**alt:** **Fertigkeiten 1947:** Telepathie 5, Menschenkenntnis 4, Konzentration 3, Geistige Widerstandskraft 3, Wahrnehmung 2, Ausweichen 1, Psi-Kampf 1, Überzeugen 1, Heimlichkeit 1, Medizin 1.

**neu:** **Fertigkeiten 1947:** Telepathie 5, Menschenkenntnis 4, Konzentration 4, Geistige Widerstandskraft 3, Überzeugen 3, Wahrnehmung 3, Täuschung 2, Psi-Kampf 2, Heimlichkeit 2, Medizin 2, Ausweichen 1, Etikette 1, Akademisches Wissen 1, Geschichte 1, Fahren 1.

- ergänzen: Fertigkeiten 1947: Telepathie 5, Menschenkenntnis 4, Konzentration 4, Geistige Widerstandskraft 3, Überzeugen 3, Wahrnehmung 3, Täuschung 2, Psi-Kampf 2, Heimlichkeit 2, Medizin 2, Ausweichen 1, Etikette 1, Akademisches Wissen 1, Geschichte 1, Fahren 1.
- streichen oder ersetzen: Fertigkeiten 1947: Telepathie 5, Menschenkenntnis 4, Konzentration 3, Geistige Widerstandskraft 3, Wahrnehmung 2, Ausweichen 1, Psi-Kampf 1, Überzeugen 1, Heimlichkeit 1, Medizin 1.

### Zeile 166, Ilga Ozola, „Möwe“

**alt:** **Fertigkeiten 1977:** Telepathie 6, Konzentration 5, Psi-Kampf 3, Menschenkenntnis 5, Geistige Widerstandskraft 4, Wahrnehmung 3, Ausweichen 2, Überzeugen 1, Heimlichkeit 1, Medizin 1.

**neu:** **Fertigkeiten 1977:** Telepathie 6, Konzentration 6, Menschenkenntnis 5, Psi-Kampf 4, Geistige Widerstandskraft 4, Wahrnehmung 4, Überzeugen 3, Täuschung 2, Heimlichkeit 2, Medizin 2, Ausweichen 2, Etikette 1, Akademisches Wissen 1, Geschichte 1, Fahren 1.

- ergänzen: Fertigkeiten 1977: Telepathie 6, Konzentration 6, Menschenkenntnis 5, Psi-Kampf 4, Geistige Widerstandskraft 4, Wahrnehmung 4, Überzeugen 3, Täuschung 2, Heimlichkeit 2, Medizin 2, Ausweichen 2, Etikette 1, Akademisches Wissen 1, Geschichte 1, Fahren 1.
- streichen oder ersetzen: Fertigkeiten 1977: Telepathie 6, Konzentration 5, Psi-Kampf 3, Menschenkenntnis 5, Geistige Widerstandskraft 4, Wahrnehmung 3, Ausweichen 2, Überzeugen 1, Heimlichkeit 1, Medizin 1.

### Zeile 203, Dilys Vaughan, „Schiefer“

**alt:** **Fertigkeiten 1947:** Thaumaturgie 4, Ritualismus 4, Okkultismus 4, Konzentration 3, Akademisches Wissen 2, Ausweichen 1, Geistige Widerstandskraft 1, Wahrnehmung 1, Alchemie 1, Geschichte 1.

**neu:** **Fertigkeiten 1947:** Thaumaturgie 4, Ritualismus 4, Okkultismus 4, Konzentration 4, Akademisches Wissen 4, Alchemie 3, Geschichte 3, Menschenkenntnis 2, Wahrnehmung 2, Ausweichen 1, Geistige Widerstandskraft 1, Überzeugen 1, Medizin 1, Handwerk 1.

- ergänzen: Fertigkeiten 1947: Thaumaturgie 4, Ritualismus 4, Okkultismus 4, Konzentration 4, Akademisches Wissen 4, Alchemie 3, Geschichte 3, Menschenkenntnis 2, Wahrnehmung 2, Ausweichen 1, Geistige Widerstandskraft 1, Überzeugen 1, Medizin 1, Handwerk 1.
- streichen oder ersetzen: Fertigkeiten 1947: Thaumaturgie 4, Ritualismus 4, Okkultismus 4, Konzentration 3, Akademisches Wissen 2, Ausweichen 1, Geistige Widerstandskraft 1, Wahrnehmung 1, Alchemie 1, Geschichte 1.

### Zeile 205, Dilys Vaughan, „Schiefer“

**alt:** **Fertigkeiten 1977:** Thaumaturgie 6, Ritualismus 6, Okkultismus 5, Konzentration 4, Akademisches Wissen 3, Ausweichen 2, Geistige Widerstandskraft 2, Wahrnehmung 2, Alchemie 1, Geschichte 1.

**neu:** **Fertigkeiten 1977:** Thaumaturgie 6, Ritualismus 6, Okkultismus 5, Konzentration 5, Akademisches Wissen 5, Alchemie 3, Geschichte 3, Wahrnehmung 3, Menschenkenntnis 2, Ausweichen 2, Geistige Widerstandskraft 2, Überzeugen 1, Medizin 1, Handwerk 1.

- ergänzen: Fertigkeiten 1977: Thaumaturgie 6, Ritualismus 6, Okkultismus 5, Konzentration 5, Akademisches Wissen 5, Alchemie 3, Geschichte 3, Wahrnehmung 3, Menschenkenntnis 2, Ausweichen 2, Geistige Widerstandskraft 2, Überzeugen 1, Medizin 1, Handwerk 1.
- streichen oder ersetzen: Fertigkeiten 1977: Thaumaturgie 6, Ritualismus 6, Okkultismus 5, Konzentration 4, Akademisches Wissen 3, Ausweichen 2, Geistige Widerstandskraft 2, Wahrnehmung 2, Alchemie 1, Geschichte 1.

### Zeile 240, Torsten Ekvall, „Zeuge“

**alt:** **Fertigkeiten 1947:** Ermittlung 4, Wahrnehmung 4, Menschenkenntnis 3, Fahren 3, Okkultismus 2, Spurenlesen 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Geschichte 1, Überzeugen 1, Heimlichkeit 1.

**neu:** **Fertigkeiten 1947:** Ermittlung 4, Wahrnehmung 4, Menschenkenntnis 3, Fahren 3, Okkultismus 3, Spurenlesen 3, Schusswaffen 2, Geschichte 2, Überzeugen 2, Heimlichkeit 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Akademisches Wissen 1, Einschüchtern 1, Medizin 1, Sicherheitssysteme 1.

- ergänzen: Fertigkeiten 1947: Ermittlung 4, Wahrnehmung 4, Menschenkenntnis 3, Fahren 3, Okkultismus 3, Spurenlesen 3, Schusswaffen 2, Geschichte 2, Überzeugen 2, Heimlichkeit 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Akademisches Wissen 1, Einschüchtern 1, Medizin 1, Sicherheitssysteme 1.
- streichen oder ersetzen: Fertigkeiten 1947: Ermittlung 4, Wahrnehmung 4, Menschenkenntnis 3, Fahren 3, Okkultismus 2, Spurenlesen 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Geschichte 1, Überzeugen 1, Heimlichkeit 1.

### Zeile 242, Torsten Ekvall, „Zeuge“

**alt:** **Fertigkeiten 1977:** Ermittlung 6, Okkultismus 4, Menschenkenntnis 5, Wahrnehmung 5, Fahren 3, Spurenlesen 3, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Geschichte 1, Überzeugen 1, Heimlichkeit 1. Ab 60: Athletik oder Ausdauer um 1 gesenkt. Ekvall hat beide auf 0, der Abzug entfällt.

**neu:** **Fertigkeiten 1977:** Ermittlung 6, Menschenkenntnis 5, Okkultismus 5, Wahrnehmung 5, Spurenlesen 4, Fahren 3, Schusswaffen 2, Geschichte 2, Überzeugen 2, Heimlichkeit 2, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Akademisches Wissen 1, Einschüchtern 1, Medizin 1, Sicherheitssysteme 1. Ab 60: Athletik oder Ausdauer um 1 gesenkt. Ekvall hat beide auf 0, der Abzug entfällt.

- ergänzen: Fertigkeiten 1977: Ermittlung 6, Menschenkenntnis 5, Okkultismus 5, Wahrnehmung 5, Spurenlesen 4, Fahren 3, Schusswaffen 2, Geschichte 2, Überzeugen 2, Heimlichkeit 2, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Akademisches Wissen 1, Einschüchtern 1, Medizin 1, Sicherheitssysteme 1.
- streichen oder ersetzen: Fertigkeiten 1977: Ermittlung 6, Okkultismus 4, Menschenkenntnis 5, Wahrnehmung 5, Fahren 3, Spurenlesen 3, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Geschichte 1, Überzeugen 1, Heimlichkeit 1.

### Zeile 248, Torsten Ekvall, „Zeuge“

**alt:** **Fäden:** Ekvall ist Hallströms erster Mann in der Registratur. Er kennt alle Aktenfarben, bevor sie offiziell werden. 1948 packt er mit Hallström die Ahnenerbe-Kiste aus. Hallström findet das Foto der Kreise von 1937 und hängt es an die Wand der Registratur. 1950 liest Ekvall das Protokoll der Apothekerin. Am Rand steht die Zahl 32, nicht von ihr. Ekvall fragt Hallström: „Wer hat die Zahl geschrieben?“ Hallström antwortet: „Ich weiß es nicht. Und ich will es nicht wissen.“ 1962 ist Ekvall dabei, als Britt Holm nach dem Zugunglück im Harz identifiziert wird. Er findet in ihrer Tasche eine Notiz: „Wer holt sie?“ Er gibt sie Hallström. Hallström legt sie in Notizbuch null. Nach der Nacht von Nordlicht bleibt der Stützpunkt versiegelt. Bis zur Räumung am 20. Februar bleiben alle außer einem Scientist mit Wendland am Draht. Wo Ekvall in der Nacht ist, im Stützpunkt oder mit Astrid im Zug, entscheidet der Spieler. Auf dem Dienstplan vertritt Lönn die Registratur (T1).

**neu:** **Fäden:** Ekvall ist Hallströms erster Mann in der Registratur. Er kennt alle Aktenfarben, bevor sie offiziell werden. 1948 packt er mit Hallström die Ahnenerbe-Kiste aus. Hallström findet das Foto der Kreise von 1937 und hängt es an die Wand der Registratur. 1950 liest Ekvall das Protokoll der Apothekerin. Am Rand steht die Zahl 32, nicht von ihr. Ekvall fragt Hallström: „Wer hat die Zahl geschrieben?“ Hallström antwortet: „Ich weiß es nicht. Und ich will es nicht wissen.“ 1962 ist Ekvall dabei, als Britt Holm nach dem Zugunglück im Harz identifiziert wird. Ihre Aktentasche mit der Akte und Hallströms Zettel wird nie gefunden. Ekvall meldet es Hallström. Hallström schreibt in Notizbuch null: „Akte Holm nicht angekommen.“ Nach der Nacht von Nordlicht bleibt der Stützpunkt gesperrt und wird erst nach der Räumung versiegelt. Während der Räumung ab dem 20. Februar bleiben alle außer einem Scientist mit Wendland am Draht. Wo Ekvall in der Nacht ist, im Stützpunkt oder mit Astrid im Zug, entscheidet der Spieler. Auf dem Dienstplan vertritt Lönn die Registratur (T1).

- ergänzen: Ihre Aktentasche mit der Akte und Hallströms Zettel wird nie gefunden.
- ergänzen: Ekvall meldet es Hallström.
- ergänzen: Während der Räumung ab dem 20.
- streichen oder ersetzen: Er findet in ihrer Tasche eine Notiz: "Wer holt sie?" Er gibt sie Hallström.
- streichen oder ersetzen: Hallström legt sie in Notizbuch null.
- streichen oder ersetzen: Bis zur Räumung am 20.

### Zeile 335, Das Ding in der Wand

**alt:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Der Schwellenhüter ist mit der Kiruna-Regel unverwundbar. Die Szene ist kein Kampf, sondern ein Gespräch, das ein Thaumaturg mit einem Bannkreis und einer Antwort überlebt.)

**neu:** (Werte: „Schwellenhüter von Kiruna“, Einsatz 4. Abweichung vom Bedrohungsatlas: Seine Berührung macht keinen Schaden, wer getroffen wird, geht durch die Wand hinüber. Mit der Kiruna-Regel ist er unverwundbar. Die Szene ist kein Kampf, sondern ein Gespräch, das mit einer Antwort endet.)

- ergänzen: (Werte: "Schwellenhüter von Kiruna", Einsatz 4.
- ergänzen: Abweichung vom Bedrohungsatlas: Seine Berührung macht keinen Schaden, wer getroffen wird, geht durch die Wand hinüber.
- ergänzen: Mit der Kiruna-Regel ist er unverwundbar.
- ergänzen: Die Szene ist kein Kampf, sondern ein Gespräch, das mit einer Antwort endet.)
- streichen oder ersetzen: (Werte: Bedrohungsatlas, Spielleiterbuch.
- streichen oder ersetzen: Abweichung der Zeit: Der Schwellenhüter ist mit der Kiruna-Regel unverwundbar.
- streichen oder ersetzen: Die Szene ist kein Kampf, sondern ein Gespräch, das ein Thaumaturg mit einem Bannkreis und einer Antwort überlebt.)

### Zeile 354, Rissling, Der Zuschauer

**alt:** In Cornwall öffnet sich 1957 ein kleiner Riss. Risslinge sickern durch, kleine, flinke Wesen, die aussehen wie Hunde, die jemand nur aus der Erinnerung gezeichnet hat. Am Rand des Risses steht ein Zuschauer: hochgewachsen, grau, still. Er trägt einen langen grauen Mantel, der wie Haut wirkt, und einen Hut, den er nicht abnimmt. Er beobachtet, notiert, verschwindet. Auf Fotos ist er verwackelt, immer, auch wenn alles andere scharf ist.

**neu:** In Cornwall öffnet sich 1957 ein kleiner Riss. Am Rand des Risses steht ein Zuschauer: hochgewachsen, grau, still. Er trägt einen langen grauen Mantel, der wie Haut wirkt, und einen Hut, den er nicht abnimmt. Er beobachtet, notiert, verschwindet. Auf Fotos ist er verwackelt, immer, auch wenn alles andere scharf ist.

- streichen oder ersetzen: Risslinge sickern durch, kleine, flinke Wesen, die aussehen wie Hunde, die jemand nur aus der Erinnerung gezeichnet hat.

### Zeile 356, Rissling, Der Zuschauer

**alt:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Risslinge treten in Cornwall auf, wo die erste Brandmunition im Herbst 1953 getestet wurde. Der Zuschauer wird vom Institut fotografiert, das Foto ist das erste von dreien, die es gibt.)

**neu:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: In Porthcarn 1957 zeigt sich nur der Zuschauer; der Riss ist derselbe, an dem im Herbst 1953 die erste Brandmunition getestet wurde. Der Zuschauer wird vom Institut fotografiert, das Foto ist das erste von dreien, die es gibt.)

- ergänzen: Abweichung der Zeit: In Porthcarn 1957 zeigt sich nur der Zuschauer; der Riss ist derselbe, an dem im Herbst 1953 die erste Brandmunition getestet wurde.
- streichen oder ersetzen: Abweichung der Zeit: Risslinge treten in Cornwall auf, wo die erste Brandmunition im Herbst 1953 getestet wurde.

### Zeile 370, Verbindungsoffizier eines Partnerdienstes

**alt:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Er arbeitet mit Fernschreibern, Telegrammen und toten Briefkästen. Seine Waffe ist eine Dienstpistole im Schulterhalfter, aber er zieht sie selten.)

**neu:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Er arbeitet mit Fernschreibern, Telegrammen und toten Briefkästen. Seine Waffe ist eine Dienstpistole im Schulterhalfter, aber er zieht sie selten. Vor dem Schleierprotokoll 1961 entfällt seine Besonderheit, Polizei, Grenze oder Justiz zurückzupfeifen.)

- ergänzen: Seine Waffe ist eine Dienstpistole im Schulterhalfter, aber er zieht sie selten.
- ergänzen: Vor dem Schleierprotokoll 1961 entfällt seine Besonderheit, Polizei, Grenze oder Justiz zurückzupfeifen.)
- streichen oder ersetzen: Seine Waffe ist eine Dienstpistole im Schulterhalfter, aber er zieht sie selten.)

### Zeile 540, Arsenal

**alt:** Phosphorbrandmunition | vor 1947

**neu:** Phosphorbrandmunition | vor 1947 | gegen Wesen aus Rissen erst ab Herbst 1953 wirksam (Kiruna-Regel, Kapitel 3)

- ergänzen: Phosphorbrandmunition vor 1947 gegen Wesen aus Rissen erst ab Herbst 1953 wirksam (Kiruna-Regel, Kapitel 3)
- streichen oder ersetzen: Phosphorbrandmunition vor 1947

### Zeile 611, Arsenal

**alt:** Weicheisenschrot | vor 1947

**neu:** Weicheisenschrot | vor 1947 | nur über die Werkstatt, im Jagdgeschäft erst nach dem Bleiverbot

- ergänzen: Weicheisenschrot vor 1947 nur über die Werkstatt, im Jagdgeschäft erst nach dem Bleiverbot
- streichen oder ersetzen: Weicheisenschrot vor 1947

### Zeile 660, Grundregelwerk

**alt:** Leichte Rüstung | ab 1953 | Behelf (Ofentür)

**neu:** Leichte Rüstung | ab 1953 | Behelf (Ofentür, Werte Kapitel 3)

- ergänzen: Leichte Rüstung ab 1953 Behelf (Ofentür, Werte Kapitel 3)
- streichen oder ersetzen: Leichte Rüstung ab 1953 Behelf (Ofentür)

### Zeile 684, Grundregelwerk

**alt:** EMF-Detektor | ab 1960

**neu:** EMF-Detektor | ab 1960 | als Rissdetektor aus Holz und Messing (Kapitel 3)

- ergänzen: EMF-Detektor ab 1960 als Rissdetektor aus Holz und Messing (Kapitel 3)
- streichen oder ersetzen: EMF-Detektor ab 1960

### Zeile 688, Grundregelwerk

**alt:** Taschenlampe mit UV-Funktion | vor 1947

**neu:** Taschenlampe mit UV-Funktion | vor 1947 | Taschenlampe mit Filter, eingeschränkt

- ergänzen: Taschenlampe mit UV-Funktion vor 1947 Taschenlampe mit Filter, eingeschränkt
- streichen oder ersetzen: Taschenlampe mit UV-Funktion vor 1947

## Englisch

### Zeile 17, Fixed Points and Open Points

**alt:** The price. The table can change the how of a fixed point if it is willing to pay for it. An agent who saves a man in Kiruna who should have fallen saves him. But someone else goes in his place. Or the agent carries a strain from then on. Or a protégé is sent on a mission too early. The price is never a rules penalty. The price is a story.

**neu:** The price. The table can change the how of a fixed point if it is willing to pay for it. An agent who saves a man in Kiruna who should have fallen saves him. But someone else goes in his place. Or the agent carries a strain from then on. Or a protégé is sent on a mission too early. The price is never a rules penalty. The price is a story. Where a mission names “trust” as the price, it means the relationship with that figure, not the group’s Trust value.

- ergänzen: Where a mission names "trust" as the price, it means the relationship with that figure, not the group's Trust value.

### Zeile 63, Time Jumps and Interlude Years

**alt:** 1950 | Sundqvist arrives; Wendland puts up the apothecary’s protocol | Sundqvist asks about the circles of Kiruna

**neu:** 1950 | Sundqvist arrives; Wendland puts up the apothecary’s protocol | Sundqvist asks about the circles of Solberg

- ergänzen: 1950 Sundqvist arrives; Wendland puts up the apothecary's protocol Sundqvist asks about the circles of Solberg
- streichen oder ersetzen: 1950 Sundqvist arrives; Wendland puts up the apothecary's protocol Sundqvist asks about the circles of Kiruna

### Zeile 107, The Succession System

**alt:** Handover. The protégé takes over when the agent dies, passes over, burns out, must enter a silence, switches to the Open Ones, disappears into a legend or steps down. Their XP is the accumulated protégé XP, but at least the minimum XP of the current Section. In addition they receive a legacy. The legacy is plus 1 to a skill of the mentor if that skill is 4 or higher. Or an object: a piece of ashsilver with the mentor’s name on its inside. A notebook. A cap or a helmet. A crystal only with the Collegium’s consent. Or a contact. Or, after death or retirement, the codename as a series, such as Salz-2, following the model of the Folio series. The handover is a scene. It is played, not ticked off.

**neu:** Handover. The protégé takes over when the agent dies, passes over, burns out, must enter a silence, switches to the Open Ones, disappears into a legend or steps down. Their XP is the accumulated protégé XP, but at least the minimum XP of the current Section. In addition they receive a legacy. The legacy is plus 1 to a skill of the mentor if that skill is 4 or higher. Or an object: a piece of ashsilver with the mentor’s name on its inside. A notebook. A cap or a helmet. A crystal only with the Collegium’s consent. Or a contact. Or, after death or retirement, the codename as a series, such as Salz-2, following the model of the Folio series; in the Investigation Branch only Folio is inherited. The handover is a scene. It is played, not ticked off.

- ergänzen: Or, after death or retirement, the codename as a series, such as Salz-2, following the model of the Folio series; in the Investigation Branch only Folio is inherited.
- streichen oder ersetzen: Or, after death or retirement, the codename as a series, such as Salz-2, following the model of the Folio series.

### Zeile 125, The Succession System

**alt:** 

**neu:** For new agents and protégés, the booklet “Nordlicht 1977: Handouts” has three blank forms, one for each era: the index card of 1948 (Handout N55), the Council personnel form of 1961 (N56) and the computer printout of 1977 (N57).

- ergänzen: For new agents and protégés, the booklet "Nordlicht 1977: Handouts" has three blank forms, one for each era: the index card of 1948 (Handout N55), the Council personnel form of 1961 (N56) and the computer printout of 1977 (N57).

### Zeile 177, Rules at the Table

**alt:** Tests are always stated as skill against difficulty, with a number in brackets. The names come from the core rulebook. The difficulties are levels from Easy (1) to Impossible (5). Perception against Doable (2). Athletics against Hard (3). Occultism against Very Hard (4). No new rules.

**neu:** Tests are always stated as skill against difficulty, with a number in brackets. The names come from the core rulebook. The difficulties are levels from Easy (1) to Impossible (5). Perception against Doable (2). Athletics against Hard (3). Occultism against Very Hard (4). No new test rules.

- ergänzen: No new test rules.
- streichen oder ersetzen: No new rules.

### Zeile 116, Incendiary Ammunition from 1953

**alt:** Before the first batch in autumn 1953, the Kiruna Rule applies. After that, the quartermaster issues one magazine per mission. Incendiary ammunition works against the Voice, not against the Dead or the Alien. Against the Dead it helps as little as ordinary ammunition. Against the Alien, the only thing that helps is what the game master decides for the individual alien.

**neu:** Before the first batch in autumn 1953, the Kiruna Rule applies. After that, the quartermaster issues one magazine per mission. Incendiary ammunition works against the Voice, not against the Dead or the Alien. Against the Dead it helps as little as ordinary ammunition. Against the Alien, ordinary weapons work in full; incendiary ammunition helps no better.

- ergänzen: Against the Alien, ordinary weapons work in full; incendiary ammunition helps no better.
- streichen oder ersetzen: Against the Alien, the only thing that helps is what the game master decides for the individual alien.

### Zeile 119, Incendiary Ammunition from 1953

**alt:** Before the first batch of incendiary ammunition in autumn 1953, ordinary weapons cause no damage against beings from rifts. Only warding circles, spells and retreat offer protection. Salt may hold them off. No one knows whether it might have helped after all. Those who were there in Kiruna say nothing. Those who survived count the names.

**neu:** Before the first batch of incendiary ammunition in autumn 1953, ordinary weapons cause no damage against beings from rifts. Only warding circles, spells and retreat offer protection. Salt may hold them off. No one knows whether it might have helped after all. Those who were there in Kiruna say nothing. Those who survived count the names. From autumn 1953, the Threat Atlas values apply to ordinary weapons.

- ergänzen: From autumn 1953, the Threat Atlas values apply to ordinary weapons.

### Zeile 163, Exchange List for Starting Equipment

**alt:** 

**neu:** Assault rifle, combat suit with helmet, high-explosive grenades | Carbine or submachine gun, steel helmet, hand grenades of the era | Assault rifles only in 1977 Light armour, stealth armour | As protective vest | Depending on year Bio-scanner, portable scanner | Microscope, magnifying glass, forensic kit | No scanner in the field Document scanner | Minox or 35 mm camera | Photographs on film Reinforced communication device | Field telephone or shortwave radio | Depending on location Prediction device, data crystal | Omitted | Does not exist before 1977

- ergänzen: Assault rifle, combat suit with helmet, high-explosive grenades Carbine or submachine gun, steel helmet, hand grenades of the era Assault rifles only in 1977 Light armour, stealth armour As protective vest Depending on year Bio-scanner, portable scanner Microscope, magnifying glass, forensic kit No scanner in the field Document scanner Minox or 35 mm camera Photographs on film Reinforced communication device Field telephone or shortwave radio Depending on location Prediction device, data crystal Omitted Does not exist before 1977

### Zeile 191, Exchange List for Starting Equipment

**alt:** Mental focus device | Cap or helmet | Depending on year

**neu:** Mental focus device, Neuro-Helm | None before 1949, every Psi test is then one level harder; from 1949 Cap, from 1963 Mk. I, from 1972 Mk. II | The Cap does not protect against psionic attacks

- ergänzen: Mental focus device, Neuro-Helm None before 1949, every Psi test is then one level harder; from 1949 Cap, from 1963 Mk.
- ergänzen: I, from 1972 Mk.
- ergänzen: II The Cap does not protect against psionic attacks
- streichen oder ersetzen: Mental focus device Cap or helmet Depending on year

### Zeile 206, Money and Expenses

**alt:** Pay and expenses follow the rules of the core rulebook, adapted to the era. Before 1961 there is no rank ladder; pay is based on Section: in the first Section the pay of an Agent, €4,500 per month, in the second until 1961 that of a Senior Agent, €6,000. From 1961 pay by rank applies as in the core rulebook. No handler approves expenses; Marsh, Ashgrove, Hallström or the Council does. Expenses for a White File are €500, for a Grey File €2,000, for a Red File €10,000. For a Black File the rule is: as much as necessary. Every receipt ends up with the Audit.

**neu:** Pay and expenses follow the rules of the core rulebook, adapted to the era. Before 1961 there is no rank ladder; pay is based on Section: in the first Section the pay of an Agent, €4,500 per month, in the second until 1961 that of a Senior Agent, €6,000. From 1961 pay by rank applies as in the core rulebook. Clearances and requisitions follow the accumulated XP as in the core rulebook even before 1961; only titles and forms of address are missing. No handler approves expenses; Marsh, Ashgrove, Hallström or the Council does. Expenses for a White File are €500, for a Grey File €2,000, for a Red File €10,000. For a Black File the rule is: as much as necessary. Every receipt ends up with the Audit.

- ergänzen: Clearances and requisitions follow the accumulated XP as in the core rulebook even before 1961; only titles and forms of address are missing.

### Zeile 83, Thomas Ashgrove

**alt:** Ashgrove is a man of command. He wears uniform, even when there is none. His voice is calm, deep, unhurried. He rarely speaks about feelings, never about fear. He calls the men by name, not by rank. He eats with them, sleeps beside them, carries the wounded himself. He does not like the nickname “Hammer”. He says: “A hammer breaks. I do not want to break.” In 1955 he receives Knife No. 1 made of ashsilver. He wears it until 1988. He says it is warm. He says that will pass. It has not passed.

**neu:** Ashgrove is a man of command. He wears uniform, even when there is none. His voice is calm, deep, unhurried. He rarely speaks about feelings, never about fear. He calls the men by name, not by rank. He eats with them, sleeps beside them, carries the wounded himself. He does not like the nickname the corridor gossip gives his branch from 1954: “Hammer”. He says: “A hammer knows only one problem.” In 1955 he receives Knife No. 1 made of ashsilver. He wears it until 1988. He says it is warm. He says that will pass. It has not passed.

- ergänzen: He does not like the nickname the corridor gossip gives his branch from 1954: "Hammer".
- streichen oder ersetzen: He does not like the nickname "Hammer".
- streichen oder ersetzen: He says: "A hammer breaks.

### Zeile 117, Evelyn Marsh

**alt:** Marsh gives the group cover. She shows how to disappear, how to lie, how to survive. She takes naivety from the players by showing what cover costs. She takes security from them by showing that no one knows the whole truth. She appears in missions 1, 3, 7, 8, 9 and 11. Mostly as a voice, as a letter, as a woman standing at the edge and watching.

**neu:** Marsh gives the group cover. She shows how to disappear, how to lie, how to survive. She takes naivety from the players by showing what cover costs. She takes security from them by showing that no one knows the whole truth. She appears in missions 1, 3, 7, 8, 9, 10 and 11. Mostly as a voice, as a letter, as a woman standing at the edge and watching.

- ergänzen: She appears in missions 1, 3, 7, 8, 9, 10 and 11.
- streichen oder ersetzen: She appears in missions 1, 3, 7, 8, 9 and 11.

### Zeile 239, Further Figures

**alt:** [table Name | Role | Missions @ 30 40 30]

**neu:** [table Name | Role | Fits mission @ 30 40 30]

- ergänzen: [table Name Role Fits mission @ 30 40 30]
- streichen oder ersetzen: [table Name Role Missions @ 30 40 30]

### Zeile 249, Further Figures

**alt:** Martin Hofer | Engineer, builds prototype 0417 | 9, 10, 11, 12

**neu:** Dr. Martin Hofer | Physicist of the Institute, builds detector 0417 | 9, 10, 11, 12

- ergänzen: Dr.
- ergänzen: Martin Hofer Physicist of the Institute, builds detector 0417 9, 10, 11, 12
- streichen oder ersetzen: Martin Hofer Engineer, builds prototype 0417 9, 10, 11, 12

### Zeile 272, Further Figures

**alt:** These figures are not fixed entities like the portraits. They can appear in missions, give information, accompany the group or hinder it. Their fates are canon. The game master uses them as supporting characters, as witnesses, as voices at the edge. They fill the world without carrying it.

**neu:** These figures are not fixed entities like the portraits. They can appear in missions, give information, accompany the group or hinder it. Their fates are canon. The game master uses them as supporting characters, as witnesses, as voices at the edge. They fill the world without carrying it. The column names missions a figure fits; the mission texts do not always mention them.

- ergänzen: The column names missions a figure fits; the mission texts do not always mention them.

### Zeile 60, What Really Happened

**alt:** - **How the crate travels.** By lorry, ship or train. If the group decides to take the land route via Denmark and Sweden, with the ferry from Harwich to Esbjerg, the mission is extended and the Collector has more chances. If they decide on the sea route, play the crossing over the North Sea and Skagerrak. Duty Log entry: transport route, incidents.

**neu:** - **How the crate travels.** By lorry, ship or train. If the group decides to take the land route via Denmark and Sweden, with the ferry from Harwich to Esbjerg, the mission is extended and the Collector has more chances. On the land route, Node 4 takes place on the ferry to Esbjerg, the Swedish customs in Helsingborg issue the customs transit document (N4), and the confrontation takes place at night in the ferry port of Helsingborg. If they decide on the sea route, play the crossing over the North Sea and Skagerrak. Duty Log entry: transport route, incidents.

- ergänzen: On the land route, Node 4 takes place on the ferry to Esbjerg, the Swedish customs in Helsingborg issue the customs transit document (N4), and the confrontation takes place at night in the ferry port of Helsingborg.

### Zeile 81, Viktor Hallström, 46

**alt:** Detective inspector from Stockholm, with File Zero since 1938. Wants to know who is behind O.D.I.N. Knows that the house without a number exists, conceals that he has kept a private file for eight years. Speaks Swedish-accented English, asks questions he answers himself.

**neu:** Detective inspector from Stockholm, with File Zero since 1938. Wants to know who is behind O.D.I.N. Knows that the house without a number exists, conceals that he has kept a private file for nine years. Speaks Swedish-accented English, asks questions he answers himself.

- ergänzen: Knows that the house without a number exists, conceals that he has kept a private file for nine years.
- streichen oder ersetzen: Knows that the house without a number exists, conceals that he has kept a private file for eight years.

### Zeile 196, Solutions

**alt:** - **Without a fight:** An Agent with Negotiation or Deception against Hard (3) convinces the Collector that the crate is worthless, a trap, an empty lead. They compare their dice with the Collector’s Persuasion and Deception (5 + 4). If the test succeeds, the Collector laughs quietly, straightens his coat and leaves. He says: “We’ll meet again.” The mercenaries follow him into the fog. The group loses an hour because they have to take another route to the lorry.

**neu:** - **Without a fight:** An Agent makes an opposed test with Negotiation or Deception against the Collector’s Persuasion and Deception (5 + 4) and convinces him that the crate is worthless, a trap, an empty lead. If the test succeeds, the Collector laughs quietly, straightens his coat and leaves. He says: “We’ll meet again.” The mercenaries follow him into the fog. The group loses an hour because they have to take another route to the lorry.

- ergänzen: Without a fight: An Agent makes an opposed test with Negotiation or Deception against the Collector's Persuasion and Deception (5 + 4) and convinces him that the crate is worthless, a trap, an empty lead.
- streichen oder ersetzen: Without a fight: An Agent with Negotiation or Deception against Hard (3) convinces the Collector that the crate is worthless, a trap, an empty lead.
- streichen oder ersetzen: They compare their dice with the Collector's Persuasion and Deception (5 + 4).

### Zeile 202, Collector’s Mercenary

**alt:** [entry - | Collector’s Mercenary | Professional · Humans]

**neu:** [entry - | Collector’s Mercenary | Henchman · Humans]

- ergänzen: [entry - Collector's Mercenary Henchman · Humans]
- streichen oder ersetzen: [entry - Collector's Mercenary Professional · Humans]

### Zeile 339, Node 1: The Mine and the Cavity

**alt:** November 1947, polar night. A cage descends into the depths, the mine manager leads the group through wet workings to level 5, location 12 (Map K3). Among his papers is the report to the mining authority (Handout N5). Miners with carbide lamps wait in front of the cavity, a mine dog lies before it. Behind it, a round cave with dull grey walls, on a stone a stopped pocket watch.

**neu:** November 1947, shortly before the polar night. A cage descends into the depths, the mine manager leads the group through wet workings to level 5, location 12 (Map K3). Among his papers is the report to the mining authority (Handout N5). Miners with carbide lamps wait in front of the cavity, a mine dog lies before it. Behind it, a round cave with dull grey walls, on a stone a stopped pocket watch.

- ergänzen: November 1947, shortly before the polar night.
- streichen oder ersetzen: November 1947, polar night.

### Zeile 413, Sequence

**alt:** 3. The crowd turns at the same moment. The game master calls for a horror test against Disturbing (2) for everyone who sees it. Whoever botches the test suffers strain and wants only to get away.

**neu:** 3. The crowd turns at the same moment. The game master calls for a horror test against Disturbing (2) for everyone who sees it. Whoever fails the test suffers strain and wants only to get away.

- ergänzen: Whoever fails the test suffers strain and wants only to get away.
- streichen oder ersetzen: Whoever botches the test suffers strain and wants only to get away.

### Zeile 613, Node 3: The Courtyard in Leipzig

**alt:** - **Clue:** The cobbler wears a leather pouch around his neck that is warm to the touch. A Scientist recognises with Physics against Hard (3) that the shard inside is lighter than it should be. (leads to: the Collegium’s lost crystal)

**neu:** - **Clue:** The cobbler wears a leather pouch around his neck that is warm to the touch. A Scientist recognises with Physics against Hard (3) that the shard inside is lighter than it should be. (leads to: the Collegium’s lost crystal; The shard holds the Name-Eater)

- ergänzen: (leads to: the Collegium's lost crystal; The shard holds the Name-Eater)
- streichen oder ersetzen: (leads to: the Collegium's lost crystal)

### Zeile 636, Node 5: The Young State Security

**alt:** - **Clue:** In his card index lies a photo of the group, taken by the observation post. (leads to: the observation post) An Agent finds this with Perception against Hard (3).

**neu:** - **Clue:** In his card index lies a photo of the group, taken by the observation post. (leads to: The young State Security watches the courtyard) An Agent finds this with Perception against Hard (3).

- ergänzen: (leads to: The young State Security watches the courtyard) An Agent finds this with Perception against Hard (3).
- streichen oder ersetzen: (leads to: the observation post) An Agent finds this with Perception against Hard (3).

### Zeile 646, Node 6: West Berlin, Emergency Reception Centre

**alt:** - **Clue:** The uncle from Salzgitter carries a form for new papers. The field for the name is still empty. (leads to: the name is discarded) An Agent finds this with Perception against Hard (3) or with Sleight of Hand against Hard (3), an Investigator with Perception against Doable (2). - **Clue:** The woman at the counter says: “The family has been sent to Lower Saxony. Where exactly is not in my card index.” (leads to: the trail ends) An Agent finds this with Persuasion against Doable (2).

**neu:** - **Clue:** The uncle from Salzgitter carries a form for new papers. The field for the name is still empty. (leads to: The girl’s trail ends in West Berlin) An Agent finds this with Perception against Hard (3) or with Sleight of Hand against Hard (3), an Investigator with Perception against Doable (2). - **Clue:** The woman at the counter says: “The family has been sent to Lower Saxony. Where exactly is not in my card index.” (leads to: The girl’s trail ends in West Berlin) An Agent finds this with Persuasion against Doable (2).

- ergänzen: (leads to: The girl's trail ends in West Berlin) An Agent finds this with Perception against Hard (3) or with Sleight of Hand against Hard (3), an Investigator with Perception against Doable (2).
- streichen oder ersetzen: (leads to: the name is discarded) An Agent finds this with Perception against Hard (3) or with Sleight of Hand against Hard (3), an Investigator with Perception against Doable (2).

### Zeile 655, Node 6: West Berlin, Emergency Reception Centre

**alt:** 

**neu:** - **The shard holds the Name-Eater in the courtyard; locked in lead, it loses its hold.** Clues: The cobbler wears a warm shard in a leather pouch (Node 3). The cobbler’s children closest to the pouch lost their names first (Node 3). Marsh gives the group the little lead box “for anything that whispers” (Briefing).

- ergänzen: The shard holds the Name-Eater in the courtyard; locked in lead, it loses its hold.
- ergänzen: Clues: The cobbler wears a warm shard in a leather pouch (Node 3).
- ergänzen: The cobbler's children closest to the pouch lost their names first (Node 3).
- ergänzen: Marsh gives the group the little lead box "for anything that whispers" (Briefing).

### Zeile 667, Escalation

**alt:** **Stage 3: Summons.** The liaison officer of the young State Security summons the group to his office in central Leipzig, door without a sign, two floors, one room with a card index. He asks about the purpose of the journey, the interest in the courtyard, the family. Whoever gets tangled in contradictions stays 48 hours in a cell in police headquarters. Afterwards the group is expelled. The camera and the films are confiscated. The photograph still exists: an agent took the first film out of the Leica after the first visit and hid it in the lining of their coat; the People’s Police find only the second (detour).

**neu:** **Stage 3: Summons.** The liaison officer of the young State Security summons the group to his office in central Leipzig, door without a sign, two floors, one room with a card index. He asks about the purpose of the journey, the interest in the courtyard, the family. Whoever gets tangled in contradictions stays 48 hours in a cell in police headquarters. Afterwards the group is released on condition that it leaves the GDR within a week; it is expelled only after the confrontation in the courtyard. The camera and the films are confiscated. The photograph still exists: an agent took the first film out of the Leica after the first visit and hid it in the lining of their coat; the People’s Police find only the second (detour).

- ergänzen: Afterwards the group is released on condition that it leaves the GDR within a week; it is expelled only after the confrontation in the courtyard.
- streichen oder ersetzen: Afterwards the group is expelled.

### Zeile 718, Liaison Officer of a Partner Service

**alt:** **Initiative** | 4

**neu:** **Initiative** | 3

- streichen oder ersetzen: Initiative 4

### Zeile 1016, Crystal Guardian of Kiruna

**alt:** **Weakness** | Ordinary weapons cause no damage (Kiruna rule). The tuning fork from Wales makes them freeze for one round

**neu:** **Weakness** | Ordinary weapons cause no damage (Kiruna rule). The tuning fork from Wales makes them freeze for one round; in 1953 it lies in the Chamber and comes along only if a Thaumaturge requests it from the Collegium (price: every Psion within 100 m suffers 2 strain)

- ergänzen: The tuning fork from Wales makes them freeze for one round; in 1953 it lies in the Chamber and comes along only if a Thaumaturge requests it from the Collegium (price: every Psion within 100 m suffers 2 strain)
- streichen oder ersetzen: The tuning fork from Wales makes them freeze for one round

### Zeile 1029, Aftermath

**alt:** **Experience:** Red File: 5 XP, +1 for the objective achieved, at most +1 personal bonus, plus 1 for each thread taken up. Duration: two to three sessions.

**neu:** **Experience:** Red File: 5 XP, +1 for the objective achieved, at most +1 personal bonus, plus 1 for each thread taken up. Threads taken up are: the mask, Ashgrove’s compass, the name Solheim (Narvik). Duration: two to three sessions.

- ergänzen: Threads taken up are: the mask, Ashgrove's compass, the name Solheim (Narvik).

### Zeile 1071, 1950: Sundqvist and the Record

**alt:** Sundqvist asks about the circles of Kiruna. She wants to know whether the arrangement of the plates on the Cap matches the circles on the wall of Solberg.

**neu:** Sundqvist asks about the circles of Solberg. She wants to know whether the arrangement of the plates on the Cap matches the circles on the wall of Solberg.

- ergänzen: Sundqvist asks about the circles of Solberg.
- streichen oder ersetzen: Sundqvist asks about the circles of Kiruna.

### Zeile 151, Escalation

**alt:** If the group is too slow, nothing spectacular happens. The Waiting One waits. But the callers grow louder. Every night the group spends in the valley increases the pressure: all agents who hear the call make a horror test against **Eerie (1)**. Anyone who answers suffers 1 strain and hears their own name in their sleep for a week.

**neu:** If the group is too slow, nothing spectacular happens. The Waiting One waits. But the callers grow louder. Every night the group spends in the valley increases the pressure: whoever hears the callers for the first time makes a horror test against **Eerie (1)**. Every further night requires everyone who hears the call to roll WIL + Mental Resistance against Doable (2), otherwise 1 strain. Anyone who answers suffers 1 strain and hears their own name in their sleep for a week.

- streichen oder ersetzen: Every night the group spends in the valley increases the pressure: all agents who hear the call make a horror test against Eerie (1).

### Zeile 170, Sequence in Numbered Steps

**alt:** 6. The piece of silver stays warm and calm. From now on it bears the name of the dead.

**neu:** 6. The piece of silver stays warm and calm. It bears a name only if the group carves it in themselves.

- ergänzen: It bears a name only if the group carves it in themselves.
- streichen oder ersetzen: From now on it bears the name of the dead.

### Zeile 228, Aftermath

**alt:** If Vaughan is at the table: her grandmother kept watch in Cwm Llwyd in 1909. Vaughan knows the stories of the dead and of the Waiting One from tales. The game master gives her this thread as a personal strain, not as a handout.

**neu:** If Vaughan is at the table: her grandmother kept watch in Cwm Llwyd in 1909. Vaughan knows the stories of the dead and of the Waiting One from tales. The game master gives her this story as personal background, not as strain points and not as a handout.

- ergänzen: The game master gives her this story as personal background, not as strain points and not as a handout.
- streichen oder ersetzen: The game master gives her this thread as a personal strain, not as a handout.

### Zeile 233, Aftermath

**alt:** - No map.

**neu:** - Map K2 (The Chamber in Wales) belongs to Mission 8; there is no map for the valley.

- ergänzen: Map K2 (The Chamber in Wales) belongs to Mission 8; there is no map for the valley.

### Zeile 337, Node 2: The Beach and the Bay

**alt:** 

**neu:** - **Clue:** On the beach Pennington labels a tag by hand: K-1957-003 (Handout N21). (leads to Node 5)

- ergänzen: Clue: On the beach Pennington labels a tag by hand: K-1957-003 (Handout N21).
- ergänzen: (leads to Node 5)

### Zeile 366, Node 6: Uppsala, December 1957

**alt:** A cellar room beneath a house in Uppsala that belongs to the Lodge. Hallström leads the Investigator there at night. What is there: a man in a white coat, round glasses, a visitors’ book.

**neu:** A cellar room in the Uppsala Regional Archive, where the Solberg church register lies. Hallström leads the Investigator there at night. What is there: a man in a white coat, round glasses, the archive’s visitors’ book.

- ergänzen: A cellar room in the Uppsala Regional Archive, where the Solberg church register lies.
- streichen oder ersetzen: A cellar room beneath a house in Uppsala that belongs to the Lodge.

### Zeile 1017, Aftermath

**alt:** **Until the next mission:** 1960: Of the Thirty-One, 22 are still alive. The Lavigne, who calls herself Margot, marries. 1961: The Typesetter begins in the Nursery. Hold-4 Oxford is established. In September the first Shadow Paratroopers jump in Lima (“I want men who can fall.”). Ekberg leaves the Institute without farewell. 1962: Nachtigall in Vienna, Britt Holm drives into the Harz on 21 December and does not return. 1963: Berglund, Neuro-Helm Mk. I, helmet day. 1964 to 1966: Hold-5 Vienna, training helmet, Hold-6 Lagos. 1968: Liège, Adeyemi, Dorje dies. 1969: Mission 9, “Elster”.

**neu:** **Until the next mission:** 1960: Of the Thirty-One, 22 are still alive. The Lavigne, who calls herself Margot, marries. 1961: The Typesetter begins in the Nursery. Hold-4 Oxford is established. In September a squad near Lima needs three days on foot to reach a rift that has closed by then; Ashgrove writes: “I want men who can fall.” In 1961 the branch trains the first Shadow Paratroopers. Ekberg leaves the Institute without farewell. 1962: Nachtigall in Vienna, Britt Holm drives into the Harz on 21 December and does not return. 1963: Berglund, Neuro-Helm Mk. I, helmet day. 1964 to 1966: Hold-5 Vienna, training helmet, Hold-6 Lagos. 1968: Liège, Adeyemi, Dorje dies. 1969: Mission 9, “Elster”.

- ergänzen: In September a squad near Lima needs three days on foot to reach a rift that has closed by then; Ashgrove writes: "I want men who can fall." In 1961 the branch trains the first Shadow Paratroopers.
- streichen oder ersetzen: In September the first Shadow Paratroopers jump in Lima ("I want men who can fall.").

### Zeile 1033, 1954

**alt:** In Lisbon a closed auction takes place. No auction house. No catalogues. A hall in a private house, three interpreters, ten bidders from six countries. Three crystals from old European private ownership are offered. The Collegium has asked the group to bid on its behalf. Those involved call the event only “the Evening”.

**neu:** In Lisbon a closed auction takes place. No auction house. No catalogues. A hall in the back building of an antiques dealer, after nightfall, three bidders: two private collectors and an Agent of the group bidding for the Collegium. Three crystals from Anatolia are offered. Because the auction only begins after nightfall, the dealer calls it “the Evening”.

- ergänzen: A hall in the back building of an antiques dealer, after nightfall, three bidders: two private collectors and an Agent of the group bidding for the Collegium.
- ergänzen: Because the auction only begins after nightfall, the dealer calls it "the Evening".
- streichen oder ersetzen: A hall in a private house, three interpreters, ten bidders from six countries.
- streichen oder ersetzen: The Collegium has asked the group to bid on its behalf.
- streichen oder ersetzen: Those involved call the event only "the Evening".

### Zeile 1035, 1954

**alt:** Possible scene: An Agent of the group sits in the hall. They wear an inconspicuous suit and a cardboard number. The crystals lie in lead boxes on a walnut table. The auctioneer speaks quietly. The bids rise in small steps. For one crystal the room stays silent. It is milky and small. Two bidders raise their hands. Whether the group’s Agent wins the bid is decided by the table. What they experience on the way to the harbour and to whom they hand the case is told by the player.

**neu:** Possible scene: An Agent of the group sits in the hall. They wear an inconspicuous suit and a cardboard number. The crystals lie in lead boxes on a walnut table. The auctioneer speaks quietly. The bids rise in small steps. For one crystal the room stays silent. It is milky and small. Two bidders raise their hands. Each of the three bidders gets one stone; which one the Agent wins and what they pay for it is decided by the table. What they experience on the way to the harbour and to whom they hand the case is told by the player.

- ergänzen: Each of the three bidders gets one stone; which one the Agent wins and what they pay for it is decided by the table.
- streichen oder ersetzen: Whether the group's Agent wins the bid is decided by the table.

### Zeile 1061, 1962

**alt:** Nachtigall reads one hundred and forty guests in Vienna. She wears a black dress. She does not speak. She stands at the edge of the hall and listens. Afterwards she writes fourteen pages. The Investigation Branch sends the group. An agent reads the pages. They contain names, fears, lies. One name is underlined three times. The agent does not ask who underlined it. He places the pages in a grey envelope. The envelope goes to Hallström. At the Institute, beryllium isolation begins. After twelve years, Greta Sundqvist finishes her work on the circles: not a code, but a language.

**neu:** Nachtigall reads one hundred and forty guests at an embassy reception in Vienna. She wears a black dress and sits at the grand piano as a pianist, between Chopin and Schubert. She does not speak. She plays and listens. Afterwards she writes fourteen pages. The Investigation Branch sends the group. An agent reads the pages. They contain names, fears, lies. One name is underlined three times. The agent does not ask who underlined it. He places the pages in a grey envelope. The envelope goes to Hallström. At the Institute, beryllium isolation begins. After twelve years, Greta Sundqvist finishes her work on the circles: not a code, but a language.

- ergänzen: She wears a black dress and sits at the grand piano as a pianist, between Chopin and Schubert.
- ergänzen: She plays and listens.
- streichen oder ersetzen: She wears a black dress.
- streichen oder ersetzen: She stands at the edge of the hall and listens.

### Zeile 1063, 1962

**alt:** On 20 December 1962, Britt Holm travels from Stockholm to the Harz. She is a secretary in the Registry. She wears a coat and carries a small bag. Hallström gave her the assignment: “Who is fetching her? Do not ask Marek. Ask the Print Shop.” It is about a Harz village with singing children. The group takes her to the train in Stockholm. One agent lifts her bag into the compartment. Another hands her a thermos flask. She smiles. She says: “I’ll come back.” The train departs. On 21 December 1962 it derails in the Harz. Thirty-six dead. Britt Holm’s name is on the list.

**neu:** On 20 December 1962, Britt Holm takes the night train from Stockholm to Hamburg; on 21 December she changes there to the train into the Harz. She is a secretary in the Registry. She wears a coat and carries a small bag. Hallström gave her the assignment: “Who is fetching her? Do not ask Marek. Ask the Print Shop.” It is about a Harz village with singing children. The group takes her to the train in Stockholm. One agent lifts her bag into the compartment. Another hands her a thermos flask. She smiles. She says: “I’ll come back.” The train departs. On 21 December 1962 her connecting train from Hamburg derails in the Harz. Thirty-six dead. Britt Holm’s name is on the list.

- ergänzen: On 20 December 1962, Britt Holm takes the night train from Stockholm to Hamburg; on 21 December she changes there to the train into the Harz.
- streichen oder ersetzen: On 20 December 1962, Britt Holm travels from Stockholm to the Harz.

### Zeile 1087, 1968

**alt:** Dorje dies. He was one of the founders of the Collegium. He found crystals in the Himalayas in 1923. In 1940 he could “call”. Now he is dead. The Chamber is silent for a day. Then the archivists read on in the circles. The Collegium does not mourn. It works. That is its mourning.

**neu:** Dorje dies. He brought the crystal from the abandoned monastery in the Himalayas to London, where the Collegium began. In 1940 he could “call”. Now he is dead. The Chamber is silent for a day. Then the archivists read on in the circles. The Collegium does not mourn. It works. That is its mourning.

- ergänzen: He brought the crystal from the abandoned monastery in the Himalayas to London, where the Collegium began.
- streichen oder ersetzen: He was one of the founders of the Collegium.
- streichen oder ersetzen: He found crystals in the Himalayas in 1923.

### Zeile 128, Node 2: Elster’s Flat in Charlottenburg

**alt:** - **Clue:** Her flat door is smeared with salt that she did not put there herself. Test: Occultism against Easy (1) to recognise: someone is protecting her, the operator who writes the numbers on her own door. (leads to K4, conclusion 2)

**neu:** - **Clue:** On Elster’s threshold lies salt she did not scatter. Test: Occultism against Easy (1). Elster says her colleague, the listener, was here at night, scattered it and wrote the same numbers on her own door without remembering. (leads to K4, conclusion 2)

- ergänzen: Clue: On Elster's threshold lies salt she did not scatter.
- ergänzen: Test: Occultism against Easy (1).
- ergänzen: Elster says her colleague, the listener, was here at night, scattered it and wrote the same numbers on her own door without remembering.
- streichen oder ersetzen: Clue: Her flat door is smeared with salt that she did not put there herself.
- streichen oder ersetzen: Test: Occultism against Easy (1) to recognise: someone is protecting her, the operator who writes the numbers on her own door.

### Zeile 171, Node 6: Marsh’s Hotel Room Near the Zoo

**alt:** - **Clue:** Hallström’s transcript from 1961 lies on the table. Test: Cryptography against Doable (2) to recognise: the broadcast answers, it does not ask. (leads to the loose thread “Numbers station: answers, not questions”)

**neu:** - **Clue:** If the group asks Hallström about 1961, he puts his transcript on the table. Test: Cryptography against Doable (2) to recognise: the broadcast answers, it does not ask. (leads to the loose thread “Numbers station: answers, not questions”)

- ergänzen: Clue: If the group asks Hallström about 1961, he puts his transcript on the table.
- streichen oder ersetzen: Clue: Hallström's transcript from 1961 lies on the table.

### Zeile 265, Aftermath

**alt:** The numbers are answers. Anyone who writes to the house without a number receives a broadcast. This leads to Mission 10, when the last broadcast runs, and to 2026, when the Grey File Kessler and “The Door” M7 Basel need Elster’s code.

**neu:** The numbers are answers. Anyone who writes to the house without a number receives a broadcast. This leads to Mission 10, when the last broadcast runs, and to 2026, when Elster reappears in the Grey File Kessler and in “The Door”, M7 Basel.

- ergänzen: This leads to Mission 10, when the last broadcast runs, and to 2026, when Elster reappears in the Grey File Kessler and in "The Door", M7 Basel.
- streichen oder ersetzen: This leads to Mission 10, when the last broadcast runs, and to 2026, when the Grey File Kessler and "The Door" M7 Basel need Elster's code.

### Zeile 303, What Really Happened

**alt:** In September 1971 Uhrwerk, a precognitive with a Neuro-Helm Mk. II in Vienna, writes a warning on an index card. She sends it to the Core. Kantor reads it and sets it aside. He considers Uhrwerk a woman who never sat in the circle and therefore does not understand what the circle means.

**neu:** In September 1971 Uhrwerk, a precognitive with a Neuro-Helm Mk. I in Vienna, writes a warning on an index card. She sends it to the Core. Kantor reads it and sets it aside. He considers Uhrwerk a woman who never sat in the circle and therefore does not understand what the circle means.

- ergänzen: I in Vienna, writes a warning on an index card.
- streichen oder ersetzen: II in Vienna, writes a warning on an index card.

### Zeile 313, What Really Happened

**alt:** **The loose thread:** The numbers station falls silent on 14 October 1971 at 3:00. The last transcript is a document the group can hold in their hands. The valve of a shortwave transmitter is found on 20 October in a burned-out farmhouse in Sweden. The house stands, the number is missing. This thread leads to the later missions and after 2026 to “The Door” and “Grey Files”.

**neu:** **The loose thread:** The numbers station falls silent on 14 October 1971 at 3:00. The last transcript is a document the group can hold in their hands. The valve of a shortwave transmitter is found in October in a burned-out farmhouse in Sweden. On 20 October Hallström walks past the house in Vasastan to which Kantor wrote: the house stands, the number is missing. This thread leads to the later missions and after 2026 to “The Door” and “Grey Files”.

- ergänzen: On 20 October Hallström walks past the house in Vasastan to which Kantor wrote: the house stands, the number is missing.
- streichen oder ersetzen: The house stands, the number is missing.

### Zeile 349, Uhrwerk, 41

**alt:** Ottilie Brandauer, born 1930. She lives in Vienna and is a precognitive of the Choir with a Neuro-Helm Mk. II. She wrote the warning because she had a premonition: three dead, seven burned out, one sentence. She wants to prevent the Cascade, but she has no proof. She conceals that she has barely slept since the premonition. She speaks precisely, like someone accustomed to noting date and time. Language of the time: “The Voice does not lie. It only repeats what it hears.”

**neu:** Ottilie Brandauer, born 1930. She lives in Vienna and is a precognitive of the Choir with a Neuro-Helm Mk. I. She wrote the warning because she had a premonition: three dead, seven burned out, one sentence. She wants to prevent the Cascade, but she has no proof. She conceals that she has barely slept since the premonition. She speaks precisely, like someone accustomed to noting date and time. Language of the time: “The Voice does not lie. It only repeats what it hears.”

- streichen oder ersetzen: II.

### Zeile 400, Node 2: Stockholm, Investigation Branch, Hallström’s Office

**alt:** - **Clue:** Hallström shows the group the transcripts of the summer broadcasts and explains how the numbers are coordinates. He has the last broadcast of 14 October brought to the group in Wales by courier. (leads to: Conclusion 2)

**neu:** - **Clue:** Hallström shows the group the transcripts of the summer broadcasts and explains how the numbers are coordinates. He has the last broadcast of 14 October brought to the group in Wales by courier. The agent who transcribed the first broadcast in 1961 (Handout N27) recognises the last one first, without a test: they lay N27 next to N33 and see that the voice falls silent where it began back then. (leads to: Conclusion 2)

- ergänzen: The agent who transcribed the first broadcast in 1961 (Handout N27) recognises the last one first, without a test: they lay N27 next to N33 and see that the voice falls silent where it began back then.

### Zeile 407, Node 3: Vienna, Uhrwerk’s Flat

**alt:** A small flat near the Westbahnhof. Index cards lie everywhere, written in pencil, each with date and time. Uhrwerk sits at a table, the Mk. II beside her, writing down her premonitions.

**neu:** A small flat near the Westbahnhof. Index cards lie everywhere, written in pencil, each with date and time. Uhrwerk sits at a table, the Mk. I beside her, writing down her premonitions.

- ergänzen: I beside her, writing down her premonitions.
- streichen oder ersetzen: II beside her, writing down her premonitions.

### Zeile 501, Psion of the Circle

**alt:** For Kantor, Rees, Ashgrove, Pryce, Hallström and Uhrwerk: they are not fighters in this mission. Kantor is unconscious. Rees carries, Ashgrove secures, Pryce waits in the workshop. They need no stats. Uhrwerk is a precognitive with Mk. II and remains in Vienna.

**neu:** For Kantor, Rees, Ashgrove, Pryce, Hallström and Uhrwerk: they are not fighters in this mission. Kantor is unconscious. Rees carries, Ashgrove secures, Pryce waits in the workshop. They need no stats. Uhrwerk is a precognitive with Mk. I and remains in Vienna.

- ergänzen: I and remains in Vienna.
- streichen oder ersetzen: II and remains in Vienna.

### Zeile 509, Aftermath

**alt:** **Experience:** Red File: 5 XP, +1 for the achieved objective, at most +1 personal bonus, plus 1 XP for each thread taken up. Possible threads: the tapes, Uhrwerk’s warning, the forty-first voice, the question about Märta, the last transcript of the numbers station.

**neu:** **Experience:** Red File that turns black: 7 XP like a Black File, +1 for the achieved objective, at most +1 personal bonus, plus 1 XP for each thread taken up. Possible threads: the tapes, Uhrwerk’s warning, the forty-first voice, the question about Märta, the last transcript of the numbers station.

- ergänzen: Experience: Red File that turns black: 7 XP like a Black File, +1 for the achieved objective, at most +1 personal bonus, plus 1 XP for each thread taken up.

### Zeile 649, Node 3: The Old Wine Cellar in Vienna

**alt:** A cellar beneath the building next door to Hold-5. Damp, dark, voices from somewhere. The walls are coated with salt. No beds, no children. Only voices singing in their sleep.

**neu:** An old wine cellar two houses further on, not the embassy cellar of Hold-5. Damp, dark, voices from somewhere. The walls are coated with salt. No beds, no children. Only voices singing in their sleep.

- ergänzen: An old wine cellar two houses further on, not the embassy cellar of Hold-5.
- streichen oder ersetzen: A cellar beneath the building next door to Hold-5.

### Zeile 671, Interlude: December 1974 to February 1976

**alt:** Between Part A and Part B lies an interlude year. It connects the two parts; it contains no clue to the monastery. Each player tells one thing their agent did during this time; the game master tells the fixed events. After that, ageing and handovers as in Chapter 2.

**neu:** Between Part A and Part B lies an interlude year. It connects the two parts; it contains no clue to the monastery. Each player tells one thing their agent did during this time; the game master tells the fixed events. After that, handovers as in Chapter 2. Ageing applies only at the start of Section IV.

- ergänzen: Ageing applies only at the start of Section IV.

### Zeile 732, Sequence

**alt:** 4. Mercier gives the signal. The devices switch on. A deep tone, not loud, but everyone in the room feels it. The Open Ones fall unconscious, one after another, without a shot, without resistance. The fifteen-year-old looks at Mercier before he collapses. A player Psion with Mk. II is also hit by the overlay: They roll WIL + Mental Resistance against Hard (3), otherwise they lose consciousness for one round.

**neu:** 4. Mercier gives the signal. The devices switch on. A deep tone, not loud, but everyone in the room feels it. The Open Ones fall unconscious, one after another, without a shot, without resistance. The fifteen-year-old looks at Mercier before he collapses. A player Psion with Mk. II is also hit by the overlay: forewarned, they roll all Psi tests with −1 die for three rounds.

- ergänzen: II is also hit by the overlay: forewarned, they roll all Psi tests with −1 die for three rounds.
- streichen oder ersetzen: II is also hit by the overlay: They roll WIL + Mental Resistance against Hard (3), otherwise they lose consciousness for one round.

### Zeile 9, The Station

**alt:** When the group arrives on 7 February, it first sees the duty roster. 41 names, in pencil, in neat columns. The column for 14 February is still empty. The game master shows Handout N42; the erasure marks appear only from Saturday, the ticks only at the roll call on 14 February. The agents see the canteen with the wall clock and the kitchen radio on the serving hatch. They see the workshop where Gunnar is repairing a generator that never gets finished. They see the sick bay with the note: Aspirin is running low. They see the steel door in the basement with two keys. If the group’s Scientist set up the probe in January, they see the probe at the stairwell. They see 212 small lead boxes. They hear the whispering. Nothing more.

**neu:** When the group arrives on 7 February, it first sees the duty roster. 41 names, in pencil, in neat columns. The column for 14 February is still empty. The game master shows Handout N42; the erasure marks appear only from Saturday, the ticks only at the roll call on 14 February. The agents see the canteen with the wall clock and the kitchen radio on the serving hatch. They see the workshop where Gunnar is repairing a generator that never gets finished. They see the sick bay with the note: Aspirin is running low. They see the steel door in the basement with two keys. They see the probe at the stairwell, which the Institute has been running since December. They see 212 small lead boxes. They hear the whispering. Nothing more.

- ergänzen: They see the probe at the stairwell, which the Institute has been running since December.
- streichen oder ersetzen: If the group's Scientist set up the probe in January, they see the probe at the stairwell.

### Zeile 26, How to Play the Section

**alt:** At roll call on 14 February 1977 at seven o’clock, all 41 names on the duty roster receive their tick. On 14 February 1977 at 22:10, a Door opens in Nordlicht station. The eleven Thaumaturges read the seventh circle. All 212 stones speak at the same time. The 41 people walk through. All clocks in the station stop. All 212 crystals are afterwards grey as slate. Gunnar Solheim is among the 41. Astrid Solheim arrives too late. Her train is standing beyond Kiruna at 22:10. Ingrid’s pocket watch runs down over a whole night. The search party under Lieutenant Kjell Haugen lands on 15 February at 6:40. They find the door unlocked, the heating on, the radio on, eleven cups on the table, ten half full and warm. Haugen’s watch stands at 22:10. The radio plays a choir. Haugen leaves the choir out of the report. The Print Shop invents 41 deaths over half a year in three countries. The radio log at 22:08 reads: “All quiet. Snow.” For every Chronomancer, at 22:10 the clocks stop and the stone turns grey. In the Crystal Ledger, the exhaustion time for all Nordlicht entries is 22:10. No player agent changes these facts.

**neu:** At roll call on 14 February 1977 at seven o’clock, all 41 names on the duty roster receive their tick. On 14 February 1977 at 22:10, a Door opens in Nordlicht station. The eleven Thaumaturges read the seventh circle. All 212 stones speak at the same time. The 41 people walk through. All clocks in the station stop. All 212 crystals are afterwards grey as slate. Gunnar Solheim is among the 41. Astrid Solheim arrives too late. Her train is standing beyond Kiruna at 22:10. The pocket watch in Ingrid’s hand runs down over a whole night. The search party under Lieutenant Kjell Haugen lands on 15 February at 6:40. They find the door unlocked, the heating on, the radio on, eleven cups on the table, ten half full and warm. Haugen’s watch stands at 22:10. The radio plays a choir. Haugen leaves the choir out of the report. The Print Shop invents 41 deaths over half a year in three countries. The radio log at 22:08 reads: “All quiet. Snow.” For every Chronomancer, at 22:10 the clocks stop and the stone turns grey. In the Crystal Ledger, the exhaustion time for all Nordlicht entries is 22:10. No player agent changes these facts.

- ergänzen: The pocket watch in Ingrid's hand runs down over a whole night.
- streichen oder ersetzen: Ingrid's pocket watch runs down over a whole night.

### Zeile 84, What Really Happened

**alt:** - **Whether the group’s Scientist sets up the Nordlicht probe in January.** Consequence: Rask or a Scientist player may test the probe in January. Whoever sets it up records the measurement strip from 14 February. Whoever does not set it up arrives too late and sees only the printout. - **What the group tells Gunnar about his father.** Consequence: Gunnar carries it into the night. Haugen later knows two names: Rønning and Gunnar. If a player agent Haugen met in Mission 12 remained, they replace one of the two.

**neu:** - **Whether the group’s Scientist works on the Nordlicht probe in January.** Consequence: Rask or a Scientist player may test the probe in January. Whoever worked on it and stays stands at the probe on 14 February. Whoever travels sees only the printout later. - **What the group tells Gunnar about his father.** Consequence: Gunnar carries it into the night. Haugen later knows two names: Rønning and Gunnar. If a player agent Haugen met in Mission 12 remained, they replace Rønning.

- ergänzen: Whoever worked on it and stays stands at the probe on 14 February.
- ergänzen: Whoever travels sees only the printout later.
- ergänzen: If a player agent Haugen met in Mission 12 remained, they replace Rønning.
- streichen oder ersetzen: Whoever sets it up records the measurement strip from 14 February.
- streichen oder ersetzen: Whoever does not set it up arrives too late and sees only the printout.
- streichen oder ersetzen: If a player agent Haugen met in Mission 12 remained, they replace one of the two.

### Zeile 155, Node 3: Stockholm

**alt:** 

**neu:** - **Clue:** Haugen has further crates of the same weight loaded alongside the 26. (leads to the confrontation)

- ergänzen: Clue: Haugen has further crates of the same weight loaded alongside the 26.
- ergänzen: (leads to the confrontation)

### Zeile 159, Node 4: The Night Train on the Iron Ore Line

**alt:** #### Node 4: The Night Train on the Ofotbanen

**neu:** #### Node 4: The Night Train on the Iron Ore Line

- ergänzen: #### Node 4: The Night Train on the Iron Ore Line
- streichen oder ersetzen: #### Node 4: The Night Train on the Ofotbanen

### Zeile 203, Escalation

**alt:** If an agent gets off in Kiruna and follows the voices, they miss the train. The Ofotbanen does not wait. There is no road from Kiruna to Narvik. They take the next train or an ore train to rejoin the group in Narvik. The voices do not want to stop them. They call to them. Whoever stays hears longer than they wanted.

**neu:** If an agent gets off in Kiruna and follows the voices, they miss the train. The Iron Ore Line does not wait. There is no road from Kiruna to Narvik. They take the next train or an ore train to rejoin the group in Narvik. The voices do not want to stop them. They call to them. Whoever stays hears longer than they wanted.

- ergänzen: The Iron Ore Line does not wait.
- streichen oder ersetzen: The Ofotbanen does not wait.

### Zeile 236, Solutions

**alt:** **Without a fight:** The group lets the hunters take the crates and follows them. The crates are not the real ones. Ashgrove had dummy crates loaded in Stockholm with sand and weights, the ones listed on the freight papers. The real crates stand in a second wagon that was reloaded in Kiruna. The group continues to Narvik and collects the real crates from the warehouse. Haugen learns that retreat is not a loss. The price: the Department now knows that O.D.I.N. expected them. The next attempt will be quieter.

**neu:** **Without a fight:** The group lets the hunters take the crates and follows them. The crates are not the real ones. On Ashgrove’s instruction, Haugen had dummy crates with sand and weights put in the goods wagon in Stockholm; they are listed that way on the freight papers. The real crates travel in a second goods wagon that Haugen had uncoupled in Kiruna and that comes to Narvik with the next ore train. The group continues and collects the real crates from the warehouse the next day. If Department 13 attacks before Kiruna, this solution is not available. Haugen learns that retreat is not a loss. The price: the Department now knows that O.D.I.N. expected them. The next attempt will be quieter.

- ergänzen: On Ashgrove's instruction, Haugen had dummy crates with sand and weights put in the goods wagon in Stockholm; they are listed that way on the freight papers.
- streichen oder ersetzen: Ashgrove had dummy crates loaded in Stockholm with sand and weights, the ones listed on the freight papers.

### Zeile 295, Aftermath

**alt:** **Handover:** A Soldier protégé who was present on Mission 12 takes over arm guard No. 114 when their mentor steps down. A Thaumaturge protégé who kept the Crystal Ledger helps enter the arrivals at Nordlicht and thereafter knows every position up to 212.

**neu:** **Handover:** Haugen keeps arm guard No. 114; it passes on only in 1990. A Soldier protégé who was present on Mission 12 knows Haugen and the route afterwards. A Thaumaturge protégé who kept the Crystal Ledger helps enter the arrivals at Nordlicht and thereafter knows every position up to 212.

- ergänzen: Handover: Haugen keeps arm guard No. 114; it passes on only in 1990.
- ergänzen: A Soldier protégé who was present on Mission 12 knows Haugen and the route afterwards.
- streichen oder ersetzen: Handover: A Soldier protégé who was present on Mission 12 takes over arm guard No. 114 when their mentor steps down.

### Zeile 305, Aftermath

**alt:** Map: K10, the Ofotbanen from Stockholm via Kiruna to Narvik.

**neu:** Map: K10, the night train from Stockholm via Kiruna to Narvik.

- ergänzen: Map: K10, the night train from Stockholm via Kiruna to Narvik.
- streichen oder ersetzen: Map: K10, the Ofotbanen from Stockholm via Kiruna to Narvik.

### Zeile 326, What It Is About

**alt:** The group finds a station with 41 people, a kitchen radio playing pop songs, a wall clock that keeps the right time, and 212 stones in the cellar that whisper louder this week than usual. The eleven Thaumaturges are preparing something, but only on Saturday do they ask for the canteen to be kept free on Monday evening. On Saturday the group must decide, following the placeholder rule, who flies to Stockholm on Sunday to collect Astrid Solheim and the parts of the time-measuring installation. Whoever stays takes a swap slot on the duty roster. Whoever travels arrives too late with Astrid. The decision is binary: whoever is at the station that night goes with it. Whoever travels grows old.

**neu:** The group finds a station with 41 people, a kitchen radio playing pop songs, a wall clock that keeps the right time, and 212 stones in the cellar that whisper louder this week than usual. The eleven Thaumaturges are preparing something, but only on Saturday do they ask for the canteen to be kept free on Monday evening. On Saturday the group must decide, following the swap-slot rule, who flies to Stockholm on Sunday to collect Astrid Solheim and the parts of the time-measuring installation. Whoever stays takes a swap slot on the duty roster. Whoever travels arrives too late with Astrid. The decision is binary: whoever is at the station that night goes with it. Whoever travels grows old.

- streichen oder ersetzen: On Saturday the group must decide, following the placeholder rule, who flies to Stockholm on Sunday to collect Astrid Solheim and the parts of the time-measuring installation.

### Zeile 428, Node 2: Canteen with Kitchen and Serving Hatch

**alt:** Tests: Ritualism, Telepathy, Insight, Perception. Classes: Thaumaturge, Psion, Agent, Scientist.

**neu:** Tests: Ritualism, Telepathy, Insight, Perception, Persuasion. Classes: Thaumaturge, Psion, Agent, Scientist.

- ergänzen: Tests: Ritualism, Telepathy, Insight, Perception, Persuasion.
- streichen oder ersetzen: Tests: Ritualism, Telepathy, Insight, Perception.

### Zeile 468, Node 6: Sick Bay and Post

**alt:** - **Clue:** The letter from the radio operator’s wife in Tromsø: she asks when he is coming home. She only knows of a company weather station with a post box in Oslo. (leads to: the 41) An Agent reads it with Sleight of Hand against Easy (1). - **Clue:** Ingrid’s drawing “Ingrid, 3 years old. For Papa.” lies on the table. (leads to: Gunnar Solheim) A Soldier sees it with Perception against Easy (1).

**neu:** - **Clue:** The letter from the radio operator’s wife in Tromsø: she asks when he is coming home. She only knows of a company weather station with a post box in Oslo. (Handout N43, leads to: the 41) An Agent reads it with Sleight of Hand against Easy (1). - **Clue:** Ingrid’s drawing “Ingrid, 3 years old. For Papa.” lies on the table. (Handout N44, leads to: Gunnar Solheim) A Soldier sees it with Perception against Easy (1).

- ergänzen: (Handout N43, leads to: the 41) An Agent reads it with Sleight of Hand against Easy (1).
- ergänzen: (Handout N44, leads to: Gunnar Solheim) A Soldier sees it with Perception against Easy (1).
- streichen oder ersetzen: (leads to: the 41) An Agent reads it with Sleight of Hand against Easy (1).
- streichen oder ersetzen: (leads to: Gunnar Solheim) A Soldier sees it with Perception against Easy (1).

### Zeile 486, Escalation

**alt:** - **Thursday, 10 February:** The school class in the valley. A boy asks about the song he heard at night. If the group is not there, they hear about it on Friday. Horror test: Disturbing (2) if they realise that the song is not from here.

**neu:** - **Thursday, 10 February:** A German school class moves into the hut in the valley. A boy asks about the station with the antennas. If the group is not there, they hear about it on Friday.

- ergänzen: A boy asks about the station with the antennas.
- streichen oder ersetzen: A boy asks about the song he heard at night.
- streichen oder ersetzen: Horror test: Disturbing (2) if they realise that the song is not from here.

### Zeile 495, The Location

**alt:** The canteen of Nordlicht, Monday, 14 February 1977, 21:45 to 22:10. The long table, the eleven Thaumaturges, the chalk circle on the tabletop, eleven cups of coffee. The kitchen radio plays pop songs. The wall clock above the door. For all those who travel: the night train from Stockholm to Narvik, beyond Kiruna, at 22:10. (Map K12)

**neu:** The canteen of Nordlicht, Monday, 14 February 1977, 21:45 to 22:10. The long table, the eleven Thaumaturges, the chalk circle on the tabletop, eleven cups of coffee. The kitchen radio plays pop songs. The wall clock above the door (Map K12). For all those who travel: the night train from Stockholm to Narvik, beyond Kiruna, at 22:10.

- ergänzen: The wall clock above the door (Map K12).
- streichen oder ersetzen: The wall clock above the door.
- streichen oder ersetzen: (Map K12)

### Zeile 518, Kjell Haugen

**alt:** [entry - | Kjell Haugen | Professional · Humans]

**neu:** [entry - | Kjell Haugen | Elite · Humans]

- ergänzen: [entry - Kjell Haugen Elite · Humans]
- streichen oder ersetzen: [entry - Kjell Haugen Professional · Humans]

### Zeile 523, Kjell Haugen

**alt:** **Defence / Armour / HP** | 3 / 2 / 15 **Horror** | Disturbing (2) if he hears the choir on the radio

**neu:** **Defence / Armour / HP** | 3 / 2 / 14 **Horror** | None. If he hears the choir on the radio, he makes a horror test against Disturbing (2) himself

- ergänzen: Defence / Armour / HP 3 / 2 / 14 Horror None.

### Zeile 536, Aftermath

**alt:** **What O.D.I.N. gets:** Haugen’s report SA-1977-02. The wall clock from the canteen, stopped at 22:10. The kitchen radio, which plays a choir in the morning. The 212 grey crystals. The probe that measures 41 people over there. The eleven files of the night worker. The Black File Nordlicht.

**neu:** **What O.D.I.N. gets:** Haugen’s report SA-1977-02. The wall clock from the canteen, stopped at 22:10. The kitchen radio, which plays a choir in the morning. The 212 grey crystals. The probe that measures 41 people over there. The personnel files of the eleven Thaumaturges (in 2014 the eleven files of the night worker). The Black File Nordlicht.

- ergänzen: The personnel files of the eleven Thaumaturges (in 2014 the eleven files of the night worker).
- streichen oder ersetzen: The eleven files of the night worker.

### Zeile 63, The Duty Roster

**alt:** **How a player agent gets onto the roster.** On Saturday, 12 February, each player decides individually whether their agent stays or travels. Whoever stays takes a swap slot of a suitable function: T1 liaison, T2 Thaumaturge, T3 archive assistant, T4 physicist, T5 radio operator, T6 guard, T7 Listener. A player Thaumaturge on T2 belongs to the eleven and reads along. Whoever wants to stay but not read takes T3. If more player agents of the same function are available than swap slots, they replace further names of suitable function. The number 41 does not break.

**neu:** **How a player agent gets onto the roster.** On Saturday, 12 February, each player decides individually whether their agent stays or travels. Whoever stays takes a swap slot of a suitable function: T1 liaison, T2 Thaumaturge, T3 archive assistant, T4 physicist, T5 radio operator, T6 guard, T7 Listener. A player Thaumaturge on T2 belongs to the eleven and reads along. Whoever wants to stay but not read takes T3. If more player agents of the same function are available than swap slots, they replace further names of suitable function, but never Einar Vatne or Arne Kvalvik. The number 41 does not break.

- ergänzen: If more player agents of the same function are available than swap slots, they replace further names of suitable function, but never Einar Vatne or Arne Kvalvik.
- streichen oder ersetzen: If more player agents of the same function are available than swap slots, they replace further names of suitable function.

### Zeile 194, 22:10, Beyond Kiruna

**alt:** Ingrid sleeps. She does not wake.

**neu:** Ingrid sleeps on. She notices nothing.

- ergänzen: Ingrid sleeps on.
- ergänzen: She notices nothing.
- streichen oder ersetzen: Ingrid sleeps.
- streichen oder ersetzen: She does not wake.

### Zeile 226, In the Station

**alt:** Haugen counts his men twice. In the station chief’s office he reads the duty roster, the 41 names, one after another, each with a tick. He knows two: Magnus Rønning from Camp Ashgrove and Gunnar Solheim from Narvik, December 1976. If a player agent whom Haugen met in Mission 12 remained, their name stands in place of one of the two.

**neu:** Haugen counts his men twice. In the station chief’s office he reads the duty roster, the 41 names, one after another, each with a tick. He knows two: Magnus Rønning from Camp Ashgrove and Gunnar Solheim from Narvik, December 1976. If a player agent whom Haugen met in Mission 12 remained, their name stands in place of Rønning’s.

- ergänzen: If a player agent whom Haugen met in Mission 12 remained, their name stands in place of Rønning's.
- streichen oder ersetzen: If a player agent whom Haugen met in Mission 12 remained, their name stands in place of one of the two.

### Zeile 51, Harald Ness, “Salz”

**alt:** **Skills 1947:** Firearms 4, Endurance 4, Tactics 3, Survival 3, Athletics 2, Melee 2, Perception 2, Dodge 2, Mental Resistance 2, Toughness 2, Driving 1, Craft 1, Stealth 1, Medicine 1.

**neu:** **Skills 1947:** Firearms 5, Endurance 4, Tactics 3, Survival 3, Athletics 2, Melee 3, Perception 3, Dodge 2, Mental Resistance 2, Toughness 2, Stealth 2, Medicine 2, Driving 1, Craft 1.

- ergänzen: Skills 1947: Firearms 5, Endurance 4, Tactics 3, Survival 3, Athletics 2, Melee 3, Perception 3, Dodge 2, Mental Resistance 2, Toughness 2, Stealth 2, Medicine 2, Driving 1, Craft 1.
- streichen oder ersetzen: Skills 1947: Firearms 4, Endurance 4, Tactics 3, Survival 3, Athletics 2, Melee 2, Perception 2, Dodge 2, Mental Resistance 2, Toughness 2, Driving 1, Craft 1, Stealth 1, Medicine 1.

### Zeile 53, Harald Ness, “Salz”

**alt:** **Skills 1977:** Firearms 5, Tactics 5, Endurance 4, Survival 4, Perception 3, Mental Resistance 3, Dodge 3, Toughness 2, Athletics 2, Melee 2, Leadership 4, Driving 1, Craft 1, Stealth 1, Medicine 1.

**neu:** **Skills 1977:** Firearms 6, Tactics 5, Endurance 4, Survival 4, Perception 4, Leadership 4, Mental Resistance 3, Dodge 3, Melee 3, Toughness 2, Athletics 2, Stealth 2, Medicine 2, Driving 1, Craft 1.

- ergänzen: Skills 1977: Firearms 6, Tactics 5, Endurance 4, Survival 4, Perception 4, Leadership 4, Mental Resistance 3, Dodge 3, Melee 3, Toughness 2, Athletics 2, Stealth 2, Medicine 2, Driving 1, Craft 1.
- streichen oder ersetzen: Skills 1977: Firearms 5, Tactics 5, Endurance 4, Survival 4, Perception 3, Mental Resistance 3, Dodge 3, Toughness 2, Athletics 2, Melee 2, Leadership 4, Driving 1, Craft 1, Stealth 1, Medicine 1.

### Zeile 88, Colette Marchais, “Garn”

**alt:** **Skills 1947:** Deception 4, Disguise 3, Etiquette 3, Stealth 3, Perception 2, Firearms 2, Persuasion 2, Dodge 1, Mental Resistance 1, Insight 2, Driving 1, Cryptography 1, Performance 1, Hacking 1 (subclass bonus, of no use in this volume).

**neu:** **Skills 1947:** Deception 4, Insight 4, Disguise 3, Etiquette 3, Stealth 3, Persuasion 3, Firearms 3, Perception 2, Sleight of Hand 2, Cryptography 2, Driving 2, Dodge 1, Mental Resistance 1, Performance 1, Hacking 1 (subclass bonus, of no use in this volume).

- ergänzen: Skills 1947: Deception 4, Insight 4, Disguise 3, Etiquette 3, Stealth 3, Persuasion 3, Firearms 3, Perception 2, Sleight of Hand 2, Cryptography 2, Driving 2, Dodge 1, Mental Resistance 1, Performance 1, Hacking 1 (subclass bonus, of no use in this volume).
- streichen oder ersetzen: Skills 1947: Deception 4, Disguise 3, Etiquette 3, Stealth 3, Perception 2, Firearms 2, Persuasion 2, Dodge 1, Mental Resistance 1, Insight 2, Driving 1, Cryptography 1, Performance 1, Hacking 1 (subclass bonus, of no use in this volume).

### Zeile 90, Colette Marchais, “Garn”

**alt:** **Skills 1977:** Deception 6, Insight 4, Cryptography 3, Disguise 4, Etiquette 4, Stealth 4, Perception 3, Dodge 2, Mental Resistance 2, Firearms 2, Persuasion 2, Driving 1, Performance 1, Hacking 1.

**neu:** **Skills 1977:** Deception 6, Insight 6, Cryptography 4, Disguise 4, Etiquette 4, Stealth 4, Perception 3, Persuasion 3, Firearms 3, Sleight of Hand 2, Driving 2, Dodge 2, Mental Resistance 2, Performance 1, Hacking 1.

- ergänzen: Skills 1977: Deception 6, Insight 6, Cryptography 4, Disguise 4, Etiquette 4, Stealth 4, Perception 3, Persuasion 3, Firearms 3, Sleight of Hand 2, Driving 2, Dodge 2, Mental Resistance 2, Performance 1, Hacking 1.
- streichen oder ersetzen: Skills 1977: Deception 6, Insight 4, Cryptography 3, Disguise 4, Etiquette 4, Stealth 4, Perception 3, Dodge 2, Mental Resistance 2, Firearms 2, Persuasion 2, Driving 1, Performance 1, Hacking 1.

### Zeile 125, Dr. Ingeborg Rask, “Lot”

**alt:** **Skills 1947:** Physics 4, Technology 3, Academic Knowledge 3, Navigation 2, Perception 2, Chemistry 2, Dodge 1, Mental Resistance 1, Toughness 1, Engineering 2, Energy Manipulation 1, Craft 1.

**neu:** **Skills 1947:** Physics 4, Technology 4, Academic Knowledge 4, Chemistry 3, Engineering 3, Navigation 3, Perception 3, Energy Manipulation 2, Medicine 2, Craft 2, Dodge 1, Mental Resistance 1, Toughness 1, Investigation 1, Driving 1.

- ergänzen: Skills 1947: Physics 4, Technology 4, Academic Knowledge 4, Chemistry 3, Engineering 3, Navigation 3, Perception 3, Energy Manipulation 2, Medicine 2, Craft 2, Dodge 1, Mental Resistance 1, Toughness 1, Investigation 1, Driving 1.
- streichen oder ersetzen: Skills 1947: Physics 4, Technology 3, Academic Knowledge 3, Navigation 2, Perception 2, Chemistry 2, Dodge 1, Mental Resistance 1, Toughness 1, Engineering 2, Energy Manipulation 1, Craft 1.

### Zeile 127, Dr. Ingeborg Rask, “Lot”

**alt:** **Skills 1977:** Physics 6, Technology 5, Energy Manipulation 3, Academic Knowledge 4, Navigation 3, Chemistry 3, Dodge 2, Mental Resistance 2, Toughness 1, Engineering 3, Craft 1, Perception 3.

**neu:** **Skills 1977:** Physics 6, Technology 6, Academic Knowledge 5, Energy Manipulation 4, Chemistry 4, Engineering 4, Navigation 4, Perception 4, Medicine 2, Craft 2, Dodge 2, Mental Resistance 2, Toughness 1, Investigation 1, Driving 1.

- ergänzen: Skills 1977: Physics 6, Technology 6, Academic Knowledge 5, Energy Manipulation 4, Chemistry 4, Engineering 4, Navigation 4, Perception 4, Medicine 2, Craft 2, Dodge 2, Mental Resistance 2, Toughness 1, Investigation 1, Driving 1.
- streichen oder ersetzen: Skills 1977: Physics 6, Technology 5, Energy Manipulation 3, Academic Knowledge 4, Navigation 3, Chemistry 3, Dodge 2, Mental Resistance 2, Toughness 1, Engineering 3, Craft 1, Perception 3.

### Zeile 135, Dr. Ingeborg Rask, “Lot”

**alt:** **Protégé:** Beate Lindqvist, born 1946. An engineer from Gothenburg who joins the Institute in 1969. Rask trains her as an Engineer: Engineering, Technology, Craft. Lindqvist builds the probe’s cabling in 1976. She is the one who brings the probe’s printout to the basement. In 1977 she waits in Bern for Rask’s return. If Rask returns, Lindqvist asks: “What did the probe count?” Rask answers: “People. Hopefully.”

**neu:** **Protégé:** Beate Lindqvist, born 1946. An engineer from Gothenburg who joins the Institute in 1969. Rask trains her as an Engineer: Technology, Engineering, Physics. Lindqvist builds the probe’s cabling in 1976. She is the one who brings the probe’s printout to the basement. In 1977 she waits in Bern for Rask’s return. If Rask returns, Lindqvist asks: “What did the probe count?” Rask answers: “People. Hopefully.”

- ergänzen: Rask trains her as an Engineer: Technology, Engineering, Physics.
- streichen oder ersetzen: Rask trains her as an Engineer: Engineering, Technology, Craft.

### Zeile 164, Ilga Ozola, “Möwe”

**alt:** **Skills 1947:** Telepathy 5, Insight 4, Concentration 3, Mental Resistance 3, Perception 2, Dodge 1, Psi Combat 1, Persuasion 1, Stealth 1, Medicine 1.

**neu:** **Skills 1947:** Telepathy 5, Insight 4, Concentration 4, Mental Resistance 3, Persuasion 3, Perception 3, Deception 2, Psi Combat 2, Stealth 2, Medicine 2, Dodge 1, Etiquette 1, Academic Knowledge 1, History 1, Driving 1.

- ergänzen: Skills 1947: Telepathy 5, Insight 4, Concentration 4, Mental Resistance 3, Persuasion 3, Perception 3, Deception 2, Psi Combat 2, Stealth 2, Medicine 2, Dodge 1, Etiquette 1, Academic Knowledge 1, History 1, Driving 1.
- streichen oder ersetzen: Skills 1947: Telepathy 5, Insight 4, Concentration 3, Mental Resistance 3, Perception 2, Dodge 1, Psi Combat 1, Persuasion 1, Stealth 1, Medicine 1.

### Zeile 166, Ilga Ozola, “Möwe”

**alt:** **Skills 1977:** Telepathy 6, Concentration 5, Psi Combat 3, Insight 5, Mental Resistance 4, Perception 3, Dodge 2, Persuasion 1, Stealth 1, Medicine 1.

**neu:** **Skills 1977:** Telepathy 6, Concentration 6, Insight 5, Psi Combat 4, Mental Resistance 4, Perception 4, Persuasion 3, Deception 2, Stealth 2, Medicine 2, Dodge 2, Etiquette 1, Academic Knowledge 1, History 1, Driving 1.

- ergänzen: Skills 1977: Telepathy 6, Concentration 6, Insight 5, Psi Combat 4, Mental Resistance 4, Perception 4, Persuasion 3, Deception 2, Stealth 2, Medicine 2, Dodge 2, Etiquette 1, Academic Knowledge 1, History 1, Driving 1.
- streichen oder ersetzen: Skills 1977: Telepathy 6, Concentration 5, Psi Combat 3, Insight 5, Mental Resistance 4, Perception 3, Dodge 2, Persuasion 1, Stealth 1, Medicine 1.

### Zeile 203, Dilys Vaughan, “Schiefer”

**alt:** **Skills 1947:** Thaumaturgy 4, Ritualism 4, Occultism 4, Concentration 3, Academic Knowledge 2, Dodge 1, Mental Resistance 1, Perception 1, Alchemy 1, History 1.

**neu:** **Skills 1947:** Thaumaturgy 4, Ritualism 4, Occultism 4, Concentration 4, Academic Knowledge 4, Alchemy 3, History 3, Insight 2, Perception 2, Dodge 1, Mental Resistance 1, Persuasion 1, Medicine 1, Craft 1.

- ergänzen: Skills 1947: Thaumaturgy 4, Ritualism 4, Occultism 4, Concentration 4, Academic Knowledge 4, Alchemy 3, History 3, Insight 2, Perception 2, Dodge 1, Mental Resistance 1, Persuasion 1, Medicine 1, Craft 1.
- streichen oder ersetzen: Skills 1947: Thaumaturgy 4, Ritualism 4, Occultism 4, Concentration 3, Academic Knowledge 2, Dodge 1, Mental Resistance 1, Perception 1, Alchemy 1, History 1.

### Zeile 205, Dilys Vaughan, “Schiefer”

**alt:** **Skills 1977:** Thaumaturgy 6, Ritualism 6, Occultism 5, Concentration 4, Academic Knowledge 3, Dodge 2, Mental Resistance 2, Perception 2, Alchemy 1, History 1.

**neu:** **Skills 1977:** Thaumaturgy 6, Ritualism 6, Occultism 5, Concentration 5, Academic Knowledge 5, Alchemy 3, History 3, Perception 3, Insight 2, Dodge 2, Mental Resistance 2, Persuasion 1, Medicine 1, Craft 1.

- ergänzen: Skills 1977: Thaumaturgy 6, Ritualism 6, Occultism 5, Concentration 5, Academic Knowledge 5, Alchemy 3, History 3, Perception 3, Insight 2, Dodge 2, Mental Resistance 2, Persuasion 1, Medicine 1, Craft 1.
- streichen oder ersetzen: Skills 1977: Thaumaturgy 6, Ritualism 6, Occultism 5, Concentration 4, Academic Knowledge 3, Dodge 2, Mental Resistance 2, Perception 2, Alchemy 1, History 1.

### Zeile 211, Dilys Vaughan, “Schiefer”

**alt:** **Threads:** If Vaughan is in Kiruna in 1953, she survives because she remains outside the warding circle. The other Thaumaturge draws the circle, answers the thing and walks through the rock. She sees him walk through the rock. Since then she draws every warding circle twice. In 1957 she becomes Astrid Solheim’s supervisor, one year after the first Chronomancer came to the Collegium. Vaughan teaches her: “Time is a circle. Whoever leaves it comes back different.” In 1977 Vaughan can be one of the eleven Thaumaturges who read the seventh circle in the canteen above the archive. She knows what happened in 1953. She reads anyway. At 22:10 the Door opens. Vaughan can step through. Her watch stops. Her crystal turns grey. Or she accompanies Astrid on the delayed train to Narvik and arrives too late.

**neu:** **Threads:** If Vaughan is in Kiruna in 1953, she survives because she remains outside his circle. The other Thaumaturge draws the circle, answers the thing and walks through the rock. She sees him walk through the rock. Since then she draws every warding circle twice. In 1957 she becomes Astrid Solheim’s supervisor, one year after the first Chronomancer came to the Collegium. Vaughan teaches her: “Time is a circle. Whoever leaves it comes back different.” In 1977 Vaughan can be one of the eleven Thaumaturges who read the seventh circle in the canteen above the archive. She knows what happened in 1953. She reads anyway. At 22:10 the Door opens. Vaughan can step through. Her watch stops. Her crystal turns grey. Or she accompanies Astrid on the delayed train to Narvik and arrives too late.

- ergänzen: Threads: If Vaughan is in Kiruna in 1953, she survives because she remains outside his circle.
- streichen oder ersetzen: Threads: If Vaughan is in Kiruna in 1953, she survives because she remains outside the warding circle.

### Zeile 240, Torsten Ekvall, “Zeuge”

**alt:** **Skills 1947:** Investigation 4, Perception 4, Insight 3, Driving 3, Occultism 2, Tracking 2, Dodge 1, Mental Resistance 1, Toughness 1, History 1, Persuasion 1, Stealth 1.

**neu:** **Skills 1947:** Investigation 4, Perception 4, Insight 3, Driving 3, Occultism 3, Tracking 3, Firearms 2, History 2, Persuasion 2, Stealth 2, Dodge 1, Mental Resistance 1, Toughness 1, Academic Knowledge 1, Intimidation 1, Medicine 1, Security Systems 1.

- ergänzen: Skills 1947: Investigation 4, Perception 4, Insight 3, Driving 3, Occultism 3, Tracking 3, Firearms 2, History 2, Persuasion 2, Stealth 2, Dodge 1, Mental Resistance 1, Toughness 1, Academic Knowledge 1, Intimidation 1, Medicine 1, Security Systems 1.
- streichen oder ersetzen: Skills 1947: Investigation 4, Perception 4, Insight 3, Driving 3, Occultism 2, Tracking 2, Dodge 1, Mental Resistance 1, Toughness 1, History 1, Persuasion 1, Stealth 1.

### Zeile 242, Torsten Ekvall, “Zeuge”

**alt:** **Skills 1977:** Investigation 6, Occultism 4, Insight 5, Perception 5, Driving 3, Tracking 3, Dodge 2, Mental Resistance 2, Toughness 1, History 1, Persuasion 1, Stealth 1. From age 60: Athletics or Endurance reduced by 1. Ekvall has both at 0, so the reduction does not apply.

**neu:** **Skills 1977:** Investigation 6, Insight 5, Occultism 5, Perception 5, Tracking 4, Driving 3, Firearms 2, History 2, Persuasion 2, Stealth 2, Dodge 2, Mental Resistance 2, Toughness 1, Academic Knowledge 1, Intimidation 1, Medicine 1, Security Systems 1. From age 60: Athletics or Endurance reduced by 1. Ekvall has both at 0, so the reduction does not apply.

- ergänzen: Skills 1977: Investigation 6, Insight 5, Occultism 5, Perception 5, Tracking 4, Driving 3, Firearms 2, History 2, Persuasion 2, Stealth 2, Dodge 2, Mental Resistance 2, Toughness 1, Academic Knowledge 1, Intimidation 1, Medicine 1, Security Systems 1.
- streichen oder ersetzen: Skills 1977: Investigation 6, Occultism 4, Insight 5, Perception 5, Driving 3, Tracking 3, Dodge 2, Mental Resistance 2, Toughness 1, History 1, Persuasion 1, Stealth 1.

### Zeile 248, Torsten Ekvall, “Zeuge”

**alt:** **Threads:** Ekvall is Hallström’s first man in the Registry. He knows all file colours before they become official. In 1948 he unpacks the Ahnenerbe crate with Hallström. Hallström finds the photo of the circles from 1937 and hangs it on the wall of the Registry. In 1950 Ekvall reads the pharmacist’s report. In the margin is the number 32, not in her hand. Ekvall asks Hallström: “Who wrote the number?” Hallström answers: “I don’t know. And I don’t want to know.” In 1962 Ekvall is present when Britt Holm is identified after the train accident in the Harz. In her bag he finds a note: “Who will fetch her?” He gives it to Hallström. Hallström places it in Notebook Zero. After the Night of Nordlicht the station remains sealed. Until the clearance on 20 February, everyone stays at the wire except one Scientist, who goes in with Wendland. Where Ekvall is that night, in the station or with Astrid on the train, is decided by the player. On the duty roster, Lönn represents the Registry (T1).

**neu:** **Threads:** Ekvall is Hallström’s first man in the Registry. He knows all file colours before they become official. In 1948 he unpacks the Ahnenerbe crate with Hallström. Hallström finds the photo of the circles from 1937 and hangs it on the wall of the Registry. In 1950 Ekvall reads the pharmacist’s report. In the margin is the number 32, not in her hand. Ekvall asks Hallström: “Who wrote the number?” Hallström answers: “I don’t know. And I don’t want to know.” In 1962 Ekvall is present when Britt Holm is identified after the train accident in the Harz. Her briefcase with the file and Hallström’s note is never found. Ekvall reports it to Hallström. Hallström writes in Notebook Zero: “File Holm not arrived.” After the Night of Nordlicht the station remains closed off and is sealed only after the clearance. During the clearance from 20 February, everyone stays at the wire except one Scientist, who goes in with Wendland. Where Ekvall is that night, in the station or with Astrid on the train, is decided by the player. On the duty roster, Lönn represents the Registry (T1).

- ergänzen: Her briefcase with the file and Hallström's note is never found.
- ergänzen: Ekvall reports it to Hallström.
- streichen oder ersetzen: In her bag he finds a note: "Who will fetch her?" He gives it to Hallström.

### Zeile 335, The Thing in the Wall

**alt:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: The Threshold Guardian is invulnerable with the Kiruna Rule. The scene is not a fight, but a conversation that a Thaumaturge survives with a warding circle and an answer.)

**neu:** (Stats: “Threshold Guardian of Kiruna”, Mission 4. Deviation from the Threat Atlas: its touch does no damage; whoever is hit goes through the wall. With the Kiruna Rule it is invulnerable. The scene is not a fight, but a conversation that ends with an answer.)

- ergänzen: (Stats: "Threshold Guardian of Kiruna", Mission 4.
- ergänzen: Deviation from the Threat Atlas: its touch does no damage; whoever is hit goes through the wall.
- ergänzen: With the Kiruna Rule it is invulnerable.
- streichen oder ersetzen: (Stats: Threat Atlas, Game Master's Book.
- streichen oder ersetzen: Era deviation: The Threshold Guardian is invulnerable with the Kiruna Rule.

### Zeile 354, Riftling, the Spectator

**alt:** In Cornwall in 1957, a small rift opens. Riftlings seep through, small, quick creatures that look like dogs someone has drawn only from memory. At the edge of the rift stands a Spectator: tall, grey, still. He wears a long grey coat that seems like skin, and a hat he does not remove. He observes, notes, disappears. In photographs he is blurred, always, even when everything else is sharp.

**neu:** In Cornwall in 1957, a small rift opens. At the edge of the rift stands a Spectator: tall, grey, still. He wears a long grey coat that seems like skin, and a hat he does not remove. He observes, notes, disappears. In photographs he is blurred, always, even when everything else is sharp.

- streichen oder ersetzen: Riftlings seep through, small, quick creatures that look like dogs someone has drawn only from memory.

### Zeile 370, Liaison Officer of a Partner Service

**alt:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: He works with teleprinters, telegrams and dead letter boxes. His weapon is a service pistol in a shoulder holster, but he rarely draws it.)

**neu:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: He works with teleprinters, telegrams and dead letter boxes. His weapon is a service pistol in a shoulder holster, but he rarely draws it. Before the Veil Protocol of 1961 his ability to call off police, border or courts does not apply.)

- ergänzen: His weapon is a service pistol in a shoulder holster, but he rarely draws it.
- ergänzen: Before the Veil Protocol of 1961 his ability to call off police, border or courts does not apply.)
- streichen oder ersetzen: His weapon is a service pistol in a shoulder holster, but he rarely draws it.)

### Zeile 540, Arsenal

**alt:** Phosphorus incendiary ammunition | before 1947

**neu:** Phosphorus incendiary ammunition | before 1947 | effective against beings from rifts only from autumn 1953 (Kiruna Rule, Chapter 3)

- ergänzen: Phosphorus incendiary ammunition before 1947 effective against beings from rifts only from autumn 1953 (Kiruna Rule, Chapter 3)
- streichen oder ersetzen: Phosphorus incendiary ammunition before 1947

### Zeile 611, Arsenal

**alt:** Soft iron shot | before 1947

**neu:** Soft iron shot | before 1947 | workshop only; in gun shops only after the lead ban

- ergänzen: Soft iron shot before 1947 workshop only; in gun shops only after the lead ban
- streichen oder ersetzen: Soft iron shot before 1947

### Zeile 660, Core Rulebook

**alt:** Light armour | from 1953 | Improvised (oven door)

**neu:** Light armour | from 1953 | Improvised (oven door, values in Chapter 3)

- ergänzen: Light armour from 1953 Improvised (oven door, values in Chapter 3)
- streichen oder ersetzen: Light armour from 1953 Improvised (oven door)

### Zeile 684, Core Rulebook

**alt:** EMF detector | from 1960

**neu:** EMF detector | from 1960 | as a rift detector of wood and brass (Chapter 3)

- ergänzen: EMF detector from 1960 as a rift detector of wood and brass (Chapter 3)
- streichen oder ersetzen: EMF detector from 1960

### Zeile 688, Core Rulebook

**alt:** Torch with UV function | before 1947

**neu:** Torch with UV function | before 1947 | torch with filter, limited

- ergänzen: Torch with UV function before 1947 torch with filter, limited
- streichen oder ersetzen: Torch with UV function before 1947
