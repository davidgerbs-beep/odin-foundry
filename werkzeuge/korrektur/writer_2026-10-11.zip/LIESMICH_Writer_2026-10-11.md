# VTT-Abgleich: Änderungslisten des Writers

Stand 11.10.2026, ODIN Writer, für ODIN Coder und ODIN Checker (Common-Zeile „Die VTT-Journale … sind gegenüber den durchgesehenen Bänden veraltet“).

## Was hier liegt

Je Band und Sprache eine Datei `<Band>_<DE|EN>_alt_neu.md`. Sie ist aus den Quelltexten erzeugt, nicht von Hand geschrieben, und deshalb vollständig: jede geänderte Zeile mit Datei, Zeilennummer der neuen Fassung, nächster Überschrift (meist Akte, Einsatz, Knoten oder Gegnername) und dem Text alt und neu. Umgeschriebene und gestrichene Sätze stehen mit drin. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10. oder 11.10. (Handout-Prüfung, Durchsicht aus Spielersicht, Nachprüfung des Checkers). Oben in jeder Datei stehen die Stellen, an denen sich Gegnerwerte geändert haben.

| Band | DE | EN |
|---|---|---|
| Graue Akten | 132 Stellen | 131 |
| Nordlicht 1977 | 161 | 161 |
| Fremdkörper | 14 | 16 |
| Schnellstart | 8 | 8 |
| Die Tür | 4 | 4 |
| Horte der Welt | 1 | 1 |
| Spielleiterbuch, Anhang „Das Haus am Stausee“ | 1 | 2 |

Seitenzahlen fehlen, weil sich in Graue Akten und Nordlicht die Seiten verschoben haben. Die Überschrift führt schneller zur Stelle im Journal.

## Gegnerwerte

Die automatische Liste oben in jeder Datei findet Zeilen mit Initiative, Angriff, Verteidigung, Grauen, LP oder Rüstung. Dazu von Hand, aus den Änderungslisten der Durchsicht:

- **Graue Akten:** Werteblöcke in Akte 3 (Owen Gwynne, Alistair Vane, Mr. Hartley, Daniel Keane, Rhys Bowen) und Akte 5 (Thomas Leitner). Sundberg in Akte 6 hat keinen Angriff mehr.
- **Nordlicht 1977:** Söldner des Sammlers jetzt Handlanger wie im Anhang, Grauen der Menge Verstörend (2), Hunde Initiative 3, Verbindungsoffizier Initiative 3 und vor 1961 ohne Schleierprotokoll, Jäger der Abteilung 13 mit den Werten des Atlas, Haugen Elite mit 14 LP (vorher „Profi“ mit 15), Polizisten als Handlanger nach der Faustregel. Anhang B: Schwellenhüter und Kristallwächter mit den Werten der Einsätze.
- **Fremdkörper:** Callum Ferris hat sich in der Durchsicht nicht geändert (keine Zeile in der Liste). Weicht das Journal ab, gilt das Buch.
- **Martha Kellner und Spuk (Schnellstart, Spielleiterbuch, Die Tür Mission 1):** Die Durchsicht hat daran keinen Wert geändert. Neu ist nur der Satz, dass beim ersten Anblick eine Grauen-Probe gegen Grauenhaft (3) fällig ist, und das ist der Wert des Atlas. Die Änderungen an Martha (nur vier Spuke, Angriff nur gegen Erwachsene, −2 Würfel bei verpacktem Kristall) stehen seit jeher im Einsatz. Weicht das Journal davon ab, liegt der Fehler im Journal; Bezug sind die Wartende und der Spuk im Bedrohungsatlas plus der Kasten im Einsatz.

## Garn und Salz

- **Salz (Harald Ness):** Das Buch ist richtig. In der Durchsicht wurden alle sechs fertigen Agenten auf 35 Fertigkeitspunkte aufgefüllt, dazu gibt der Eskorte-Veteran jetzt +2 Schusswaffen. Daher Schusswaffen 5 (1947) und 6 (1977) und vier weitere Fertigkeiten 1 höher. Der Checker hat alle Summen und abgeleiteten Werte nachgerechnet. Das Journal hat den alten Stand.
- **Garn (Colette Marchais):** Im Buch steht IN 5 für 1947 und 1977, in DE und EN gleich, auch in der Fassung vor der Durchsicht. Eine IN 6 finde ich weder im Quelltext noch im PDF. Vermutlich hat die Textextraktion zwei Spalten vermischt (in der englischen PDF-Ausgabe steht neben ihrer Tabelle die von Ness). Foundry mit IN 5 ist also richtig, nur die Fertigkeiten haben sich geändert.

## Handouts

Geänderte Handout-Bilder, falls die Journale sie einbinden: Graue Akten 4.1 und 4.3 (DE und EN), 5.3 und 6.3 (nur EN, „Back:“), Die Tür Handout 9 (Legende). Die neuen Bilder liegen im Website-Ordner unter pakete/bilder.

## Ältere Änderungen

Am 05.10. gab es eine Runde „nicht nur“ (Satzmuster) in Graue Akten 03, 07, 08, Nordlicht 03 und 05 und im Spielleiterbuch 03. Die steckt nicht in diesen Listen. Fehlt sie auch im Journal, findet sie der Satzvergleich des Coders; auf Wunsch erzeuge ich die Listen dafür nach.
