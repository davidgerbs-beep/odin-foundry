# Nachträge zu den Vorschlagslisten: Schnellstart

Stand 11.10.2026, ODIN Writer. Hier stehen die Stellen, die das Vorschlagswerkzeug nicht abdeckt: Sätze, die im Band neu dazugekommen sind, und Sätze, die im Band weggefallen sind. Ermittelt aus dem Vergleich der Buchquellen vor und nach der Durchsicht (Listen in writer_2026-10-11), abzüglich aller Sätze, die in den Vorschlagslisten schon mit „ja“ stehen. Je Stelle der ganze Absatz alt und neu; „ergänzen“ und „streichen“ nennen die Sätze, die nach dem Übernehmen der Vorschläge noch fehlen oder übrig sind.

## Deutsch

### Zeile 47, Knoten 1: Der Makler

**alt:** Ein Agent oder Negotiator bekommt mit einer Probe auf Menschenkenntnis gegen Machbar (2) heraus, dass er etwas verschweigt: dass im Grundbuch ein Vermerk steht. Er ist der rote Hering. Wer ihn für den Täter hält, verliert Zeit.

**neu:** Wer ihn mit einer Probe auf Menschenkenntnis gegen Machbar (2) liest, etwa Echo oder Raven, merkt, dass er etwas verschweigt: dass im Grundbuch ein Vermerk steht. Er ist der rote Hering. Wer ihn für den Täter hält, verliert Zeit.

- ergänzen: Wer ihn mit einer Probe auf Menschenkenntnis gegen Machbar (2) liest, etwa Echo oder Raven, merkt, dass er etwas verschweigt: dass im Grundbuch ein Vermerk steht.
- streichen oder ersetzen: Ein Agent oder Negotiator bekommt mit einer Probe auf Menschenkenntnis gegen Machbar (2) heraus, dass er etwas verschweigt: dass im Grundbuch ein Vermerk steht.

### Zeile 56, Knoten 2: Die ersten Gäste

**alt:** - **Hinweis:** Sie haben ein Handyfoto vom Fenster. Ein Paranormal Detective oder Investigator mit Tatortbegehung sieht im Glas eine Spiegelung, die kein Möbelstück ist. (Ursprung Tote)

**neu:** - **Hinweis:** Sie haben ein Handyfoto vom Fenster. Wer das Foto genau ansieht, Wahrnehmung gegen Machbar (2), entdeckt im Glas eine Spiegelung, die kein Möbelstück ist. Ravens Geistersichtung gibt hier 2 Bonuswürfel. (Ursprung Tote)

- ergänzen: Wer das Foto genau ansieht, Wahrnehmung gegen Machbar (2), entdeckt im Glas eine Spiegelung, die kein Möbelstück ist.
- ergänzen: Ravens Geistersichtung gibt hier 2 Bonuswürfel.
- streichen oder ersetzen: Ein Paranormal Detective oder Investigator mit Tatortbegehung sieht im Glas eine Spiegelung, die kein Möbelstück ist.

### Zeile 65, Knoten 3: Das Dorf am See

**alt:** - **Hinweis:** Bei Niedrigwasser hört man vom See eine Kirchenglocke. Ein Physicist mit Messgeräten oder ein Thaumaturg mit Kristalldetektor bemerkt am Ufer einen Ausschlag. (Spur zur Stimme, optional)

**neu:** - **Hinweis:** Bei Niedrigwasser hört man vom See eine Kirchenglocke. Ein Thaumaturg hört am Ufer ein leises Flüstern aus dem Wasser, wie in der Nähe jedes Nexus-Kristalls. (Spur zur Stimme, optional)

- ergänzen: Ein Thaumaturg hört am Ufer ein leises Flüstern aus dem Wasser, wie in der Nähe jedes Nexus-Kristalls.
- streichen oder ersetzen: Ein Physicist mit Messgeräten oder ein Thaumaturg mit Kristalldetektor bemerkt am Ufer einen Ausschlag.

### Zeile 69, Knoten 4: Das Archiv

**alt:** Das Kreisarchiv oder das Kirchenbuch der gefluteten Gemeinde. Ein Antiquarian ist hier in seinem Element.

**neu:** Das Kreisarchiv oder das Kirchenbuch der gefluteten Gemeinde. Wer Geschichte oder Akademisches Wissen mitbringt, wie Folio, findet hier schnell, was er sucht.

- ergänzen: Wer Geschichte oder Akademisches Wissen mitbringt, wie Folio, findet hier schnell, was er sucht.
- streichen oder ersetzen: Ein Antiquarian ist hier in seinem Element.

### Zeile 87, Die Nacht

**alt:** Wer bis zum Abend im Haus bleibt, erlebt die Wartende. Die Türen schließen sich, die Fenster zeigen nur Wasser, und am Fenster sitzt eine alte Frau in einer Strickjacke und wartet. Sie ist freundlich zu Paul und eisig zu allen anderen.

**neu:** Wer bis zum Abend im Haus bleibt, erlebt die Wartende. Die Türen schließen sich, die Fenster zeigen nur Wasser, und am Fenster sitzt eine alte Frau in einer Strickjacke und wartet. Sie ist freundlich zu Paul und eisig zu allen anderen. Wer sie zum ersten Mal sieht, legt eine Grauen-Probe gegen Grauenhaft (3) ab.

- ergänzen: Wer sie zum ersten Mal sieht, legt eine Grauen-Probe gegen Grauenhaft (3) ab.

### Zeile 115, Nachspiel

**alt:** - **EP:** 5 pro Charakter, +1 für die Lösung mit der Wahrheit.

**neu:** - **EP:** Graue Akte, Grundwert 4 EP. Dazu +1 EP, wenn die Familie lebend aus dem Haus kommt, höchstens +1 EP persönlicher Bonus, etwa für die Lösung mit der Wahrheit, und +1 EP, wenn die Zelle den Kristall im Seegrund findet (ein Faden).

- ergänzen: EP: Graue Akte, Grundwert 4 EP.
- ergänzen: Dazu +1 EP, wenn die Familie lebend aus dem Haus kommt, höchstens +1 EP persönlicher Bonus, etwa für die Lösung mit der Wahrheit, und +1 EP, wenn die Zelle den Kristall im Seegrund findet (ein Faden).
- streichen oder ersetzen: EP: 5 pro Charakter, +1 für die Lösung mit der Wahrheit.

### Zeile 11, Wie es weitergeht

**alt:** Wer tiefer einsteigen will, findet sechs Klassenbücher, ein Arsenal mit 201 Gegenständen, ein Spielleiterbuch und die Kampagne „Die Tür“. Die Kampagne beginnt in derselben Villa am Stausee, in der dieser Einsatz spielt. Die Örtlichkeiten sind bereits bekannt. Die Ereignisse dieses Abends können als Vorgeschichte dienen oder unberührt bleiben. Die Kampagne setzt keine Kenntnis des Schnellstarts voraus, aber sie verträgt sie.

**neu:** Wer tiefer einsteigen will, findet sechs Klassenbücher, das Ausrüstungsbuch Arsenal, ein Spielleiterbuch und die Kampagne „Die Tür“. Ihre erste Mission ist genau dieser Einsatz, mit einer Ergänzung im Nachspiel. Wer den Schnellstart gespielt hat, steigt mit Mission 2 ein. Was die Zelle mit Martha Kellner und dem Kristall getan hat, zählt dann für die Kampagne, und die Messingkapsel an der Glocke schickt der Taucher des Horts eine Woche später.

- ergänzen: Ihre erste Mission ist genau dieser Einsatz, mit einer Ergänzung im Nachspiel.
- ergänzen: Wer den Schnellstart gespielt hat, steigt mit Mission 2 ein.
- ergänzen: Was die Zelle mit Martha Kellner und dem Kristall getan hat, zählt dann für die Kampagne, und die Messingkapsel an der Glocke schickt der Taucher des Horts eine Woche später.
- streichen oder ersetzen: Die Kampagne beginnt in derselben Villa am Stausee, in der dieser Einsatz spielt.
- streichen oder ersetzen: Die Örtlichkeiten sind bereits bekannt.
- streichen oder ersetzen: Die Ereignisse dieses Abends können als Vorgeschichte dienen oder unberührt bleiben.
- streichen oder ersetzen: Die Kampagne setzt keine Kenntnis des Schnellstarts voraus, aber sie verträgt sie.

## Englisch

### Zeile 47, Node 1: The Estate Agent

**alt:** An Agent or Negotiator finds out with a test on Insight against Doable (2) that he is concealing something: that there is a note in the land register. He is the red herring. Whoever takes him for the perpetrator loses time.

**neu:** Whoever reads him with a test on Insight against Doable (2), Echo or Raven for instance, notices that he is concealing something: that there is a note in the land register. He is the red herring. Whoever takes him for the perpetrator loses time.

- ergänzen: Whoever reads him with a test on Insight against Doable (2), Echo or Raven for instance, notices that he is concealing something: that there is a note in the land register.
- streichen oder ersetzen: An Agent or Negotiator finds out with a test on Insight against Doable (2) that he is concealing something: that there is a note in the land register.

### Zeile 56, Node 2: The First Guests

**alt:** - **Clue:** They have a mobile phone photo of the window. A Paranormal Detective or Investigator with Crime Scene Investigation sees in the glass a reflection that is not a piece of furniture. (Origin: the dead)

**neu:** - **Clue:** They have a mobile phone photo of the window. Whoever studies the photo closely, Perception against Doable (2), spots in the glass a reflection that is not a piece of furniture. Raven’s Ghost Sight gives 2 bonus dice here. (Origin: the dead)

- ergänzen: Whoever studies the photo closely, Perception against Doable (2), spots in the glass a reflection that is not a piece of furniture.
- ergänzen: Raven's Ghost Sight gives 2 bonus dice here.
- streichen oder ersetzen: A Paranormal Detective or Investigator with Crime Scene Investigation sees in the glass a reflection that is not a piece of furniture.

### Zeile 65, Node 3: The Village by the Lake

**alt:** - **Clue:** At low water one hears a church bell from the lake. A Physicist with measuring instruments or a Thaumaturge with a crystal detector notices a reading on the shore. (lead to the voice, optional)

**neu:** - **Clue:** At low water one hears a church bell from the lake. A Thaumaturge on the shore hears a faint whisper from the water, as near any Nexus crystal. (lead to the voice, optional)

- ergänzen: A Thaumaturge on the shore hears a faint whisper from the water, as near any Nexus crystal.
- streichen oder ersetzen: A Physicist with measuring instruments or a Thaumaturge with a crystal detector notices a reading on the shore.

### Zeile 69, Node 4: The Archive

**alt:** The district archive or the church register of the flooded parish. An Antiquarian is in their element here.

**neu:** The district archive or the church register of the flooded parish. Whoever brings History or Academic Knowledge, like Folio, quickly finds what they are looking for.

- ergänzen: Whoever brings History or Academic Knowledge, like Folio, quickly finds what they are looking for.
- streichen oder ersetzen: An Antiquarian is in their element here.

### Zeile 87, The Night

**alt:** Anyone who stays in the house until evening experiences the Waiting One. The doors close, the windows show only water, and at the window sits an old woman in a cardigan, waiting. She is friendly to Paul and icy to everyone else.

**neu:** Anyone who stays in the house until evening experiences the Waiting One. The doors close, the windows show only water, and at the window sits an old woman in a cardigan, waiting. She is friendly to Paul and icy to everyone else. Anyone who sees her for the first time makes a horror test against Horrifying (3).

- ergänzen: Anyone who sees her for the first time makes a horror test against Horrifying (3).

### Zeile 115, Aftermath

**alt:** - **XP:** 5 per character, +1 for the solution with the truth.

**neu:** - **XP:** Grey File, base value 4 XP. Plus 1 XP if the family leaves the house alive, at most 1 XP personal bonus, for example for the solution with the truth, and 1 XP if the cell finds the crystal in the lake bed (a thread).

- ergänzen: XP: Grey File, base value 4 XP.
- ergänzen: Plus 1 XP if the family leaves the house alive, at most 1 XP personal bonus, for example for the solution with the truth, and 1 XP if the cell finds the crystal in the lake bed (a thread).
- streichen oder ersetzen: XP: 5 per character, +1 for the solution with the truth.

### Zeile 7, What Happens Next

**alt:** The core rulebook comprises 88 pages and is free. It contains the complete dice system, character creation in nine steps, six classes with thirty subclasses, 63 skills, psi powers, spells, equipment and the rules for advancement. Anyone who wants to use the system fully will find everything necessary there. The file is available at odin-rpg.pages.dev.

**neu:** The core rulebook is free. It contains the complete dice system, character creation in nine steps, six classes with thirty subclasses, 63 skills, psi powers, spells, equipment and the rules for advancement. Anyone who wants to use the system fully will find everything necessary there. The file is available at odin-rpg.pages.dev.

- ergänzen: The core rulebook is free.
- streichen oder ersetzen: The core rulebook comprises 88 pages and is free.

### Zeile 11, What Happens Next

**alt:** Those who want to go deeper will find six class books, an arsenal with 201 items, a game master book and the campaign “The Door”. The campaign begins in the same villa by the reservoir where this mission takes place. The locations are already known. The events of this evening can serve as backstory or remain untouched. The campaign does not require knowledge of the Quickstart, but it can accommodate it.

**neu:** Those who want to go deeper will find six class books, the equipment book Arsenal, a game master book and the campaign “The Door”. Its first mission is exactly this one, with an addition in the aftermath. Groups that have played the Quickstart start with Mission 2. What the cell did with Martha Kellner and the crystal then counts for the campaign, and the Hold’s diver sends the brass capsule from the bell a week later.

- ergänzen: Its first mission is exactly this one, with an addition in the aftermath.
- ergänzen: Groups that have played the Quickstart start with Mission 2.
- ergänzen: What the cell did with Martha Kellner and the crystal then counts for the campaign, and the Hold's diver sends the brass capsule from the bell a week later.
- streichen oder ersetzen: The campaign begins in the same villa by the reservoir where this mission takes place.
- streichen oder ersetzen: The locations are already known.
- streichen oder ersetzen: The events of this evening can serve as backstory or remain untouched.
- streichen oder ersetzen: The campaign does not require knowledge of the Quickstart, but it can accommodate it.
