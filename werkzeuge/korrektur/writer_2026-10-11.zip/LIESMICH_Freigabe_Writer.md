# Freigabe der Vorschlagslisten (ODIN Writer, 11.10.2026)

## Wie entschieden wurde

Maßstab ist der Band, wie er jetzt im Website-Ordner liegt. Jeder Vorschlag wurde gegen die Buchquellen geprüft, nicht gegen das PDF:

- **ja, „neu“ unverändert:** Der Satz steht genau so im Band, und der alte Satz steht dort nicht mehr. Graue Akten 129, Nordlicht 146, Die Tür 4, Schnellstart 5.
- **ja, „neu“ nachgebessert:** Die Textextraktion hatte den Satz abgeschnitten, zwei Spalten vermischt oder einen Nachsatz weggelassen. „neu“ ist jetzt der vollständige Satz aus dem Band, mit den Anführungszeichen des Bandes. Graue Akten 24, Nordlicht 31. Bei zwei Gegnerzeilen (Mr. Hartley, DE und EN) fehlte am Ende „Verdeckt“ bzw. „Concealed“.
- **nein:** Fehltreffer oder Tabellenzellen, die das Werkzeug nicht sauber trennt. Nordlicht 8 (zwei verstümmelte Abschnittsüberschriften je Sprache, die Tabelle „Die Organisation je Abschnitt“, zweimal steht der alte Satz noch so im Band), Schnellstart 1 (Absatz neu geschrieben).

## Was die Listen nicht abdecken

`writer_nachtraege_<Band>.md`: je Stelle der ganze Absatz alt und neu und darunter die Sätze, die nach dem Übernehmen der Vorschläge noch fehlen („ergänzen“) oder übrig bleiben („streichen oder ersetzen“). Dazu gehören Tabellenzeilen (etwa die Aktenfarben in Graue Akten), ganz neue Sätze und der Messer-Satz in Horte der Welt. Erzeugt aus dem Vergleich der Buchquellen; Stellen, die schon über ein „ja“ abgedeckt sind, sind herausgerechnet. Ein paar Treffer können doppelt sein, wenn Satzgrenzen anders liegen: Was im Journal schon richtig steht, einfach überspringen.

Gegnerwerte: alle Vorschläge zu Gegnerzeilen stehen auf „ja“, weil die neuen Werte im Band stehen (vom Checker in den Freigaben geprüft). Dazu der Hinweis des Checkers: Bei Martha Kellner im Feld „Besonderheit“ vier statt zwölf Tote.
