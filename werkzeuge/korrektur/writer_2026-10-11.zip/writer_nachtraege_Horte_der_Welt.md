# Nachträge zu den Vorschlagslisten: Horte der Welt

Stand 11.10.2026, ODIN Writer. Hier stehen die Stellen, die das Vorschlagswerkzeug nicht abdeckt: Sätze, die im Band neu dazugekommen sind, und Sätze, die im Band weggefallen sind. Ermittelt aus dem Vergleich der Buchquellen vor und nach der Durchsicht (Listen in writer_2026-10-11), abzüglich aller Sätze, die in den Vorschlagslisten schon mit „ja“ stehen. Je Stelle der ganze Absatz alt und neu; „ergänzen“ und „streichen“ nennen die Sätze, die nach dem Übernehmen der Vorschläge noch fehlen oder übrig sind.

## Deutsch

### Zeile 33, Geschichte

**alt:** **1955.** Evan Pryce übergibt Ashgrove das erste Messer aus Aschesilber. Ashgrove gibt es in die Waffenkammer von Hort-1, wo es bis heute liegt.

**neu:** **1955.** Evan Pryce übergibt Ashgrove das erste Messer aus Aschesilber. Ashgrove trägt es bis zu seinem Tod; seitdem liegt es in der Waffenkammer von Hort-1.

- ergänzen: Ashgrove trägt es bis zu seinem Tod; seitdem liegt es in der Waffenkammer von Hort-1.
- streichen oder ersetzen: Ashgrove gibt es in die Waffenkammer von Hort-1, wo es bis heute liegt.

## Englisch

### Zeile 33, History

**alt:** **1955.** Evan Pryce hands Ashgrove the first knife made of ashsilver. Ashgrove places it in the armoury of Hold-1, where it lies to this day.

**neu:** **1955.** Evan Pryce hands Ashgrove the first knife made of ashsilver. Ashgrove carries it until his death; since then it has lain in the armoury of Hold-1.

- ergänzen: Ashgrove carries it until his death; since then it has lain in the armoury of Hold-1.
- streichen oder ersetzen: Ashgrove places it in the armoury of Hold-1, where it lies to this day.
