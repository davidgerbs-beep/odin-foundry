# Nachträge zu den Vorschlagslisten: Graue Akten

Stand 11.10.2026, ODIN Writer. Hier stehen die Stellen, die das Vorschlagswerkzeug nicht abdeckt: Sätze, die im Band neu dazugekommen sind, und Sätze, die im Band weggefallen sind. Ermittelt aus dem Vergleich der Buchquellen vor und nach der Durchsicht (Listen in writer_2026-10-11), abzüglich aller Sätze, die in den Vorschlagslisten schon mit „ja“ stehen. Je Stelle der ganze Absatz alt und neu; „ergänzen“ und „streichen“ nennen die Sätze, die nach dem Übernehmen der Vorschläge noch fehlen oder übrig sind.

## Deutsch

### Zeile 31, Die acht Akten

**alt:** 3 | Nummer 341 | Cardiff, Grangetown | Die Toten, Menschen | Grau

**neu:** 3 | Nummer 341 | Cardiff, Grangetown | Die Toten, Menschen | Grau, kann rot werden

- ergänzen: 3 Nummer 341 Cardiff, Grangetown Die Toten, Menschen Grau, kann rot werden
- streichen oder ersetzen: 3 Nummer 341 Cardiff, Grangetown Die Toten, Menschen Grau

### Zeile 36, Die acht Akten

**alt:** 8 | Das Zweite Licht | Brüssel, Anderlecht | Menschen, Stimme | Grau

**neu:** 8 | Das Zweite Licht | Brüssel, Anderlecht | Menschen, Stimme | Grau, kann rot werden

- ergänzen: 8 Das Zweite Licht Brüssel, Anderlecht Menschen, Stimme Grau, kann rot werden
- streichen oder ersetzen: 8 Das Zweite Licht Brüssel, Anderlecht Menschen, Stimme Grau

### Zeile 63, Akten verbinden

**alt:** Einige Akten teilen offene Fäden. Das Lied der Kinder taucht in den Akten 5, 6 und 7 auf. Die Uhrzeit 22:10 erscheint in den Akten 2 und 3. Das unbekannte Kürzel im Kristallbuch verbindet Akte 1 mit Akte 2. Die Spielleitung kann diese Fäden aufgreifen, wenn sie die Akten in eine Kampagne einstreut. Jede Akte funktioniert auch allein.

**neu:** Einige Akten teilen offene Fäden. Das Lied der Kinder taucht in den Akten 5, 6 und 7 auf. Die Uhrzeit 22:10 erscheint in den Akten 2, 3 und 6. Das unbekannte Kürzel im Kristallbuch verbindet Akte 1 mit Akte 2. Die Spielleitung kann diese Fäden aufgreifen, wenn sie die Akten in eine Kampagne einstreut. Jede Akte funktioniert auch allein.

- ergänzen: Die Uhrzeit 22:10 erscheint in den Akten 2, 3 und 6.
- streichen oder ersetzen: Die Uhrzeit 22:10 erscheint in den Akten 2 und 3.

### Zeile 22, Was wirklich geschah

**alt:** Seit einigen Wochen hört Linus ein Summen, das lauter wird. Er schläft schlecht, isst wenig, und wenn er sich konzentriert, werden Dinge warm. Vor drei Wochen fand er am Elbufer einen kleinen, milchigen Kristall, der das Summen dämpfte, wenn er ihn festhielt. Er nahm ihn mit nach Hause und versteckte ihn unter der Matratze. Gestern Abend war er bei den Kowalskis, um den Fischen beim Schwimmen zuzusehen. Er dachte an nichts, nur an das Wasser, und das Wasser begann zu kochen. Linus rannte nach Hause, packte seinen Rucksack und verschwand. Er will nicht, dass seine Eltern seinetwegen Ärger bekommen. Er ist zu Fuß Richtung S-Bahn, dann in die Innenstadt, und sucht einen Ort, an dem es still ist. Er hat sich im alten Elbtunnel versteckt, in der Oströhre, wo das Summen leiser ist.

**neu:** Seit einigen Wochen hört Linus ein Summen, das lauter wird. Er schläft schlecht, isst wenig, und wenn er sich konzentriert, werden Dinge warm. Vor drei Wochen fand er am Elbufer einen kleinen, milchigen Kristall, der das Summen dämpfte, solange er ihn festhielt. Ließ er ihn los, kam das Summen lauter zurück: Der Stein nährt die Gabe. Linus nahm ihn mit nach Hause und versteckte ihn unter der Matratze. Gestern Abend war er bei den Kowalskis, um den Fischen beim Schwimmen zuzusehen. Er dachte an nichts, nur an das Wasser, und das Wasser begann zu kochen. Linus rannte nach Hause, packte seinen Rucksack und verschwand. Er will nicht, dass seine Eltern seinetwegen Ärger bekommen. Er ist zu Fuß Richtung S-Bahn, dann in die Innenstadt, und sucht einen Ort, an dem es still ist. Er hat sich im alten Elbtunnel versteckt, in der Oströhre, wo das Summen leiser ist.

- ergänzen: Ließ er ihn los, kam das Summen lauter zurück: Der Stein nährt die Gabe.
- ergänzen: Linus nahm ihn mit nach Hause und versteckte ihn unter der Matratze.
- streichen oder ersetzen: Er nahm ihn mit nach Hause und versteckte ihn unter der Matratze.

### Zeile 44, Herr Kowalski, 52

**alt:** Nachbar, Versicherungskaufmann. Will Ruhe und eine Erklärung für das tote Aquarium. Weiß nichts Übernatürliches, verdächtigt einen ehemaligen Mieter. Verschweigt, dass er die Polizei doch gerufen hat, weil er den Vossens nicht traut. Redet laut, empört, wiederholt sich.

**neu:** Nachbar, Versicherungskaufmann. Will Ruhe und eine Erklärung für das tote Aquarium. Weiß nichts Übernatürliches, verdächtigt einen ehemaligen Mieter. Verschweigt, dass er gestern Abend wegen des Aquariums doch die Polizei gerufen hat, weil er den Vossens nicht traut. Die Streife kam, fand nichts und fuhr wieder. Redet laut, empört, wiederholt sich.

- ergänzen: Die Streife kam, fand nichts und fuhr wieder.

### Zeile 127, Eskalation

**alt:** Die Akte wird rot, wenn die Zelle zu langsam ist oder wenn Jonas Vogt sie bemerkt. Vogt ist kein Mörder, aber er wird Linus nicht kampflos gehen lassen. Wenn die Zelle den alten Elbtunnel betritt, ohne sich zu verbergen, spricht Vogt sie mit Namen an und stellt sich zwischen sie und Linus. Linus' Gabe reagiert auf die Anspannung: Die Lampen im Tunnel flackern, das Wasser in den Pfützen beginnt zu dampfen.

**neu:** Die Akte wird rot, wenn die Zelle zu langsam ist oder wenn Jonas Vogt sie bemerkt. Zu langsam ist sie, wenn sie mehr als drei Knoten besucht, bevor sie zum alten Elbtunnel aufbricht. Vogt ist kein Mörder, aber er wird Linus nicht kampflos gehen lassen. Wenn die Zelle den alten Elbtunnel betritt, ohne sich zu verbergen, spricht Vogt sie mit Namen an und stellt sich zwischen sie und Linus. Linus' Gabe reagiert auf die Anspannung: Die Lampen im Tunnel flackern, das Wasser in den Pfützen beginnt zu dampfen.

- ergänzen: Zu langsam ist sie, wenn sie mehr als drei Knoten besucht, bevor sie zum alten Elbtunnel aufbricht.

### Zeile 197, Linus Voss

**alt:** Die Offenen als Organisation, ihre Ziele und weitere Gegner stehen im Bedrohungsatlas. Die Werte des Offenen (Elite) stammen aus dem Baustein Psion, die Werte für Linus aus dem Eintrag Chorkind im Bedrohungsatlas. Maren Falk, die Beobachterin, erscheint nur, wenn die Zelle sie anfordert. Sie hat keine Kampfwerte, kann aber am Telefon Hinweise geben.

**neu:** Die Offenen als Organisation und ihre Ziele stehen im Kapitel „Die Welt hinter dem Schleier“ des Spielleiterbuchs, weitere Gegner im Bedrohungsatlas. Die Werte des Offenen (Elite) stammen aus dem Baustein Psion, die Werte für Linus aus dem Eintrag Chorkind im Bedrohungsatlas. Maren Falk, die Beobachterin, erscheint nur, wenn die Zelle sie anfordert. Sie hat keine Kampfwerte, kann aber am Telefon Hinweise geben.

- ergänzen: Die Offenen als Organisation und ihre Ziele stehen im Kapitel "Die Welt hinter dem Schleier" des Spielleiterbuchs, weitere Gegner im Bedrohungsatlas.
- streichen oder ersetzen: Die Offenen als Organisation, ihre Ziele und weitere Gegner stehen im Bedrohungsatlas.

### Zeile 205, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter. Plus 1 EP für eine Lösung ohne Kampf. Plus 1 EP für die Rettung des Kristalls.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn Linus in Sicherheit ist. Höchstens +1 EP persönlicher Bonus, etwa für eine Lösung ohne Kampf. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa das Kürzel im Kristallbuch.

- ergänzen: Erfahrung: 4 EP pro Charakter, 5, wenn die Akte rot geworden ist.
- ergänzen: +1 EP, wenn Linus in Sicherheit ist.
- ergänzen: Höchstens +1 EP persönlicher Bonus, etwa für eine Lösung ohne Kampf.
- ergänzen: +1 EP für jeden Faden, den die Zelle aufnimmt, etwa das Kürzel im Kristallbuch.
- streichen oder ersetzen: Erfahrung: 5 EP pro Charakter.
- streichen oder ersetzen: Plus 1 EP für eine Lösung ohne Kampf.
- streichen oder ersetzen: Plus 1 EP für die Rettung des Kristalls.

### Zeile 14, Worum es geht

**alt:** Dort, im Keller des Horts, gibt es laut alten Bauplänen einen Raum mit der Nummer 4/12. In den offiziellen Begehungen existiert er nicht. Die Zelle soll herausfinden, was es mit dem Raum auf sich hat, ohne den Hort zu alarmieren. Der Führungsoffizier der Zelle weiß nichts von dem Auftrag.

**neu:** Dort, im Keller des Horts, gibt es laut alten Bauplänen einen Raum mit der Nummer 4/12. Im aktuellen Grundriss fehlt er. Die Zelle soll herausfinden, was es mit dem Raum auf sich hat, ohne den Hort zu alarmieren. Der Führungsoffizier der Zelle weiß nichts von dem Auftrag.

- ergänzen: Im aktuellen Grundriss fehlt er.
- streichen oder ersetzen: In den offiziellen Begehungen existiert er nicht.

### Zeile 20, Was wirklich geschah

**alt:** **Die Vorgeschichte:** Hort-9 in Prag wurde 1992 gegründet, in einem alten Kellergewölbe unter der Altstadt. Der Bauplan von 1991 zeigt zwölf Räume im Untergeschoss. Gebaut wurden elf. Der zwölfte Raum, Nummer 4/12, existiert nur auf dem Papier, aber nicht in der Realität. So steht es in den offiziellen Unterlagen.

**neu:** **Die Vorgeschichte:** Hort-9 in Prag wurde 1992 gegründet, in einem alten Kellergewölbe unter der Altstadt. Der Umbauplan von 1991 übernimmt die Zählung des alten Luftschutzkellers und zeigt zwölf Räume im Untergeschoss. Ausgebaut wurden elf. Der zwölfte Raum, Nummer 4/12, existiert nur auf dem Papier, aber nicht in der Realität. So steht es im aktuellen Grundriss.

- ergänzen: Ausgebaut wurden elf.
- ergänzen: So steht es im aktuellen Grundriss.
- streichen oder ersetzen: Gebaut wurden elf.
- streichen oder ersetzen: So steht es in den offiziellen Unterlagen.

### Zeile 30, Was wirklich geschah

**alt:** **Der rote Hering:** Der Hortleiter von Hort-9, Major Pavel Černý, ein Soldier alter Schule, hält den Raum für ein Artefakt der kommunistischen Vergangenheit: ein ehemaliger Abhörraum des tschechoslowakischen Geheimdienstes, der in den Plänen fehlt, weil er nie offiziell existierte. Er hat den Raum vor Jahren gefunden, aber nie betreten, weil er glaubt, er sei eine Falle. Er hat die Tür mit einem Vorhängeschloss versehen und den Raum aus den aktuellen Plänen streichen lassen. Er verschweigt das, weil er befürchtet, dass O.D.I.N. den Hort schließen würde, wenn bekannt wird, dass es dort einen unbekannten Raum gibt.

**neu:** **Der rote Hering:** Der Hortleiter von Hort-9, Major Pavel Černý, ein Soldier alter Schule, hält den Raum für ein Artefakt der kommunistischen Vergangenheit: ein ehemaliger Abhörraum des tschechoslowakischen Geheimdienstes, der in den Plänen fehlt, weil er nie offiziell existierte. Er hat den Raum vor Jahren gefunden, aber nie betreten, weil er glaubt, er sei eine Falle. Er hat die Tür mit einem Vorhängeschloss versehen und den Raum aus den aktuellen Plänen streichen lassen, von einer Baufirma, die es nicht gibt, bezahlt aus der Hortkasse. Er verschweigt das, weil er befürchtet, dass O.D.I.N. den Hort schließen würde, wenn bekannt wird, dass es dort einen unbekannten Raum gibt.

- ergänzen: Er hat die Tür mit einem Vorhängeschloss versehen und den Raum aus den aktuellen Plänen streichen lassen, von einer Baufirma, die es nicht gibt, bezahlt aus der Hortkasse.
- streichen oder ersetzen: Er hat die Tür mit einem Vorhängeschloss versehen und den Raum aus den aktuellen Plänen streichen lassen.

### Zeile 48, Ing. Marta Nováková, 47

**alt:** Bauingenieurin und Horttechnikerin. Sie kennt die Pläne des Horts besser als jeder andere. Sie will, dass die Pläne stimmen, und es beunruhigt sie, dass Raum 4/12 im aktuellen Plan fehlt. Sie weiß, dass Černý den Raum gefunden hat, aber sie hat ihn nie betreten. Sie verschweigt, dass sie einmal nachts ein Klopfen aus dem Raum gehört hat, obwohl er leer sein müsste. Sie redet schnell, technisch, mit vielen Zahlen.

**neu:** Bauingenieurin und Horttechnikerin. Sie kennt die Pläne des Horts besser als jeder andere. Sie will, dass die Pläne stimmen, und es beunruhigt sie, dass Raum 4/12 im aktuellen Plan fehlt. Sie weiß, dass Černý den Raum gefunden hat, aber sie hat ihn nie betreten. Sie verschweigt, dass sie einmal nachts ein Klopfen aus dem Raum gehört hat, obwohl er leer sein müsste. Ing. K. Svoboda, der die alten Pläne mit Bleistift ergänzt und 1992 die erste Begehung gemacht hat, war ihr Lehrmeister. Sie weiß, dass er Raum 4/12 nie öffnen wollte. Sie redet schnell, technisch, mit vielen Zahlen.

- ergänzen: Ing.
- ergänzen: K.
- ergänzen: Svoboda, der die alten Pläne mit Bleistift ergänzt und 1992 die erste Begehung gemacht hat, war ihr Lehrmeister.
- ergänzen: Sie weiß, dass er Raum 4/12 nie öffnen wollte.

### Zeile 56, Eliška, 12

**alt:** Tochter eines externen Dienstleisters. Ihr Vater wartet die Heizungsanlage des Horts, und sie begleitet ihn manchmal in den Keller. Sie hat den Hort oft erkundet. Sie will Abenteuer erleben und von den Agenten ernst genommen werden. Sie weiß, dass der Raum 4/12 manchmal da ist und manchmal nicht. Sie verschweigt, dass sie einmal durch das Schlüsselloch gesehen hat, dass der Raum innen größer ist als außen. Sie redet schnell, neugierig, mit kindlicher Direktheit.

**neu:** Tochter eines Zivilangestellten des Horts. Ihr Vater hilft Marta Nováková bei der Wartung der Heizung, und sie begleitet ihn manchmal in den Keller. Sie hat den Hort oft erkundet. Sie will Abenteuer erleben und von den Agenten ernst genommen werden. Sie weiß, dass der Raum 4/12 manchmal da ist und manchmal nicht. Sie verschweigt, dass sie einmal durch das Schlüsselloch gesehen hat, dass der Raum innen größer ist als außen. Sie redet schnell, neugierig, mit kindlicher Direktheit.

- ergänzen: Tochter eines Zivilangestellten des Horts.
- streichen oder ersetzen: Tochter eines externen Dienstleisters.

### Zeile 74, Briefing

**alt:** **Der private Gefallen:** Dr. Brandl kontaktiert die Zelle vor dem Briefing, über einen toten Briefkasten oder ein persönliches Treffen. Sie gibt der Zelle einen Zettel mit dem Kürzel „Stille 4/12“ und dem Hinweis auf Hort-9 (Handout 2.1). Sie bittet die Zelle, herauszufinden, was das Kürzel bedeutet, und ihr zu berichten. Sie bietet als Gegenleistung einen Gefallen: Zugang zum Kristallarchiv in Oxford oder ein Empfehlungsschreiben an die Siegelwahrer.

**neu:** **Der private Gefallen:** Dr. Brandl kontaktiert die Zelle vor dem Briefing, über einen toten Briefkasten oder ein persönliches Treffen. Sie gibt der Zelle einen Zettel mit dem Kürzel „Stille 4/12“ und dem Hinweis auf Hort-9 (Handout 2.1). Sie bittet die Zelle, herauszufinden, was das Kürzel bedeutet, und ihr zu berichten. Sie bietet als Gegenleistung einen Gefallen: Zugang zum Kristallarchiv in Oxford oder ein Empfehlungsschreiben an die Siegelwahrer. Fragt die Zelle nach Ausrüstung, gibt Brandl ihr einen Beryllium-Isolierbehälter aus der Werkstatt von Hort-7 mit.

- ergänzen: Fragt die Zelle nach Ausrüstung, gibt Brandl ihr einen Beryllium-Isolierbehälter aus der Werkstatt von Hort-7 mit.

### Zeile 86, Knoten 1: Das Hortarchiv

**alt:** - **Hinweis:** Ein Begehungsprotokoll von 1992 erwähnt „Unregelmäßigkeiten im Untergeschoss, Raum 4/12 nicht betreten“ (Handout 2.2). (führt zu Černý, Knoten 2)

**neu:** - **Hinweis:** Ein Begehungsprotokoll von 1992 vermerkt: „Raum 4/12 nicht betreten. Tür verschlossen, Schlüssel nicht auffindbar.“ (Handout 2.2). (führt zu Černý, Knoten 2)

- ergänzen: Tür verschlossen, Schlüssel nicht auffindbar." (Handout 2.2).

### Zeile 104, Knoten 3: Die Kantine

**alt:** - **Hinweis:** Eliška erzählt, dass der Raum manchmal da ist und manchmal nicht. (führt zu Raum 4/12) - **Hinweis:** Eliška hat durch das Schlüsselloch gesehen, dass der Raum innen größer ist als außen. (führt zu Raum 4/12)

**neu:** - **Hinweis:** Eliška erzählt, dass der Raum manchmal da ist und manchmal nicht. (führt zu Raum 4/12, Schlussfolgerung 2) - **Hinweis:** Eliška hat durch das Schlüsselloch gesehen, dass der Raum innen größer ist als außen. (führt zu Raum 4/12, Schlussfolgerung 2)

- ergänzen: (führt zu Raum 4/12, Schlussfolgerung 2) - Hinweis: Eliška hat durch das Schlüsselloch gesehen, dass der Raum innen größer ist als außen.
- ergänzen: (führt zu Raum 4/12, Schlussfolgerung 2)
- streichen oder ersetzen: (führt zu Raum 4/12) - Hinweis: Eliška hat durch das Schlüsselloch gesehen, dass der Raum innen größer ist als außen.
- streichen oder ersetzen: (führt zu Raum 4/12)

### Zeile 107, Knoten 3: Die Kantine

**alt:** - **Hinweis:** Ein Agent findet in Černýs Dienstakte Unregelmäßigkeiten in den Hortfinanzen: Zahlungen an eine Baufirma, die es nicht gibt. (führt zu Černý, Knoten 2)

**neu:** - **Hinweis:** Die Hortköchin, die auch die Kasse führt, wundert sich über Zahlungen an eine Baufirma, die nie im Hort war. (führt zu Černý, Knoten 2)

- ergänzen: Hinweis: Die Hortköchin, die auch die Kasse führt, wundert sich über Zahlungen an eine Baufirma, die nie im Hort war.
- streichen oder ersetzen: Hinweis: Ein Agent findet in Černýs Dienstakte Unregelmäßigkeiten in den Hortfinanzen: Zahlungen an eine Baufirma, die es nicht gibt.

### Zeile 115, Knoten 4: Der Kellerflur vor Raum 4/12

**alt:** - **Hinweis:** Ein Psion hört in der Nähe des Raums eine Stille, die tiefer ist als jede Abschirmung: keine Gedanken, kein Summen, nichts. (führt zu Raum 4/12)

**neu:** - **Hinweis:** Ein Psion hört in der Nähe des Raums die eigenen Gedanken einen Herzschlag zu spät zurückkommen, als hallten sie aus einer anderen Zeit. (führt zu Raum 4/12, Schlussfolgerung 2)

- ergänzen: Hinweis: Ein Psion hört in der Nähe des Raums die eigenen Gedanken einen Herzschlag zu spät zurückkommen, als hallten sie aus einer anderen Zeit.
- ergänzen: (führt zu Raum 4/12, Schlussfolgerung 2)
- streichen oder ersetzen: Hinweis: Ein Psion hört in der Nähe des Raums eine Stille, die tiefer ist als jede Abschirmung: keine Gedanken, kein Summen, nichts.
- streichen oder ersetzen: (führt zu Raum 4/12)

### Zeile 127, Knoten 5: Raum 4/12 und der Raum hinter der Tür

**alt:** - **Hinweis:** Ein Scientist mit Physik erkennt, dass die Raumgeometrie nicht stimmt: Der Raum ist innen 1,2 Meter länger als außen. (führt zu Schlussfolgerung 4) - **Hinweis:** Ein Thaumaturg, der den Stein berührt, spürt, dass er warm ist und flüstert, und dass das Flüstern lauter wird, wenn man ihn anhebt. (führt zu Schlussfolgerung 4)

**neu:** - **Hinweis:** Ein Scientist mit Physik erkennt, dass die Raumgeometrie nicht stimmt: Der Raum ist innen 1,2 Meter länger als außen, und am stärksten verzieht sich die Geometrie um den Tisch mit dem Stein. (führt zu Schlussfolgerung 2 und 4) - **Hinweis:** Ein Thaumaturg, der den Stein berührt, spürt, dass er warm ist und flüstert, und dass das Flüstern lauter wird, wenn man ihn anhebt. Dabei verziehen sich die Wände des Raums. (führt zu Schlussfolgerung 4)

- ergänzen: Hinweis: Ein Scientist mit Physik erkennt, dass die Raumgeometrie nicht stimmt: Der Raum ist innen 1,2 Meter länger als außen, und am stärksten verzieht sich die Geometrie um den Tisch mit dem Stein.
- ergänzen: (führt zu Schlussfolgerung 2 und 4) - Hinweis: Ein Thaumaturg, der den Stein berührt, spürt, dass er warm ist und flüstert, und dass das Flüstern lauter wird, wenn man ihn anhebt.
- ergänzen: Dabei verziehen sich die Wände des Raums.
- streichen oder ersetzen: Hinweis: Ein Scientist mit Physik erkennt, dass die Raumgeometrie nicht stimmt: Der Raum ist innen 1,2 Meter länger als außen.
- streichen oder ersetzen: (führt zu Schlussfolgerung 4) - Hinweis: Ein Thaumaturg, der den Stein berührt, spürt, dass er warm ist und flüstert, und dass das Flüstern lauter wird, wenn man ihn anhebt.

### Zeile 137, Knoten 5: Raum 4/12 und der Raum hinter der Tür

**alt:** **2. Welcher Ursprung?** | Das Verschobene. Der Raum ist eine Falte in der Welt, entstanden in der Nacht von Nordlicht 1977. | Hinweise in Knoten 4, 5

**neu:** **2. Welcher Ursprung?** | Das Verschobene. Der Raum ist eine Falte in der Welt, entstanden in der Nacht von Nordlicht 1977. | Hinweise in Knoten 3, 4, 5

- ergänzen: Hinweise in Knoten 3, 4, 5
- streichen oder ersetzen: Hinweise in Knoten 4, 5

### Zeile 167, Ablauf

**alt:** 5. Wird der Stein nicht gesichert, zählt der Countdown schneller. Kurz vor 22:10 bricht die Stimme ab, die Tür am Ende des Flurs öffnet sich flackernd einen Spalt weit, und dahinter ist nichts. Dann springt der Zähler auf sechzig zurück, die Tür schließt sich, und die Zählung beginnt von vorn. Der Stein erreicht das Ende nie.

**neu:** 5. Wird der Stein nicht gesichert, zählt der Countdown schneller. Kurz vor 22:10 bricht die Stimme ab, die Tür des Archivraums öffnet sich flackernd einen Spalt weit, und dahinter ist kein Flur mehr, nur Dunkel. Dann springt der Zähler auf sechzig zurück, die Tür schließt sich, und die Zählung beginnt von vorn. Der Stein erreicht das Ende nie.

- ergänzen: Kurz vor 22:10 bricht die Stimme ab, die Tür des Archivraums öffnet sich flackernd einen Spalt weit, und dahinter ist kein Flur mehr, nur Dunkel.
- streichen oder ersetzen: Kurz vor 22:10 bricht die Stimme ab, die Tür am Ende des Flurs öffnet sich flackernd einen Spalt weit, und dahinter ist nichts.

### Zeile 173, Lösungen

**alt:** **Mit Kampf:** Wenn die Zelle den Stein nicht sichern kann, öffnet sich die Tür am Ende des Flurs, und ein Rissling tritt heraus. Die Zelle muss ihn abwehren, während sie den Stein sichert. Der Rissling ist ein Handlanger, aber er kommt nicht allein: Ein Trupp zu dritt, wie im Bedrohungsatlas beschrieben.

**neu:** **Mit Kampf:** Wenn die Zelle den Stein nicht sichern kann, öffnet sich die Tür des Archivraums, und aus dem Dunkel dahinter tritt ein Rissling. Die Zelle muss ihn abwehren, während sie den Stein sichert. Der Rissling ist ein Handlanger, aber er kommt nicht allein: Ein Trupp zu dritt, wie im Bedrohungsatlas beschrieben.

- ergänzen: Mit Kampf: Wenn die Zelle den Stein nicht sichern kann, öffnet sich die Tür des Archivraums, und aus dem Dunkel dahinter tritt ein Rissling.
- streichen oder ersetzen: Mit Kampf: Wenn die Zelle den Stein nicht sichern kann, öffnet sich die Tür am Ende des Flurs, und ein Rissling tritt heraus.

### Zeile 177, Lösungen

**alt:** **Wissen aus der Ermittlung belohnen:** Wer den alten Bauplan von 1977 gefunden hat, weiß, dass der Raum ursprünglich ein Lagerraum war. Wer die offene Akte über Nordlicht kennt, erkennt den Stein als Nordlichtstein. Wer das Kürzel „Stille 4/12“ gesehen hat, weiß, dass der Raum im Kristallbuch vermerkt ist und die Angelegenheit für die Siegelwahrer bedeutsam sein muss. Keines dieser Hinweise verrät, dass der Stein der Anker ist. Das muss die Zelle selbst erkennen.

**neu:** **Wissen aus der Ermittlung belohnen:** Wer den alten Bauplan von 1977 gefunden hat, weiß, dass der Raum ursprünglich ein Lagerraum war. Wer die offene Akte über Nordlicht kennt, erkennt den Stein als Nordlichtstein. Wer das Kürzel „Stille 4/12“ gesehen hat, weiß, dass der Raum im Kristallbuch vermerkt ist und die Angelegenheit für die Siegelwahrer bedeutsam sein muss. Wer dazu die Messungen am Stein aus Knoten 5 kennt, erkennt in ihm den Anker.

- ergänzen: Wer dazu die Messungen am Stein aus Knoten 5 kennt, erkennt in ihm den Anker.
- streichen oder ersetzen: Keines dieser Hinweise verrät, dass der Stein der Anker ist.
- streichen oder ersetzen: Das muss die Zelle selbst erkennen.

### Zeile 183, Gegner

**alt:** Major Pavel Černý ist kein Feind, solange die Zelle den Hort nicht alarmiert. Stellt er die Zelle im Keller, wird er laut und verlangt eine Erklärung. Er greift nur an, wenn die Zelle den Raum öffnet oder den Stein mitnimmt. Seine Werte stehen unten.

**neu:** Major Pavel Černý ist kein Feind, solange die Zelle den Hort nicht alarmiert. Stellt er die Zelle im Keller, wird er laut und verlangt eine Erklärung. Er greift nur an, wenn die Zelle mit dem Stein den Hort verlassen will, ohne ihm zu sagen, was er ist. Seine Werte stehen unten.

- ergänzen: Er greift nur an, wenn die Zelle mit dem Stein den Hort verlassen will, ohne ihm zu sagen, was er ist.
- streichen oder ersetzen: Er greift nur an, wenn die Zelle den Raum öffnet oder den Stein mitnimmt.

### Zeile 204, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter. +1 EP für die Lösung ohne Kampf. +1 EP für die Sicherung des Steins.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn die Zelle den Stein gesichert hat. Höchstens +1 EP persönlicher Bonus, etwa für die Lösung ohne Kampf. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den Stein, der rückwärts zählt.

- ergänzen: Erfahrung: 4 EP pro Charakter, 5, wenn die Akte rot geworden ist.
- ergänzen: +1 EP, wenn die Zelle den Stein gesichert hat.
- ergänzen: Höchstens +1 EP persönlicher Bonus, etwa für die Lösung ohne Kampf.
- ergänzen: +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den Stein, der rückwärts zählt.
- streichen oder ersetzen: Erfahrung: 5 EP pro Charakter.
- streichen oder ersetzen: +1 EP für die Lösung ohne Kampf.
- streichen oder ersetzen: +1 EP für die Sicherung des Steins.

### Zeile 42, Daniel Keane, 44

**alt:** Ehemaliger Soldier, jetzt Sicherheitsberater. Breitschultrig, Lederjacke, Stiefel, ein Stück Aschesilber an einer Kette um den Hals. Will das Visier für den Rüstmeister sichern, weil er Idris Pryce einen Gefallen schuldet. Weiß, dass das Visier summt, wenn man es aufsetzt, und dass es Tote anzieht. Verschweigt, dass er seit seiner Dienstzeit nachts Stimmen hört, wenn er sein Silber berührt. Redet wenig, beobachtet viel, steht gern im Dunkeln.

**neu:** Ehemaliger Soldier, jetzt Sicherheitsberater. Breitschultrig, Lederjacke, Stiefel, ein Stück Aschesilber an einer Kette um den Hals, das Idris Pryce ihm für diesen Auftrag geliehen hat. Will das Visier für den Rüstmeister sichern, weil er Idris Pryce einen Gefallen schuldet. Weiß, dass das Visier summt, wenn man es aufsetzt, und dass es Tote anzieht. Verschweigt, dass er seit seiner Dienstzeit nachts Stimmen hört, wenn er Silber berührt. Redet wenig, beobachtet viel, steht gern im Dunkeln.

- ergänzen: Breitschultrig, Lederjacke, Stiefel, ein Stück Aschesilber an einer Kette um den Hals, das Idris Pryce ihm für diesen Auftrag geliehen hat.
- streichen oder ersetzen: Breitschultrig, Lederjacke, Stiefel, ein Stück Aschesilber an einer Kette um den Hals.

### Zeile 52, Briefing

**alt:** **Was die Akte enthält:** Adresse des Pfandhandels, Name des Pfandleihers, Foto des Visiers aus einem Onlineinserat, eine kurze Notiz des Rüstmeisters: „Stück ist seit 1989 verschollen, hergestellt von Evan Pryce, Innenseite trägt seinen Namen, nicht öffnen, nicht aufsetzen“, eine Notiz des Kollegiums: „Aschesilber mit Echo, sicherstellen, in Blei verpacken, nach Wales bringen“. **Spesen:** 2.000 Euro. **Anfordern:** Ein EMF-Detektor, Salz, ein Beryllium-Isolierbehälter, ein Fahrzeug mit Tarnkennzeichen. Der Führungsoffizier sagt nicht, dass der Rüstmeister und das Kollegium bereits eigene Leute geschickt haben.

**neu:** **Was die Akte enthält:** Adresse des Pfandhandels, Name des Pfandleihers, Foto des Visiers aus einem Onlineinserat, eine kurze Notiz des Rüstmeisters: „Stück ist seit 1989 verschollen, hergestellt von Evan Pryce, Innenseite trägt seinen Namen, nicht öffnen, nicht aufsetzen“. **Spesen:** 2.000 Euro. **Anfordern:** Ein EMF-Detektor, Salz, ein Beryllium-Isolierbehälter, ein Fahrzeug mit Tarnkennzeichen. Der Führungsoffizier sagt nicht, dass der Rüstmeister und das Kollegium bereits eigene Leute geschickt haben.

- ergänzen: Was die Akte enthält: Adresse des Pfandhandels, Name des Pfandleihers, Foto des Visiers aus einem Onlineinserat, eine kurze Notiz des Rüstmeisters: "Stück ist seit 1989 verschollen, hergestellt von Evan Pryce, Innenseite trägt seinen Namen, nicht öffnen, nicht aufsetzen".
- streichen oder ersetzen: Was die Akte enthält: Adresse des Pfandhandels, Name des Pfandleihers, Foto des Visiers aus einem Onlineinserat, eine kurze Notiz des Rüstmeisters: "Stück ist seit 1989 verschollen, hergestellt von Evan Pryce, Innenseite trägt seinen Namen, nicht öffnen, nicht aufsetzen", eine Notiz des Kollegiums: "Aschesilber mit Echo, sicherstellen, in Blei verpacken, nach Wales bringen".

### Zeile 62, Knoten 1: Das Pfandhaus in Grangetown

**alt:** - **Hinweis:** Gwynne erzählt von drei Interessenten: einem Kunsthändler aus Bath, einem Antiquitätenhändler aus Bristol und einem stummen Mann in Lederjacke, der nur einmal hereinkam und wieder ging (führt zu Miriam Hale, Alistair Vane und Daniel Keane).

**neu:** - **Hinweis:** Nach Menschenkenntnis gegen Machbar (2) erzählt Gwynne von drei Interessenten: einem Kunsthändler aus Bath, einem Antiquitätenhändler aus Bristol und einem stummen Mann in Lederjacke, der nur einmal hereinkam und wieder ging (führt zu Knoten 4, zu Alistair Vane und zu Knoten 3).

- ergänzen: Hinweis: Nach Menschenkenntnis gegen Machbar (2) erzählt Gwynne von drei Interessenten: einem Kunsthändler aus Bath, einem Antiquitätenhändler aus Bristol und einem stummen Mann in Lederjacke, der nur einmal hereinkam und wieder ging (führt zu Knoten 4, zu Alistair Vane und zu Knoten 3).
- streichen oder ersetzen: Hinweis: Gwynne erzählt von drei Interessenten: einem Kunsthändler aus Bath, einem Antiquitätenhändler aus Bristol und einem stummen Mann in Lederjacke, der nur einmal hereinkam und wieder ging (führt zu Miriam Hale, Alistair Vane und Daniel Keane).

### Zeile 80, Knoten 2: Hort-2, die Werkstatt

**alt:** - **Hinweis für Soldier:** Ein Nachhall-Wurf in der Werkstatt zeigt, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist. Ein Vorbesitzer warnt vor einem Mann in einem dunklen Mantel, der das Stück einschließen will (führt zu Miriam Hale, zum Kollegium).

**neu:** - **Hinweis:** Der Rüstmeister erzählt, der Psionik-Kern melde seit drei Tagen einen jungen Mann in Splott, dessen Gabe erwacht ist und der nachts Namen hört (führt zu Knoten 5). - **Hinweis für Soldier:** Ein Nachhall-Wurf in der Werkstatt zeigt, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist. Ein Vorbesitzer warnt vor einem Mann in einem dunklen Mantel, der das Stück einschließen will (führt zu Knoten 4, zum Kunsthändler aus Bath).

- ergänzen: Hinweis: Der Rüstmeister erzählt, der Psionik-Kern melde seit drei Tagen einen jungen Mann in Splott, dessen Gabe erwacht ist und der nachts Namen hört (führt zu Knoten 5).
- ergänzen: Ein Vorbesitzer warnt vor einem Mann in einem dunklen Mantel, der das Stück einschließen will (führt zu Knoten 4, zum Kunsthändler aus Bath).
- streichen oder ersetzen: Hinweis für Soldier: Ein Nachhall-Wurf in der Werkstatt zeigt, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist.
- streichen oder ersetzen: Ein Vorbesitzer warnt vor einem Mann in einem dunklen Mantel, der das Stück einschließen will (führt zu Miriam Hale, zum Kollegium).

### Zeile 84, Knoten 2: Hort-2, die Werkstatt

**alt:** **Proben:** Nachhall gegen Schwer (3), um zu spüren, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist. Thaumaturgie gegen Machbar (2), um zu erkennen, dass das Visier kein gefährliches Artefakt ist, sondern ein Träger. Glänzende Klassen: Soldier, Thaumaturg, Investigator.

**neu:** **Proben:** Nachhall-Wurf, nur für Soldiers mit Nachhall: Die Spielleitung würfelt verdeckt einen W6. Ist das Ergebnis gleich oder kleiner als der Nachhall, spürt der Soldier, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist. Thaumaturgie gegen Machbar (2), um zu erkennen, dass das Visier kein gefährliches Artefakt ist, sondern ein Träger. Glänzende Klassen: Soldier, Thaumaturg, Investigator.

- ergänzen: Proben: Nachhall-Wurf, nur für Soldiers mit Nachhall: Die Spielleitung würfelt verdeckt einen W6.
- ergänzen: Ist das Ergebnis gleich oder kleiner als der Nachhall, spürt der Soldier, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist.

### Zeile 92, Knoten 3: Die Straße vor dem Pfandhaus

**alt:** 

**neu:** - **Hinweis:** Keane erzählt, dass die Rüstmeister Salz vor die Waffenkammer streuen und das Licht brennen lassen, wenn das Silber nachts summt (führt zu Was wirkt?).

- ergänzen: Hinweis: Keane erzählt, dass die Rüstmeister Salz vor die Waffenkammer streuen und das Licht brennen lassen, wenn das Silber nachts summt (führt zu Was wirkt?).

### Zeile 121, Knoten 5: Die Pflegefamilie in Splott

**alt:** **Was wirkt?** Das Visier ist kein Gegner. Es will getragen werden, oder es will zurück zu denen, die es verstehen. Salz, Licht und Silber wirken gegen das Echo, aber sie zerstören es nicht. Ein Ende für das offene Werk: Pryces Wunsch, dass jemand das Stück trägt und versteht. Hinweise in Knoten 1, 2.

**neu:** **Was wirkt?** Das Visier ist kein Gegner. Es will getragen werden, oder es will zurück zu denen, die es verstehen. Salz, Licht und Silber wirken gegen das Echo, aber sie zerstören es nicht. Ein Ende für das offene Werk: Pryces Wunsch, dass jemand das Stück trägt und versteht. Hinweise in Knoten 1, 2, 3.

- ergänzen: Hinweise in Knoten 1, 2, 3.
- streichen oder ersetzen: Hinweise in Knoten 1, 2.

### Zeile 129, Eskalation

**alt:** - **Nach 24 Stunden:** Alistair Vane erhöht sein Angebot auf 8.000 Pfund und lässt seinen Anwalt bei Gwynne anrufen. Gwynne wird nervös und beschließt, das Visier noch in derselben Nacht zu verkaufen, an wen auch immer.

**neu:** - **Nach 24 Stunden:** Alistair Vane erhöht sein Angebot auf 8.000 Pfund und lässt seinen Anwalt bei Gwynne anrufen. Gwynne wird nervös und bestellt alle Interessenten für diese Nacht nach Ladenschluss in den Laden: Wer am meisten bietet, nimmt das Stück mit.

- ergänzen: Gwynne wird nervös und bestellt alle Interessenten für diese Nacht nach Ladenschluss in den Laden: Wer am meisten bietet, nimmt das Stück mit.
- streichen oder ersetzen: Gwynne wird nervös und beschließt, das Visier noch in derselben Nacht zu verkaufen, an wen auch immer.

### Zeile 167, Owen Gwynne

**alt:** [entry - | Owen Gwynne | Pfandleiher · Mensch]

**neu:** [entry - | Owen Gwynne | Pfandleiher · Menschen]

- ergänzen: [entry - Owen Gwynne Pfandleiher · Menschen]
- streichen oder ersetzen: [entry - Owen Gwynne Pfandleiher · Mensch]

### Zeile 174, Owen Gwynne

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint

- ergänzen: Grauen Keines.

### Zeile 181, Alistair Vane

**alt:** [entry - | Alistair Vane | Ehemaliger Antiquitätenhändler · Mensch]

**neu:** [entry - | Alistair Vane | Ehemaliger Antiquitätenhändler · Menschen]

- ergänzen: [entry - Alistair Vane Ehemaliger Antiquitätenhändler · Menschen]
- streichen oder ersetzen: [entry - Alistair Vane Ehemaliger Antiquitätenhändler · Mensch]

### Zeile 188, Alistair Vane

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint

- ergänzen: Grauen Keines.

### Zeile 195, Mr. Hartley

**alt:** [entry - | Mr. Hartley | Kunsthändler des Kollegiums · Mensch]

**neu:** [entry - | Mr. Hartley | Kunsthändler des Kollegiums · Menschen]

- ergänzen: Hartley Kunsthändler des Kollegiums · Menschen]
- streichen oder ersetzen: Hartley Kunsthändler des Kollegiums · Mensch]

### Zeile 202, Mr. Hartley

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint

- ergänzen: Grauen Keines.

### Zeile 209, Daniel Keane

**alt:** [entry - | Daniel Keane | Ehemaliger Soldier, Sicherheitsberater · Mensch]

**neu:** [entry - | Daniel Keane | Ehemaliger Soldier, Sicherheitsberater · Menschen]

- ergänzen: [entry - Daniel Keane Ehemaliger Soldier, Sicherheitsberater · Menschen]
- streichen oder ersetzen: [entry - Daniel Keane Ehemaliger Soldier, Sicherheitsberater · Mensch]

### Zeile 216, Daniel Keane

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint. Er hat Schlimmeres gesehen.

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint. Er hat Schlimmeres gesehen.

- ergänzen: Grauen Keines.

### Zeile 223, Rhys Bowen

**alt:** [entry - | Rhys Bowen | Psion mit ungeöffneter Gabe · Mensch]

**neu:** [entry - | Rhys Bowen | Psion mit ungeöffneter Gabe · Menschen]

- ergänzen: [entry - Rhys Bowen Psion mit ungeöffneter Gabe · Menschen]
- streichen oder ersetzen: [entry - Rhys Bowen Psion mit ungeöffneter Gabe · Mensch]

### Zeile 230, Rhys Bowen

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint

- ergänzen: Grauen Keines.

### Zeile 243, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter, +1 für eine Lösung ohne Kampf, +1 für die Entscheidung, das Visier an Rhys Bowen zu geben oder es dem Rüstmeister zu überlassen.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn das Visier sichergestellt ist, ohne dass zwei Stellen von O.D.I.N. aufeinander schießen. Höchstens +1 EP persönlicher Bonus, etwa für eine Lösung ohne Kampf. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa Rhys Bowen und den Namen, den er hört.

- ergänzen: Erfahrung: 4 EP pro Charakter, 5, wenn die Akte rot geworden ist.
- ergänzen: +1 EP, wenn das Visier sichergestellt ist, ohne dass zwei Stellen von O.D.I.N. aufeinander schießen.
- ergänzen: Höchstens +1 EP persönlicher Bonus, etwa für eine Lösung ohne Kampf.
- ergänzen: +1 EP für jeden Faden, den die Zelle aufnimmt, etwa Rhys Bowen und den Namen, den er hört.
- streichen oder ersetzen: Erfahrung: 5 EP pro Charakter, +1 für eine Lösung ohne Kampf, +1 für die Entscheidung, das Visier an Rhys Bowen zu geben oder es dem Rüstmeister zu überlassen.

### Zeile 245, Nachspiel

**alt:** **Totenköpfe:** Keine, solange die Zelle das Visier nicht zerstört oder an einen Sammler verkauft. Wenn das Visier in Blei eingeschlossen ins Archiv nach Wales geht, erhält das Kollegium einen Totenkopf dazu, weil es ein Artefakt einschließt, das getragen werden will. Wenn das Visier an Vane geht, erhält Grey Meridian einen Totenkopf dazu, sobald der Weiterverkauf bekannt wird.

**neu:** **Totenköpfe:** Keine, solange die Zelle das Visier nicht zerstört oder an einen Sammler verkauft. Wird es zerstört oder verkauft, zählt es als verlorenes Stück Aschesilber (ein Totenkopf für jeweils zehn verlorene Stücke, Spielleiterbuch). Geht es an Vane und von ihm an einen Sammler, erhält der Abend einen Totenkopf dazu, sobald der Weiterverkauf bekannt wird.

- ergänzen: Wird es zerstört oder verkauft, zählt es als verlorenes Stück Aschesilber (ein Totenkopf für jeweils zehn verlorene Stücke, Spielleiterbuch).
- ergänzen: Geht es an Vane und von ihm an einen Sammler, erhält der Abend einen Totenkopf dazu, sobald der Weiterverkauf bekannt wird.
- streichen oder ersetzen: Wenn das Visier in Blei eingeschlossen ins Archiv nach Wales geht, erhält das Kollegium einen Totenkopf dazu, weil es ein Artefakt einschließt, das getragen werden will.
- streichen oder ersetzen: Wenn das Visier an Vane geht, erhält Grey Meridian einen Totenkopf dazu, sobald der Weiterverkauf bekannt wird.

### Zeile 12, Worum es geht

**alt:** Die Stiftung „Sammlung und Bewahrung“ in Basel kauft seit Jahrzehnten Kristalle auf, um sie in Blei einzuschließen. Im Stiftungsrat sitzt eine alte Dame namens Renate Albers. In der Buchhaltung arbeitet seit vier Jahren Martin Kessler, ein stiller Mann mit einer Krawatte mit Rentieren. Vor sechs Monaten wurde Kessler krank, sehr krank, und niemand durfte ihn besuchen. Jetzt ist er zurück. Sabine aus der Buchhaltung hat ihn gefragt, warum er sich nicht an Otto erinnert, den Hund des Hausmeisters, den Kessler jeden Morgen gefüttert hat. Kessler hat gelächelt und gesagt, die Krankheit habe ihm das Gedächtnis genommen. Sabine glaubt ihm nicht. Sie hat bei der Polizei angerufen, und die Polizei hat den Anruf an eine Stelle weitergegeben, die es nicht gibt.

**neu:** Die Stiftung „Sammlung und Bewahrung“ in Basel kauft seit Jahrzehnten Kristalle auf, um sie in Blei einzuschließen. Im Stiftungsrat sitzt eine alte Dame namens Renate Albers. In der Buchhaltung arbeitete vier Jahre lang Martin Kessler, ein stiller Mann mit einer Krawatte mit Rentieren. Im März 2025 wurde Kessler krank, sehr krank, und niemand durfte ihn besuchen. Im Januar kam er zurück. Sabine aus der Buchhaltung hat ihn gefragt, warum er sich nicht an Otto erinnert, den Hund des Hausmeisters, den Kessler jeden Morgen gefüttert hat. Kessler hat gelächelt und gesagt, die Krankheit habe ihm das Gedächtnis genommen. Im März hatte die Stiftung ihn der Polizei als verschwunden gemeldet. Im Januar war aus dem Vermissten ein Langzeitkranker geworden, und die Meldung wurde zurückgezogen. Sabine hat beides mitbekommen. Sabine glaubt ihm nicht. Sie hat bei der Polizei angerufen, und die Polizei hat den Anruf an eine Stelle weitergegeben, die es nicht gibt.

- ergänzen: Im März 2025 wurde Kessler krank, sehr krank, und niemand durfte ihn besuchen.
- ergänzen: Im Januar kam er zurück.
- ergänzen: Im März hatte die Stiftung ihn der Polizei als verschwunden gemeldet.
- ergänzen: Im Januar war aus dem Vermissten ein Langzeitkranker geworden, und die Meldung wurde zurückgezogen.
- ergänzen: Sabine hat beides mitbekommen.
- streichen oder ersetzen: Vor sechs Monaten wurde Kessler krank, sehr krank, und niemand durfte ihn besuchen.
- streichen oder ersetzen: Jetzt ist er zurück.

### Zeile 22, Was wirklich geschah

**alt:** Elster, die im Stiftungsrat sitzt und in Wahrheit das Kind ist, das die Hände 1952 nicht geholt haben, erkannte Kuckucks Legende nach drei Wochen. Sie ließ ihn vier Jahre arbeiten und sah ihm zu. Dann ließ sie ein Foto vom Sommerfest dort ablegen, wo ein Buchhalter es finden würde: ein Foto, das Kuckuck in der Rolle Martin Kessler zeigt, aufgenommen beim Sommerfest 2024. Elster wollte, dass Kuckuck stolpert. Sie wollte, dass er Fragen stellt. Sie wollte, dass er den Artikel über das Ertrinken in der Elbe zu Ende schreibt.

**neu:** Elster, die im Stiftungsrat sitzt und in Wahrheit das Kind ist, das die Hände 1952 nicht geholt haben, erkannte Kuckucks Legende nach drei Wochen. Sie ließ ihn vier Jahre arbeiten und sah ihm zu. Dann ließ sie einen Ordner mit Fotos vom Sommerfest 2024 in der Villa des Direktors in den Keller der Stiftung stellen, zu den Akten der Restaurierungen, wo ein Buchhalter ihn finden würde. Auf einem der Bilder steht sie selbst neben dem Direktor. Elster wollte, dass Kuckuck stolpert. Sie wollte, dass er Fragen stellt. Sie wollte, dass er den Artikel über das Ertrinken in der Elbe zu Ende schreibt.

- ergänzen: Dann ließ sie einen Ordner mit Fotos vom Sommerfest 2024 in der Villa des Direktors in den Keller der Stiftung stellen, zu den Akten der Restaurierungen, wo ein Buchhalter ihn finden würde.
- ergänzen: Auf einem der Bilder steht sie selbst neben dem Direktor.
- streichen oder ersetzen: Dann ließ sie ein Foto vom Sommerfest dort ablegen, wo ein Buchhalter es finden würde: ein Foto, das Kuckuck in der Rolle Martin Kessler zeigt, aufgenommen beim Sommerfest 2024.

### Zeile 49, Herr Leuenberger

**alt:** Ende sechzig, Direktor der Stiftung, früher selbst bei den Händen, gilt seit 1990 als tot. Er kauft Kristalle und schließt sie in Blei ein. Er will, dass die Stiftung weiterarbeitet, und er will nicht, dass der Rat Elster bekommt. Er weiß, dass Brunner nicht Kuckuck ist, weil er Kuckuck vier Jahre lang beobachtet hat. Er verschweigt, dass er Elster seit 1990 kennt. Er redet freundlich, gründlich, und er lächelt, wenn er lügt.

**neu:** Ende sechzig, Direktor der Stiftung, früher selbst bei den Händen, gilt seit 1990 als tot. Er kauft Kristalle und schließt sie in Blei ein. Er will, dass die Stiftung weiterarbeitet, und er will nicht, dass der Rat Elster bekommt. Er weiß, dass Brunner nicht Kuckuck ist, weil er Kuckuck vier Jahre lang beobachtet hat. Brunner kennt er aus seiner eigenen Zeit bei den Händen. Er verschweigt, dass er Elster seit 1990 kennt. Er redet freundlich, gründlich, und er lächelt, wenn er lügt.

- ergänzen: Brunner kennt er aus seiner eigenen Zeit bei den Händen.

### Zeile 63, Briefing

**alt:** **Was die Akte enthält:** Adresse der Stiftung, Name der Buchhalterin (Sabine Wirz), Name des Direktors (Herr Leuenberger), ein älteres Personalbild aus Kuckucks Legendenakte, aufgenommen 2021 bei der Übernahme der Legende. Ein Vermerk: „Kuckuck, Tobias Lenz, Legende Martin Kessler, seit 2021 in Basel. Letzte Meldung vor sechs Monaten. Seitdem krank. Rückkehr gemeldet von Sabine Wirz.“

**neu:** **Was die Akte enthält:** Adresse der Stiftung, Name der Buchhalterin (Sabine Wirz), Name des Direktors (Herr Leuenberger), ein älteres Personalbild aus Kuckucks Legendenakte, aufgenommen 2021 bei der Übernahme der Legende. Ein Vermerk: „Kuckuck, Tobias Lenz, Legende Martin Kessler, seit 2021 in Basel. Letzte Meldung im März 2025. Seitdem krank. Rückkehr im Januar 2026, gemeldet von Sabine Wirz.“

- ergänzen: Letzte Meldung im März 2025.
- streichen oder ersetzen: Letzte Meldung vor sechs Monaten.

### Zeile 78, Knoten 1: Die Stiftung

**alt:** - **Hinweis:** Das Foto vom Sommerfest 2024 liegt in einer Schublade in der Buchhaltung. Ein Investigator mit Ermittlung oder ein Agent mit Täuschung erkennt die Abweichung. (führt zu Knoten 2)

**neu:** - **Hinweis:** Im Keller, bei den Akten der Restaurierungen, steht ein Ordner mit Fotos vom Sommerfest 2024. Ein Bild fehlt, auf einem anderen steht Martin Kessler. Ein Investigator mit Ermittlung oder ein Agent mit Menschenkenntnis erkennt die Abweichung. (führt zu Knoten 2)

- ergänzen: Hinweis: Im Keller, bei den Akten der Restaurierungen, steht ein Ordner mit Fotos vom Sommerfest 2024.
- ergänzen: Ein Bild fehlt, auf einem anderen steht Martin Kessler.
- streichen oder ersetzen: Hinweis: Das Foto vom Sommerfest 2024 liegt in einer Schublade in der Buchhaltung.

### Zeile 80, Knoten 1: Die Stiftung

**alt:** 

**neu:** - **Hinweis:** In Kesslers Personalakte liegt für zehn Monate Krankheit kein einziges Attest. Sabine hat es bemerkt. (führt zu Knoten 5) - **Hinweis:** Leuenberger erkennt Brunner aus seiner Zeit bei den Händen. Den Namen Viktor Brunner sagt er nur, wenn die Zelle ihm verspricht, Elster nicht auszuliefern. (führt zu Knoten 3)

- ergänzen: Hinweis: In Kesslers Personalakte liegt für zehn Monate Krankheit kein einziges Attest.
- ergänzen: Sabine hat es bemerkt.
- ergänzen: (führt zu Knoten 5) - Hinweis: Leuenberger erkennt Brunner aus seiner Zeit bei den Händen.
- ergänzen: Den Namen Viktor Brunner sagt er nur, wenn die Zelle ihm verspricht, Elster nicht auszuliefern.
- ergänzen: (führt zu Knoten 3)

### Zeile 91, Knoten 2: Das Foto

**alt:** Das Foto vom Sommerfest 2024, aufgenommen im Innenhof der Stiftung. Es zeigt Martin Kessler mit einer Krawatte mit Rentieren, ein Glas in der Hand, ein Lächeln, das nicht ganz zu ihm passt. Das Foto ist als Handout 4.1 beigelegt.

**neu:** Das Foto vom Sommerfest 2024, aufgenommen im Garten der Villa des Direktors. Es zeigt Martin Kessler mit der Krawatte mit Rentieren und einem Lächeln, das nicht ganz zu ihm passt. Am Rand, angeschnitten, eine alte Frau mit weißem Haar. Das Foto ist als Handout 4.1 beigelegt.

- ergänzen: Am Rand, angeschnitten, eine alte Frau mit weißem Haar.

### Zeile 93, Knoten 2: Das Foto

**alt:** - **Hinweis:** Ein Investigator mit Ermittlung oder ein Agent mit Täuschung erkennt, dass der Mann auf dem Foto nicht derselbe ist wie der Mann, der heute in der Stiftung arbeitet. (führt zu Knoten 1) - **Hinweis:** Auf der Rückseite steht mit Bleistift: „Sommerfest 2024, Martin Kessler.“ Die Handschrift ist nicht von Sabine. Ein Investigator mit Ermittlung oder ein Agent mit Täuschung erkennt, dass die Handschrift alt ist, sehr alt. (führt zu Knoten 3) - **Hinweis:** Das Foto lag in einer Schublade, die Kuckuck jeden Tag benutzt hat. Ein Investigator mit Ermittlung erkennt, dass jemand es dort abgelegt hat, wo er es finden würde. (führt zu Knoten 3)

**neu:** - **Hinweis:** Ein Investigator mit Ermittlung oder ein Agent mit Menschenkenntnis erkennt, dass der Mann auf dem Foto nicht derselbe ist wie der Mann, der heute in der Stiftung arbeitet. (führt zu Knoten 1) - **Hinweis:** Auf der Rückseite steht mit Bleistift: „Sommerfest 2024, Martin Kessler.“ Die Handschrift ist nicht von Sabine. Ein Investigator mit Ermittlung oder ein Agent mit Wahrnehmung erkennt, dass die Handschrift alt ist, sehr alt. (führt zu Knoten 3) - **Hinweis:** Der Ordner stand zwischen Akten, die nur die Buchhaltung braucht. Ein Investigator mit Ermittlung erkennt, dass jemand ihn dort abgestellt hat, wo ein Buchhalter ihn finden würde. (führt zu Knoten 3)

- ergänzen: (führt zu Knoten 3) - Hinweis: Der Ordner stand zwischen Akten, die nur die Buchhaltung braucht.
- streichen oder ersetzen: (führt zu Knoten 3) - Hinweis: Das Foto lag in einer Schublade, die Kuckuck jeden Tag benutzt hat.

### Zeile 124, Knoten 4: Die Druckerei in Zürich

**alt:** - **Hinweis:** Der Vermerk in der Akte ist als Handout 4.3 beigelegt.

**neu:** - **Hinweis:** Der Kadett-Vermerk aus Kuckucks Akte, ein Auszug der Registratur, ist als Handout 4.3 beigelegt.

- ergänzen: Hinweis: Der Kadett-Vermerk aus Kuckucks Akte, ein Auszug der Registratur, ist als Handout 4.3 beigelegt.
- streichen oder ersetzen: Hinweis: Der Vermerk in der Akte ist als Handout 4.3 beigelegt.

### Zeile 132, Knoten 5: Der tote Briefkasten

**alt:** Ein Schließfach im Bahnhof Basel SBB, das Brunner für Meldungen an den Rat benutzt. Ein Agent mit Zugang zum toten Briefkasten des Zweigs findet die Handschrift eines Sekretärs von Prometheus.

**neu:** Ein Schließfach im Bahnhof Basel SBB, das Brunner für Meldungen an den Rat benutzt, und der alte tote Briefkasten des Zweigs im Stadtpark, in der Ritze der Mauer hinter dem Musikpavillon. Über ihn hat Kuckuck gemeldet. Ein Agent mit Zugang zu den Unterlagen des Zweigs findet die Handschrift eines Sekretärs von Prometheus.

- ergänzen: Ein Schließfach im Bahnhof Basel SBB, das Brunner für Meldungen an den Rat benutzt, und der alte tote Briefkasten des Zweigs im Stadtpark, in der Ritze der Mauer hinter dem Musikpavillon.
- ergänzen: Über ihn hat Kuckuck gemeldet.
- streichen oder ersetzen: Ein Schließfach im Bahnhof Basel SBB, das Brunner für Meldungen an den Rat benutzt.

### Zeile 135, Knoten 5: Der tote Briefkasten

**alt:** - **Hinweis:** In Mulhouse warten zwei Männer der Hände. Ein Soldier oder Investigator, der die Reisebewegungen von Kuckuck rekonstruiert, findet, dass er über Konstanz kam, nicht über Mulhouse. (führt zu Knoten 1) - **Hinweis:** Brunner hat einen eigenen toten Briefkasten. Ein Agent mit Heimlichkeit findet ihn. (führt zu Knoten 1)

**neu:** - **Hinweis:** In Mulhouse warteten zwei Männer der Hände. Ein Soldier oder Investigator, der die Reisebewegungen von Kuckuck rekonstruiert, findet, dass er über Konstanz kam, nicht über Mulhouse. (führt zu Knoten 1) - **Hinweis:** Die Meldungen im Schließfach sind mit „V. B.“ abgezeichnet. Wer das Kürzel mit den alten Listen der Hände abgleicht, findet einen Viktor Brunner, gestorben 2005. Das Schließfach findet ein Agent, der Brunner mit Heimlichkeit folgt. (führt zu Knoten 1)

- ergänzen: (führt zu Knoten 1) - Hinweis: Die Meldungen im Schließfach sind mit "V.
- ergänzen: B." abgezeichnet.
- ergänzen: Wer das Kürzel mit den alten Listen der Hände abgleicht, findet einen Viktor Brunner, gestorben 2005.
- streichen oder ersetzen: (führt zu Knoten 1) - Hinweis: Brunner hat einen eigenen toten Briefkasten.

### Zeile 209, Nachspiel

**alt:** **Erfahrung:** 5 pro Charakter, +1 für eine Lösung ohne Kampf, +1 für eine Lösung, die Elster ins Kinderzimmer bringt.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn die Zelle herausfindet, wer Kessler ist. Höchstens +1 EP persönlicher Bonus, etwa für eine Lösung ohne Kampf oder eine, die Elster ins Kinderzimmer bringt. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den Nexus-Kristall in Elsters Haus.

- ergänzen: Erfahrung: 4 EP pro Charakter, 5, wenn die Akte rot geworden ist.
- ergänzen: +1 EP, wenn die Zelle herausfindet, wer Kessler ist.
- ergänzen: Höchstens +1 EP persönlicher Bonus, etwa für eine Lösung ohne Kampf oder eine, die Elster ins Kinderzimmer bringt.
- ergänzen: +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den Nexus-Kristall in Elsters Haus.
- streichen oder ersetzen: Erfahrung: 5 pro Charakter, +1 für eine Lösung ohne Kampf, +1 für eine Lösung, die Elster ins Kinderzimmer bringt.

### Zeile 54, Paul Reiter, 66

**alt:** ### Paul Reiter, 63

**neu:** ### Paul Reiter, 66

- ergänzen: ### Paul Reiter, 66
- streichen oder ersetzen: ### Paul Reiter, 63

### Zeile 74, Knoten 1: Der Anger mit dem Marktbrunnen

**alt:** Der zentrale Platz in Oberwölz, Kopfsteinpflaster, der Brunnen aus dem 17. Jahrhundert mit einer Steinfigur des heiligen Florian. Das Wasser ist klar, am Grund glitzert es. Rundherum: das Gasthaus, die Volksschule, die Kirche.

**neu:** Der zentrale Platz in Oberwölz, Kopfsteinpflaster, der Brunnen aus dem 17. Jahrhundert mit einer Steinfigur des heiligen Florian. Das Wasser ist klar, am Grund glitzert es: Unter dem Becken führt ein gemauerter Schacht sechs Meter tief zur Quellfassung, und dort unten liegt das Licht. Rundherum: das Gasthaus, die Volksschule, die Kirche.

- ergänzen: Das Wasser ist klar, am Grund glitzert es: Unter dem Becken führt ein gemauerter Schacht sechs Meter tief zur Quellfassung, und dort unten liegt das Licht.
- streichen oder ersetzen: Das Wasser ist klar, am Grund glitzert es.

### Zeile 95, Knoten 2: Das Gasthaus „Zum Goldenen Hirschen“

**alt:** - **Hinweis:** Paul Reiter übergibt der Zelle ein Foto von 1977 mit einer Beschriftung auf der Rückseite. (Handout 5.3)

**neu:** - **Hinweis:** Wer Reiters Zögern mit Menschenkenntnis gegen Schwer (3) bemerkt und nachfragt, bekommt von ihm ein Foto von 1977 mit einer Beschriftung auf der Rückseite. (Handout 5.3)

- ergänzen: Hinweis: Wer Reiters Zögern mit Menschenkenntnis gegen Schwer (3) bemerkt und nachfragt, bekommt von ihm ein Foto von 1977 mit einer Beschriftung auf der Rückseite.
- streichen oder ersetzen: Hinweis: Paul Reiter übergibt der Zelle ein Foto von 1977 mit einer Beschriftung auf der Rückseite.

### Zeile 107, Knoten 3: Das Labor im Haus der Leitners

**alt:** - **Hinweis:** Ein Biochemist oder Chemiker analysiert die Medikamente. Probe auf Chemie gegen Schwer (3): Es handelt sich um ein Suppressivum, das die Wirkung der Kontamination unterdrückt. Es ist nicht harmlos, aber ohne dauerhaften Schaden. (führt zu Knoten 4, 5) - **Hinweis:** Ein handschriftliches Laborprotokoll, Messung Nr. 7, mit fallender Pulsfrequenz und der Empfehlung zur Bergung innerhalb von 48 Stunden wegen Entdeckungsrisiko. (Handout 5.2)

**neu:** - **Hinweis:** Ein Biochemist oder Chemiker analysiert die Medikamente. Probe auf Chemie gegen Schwer (3): Es handelt sich um ein Suppressivum, das die Wirkung der Kontamination unterdrückt. Es ist nicht harmlos, aber ohne dauerhaften Schaden, wenn es bald abgesetzt wird. (führt zu Knoten 4, 5) - **Hinweis:** Ein handschriftliches Laborprotokoll, Messung Nr. 7, mit fallendem Pulsabstand und der Empfehlung zur Bergung innerhalb von 48 Stunden wegen Entdeckungsrisiko. (Handout 5.2)

- ergänzen: Es ist nicht harmlos, aber ohne dauerhaften Schaden, wenn es bald abgesetzt wird.
- streichen oder ersetzen: Es ist nicht harmlos, aber ohne dauerhaften Schaden.

### Zeile 128, Knoten 5: Der Marktbrunnen bei Nacht

**alt:** - **Hinweis:** Ein Psion mit Telepathie hört den Chor der Kinder als ein einziges Summen, das aus dem Brunnen kommt. Probe auf WK + Telepathie gegen Sehr schwer (4): Der Kristall „singt“ durch die Kinder, und er will gehört werden. (führt zu Konfrontation)

**neu:** - **Hinweis:** Ein Psion mit Telepathie hört den Chor der Kinder als ein einziges Summen, das aus dem Brunnen kommt. Probe auf WK + Telepathie gegen Sehr schwer (4): Der Kristall „singt“ durch die Kinder, und er will gehört werden. Wer ihn zum Schweigen bringt, bringt auch sie zum Schweigen. (führt zu Konfrontation)

- ergänzen: Wer ihn zum Schweigen bringt, bringt auch sie zum Schweigen.

### Zeile 141, Knoten 5: Der Marktbrunnen bei Nacht

**alt:** 1. Ein EMF-Detektor zeigt Pulse im Takt von Nordlicht, alle vier Minuten. (Knoten 3, 5)

**neu:** 1. Ein EMF-Detektor zeigt Pulse im Takt von Nordlicht, alle vier Minuten. (Knoten 1, 3, 5)

- ergänzen: (Knoten 1, 3, 5)
- streichen oder ersetzen: (Knoten 3, 5)

### Zeile 143, Knoten 5: Der Marktbrunnen bei Nacht

**alt:** 3. Der Kristall im Brunnen ist ein Rissfragment, klar mit milchigem Kern. (Knoten 3, 5)

**neu:** 3. Die Wasserprobe enthält Kristallstaub, und Kinder, die im Schlaf singen, sind ein bekanntes Vorzeichen der Stimme. (Knoten 1, 2)

- ergänzen: Die Wasserprobe enthält Kristallstaub, und Kinder, die im Schlaf singen, sind ein bekanntes Vorzeichen der Stimme.
- ergänzen: (Knoten 1, 2)
- streichen oder ersetzen: Der Kristall im Brunnen ist ein Rissfragment, klar mit milchigem Kern.
- streichen oder ersetzen: (Knoten 3, 5)

### Zeile 200, Dr. Eva Leitner, alias Eva Lechner

**alt:** [entry - | Dr. Eva Leitner, alias Eva Lechner | Nichtspielercharakter · Wissenschaftlerin]

**neu:** [entry - | Dr. Eva Leitner, alias Eva Lechner | Biochemikerin · Menschen]

- ergänzen: Eva Leitner, alias Eva Lechner Biochemikerin · Menschen]
- streichen oder ersetzen: Eva Leitner, alias Eva Lechner Nichtspielercharakter · Wissenschaftlerin]

### Zeile 213, Thomas Leitner, alias Thomas Lechner

**alt:** [entry - | Thomas Leitner, alias Thomas Lechner | Nichtspielercharakter · Ingenieur]

**neu:** [entry - | Thomas Leitner, alias Thomas Lechner | Ingenieur · Menschen]

- ergänzen: [entry - Thomas Leitner, alias Thomas Lechner Ingenieur · Menschen]
- streichen oder ersetzen: [entry - Thomas Leitner, alias Thomas Lechner Nichtspielercharakter · Ingenieur]

### Zeile 219, Thomas Leitner, alias Thomas Lechner

**alt:** **Grauen** | kein

**neu:** **Grauen** | Keines

- ergänzen: Grauen Keines
- streichen oder ersetzen: Grauen kein

### Zeile 234, Nachspiel

**alt:** **Erfahrung:** 5 pro Charakter, +1 für die Lösung ohne Kampf, +1 für die Bergung im richtigen Moment.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn der Kristall geborgen und isoliert ist. Höchstens +1 EP persönlicher Bonus, etwa für die Lösung ohne Kampf oder die Bergung im richtigen Moment. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa Paul Reiters Nacht von 1977.

- ergänzen: Erfahrung: 4 EP pro Charakter, 5, wenn die Akte rot geworden ist.
- ergänzen: +1 EP, wenn der Kristall geborgen und isoliert ist.
- ergänzen: Höchstens +1 EP persönlicher Bonus, etwa für die Lösung ohne Kampf oder die Bergung im richtigen Moment.
- ergänzen: +1 EP für jeden Faden, den die Zelle aufnimmt, etwa Paul Reiters Nacht von 1977.
- streichen oder ersetzen: Erfahrung: 5 pro Charakter, +1 für die Lösung ohne Kampf, +1 für die Bergung im richtigen Moment.

### Zeile 11, Worum es geht

**alt:** Am Solbergsee wird bei Bauarbeiten ein Runenstein mit denselben Kreisen gefunden wie an der Wand des Gutshauses. Seit einer Woche singen im Dorf die Kinder im Schlaf. Die Zelle wird geschickt, um herauszufinden, was geschieht, bevor die Lage eskaliert. Vor Ort findet sie einen verunsicherten Bauleiter, Eltern, die ihre Kinder nicht mehr wecken wollen, und eine Wand im Gutshaus, die unter der Tapete warm ist. Solberg ist Sperrzone. Die Zelle reist mit einer Genehmigung des Rates ein, getarnt als Mitarbeiter einer Stiftung für Denkmalpflege, die den Runenstein dokumentieren soll.

**neu:** Am Solbergsee wird bei Bauarbeiten ein Runenstein mit denselben Kreisen gefunden wie an der Wand des Gutshauses. Seit einer Woche singen im Dorf die Kinder im Schlaf. Die Zelle wird geschickt, um herauszufinden, was geschieht, bevor die Lage eskaliert. Vor Ort findet sie einen verunsicherten Bauleiter, Eltern, die ihre Kinder nicht mehr wecken wollen, und eine Wand im Gutshaus, die unter der Tapete warm ist. Das Gutshaus am See ist Sperrzone, sonst nur mit Schwarzer Akte zugänglich. Die Zelle reist mit einer Genehmigung des Rates ein, getarnt als Mitarbeiter einer Stiftung für Denkmalpflege, die den Runenstein dokumentieren soll.

- ergänzen: Das Gutshaus am See ist Sperrzone, sonst nur mit Schwarzer Akte zugänglich.
- streichen oder ersetzen: Solberg ist Sperrzone.

### Zeile 51, Knoten 1: Die Baustelle am See

**alt:** Die Baugrube, der Runenstein unter einer Plane, Bauarbeiter, Jens Harder. Der Stein liegt halb im Schlamm, die Kreise sind deutlich sichtbar. Am Waldrand stehen die Bäume dicht, der Boden ist aufgewühlt.

**neu:** Die Baugrube am Waldrand, Bauarbeiter, Jens Harder. Daneben liegt der Runenstein unter einer Plane, halb im Schlamm, wo der Bagger ihn abgesetzt hat. Die Kreise sind deutlich sichtbar. Gefunden wurde er fünfzig Meter weiter im Wald, auf einer Lichtung. Das Gutshaus liegt einen Kilometer entfernt. Am Waldrand stehen die Bäume dicht, der Boden ist aufgewühlt.

- ergänzen: Die Baugrube am Waldrand, Bauarbeiter, Jens Harder.
- ergänzen: Daneben liegt der Runenstein unter einer Plane, halb im Schlamm, wo der Bagger ihn abgesetzt hat.
- ergänzen: Die Kreise sind deutlich sichtbar.
- ergänzen: Gefunden wurde er fünfzig Meter weiter im Wald, auf einer Lichtung.
- ergänzen: Das Gutshaus liegt einen Kilometer entfernt.
- streichen oder ersetzen: Die Baugrube, der Runenstein unter einer Plane, Bauarbeiter, Jens Harder.
- streichen oder ersetzen: Der Stein liegt halb im Schlamm, die Kreise sind deutlich sichtbar.

### Zeile 69, Knoten 2: Das Dorf und die Kinder

**alt:** 

**neu:** - **Hinweis:** Dr. Lindqvist erzählt, was die Alten im Dorf den Kindern beibringen: Im Wald pfeift man nicht, man ruft nicht, und man nimmt nichts mit (führt zu „Was wirkt“).

- ergänzen: Hinweis: Dr.
- ergänzen: Lindqvist erzählt, was die Alten im Dorf den Kindern beibringen: Im Wald pfeift man nicht, man ruft nicht, und man nimmt nichts mit (führt zu "Was wirkt").

### Zeile 74, Knoten 3: Das Kirchenbuch und das Pfarrhaus

**alt:** Das alte Kirchenbuch von Solberg, Pfarrer Mattias Berg, ein kleines Archiv im Pfarrhaus. Das Kirchenbuch hat einen Eintrag von 1871, der mitten im Satz abbricht. Im Archiv liegt eine Kiste mit alten Papieren, darunter der Zeitungsartikel von 1872 (Handout 6.1) und der Brief des Pfarrers (Handout 6.2).

**neu:** Pfarrer Mattias Berg, ein kleines Archiv im Pfarrhaus und darin eine beglaubigte Abschrift des alten Kirchenbuchs von Solberg. Das Original liegt im Landesarchiv Uppsala. Der Eintrag von 1871 bricht auch in der Abschrift mitten im Satz ab. Im Archiv liegt eine Kiste mit alten Papieren, darunter der Zeitungsartikel von 1872 (Handout 6.1) und der Brief des Pfarrers (Handout 6.2).

- ergänzen: Der Eintrag von 1871 bricht auch in der Abschrift mitten im Satz ab.
- streichen oder ersetzen: Das Kirchenbuch hat einen Eintrag von 1871, der mitten im Satz abbricht.

### Zeile 95, Knoten 5: Das Gutshaus

**alt:** Das alte Gutshaus, die Wand mit den Kreisen, hinter Tapete oder Farbe. Ein Verwalter wohnt im Nebengebäude. Das Haus ist leer, die Luft steht. Die Wand im Speisesaal ist warm, die Tapete löst sich an einer Stelle.

**neu:** Das alte Gutshaus, die Wand mit den Kreisen, hinter Tapete oder Farbe. Niemand wohnt hier. Das Haus ist leer, die Luft steht. Die Wand im Speisesaal ist warm, die Tapete löst sich an einer Stelle.

- ergänzen: Niemand wohnt hier.
- streichen oder ersetzen: Ein Verwalter wohnt im Nebengebäude.

### Zeile 104, Knoten 5: Das Gutshaus

**alt:** Probe: Thaumaturg oder Paranormal Detective, Ritualismus gegen Schwer (3), um die Kreise zu lesen.

**neu:** Probe: Thaumaturg mit Ritualismus oder Paranormal Detective mit Okkultismus, jeweils gegen Schwer (3), um die Kreise zu lesen.

- ergänzen: Probe: Thaumaturg mit Ritualismus oder Paranormal Detective mit Okkultismus, jeweils gegen Schwer (3), um die Kreise zu lesen.
- streichen oder ersetzen: Probe: Thaumaturg oder Paranormal Detective, Ritualismus gegen Schwer (3), um die Kreise zu lesen.

### Zeile 170, Nichtspielercharaktere

**alt:** **Alfred Sundberg, Antiquar.** Er ist alt und gebrechlich. Er trägt einen schweren Spazierstock. Wenn die Zelle ihn enttarnt, wird er leise und zitiert aus alten Büchern. Er kann mit dem Stock zuschlagen: Angriff 2 + 2, Schaden 2. Er ist kein Kämpfer, aber er ist verzweifelt.

**neu:** **Alfred Sundberg, Antiquar.** Er ist alt und gebrechlich. Er trägt einen schweren Spazierstock. Wenn die Zelle ihn enttarnt, wird er leise und zitiert aus alten Büchern. Er hebt in seiner Verzweiflung den Stock, aber er schlägt nicht zu. Er hat keinen Angriff.

- ergänzen: Er hebt in seiner Verzweiflung den Stock, aber er schlägt nicht zu.
- ergänzen: Er hat keinen Angriff.
- streichen oder ersetzen: Er kann mit dem Stock zuschlagen: Angriff 2 + 2, Schaden 2.
- streichen oder ersetzen: Er ist kein Kämpfer, aber er ist verzweifelt.

### Zeile 179, Nachspiel

**alt:** **Was O.D.I.N. bekommt:** Den Runenstein oder eine Kopie der Kreise. Der Stein bleibt im Wald, aber ein Abrieb der Kreise geht an die Registratur. Die offene Akte von 1871 bleibt offen, mit neuen Fäden: die fehlende Seite, die Loge, der Name des Hauslehrers. Der rote Hering um Sundberg wird notiert. Die Loge Zum Schweigenden Kreis wird als aktive Organisation markiert.

**neu:** **Was O.D.I.N. bekommt:** Einen Abrieb der Kreise für die Registratur. Den Runenstein nur, wenn die Zelle ihn nicht zurückbringt, und dann kommt der Waldgänger jede Nacht wieder. Die offene Akte von 1871 bleibt offen, mit neuen Fäden: die fehlende Seite, die Loge, der Name des Hauslehrers. Der rote Hering um Sundberg wird notiert. Die Loge Zum Schweigenden Kreis wird als aktive Organisation markiert.

- ergänzen: Was O.D.I.N. bekommt: Einen Abrieb der Kreise für die Registratur.
- ergänzen: Den Runenstein nur, wenn die Zelle ihn nicht zurückbringt, und dann kommt der Waldgänger jede Nacht wieder.
- streichen oder ersetzen: Was O.D.I.N. bekommt: Den Runenstein oder eine Kopie der Kreise.
- streichen oder ersetzen: Der Stein bleibt im Wald, aber ein Abrieb der Kreise geht an die Registratur.

### Zeile 181, Nachspiel

**alt:** **Erfahrung:** 5 pro Charakter, +1 für eine friedliche Lösung, +1 für das Verfolgen der Spur der fehlenden Seite bis zur Hausbibel. Zusätzlich +1 für einen Investigator, der die Verbindung zwischen 1871 und der offenen Akte von 1938 herstellt.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn der Stein zurück im Wald ist und die Kinder still sind. Höchstens +1 EP persönlicher Bonus, etwa für eine friedliche Lösung. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa die Spur der fehlenden Seite bis zur Hausbibel oder die Verbindung zwischen 1871 und der offenen Akte von 1938.

- ergänzen: Erfahrung: 4 EP pro Charakter, 5, wenn die Akte rot geworden ist.
- ergänzen: +1 EP, wenn der Stein zurück im Wald ist und die Kinder still sind.
- ergänzen: Höchstens +1 EP persönlicher Bonus, etwa für eine friedliche Lösung.
- ergänzen: +1 EP für jeden Faden, den die Zelle aufnimmt, etwa die Spur der fehlenden Seite bis zur Hausbibel oder die Verbindung zwischen 1871 und der offenen Akte von 1938.
- streichen oder ersetzen: Erfahrung: 5 pro Charakter, +1 für eine friedliche Lösung, +1 für das Verfolgen der Spur der fehlenden Seite bis zur Hausbibel.
- streichen oder ersetzen: Zusätzlich +1 für einen Investigator, der die Verbindung zwischen 1871 und der offenen Akte von 1938 herstellt.

### Zeile 20, Was wirklich geschah

**alt:** Im Dezember 1938, in der Nacht zum 3., starb in Bad Grund ein Mädchen namens Liese Hartmann, zehn Jahre alt. Sie war die Tochter des Steigers Wilhelm Hartmann, der im Schacht „Silberner Hirsch“ arbeitete. Am Abend des 2. Dezember brachte ihr Vater einen Kristall mit nach Hause, den er am 1. Dezember in der Grube gefunden hatte: einen faustgroßen, milchigen Stein, ungewöhnlich warm. Liese nahm ihn mit ins Bett. In jener Nacht, in der in Solberg die Kinder sangen und neunzehn Erwachsene verschwanden, starb Liese in ihrem Zimmer. Der Arzt schrieb „Herzschlag“. Der Vater verkaufte den Kristall am 6. Dezember an den Sammler Hermann Wegener und verschwand am selben Tag im Schacht. Er wurde nie gefunden.

**neu:** Im Dezember 1938, in der Nacht zum 3., starb in Bad Grund ein Mädchen namens Liese Hartmann, zehn Jahre alt. Sie war die Tochter des Steigers Wilhelm Hartmann, der im Schacht „Silberner Hirsch“ arbeitete. Am Abend des 2. Dezember brachte ihr Vater einen Kristall mit nach Hause, den er am 1. Dezember in der Grube gefunden hatte: einen faustgroßen, milchigen Stein, ungewöhnlich warm. Liese nahm ihn mit ins Bett. In jener Nacht, in der in Solberg die Kinder sangen und neunzehn Erwachsene verschwanden, starb Liese in ihrem Zimmer. In derselben Nacht starben in Bad Grund zwei weitere Kinder im Schlaf. Der Arzt schrieb dreimal „Herzschlag“. Der Vater verkaufte den Kristall am 6. Dezember an den Sammler Hermann Wegener und verschwand am selben Tag im Schacht. Er wurde nie gefunden.

- ergänzen: In derselben Nacht starben in Bad Grund zwei weitere Kinder im Schlaf.
- ergänzen: Der Arzt schrieb dreimal "Herzschlag".
- streichen oder ersetzen: Der Arzt schrieb "Herzschlag".

### Zeile 49, Inge Lorenz, 58

**alt:** Lehrerin an der Grundschule. Sie will, dass die Kinder ihrer Klasse aufhören, im Schlaf zu singen. Sie weiß, dass drei Kinder aus ihrer Klasse betroffen sind, und dass alle drei in der Woche nach der Ausstellungseröffnung im Museum waren. Sie verschweigt, dass sie das Lied als altes Bad Grunder Lied von ihrer Großmutter kennt, die es 1938 von einem Mädchen namens Liese gehört hat. Sie redet schnell, besorgt, mit vielen Fragen. Sie sagt: „Die Kinder singen dasselbe Lied. Ich kenne es. Meine Großmutter hat es mir vorgesungen.“

**neu:** Lehrerin an der Grundschule. Sie will, dass die Kinder ihrer Klasse aufhören, im Schlaf zu singen. Sie weiß, dass drei Kinder aus ihrer Klasse betroffen sind, und dass alle drei in der Woche nach der Ausstellungseröffnung im Museum waren. Sie verschweigt, dass sie das Lied als altes Bad Grunder Lied von ihrer Großmutter kennt, die es in der Nacht zum 3. Dezember 1938 durch die Wand aus dem Nachbarhaus der Hartmanns gehört hat, von einem Mädchen namens Liese. Sie redet schnell, besorgt, mit vielen Fragen. Sie sagt: „Die Kinder singen dasselbe Lied. Ich kenne es. Meine Großmutter hat es mir vorgesungen.“

- ergänzen: Sie verschweigt, dass sie das Lied als altes Bad Grunder Lied von ihrer Großmutter kennt, die es in der Nacht zum 3.
- ergänzen: Dezember 1938 durch die Wand aus dem Nachbarhaus der Hartmanns gehört hat, von einem Mädchen namens Liese.
- streichen oder ersetzen: Sie verschweigt, dass sie das Lied als altes Bad Grunder Lied von ihrer Großmutter kennt, die es 1938 von einem Mädchen namens Liese gehört hat.

### Zeile 124, Knoten 5: Das Archiv der Stadt (Stadtarchiv Bad Grund)

**alt:** - **Hinweis:** Ein Aktenvermerk der Registratur über Spuke: Ein Spuk verschwindet, wenn man findet, was er wiederholt, und es beendet. (führt zu: Was wirkt, Konfrontation)

**neu:** - **Hinweis:** Ein Anruf bei der Registratur ergibt einen Aktenvermerk über Spuke: Ein Spuk verschwindet, wenn man findet, was er wiederholt, und es beendet. (führt zu: Was wirkt, Konfrontation)

- ergänzen: Hinweis: Ein Anruf bei der Registratur ergibt einen Aktenvermerk über Spuke: Ein Spuk verschwindet, wenn man findet, was er wiederholt, und es beendet.
- streichen oder ersetzen: Hinweis: Ein Aktenvermerk der Registratur über Spuke: Ein Spuk verschwindet, wenn man findet, was er wiederholt, und es beendet.

### Zeile 157, Ablauf

**alt:** 1. Die Zelle betritt das Museum oder beobachtet es von außen. Die Direktorin ist im Raum „Bergbau und Mineralien“ und liest vor. Ihre Stimme ist monoton. Jule steht neben ihr und hält ihre Hand. Die Enkelin ist an diesem Wochenende zu Besuch, weil ihre Mutter sie für zwei Tage zur Großmutter gebracht hat.

**neu:** 1. Die Zelle betritt das Museum oder beobachtet es von außen. Die Direktorin ist im Raum „Bergbau und Mineralien“ und liest vor. Ihre Stimme ist monoton. Jule steht neben ihr und hält ihre Hand. Die Enkelin ist noch bei ihrer Großmutter zu Besuch.

- ergänzen: Die Enkelin ist noch bei ihrer Großmutter zu Besuch.
- streichen oder ersetzen: Die Enkelin ist an diesem Wochenende zu Besuch, weil ihre Mutter sie für zwei Tage zur Großmutter gebracht hat.

### Zeile 196, Dr. Marianne Weber

**alt:** [entry - | Dr. Marianne Weber | Nichtspielercharakter · Museumsdirektorin]

**neu:** [entry - | Dr. Marianne Weber | Museumsdirektorin · Menschen]

- ergänzen: Marianne Weber Museumsdirektorin · Menschen]
- streichen oder ersetzen: Marianne Weber Nichtspielercharakter · Museumsdirektorin]

### Zeile 220, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter, +1 für die Lösung mit der Wahrheit, +1 für die Rettung der Direktorin und der Enkelin.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn Liese erlöst ist und Direktorin und Enkelin unversehrt sind. Höchstens +1 EP persönlicher Bonus, etwa für die Lösung mit der Wahrheit. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den zweiten Kristall im Schacht.

- ergänzen: Erfahrung: 4 EP pro Charakter, 5, wenn die Akte rot geworden ist.
- ergänzen: +1 EP, wenn Liese erlöst ist und Direktorin und Enkelin unversehrt sind.
- ergänzen: Höchstens +1 EP persönlicher Bonus, etwa für die Lösung mit der Wahrheit.
- ergänzen: +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den zweiten Kristall im Schacht.
- streichen oder ersetzen: Erfahrung: 5 EP pro Charakter, +1 für die Lösung mit der Wahrheit, +1 für die Rettung der Direktorin und der Enkelin.

### Zeile 222, Nachspiel

**alt:** **Totenköpfe:** Wenn die Zelle den Kristall an O.D.I.N. gibt, verliert die Stiftung in Basel einen Totenkopf, weil der Stein nicht auf den Markt kommt. Gibt sie ihn an das Kollegium, verliert O.D.I.N. einen Totenkopf, weil der Rat einen Nexus-Kristall nicht bekommt.

**neu:** **Totenköpfe:** Wenn die Zelle den Kristall abgibt, an den Rat oder an das Kollegium, verliert die Stiftung in Basel einen Totenkopf, weil der Stein nicht auf den Markt kommt. Gibt sie ihn dem Kollegium statt dem Rat, bekommt der Führungsoffizier Ärger: Vertrauen −1.

- ergänzen: Gibt sie ihn dem Kollegium statt dem Rat, bekommt der Führungsoffizier Ärger: Vertrauen −1.
- streichen oder ersetzen: Gibt sie ihn an das Kollegium, verliert O.D.I.N. einen Totenkopf, weil der Rat einen Nexus-Kristall nicht bekommt.

### Zeile 34, Jonas Vermeulen, 41

**alt:** Buchhalter, Freimaurer, verschwunden. Er war das vorsichtigste Mitglied, hatte den Logenabend abgesagt, um zu Maarten zu fahren. Sein Logenkalender ist der rote Hering. Er weiß nichts vom Ritual.

**neu:** Buchhalter, Freimaurer, verschwunden. Er war das vorsichtigste Mitglied, hatte den Logenabend abgesagt, um zu Maarten zu fahren. Sein Logenkalender ist der rote Hering. Er hielt das Ritual für ein Spiel.

- ergänzen: Er hielt das Ritual für ein Spiel.
- streichen oder ersetzen: Er weiß nichts vom Ritual.

### Zeile 37, Aylin Demir, 31

**alt:** Krankenschwester, verschwunden. Sie hatte in der Gruppe zuletzt gepostet: „Das Licht ist kein Licht. Es ist ein Auge.“ Sie ahnte etwas, aber zu spät.

**neu:** Krankenschwester, verschwunden. Ihr letzter Beitrag in der Gruppe endet mit: „Sagt ihm, das Licht ist kein Licht.“ Sie hatte geträumt, das Licht sei ein Auge. Sie ahnte etwas, aber zu spät.

- ergänzen: Ihr letzter Beitrag in der Gruppe endet mit: "Sagt ihm, das Licht ist kein Licht." Sie hatte geträumt, das Licht sei ein Auge.
- ergänzen: Sie ahnte etwas, aber zu spät.
- streichen oder ersetzen: Sie hatte in der Gruppe zuletzt gepostet: "Das Licht ist kein Licht.
- streichen oder ersetzen: Es ist ein Auge." Sie ahnte etwas, aber zu spät.

### Zeile 51, Briefing

**alt:** > „Drei Vermisste in Brüssel, alle in derselben Internetgruppe. Auf ihren Rechnern liegt ein Dokument, das aus unserer Druckerei stammt. Es ist ein Ritual, das nie hätte geschrieben werden dürfen. Findet heraus, wer es benutzt hat, und beendet es, bevor ein viertes Mitglied verschwindet. Die belgische Polizei hat noch keine Spur vom Ritual. Haltet es so.“ || Führungsoffizier

**neu:** > „Drei Vermisste in Brüssel, alle in derselben Internetgruppe. Auf ihren Rechnern liegt ein Dokument, das aus unserer Druckerei stammt. Es ist ein Ritual, das nie hätte geschrieben werden dürfen. Findet heraus, wer es benutzt hat, und beendet es, bevor ein viertes Mitglied verschwindet. Die belgische Polizei hält das Ritual für einen Scherz. Haltet es so.“ || Führungsoffizier

- ergänzen: Die belgische Polizei hält das Ritual für einen Scherz.
- streichen oder ersetzen: Die belgische Polizei hat noch keine Spur vom Ritual.

### Zeile 53, Briefing

**alt:** **Was die Akte enthält:** Namen und Adressen der drei Vermissten, Ausdrucke aus dem Forum „Illuminati Europa“, das Ritual „Das Zweite Licht“ als PDF, die Adresse von Maarten de Vries, ein Foto des Kellers aus einem Online-Inserat des Hauses. Der Beobachter, der die Meldung abgefangen hat, hat alle belgischen Mitglieder der Gruppe samt Adressen erfasst und der Akte beigelegt. **Spesen:** 2.000 €. **Anfordern:** Ein EMF-Detektor, Salz, ein Multispektralscanner. Ein Thaumaturg kann einen Bannkreis selbst errichten, wenn er die Fertigkeit Ritualismus beherrscht. Häufiges ohne Wartezeit.

**neu:** **Was die Akte enthält:** Namen und Adressen der drei Vermissten, Ausdrucke aus dem Forum „Illuminati Europa“, das Ritual „Das Zweite Licht“ als PDF. Der Beobachter, der die Meldung abgefangen hat, hat alle belgischen Mitglieder der Gruppe samt Adressen erfasst und der Akte beigelegt. **Spesen:** 2.000 €. **Anfordern:** Ein EMF-Detektor, Salz, ein Multispektralscanner. Ein Thaumaturg kann einen Bannkreis selbst errichten, wenn er die Fertigkeit Ritualismus beherrscht. Häufiges ohne Wartezeit.

- ergänzen: Was die Akte enthält: Namen und Adressen der drei Vermissten, Ausdrucke aus dem Forum "Illuminati Europa", das Ritual "Das Zweite Licht" als PDF.
- streichen oder ersetzen: Was die Akte enthält: Namen und Adressen der drei Vermissten, Ausdrucke aus dem Forum "Illuminati Europa", das Ritual "Das Zweite Licht" als PDF, die Adresse von Maarten de Vries, ein Foto des Kellers aus einem Online-Inserat des Hauses.

### Zeile 64, Knoten 1: Die Wohnungen der Vermissten

**alt:** - **Hinweis:** Aylin Demirs letzter Forenbeitrag: „Das Licht ist kein Licht. Es ist ein Auge.“ Ein Investigator mit Menschenkenntnis erkennt, dass sie als Einzige Angst hatte. (führt zu Knoten 2)

**neu:** - **Hinweis:** Aylin Demirs letzter Forenbeitrag: „Sagt ihm, das Licht ist kein Licht.“ Ein Investigator mit Menschenkenntnis erkennt, dass sie als Einzige Angst hatte. (führt zu Knoten 2)

- streichen oder ersetzen: Es ist ein Auge." Ein Investigator mit Menschenkenntnis erkennt, dass sie als Einzige Angst hatte.

### Zeile 75, Knoten 2: Das Forum „Illuminati Europa“

**alt:** 

**neu:** - **Hinweis:** Nadia zeigt Maartens letzte private Nachricht an sie: „Es kommt durch mich zurück. Ich bin die Tür.“ (führt zu Knoten 5)

- ergänzen: Hinweis: Nadia zeigt Maartens letzte private Nachricht an sie: "Es kommt durch mich zurück.
- ergänzen: Ich bin die Tür." (führt zu Knoten 5)

### Zeile 98, Knoten 5: Der Keller des Reihenhauses

**alt:** Der Keller ist ein rechteckiger Raum, etwa 4 mal 5 Meter, mit einer Treppe von oben. Der Kreis ist mit Kreide und Asche auf den Betonboden gemalt, etwa 2 Meter im Durchmesser. In der Mitte liegt ein faustgroßer Kristall. Der Kreis ist warm, als läge eine Heizung darunter.

**neu:** Der Keller ist ein rechteckiger Raum, etwa 4 mal 5 Meter, mit einer Treppe von oben. Der Kreis ist mit Kreide und Asche auf den Betonboden gemalt, etwa 2 Meter im Durchmesser. In der Mitte liegt ein faustgroßer Kristall. Der Kreis ist warm, als läge eine Heizung darunter. Tagsüber schläft Maarten im Obergeschoss. Wer leise ist (Heimlichkeit gegen Machbar (2)), kann den Keller untersuchen, ohne dass er es merkt.

- ergänzen: Tagsüber schläft Maarten im Obergeschoss.
- ergänzen: Wer leise ist (Heimlichkeit gegen Machbar (2)), kann den Keller untersuchen, ohne dass er es merkt.

### Zeile 104, Knoten 5: Der Keller des Reihenhauses

**alt:** - **Probe:** Ein Thaumaturg mit Ritualismus analysiert den Kreis. Schwierigkeit: Schwer (3). Ein Scientist mit Physik misst die Wärme. Schwierigkeit: Machbar (2). Ein Psion mit Telepathie hört die Stimme. Schwierigkeit: Schwer (3). Ein Soldier mit Taktik erkennt, dass der Keller nur einen Ausgang hat. Schwierigkeit: Einfach (1).

**neu:** - **Probe:** Ein Thaumaturg mit Ritualismus analysiert den Kreis. Schwierigkeit: Schwer (3). Ein Scientist mit Physik misst die Wärme. Schwierigkeit: Machbar (2). Ein Psion mit Telepathie hört die Stimme. Schwierigkeit: Schwer (3). Ein Soldier mit Taktik erkennt, dass außer der Treppe nur das Gartenfenster hinausführt. Schwierigkeit: Einfach (1).

- ergänzen: Ein Soldier mit Taktik erkennt, dass außer der Treppe nur das Gartenfenster hinausführt.

### Zeile 111, Knoten 5: Der Keller des Reihenhauses

**alt:** **Was will es?** Die Stimme will durch den Kreis zurückkehren und Maarten als Tor benutzen. Hinweise in Knoten 5, 5, 5.

**neu:** **Was will es?** Die Stimme will durch den Kreis zurückkehren und Maarten als Tor benutzen. Hinweise in Knoten 2, 5, 5.

- ergänzen: Hinweise in Knoten 2, 5, 5.
- streichen oder ersetzen: Hinweise in Knoten 5, 5, 5.

### Zeile 155, Lösungen

**alt:** 

**neu:** **Ohne Thaumaturg.** Wer den Kristall aus dem Kreis nimmt und in Beryllium oder Salz legt, schließt den Kreis für eine Nacht. Die Risslinge zerfallen. Am nächsten Tag schickt das Kollegium einen Thaumaturgen, der ihn versiegelt.

- ergänzen: Ohne Thaumaturg.
- ergänzen: Wer den Kristall aus dem Kreis nimmt und in Beryllium oder Salz legt, schließt den Kreis für eine Nacht.
- ergänzen: Die Risslinge zerfallen.
- ergänzen: Am nächsten Tag schickt das Kollegium einen Thaumaturgen, der ihn versiegelt.

### Zeile 196, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter. +1 EP für die Lösung ohne Kampf. +1 EP für die Versiegelung des Kreises.

**neu:** **Die drei Verschwundenen:** Sophie Renard, Jonas Vermeulen und Aylin Demir kommen nicht zurück. Wird der Kreis versiegelt, verstummt Sophies Stimme im Keller. Ihre Akten bleiben bei der Registratur offen.

- ergänzen: Die drei Verschwundenen: Sophie Renard, Jonas Vermeulen und Aylin Demir kommen nicht zurück.
- ergänzen: Wird der Kreis versiegelt, verstummt Sophies Stimme im Keller.
- ergänzen: Ihre Akten bleiben bei der Registratur offen.
- streichen oder ersetzen: Erfahrung: 5 EP pro Charakter.
- streichen oder ersetzen: +1 EP für die Lösung ohne Kampf.
- streichen oder ersetzen: +1 EP für die Versiegelung des Kreises.

### Zeile 198, Nachspiel

**alt:** **Totenköpfe:** Die Erleuchteten verlieren einen Totenkopf, weil das Ritual beendet wurde. Die Erleuchteten sinken damit von drei auf zwei Totenköpfe.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn der Kreis versiegelt und Maarten aufgehalten ist. Höchstens +1 EP persönlicher Bonus, etwa für die Lösung ohne Kampf. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den Hobbygeologen mit den übrigen Steinen. **Totenköpfe:** Die Erleuchteten verlieren zwei Totenköpfe, weil ihr Schlüsselkopf Maarten de Vries ausgeschaltet ist, und sinken von drei auf einen. Nach der nächsten Mission würfelt die Spielleitung für diesen Plan nicht.

- ergänzen: Erfahrung: 4 EP pro Charakter, 5, wenn die Akte rot geworden ist.
- ergänzen: +1 EP, wenn der Kreis versiegelt und Maarten aufgehalten ist.
- ergänzen: Höchstens +1 EP persönlicher Bonus, etwa für die Lösung ohne Kampf.
- ergänzen: +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den Hobbygeologen mit den übrigen Steinen.
- ergänzen: Totenköpfe: Die Erleuchteten verlieren zwei Totenköpfe, weil ihr Schlüsselkopf Maarten de Vries ausgeschaltet ist, und sinken von drei auf einen.
- ergänzen: Nach der nächsten Mission würfelt die Spielleitung für diesen Plan nicht.
- streichen oder ersetzen: Totenköpfe: Die Erleuchteten verlieren einen Totenkopf, weil das Ritual beendet wurde.
- streichen oder ersetzen: Die Erleuchteten sinken damit von drei auf zwei Totenköpfe.

## Englisch

### Zeile 31, The Eight Files

**alt:** 3 | Number 341 | Cardiff, Grangetown | The Dead, Humans | Grey

**neu:** 3 | Number 341 | Cardiff, Grangetown | The Dead, Humans | Grey, can turn red

- ergänzen: 3 Number 341 Cardiff, Grangetown The Dead, Humans Grey, can turn red
- streichen oder ersetzen: 3 Number 341 Cardiff, Grangetown The Dead, Humans Grey

### Zeile 36, The Eight Files

**alt:** 8 | The Second Light | Brussels, Anderlecht | Humans, The Voice | Grey

**neu:** 8 | The Second Light | Brussels, Anderlecht | Humans, The Voice | Grey, can turn red

- ergänzen: 8 The Second Light Brussels, Anderlecht Humans, The Voice Grey, can turn red
- streichen oder ersetzen: 8 The Second Light Brussels, Anderlecht Humans, The Voice Grey

### Zeile 45, The Eight Files

**alt:** **File 4: Kessler.** A quiet accountant has been working at a Basel foundation for four years. Six months ago he fell ill, now he is back, and a colleague does not believe his memory gaps. The cell is to discreetly find out who the man calling himself Martin Kessler is.

**neu:** **File 4: Kessler.** A quiet accountant worked at a Basel foundation for four years. In March 2025 he fell ill, in January he came back, and a colleague does not believe his memory gaps. The cell is to discreetly find out who the man calling himself Martin Kessler is.

- ergänzen: In March 2025 he fell ill, in January he came back, and a colleague does not believe his memory gaps.
- streichen oder ersetzen: Six months ago he fell ill, now he is back, and a colleague does not believe his memory gaps.

### Zeile 63, Connecting Files

**alt:** Some files share open threads. The children’s song appears in Files 5, 6 and 7. The time 22:10 appears in Files 2 and 3. The unknown abbreviation in the Crystal Ledger connects File 1 to File 2. The game master can pick up these threads when weaving the files into a campaign. Each file also works on its own.

**neu:** Some files share open threads. The children’s song appears in Files 5, 6 and 7. The time 22:10 appears in Files 2, 3 and 6. The unknown abbreviation in the Crystal Ledger connects File 1 to File 2. The game master can pick up these threads when weaving the files into a campaign. Each file also works on its own.

- ergänzen: The time 22:10 appears in Files 2, 3 and 6.
- streichen oder ersetzen: The time 22:10 appears in Files 2 and 3.

### Zeile 22, What Really Happened

**alt:** For a few weeks, Linus has been hearing a hum that is getting louder. He sleeps badly, eats little, and when he concentrates, things become warm. Three weeks ago, he found a small, milky crystal on the banks of the Elbe that dampened the hum when he held it tight. He took it home and hid it under the mattress. Last night he was at the Kowalskis’ to watch the fish swim. He thought of nothing, only of the water, and the water began to boil. Linus ran home, packed his rucksack and disappeared. He does not want his parents to get into trouble because of him. He went on foot towards the S-Bahn, then into the city centre, and is looking for a place where it is quiet. He has hidden in the old Elbe Tunnel, in the east tube, where the hum is quieter.

**neu:** For a few weeks, Linus has been hearing a hum that is getting louder. He sleeps badly, eats little, and when he concentrates, things become warm. Three weeks ago, he found a small, milky crystal on the banks of the Elbe that dampened the hum as long as he held it tight. When he let go, the hum came back louder: the stone feeds the gift. Linus took it home and hid it under the mattress. Last night he was at the Kowalskis’ to watch the fish swim. He thought of nothing, only of the water, and the water began to boil. Linus ran home, packed his rucksack and disappeared. He does not want his parents to get into trouble because of him. He went on foot towards the S-Bahn, then into the city centre, and is looking for a place where it is quiet. He has hidden in the old Elbe Tunnel, in the east tube, where the hum is quieter.

- ergänzen: When he let go, the hum came back louder: the stone feeds the gift.
- ergänzen: Linus took it home and hid it under the mattress.
- streichen oder ersetzen: He took it home and hid it under the mattress.

### Zeile 44, Mr Kowalski, 52

**alt:** Neighbour, insurance salesman. Wants peace and an explanation for the dead aquarium. Knows nothing about the supernatural, suspects a former tenant. Conceals that he did call the police after all, because he does not trust the Vosses. Speaks loudly, indignantly, repeats himself.

**neu:** Neighbour, insurance salesman. Wants peace and an explanation for the dead aquarium. Knows nothing about the supernatural, suspects a former tenant. Conceals that he did call the police last night after all, because of the aquarium and because he does not trust the Vosses. The patrol came, found nothing and left again. Speaks loudly, indignantly, repeats himself.

- ergänzen: The patrol came, found nothing and left again.

### Zeile 127, Escalation

**alt:** The file turns red if the cell is too slow or if Jonas Vogt notices them. Vogt is not a murderer, but he will not let Linus go without a fight. If the cell enters the old Elbe Tunnel without concealing themselves, Vogt addresses them by name and places himself between them and Linus. Linus’ gift reacts to the tension: the lamps in the tunnel flicker, the water in the puddles begins to steam.

**neu:** The file turns red if the cell is too slow or if Jonas Vogt notices them. The cell is too slow if it visits more than three nodes before setting out for the old Elbe Tunnel. Vogt is not a murderer, but he will not let Linus go without a fight. If the cell enters the old Elbe Tunnel without concealing themselves, Vogt addresses them by name and places himself between them and Linus. Linus’ gift reacts to the tension: the lamps in the tunnel flicker, the water in the puddles begins to steam.

- ergänzen: The cell is too slow if it visits more than three nodes before setting out for the old Elbe Tunnel.

### Zeile 201, Aftermath

**alt:** **The Veil:** The neighbours saw the boiling aquarium, but the police were not called, except by Mr Kowalski, who reported a break-in. An agent can close the file: The Kowalskis get an explanation: a faulty heating element. The Vosses get a new legend for Linus’ disappearance: a boarding school, a cure. The S-Bahn recordings are secured and deleted.

**neu:** **The Veil:** The neighbours saw the boiling aquarium, but the police were not called, except by Mr Kowalski, who reported a break-in two weeks ago and called the patrol last night. An agent can close the file: The Kowalskis get an explanation: a faulty heating element. The Vosses get a new legend for Linus’ disappearance: a boarding school, a cure. The S-Bahn recordings are secured and deleted.

- ergänzen: The Veil: The neighbours saw the boiling aquarium, but the police were not called, except by Mr Kowalski, who reported a break-in two weeks ago and called the patrol last night.
- streichen oder ersetzen: The Veil: The neighbours saw the boiling aquarium, but the police were not called, except by Mr Kowalski, who reported a break-in.

### Zeile 205, Aftermath

**alt:** **Experience:** 5 XP per character. Plus 1 XP for a solution without combat. Plus 1 XP for saving the crystal.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if Linus is safe. At most +1 XP personal bonus, for example for a solution without combat. +1 XP for each thread the cell takes up, for example the abbreviation in the Crystal Ledger.

- streichen oder ersetzen: Plus 1 XP for a solution without combat.
- streichen oder ersetzen: Plus 1 XP for saving the crystal.

### Zeile 14, What It Is About

**alt:** There, in the basement of the Hold, according to old building plans, there is a room with the number 4/12. In the official inspections it does not exist. The cell is to find out what is going on with the room without alerting the Hold. The cell’s handler knows nothing of the assignment.

**neu:** There, in the basement of the Hold, according to old building plans, there is a room with the number 4/12. The current floor plan does not show it. The cell is to find out what is going on with the room without alerting the Hold. The cell’s handler knows nothing of the assignment.

- ergänzen: The current floor plan does not show it.
- streichen oder ersetzen: In the official inspections it does not exist.

### Zeile 20, What Really Happened

**alt:** **The backstory:** Hold-9 in Prague was founded in 1992, in an old vaulted cellar beneath the old town. The building plan from 1991 shows twelve rooms in the basement. Eleven were built. The twelfth room, number 4/12, exists only on paper, but not in reality. That is what the official documents say.

**neu:** **The backstory:** Hold-9 in Prague was founded in 1992, in an old vaulted cellar beneath the old town. The conversion plan from 1991 keeps the numbering of the old air-raid shelter and shows twelve rooms in the basement. Eleven were fitted out. The twelfth room, number 4/12, exists only on paper, but not in reality. That is what the current floor plan says.

- ergänzen: The conversion plan from 1991 keeps the numbering of the old air-raid shelter and shows twelve rooms in the basement.
- ergänzen: Eleven were fitted out.
- ergänzen: That is what the current floor plan says.
- streichen oder ersetzen: The building plan from 1991 shows twelve rooms in the basement.
- streichen oder ersetzen: Eleven were built.
- streichen oder ersetzen: That is what the official documents say.

### Zeile 30, What Really Happened

**alt:** **The red herring:** The Hold director of Hold-9, Major Pavel Černý, a Soldier of the old school, considers the room to be an artefact of the communist past: a former listening room of the Czechoslovak secret service, which is missing from the plans because it never officially existed. He found the room years ago, but never entered it, because he believes it is a trap. He has fitted the door with a padlock and had the room removed from the current plans. He conceals this because he fears that O.D.I.N. would close the Hold if it became known that there is an unknown room there.

**neu:** **The red herring:** The Hold director of Hold-9, Major Pavel Černý, a Soldier of the old school, considers the room to be an artefact of the communist past: a former listening room of the Czechoslovak secret service, which is missing from the plans because it never officially existed. He found the room years ago, but never entered it, because he believes it is a trap. He has fitted the door with a padlock and had the room removed from the current plans, by a construction company that does not exist, paid from the Hold’s funds. He conceals this because he fears that O.D.I.N. would close the Hold if it became known that there is an unknown room there.

- ergänzen: He has fitted the door with a padlock and had the room removed from the current plans, by a construction company that does not exist, paid from the Hold's funds.
- streichen oder ersetzen: He has fitted the door with a padlock and had the room removed from the current plans.

### Zeile 48, Ing. Marta Nováková, 47

**alt:** Civil engineer and Hold technician. She knows the Hold’s plans better than anyone else. She wants the plans to be correct, and it worries her that Room 4/12 is missing from the current plan. She knows that Černý found the room, but she has never entered it. She conceals that she once heard knocking from the room at night, even though it should have been empty. She talks quickly, technically, with lots of numbers.

**neu:** Civil engineer and Hold technician. She knows the Hold’s plans better than anyone else. She wants the plans to be correct, and it worries her that Room 4/12 is missing from the current plan. She knows that Černý found the room, but she has never entered it. She conceals that she once heard knocking from the room at night, even though it should have been empty. Eng. K. Svoboda, who added pencil notes to the old plans and carried out the first inspection in 1992, was her mentor. She knows that he never wanted Room 4/12 opened. She talks quickly, technically, with lots of numbers.

- ergänzen: Eng.
- ergänzen: K.
- ergänzen: Svoboda, who added pencil notes to the old plans and carried out the first inspection in 1992, was her mentor.
- ergänzen: She knows that he never wanted Room 4/12 opened.

### Zeile 56, Eliška, 12

**alt:** Daughter of an external service provider. Her father maintains the Hold’s heating system, and she sometimes accompanies him to the cellar. She has often explored the Hold. She wants to have adventures and be taken seriously by the agents. She knows that Room 4/12 is sometimes there and sometimes not. She conceals that she once looked through the keyhole and saw that the room is larger inside than outside. She talks quickly, curiously, with childlike directness.

**neu:** Daughter of a civilian employee of the Hold. Her father helps Marta Nováková maintain the heating, and she sometimes accompanies him to the cellar. She has often explored the Hold. She wants to have adventures and be taken seriously by the agents. She knows that Room 4/12 is sometimes there and sometimes not. She conceals that she once looked through the keyhole and saw that the room is larger inside than outside. She talks quickly, curiously, with childlike directness.

- ergänzen: Daughter of a civilian employee of the Hold.
- streichen oder ersetzen: Daughter of an external service provider.

### Zeile 74, Briefing

**alt:** **The private favour:** Dr. Brandl contacts the cell before the briefing, via a dead drop or a personal meeting. She gives the cell a note with the abbreviation “silence 4/12” and the reference to Hold-9 (Handout 2.1). She asks the cell to find out what the abbreviation means and report back to her. She offers a favour in return: access to the Crystal Archive in Oxford or a letter of recommendation to the Seal Keepers.

**neu:** **The private favour:** Dr. Brandl contacts the cell before the briefing, via a dead drop or a personal meeting. She gives the cell a note with the abbreviation “silence 4/12” and the reference to Hold-9 (Handout 2.1). She asks the cell to find out what the abbreviation means and report back to her. She offers a favour in return: access to the Crystal Archive in Oxford or a letter of recommendation to the Seal Keepers. If the cell asks for equipment, Brandl gives them a beryllium isolation container from the Hold-7 workshop.

- ergänzen: If the cell asks for equipment, Brandl gives them a beryllium isolation container from the Hold-7 workshop.

### Zeile 86, Node 1: The Hold Archive

**alt:** - **Clue:** An inspection report from 1992 mentions “irregularities in the basement, Room 4/12 not entered” (Handout 2.2). (leads to Černý, Node 2)

**neu:** - **Clue:** An inspection report from 1992 notes: “Room 4/12 not entered. Door locked, key not found.” (Handout 2.2). (leads to Černý, Node 2)

- ergänzen: Door locked, key not found." (Handout 2.2).

### Zeile 104, Node 3: The Canteen

**alt:** - **Clue:** Eliška tells the cell that the room is sometimes there and sometimes not. (leads to Room 4/12) - **Clue:** Eliška has seen through the keyhole that the room is larger inside than outside. (leads to Room 4/12)

**neu:** - **Clue:** Eliška tells the cell that the room is sometimes there and sometimes not. (leads to Room 4/12, Conclusion 2) - **Clue:** Eliška has seen through the keyhole that the room is larger inside than outside. (leads to Room 4/12, Conclusion 2)

- ergänzen: (leads to Room 4/12, Conclusion 2) - Clue: Eliška has seen through the keyhole that the room is larger inside than outside.
- ergänzen: (leads to Room 4/12, Conclusion 2)
- streichen oder ersetzen: (leads to Room 4/12) - Clue: Eliška has seen through the keyhole that the room is larger inside than outside.
- streichen oder ersetzen: (leads to Room 4/12)

### Zeile 107, Node 3: The Canteen

**alt:** - **Clue:** An Agent finds irregularities in Černý’s service file in the Hold finances: payments to a construction company that does not exist. (leads to Černý, Node 2)

**neu:** - **Clue:** The Hold cook, who also keeps the accounts, wonders about payments to a construction company that never set foot in the Hold. (leads to Černý, Node 2)

- ergänzen: Clue: The Hold cook, who also keeps the accounts, wonders about payments to a construction company that never set foot in the Hold.
- streichen oder ersetzen: Clue: An Agent finds irregularities in Černý's service file in the Hold finances: payments to a construction company that does not exist.

### Zeile 115, Node 4: The Basement Corridor Before Room 4/12

**alt:** - **Clue:** A Psion hears a silence near the room that is deeper than any shielding: no thoughts, no hum, nothing. (leads to Room 4/12)

**neu:** - **Clue:** A Psion near the room hears their own thoughts come back a heartbeat too late, as if echoing from another time. (leads to Room 4/12, Conclusion 2)

- ergänzen: Clue: A Psion near the room hears their own thoughts come back a heartbeat too late, as if echoing from another time.
- ergänzen: (leads to Room 4/12, Conclusion 2)
- streichen oder ersetzen: Clue: A Psion hears a silence near the room that is deeper than any shielding: no thoughts, no hum, nothing.
- streichen oder ersetzen: (leads to Room 4/12)

### Zeile 127, Node 5: Room 4/12 and the Room Behind the Door

**alt:** - **Clue:** A Scientist with Physics recognises that the room geometry is wrong: the room is 1.2 metres longer on the inside than outside. (leads to Conclusion 4) - **Clue:** A Thaumaturge who touches the stone feels that it is warm and whispers, and that the whisper gets louder when lifted. (leads to Conclusion 4)

**neu:** - **Clue:** A Scientist with Physics recognises that the room geometry is wrong: the room is 1.2 metres longer on the inside than outside, and the geometry warps most around the table with the stone. (leads to Conclusions 2 and 4) - **Clue:** A Thaumaturge who touches the stone feels that it is warm and whispers, and that the whisper gets louder when lifted. Meanwhile the walls of the room warp. (leads to Conclusion 4)

- ergänzen: Clue: A Scientist with Physics recognises that the room geometry is wrong: the room is 1.2 metres longer on the inside than outside, and the geometry warps most around the table with the stone.
- ergänzen: (leads to Conclusions 2 and 4) - Clue: A Thaumaturge who touches the stone feels that it is warm and whispers, and that the whisper gets louder when lifted.
- ergänzen: Meanwhile the walls of the room warp.
- streichen oder ersetzen: Clue: A Scientist with Physics recognises that the room geometry is wrong: the room is 1.2 metres longer on the inside than outside.
- streichen oder ersetzen: (leads to Conclusion 4) - Clue: A Thaumaturge who touches the stone feels that it is warm and whispers, and that the whisper gets louder when lifted.

### Zeile 137, Node 5: Room 4/12 and the Room Behind the Door

**alt:** **2. Which origin?** | The Shifted. The room is a fold in the world, created in the night of Nordlicht 1977. | Clues in Node 4, 5

**neu:** **2. Which origin?** | The Shifted. The room is a fold in the world, created in the night of Nordlicht 1977. | Clues in Node 3, 4, 5

- ergänzen: Clues in Node 3, 4, 5
- streichen oder ersetzen: Clues in Node 4, 5

### Zeile 177, Solutions

**alt:** **Reward knowledge from the investigation:** Whoever has found the old building plan from 1977 knows that the room was originally a storage room. Whoever knows the open case about Nordlicht recognises the stone as the Nordlicht stone. Whoever has seen the abbreviation “silence 4/12” knows that the room is noted in the Crystal Ledger and that the matter must be significant for the Seal Keepers. None of these clues reveal that the stone is the anchor. The cell must recognise that themselves.

**neu:** **Reward knowledge from the investigation:** Whoever has found the old building plan from 1977 knows that the room was originally a storage room. Whoever knows the open case about Nordlicht recognises the stone as the Nordlicht stone. Whoever has seen the abbreviation “silence 4/12” knows that the room is noted in the Crystal Ledger and that the matter must be significant for the Seal Keepers. Whoever also knows the measurements at the stone from Node 5 recognises it as the anchor.

- ergänzen: Whoever also knows the measurements at the stone from Node 5 recognises it as the anchor.
- streichen oder ersetzen: None of these clues reveal that the stone is the anchor.
- streichen oder ersetzen: The cell must recognise that themselves.

### Zeile 183, Opponents

**alt:** Major Pavel Černý is not an enemy as long as the cell does not alarm the Hold. If he confronts the cell in the basement, he raises his voice and demands an explanation. He only attacks if the cell opens the room or takes the stone with them. His values are below.

**neu:** Major Pavel Černý is not an enemy as long as the cell does not alarm the Hold. If he confronts the cell in the basement, he raises his voice and demands an explanation. He only attacks if the cell tries to leave the Hold with the stone without telling him what it is. His values are below.

- ergänzen: He only attacks if the cell tries to leave the Hold with the stone without telling him what it is.
- streichen oder ersetzen: He only attacks if the cell opens the room or takes the stone with them.

### Zeile 204, Aftermath

**alt:** **Experience:** 5 XP per character. +1 XP for the solution without combat. +1 XP for securing the stone.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the cell has secured the stone. At most +1 XP personal bonus, for example for the solution without combat. +1 XP for each thread the cell takes up, for example the stone that counts backwards.

- ergänzen: +1 XP if the cell has secured the stone.
- ergänzen: At most +1 XP personal bonus, for example for the solution without combat.
- ergänzen: +1 XP for each thread the cell takes up, for example the stone that counts backwards.
- streichen oder ersetzen: +1 XP for the solution without combat.
- streichen oder ersetzen: +1 XP for securing the stone.

### Zeile 42, Daniel Keane, 44

**alt:** Former Soldier, now a security consultant. Broad-shouldered, leather jacket, boots, a piece of ashsilver on a chain around his neck. Wants to secure the visor for the quartermaster because he owes Idris Pryce a favour. Knows that the visor hums when put on and that it attracts the Dead. Conceals that, since his time in service, he hears voices at night when he touches his silver. Speaks little, observes much, likes to stand in the dark.

**neu:** Former Soldier, now a security consultant. Broad-shouldered, leather jacket, boots, a piece of ashsilver on a chain around his neck, lent to him by Idris Pryce for this job. Wants to secure the visor for the quartermaster because he owes Idris Pryce a favour. Knows that the visor hums when put on and that it attracts the Dead. Conceals that, since his time in service, he hears voices at night when he touches silver. Speaks little, observes much, likes to stand in the dark.

- ergänzen: Broad-shouldered, leather jacket, boots, a piece of ashsilver on a chain around his neck, lent to him by Idris Pryce for this job.
- streichen oder ersetzen: Broad-shouldered, leather jacket, boots, a piece of ashsilver on a chain around his neck.

### Zeile 52, Briefing

**alt:** **What the file contains:** Address of the pawnshop, name of the pawnbroker, photo of the visor from an online advert, a short note from the quartermaster: “Piece has been missing since 1989, made by Evan Pryce, the inside bears his name, do not open, do not put on”, a note from the Collegium: “Ashsilver with Echo, secure, wrap in lead, bring to Wales”. **Expenses:** €2,000. **Requisition:** An EMF detector, salt, a beryllium isolation container, a vehicle with false plates. The handler does not say that the quartermaster and the Collegium have already sent their own people.

**neu:** **What the file contains:** Address of the pawnshop, name of the pawnbroker, photo of the visor from an online advert, a short note from the quartermaster: “Piece has been missing since 1989, made by Evan Pryce, the inside bears his name, do not open, do not put on”. **Expenses:** €2,000. **Requisition:** An EMF detector, salt, a beryllium isolation container, a vehicle with false plates. The handler does not say that the quartermaster and the Collegium have already sent their own people.

- ergänzen: What the file contains: Address of the pawnshop, name of the pawnbroker, photo of the visor from an online advert, a short note from the quartermaster: "Piece has been missing since 1989, made by Evan Pryce, the inside bears his name, do not open, do not put on".
- streichen oder ersetzen: What the file contains: Address of the pawnshop, name of the pawnbroker, photo of the visor from an online advert, a short note from the quartermaster: "Piece has been missing since 1989, made by Evan Pryce, the inside bears his name, do not open, do not put on", a note from the Collegium: "Ashsilver with Echo, secure, wrap in lead, bring to Wales".

### Zeile 62, Node 1: The Pawnshop in Grangetown

**alt:** - **Clue:** Gwynne talks about three interested parties: an art dealer from Bath, an antiques dealer from Bristol and a silent man in a leather jacket who came in once and left again (leads to Miriam Hale, Alistair Vane and Daniel Keane).

**neu:** - **Clue:** After Insight against Doable (2), Gwynne talks about three interested parties: an art dealer from Bath, an antiques dealer from Bristol and a silent man in a leather jacket who came in once and left again (leads to Node 4, to Alistair Vane and to Node 3).

- ergänzen: Clue: After Insight against Doable (2), Gwynne talks about three interested parties: an art dealer from Bath, an antiques dealer from Bristol and a silent man in a leather jacket who came in once and left again (leads to Node 4, to Alistair Vane and to Node 3).
- streichen oder ersetzen: Clue: Gwynne talks about three interested parties: an art dealer from Bath, an antiques dealer from Bristol and a silent man in a leather jacket who came in once and left again (leads to Miriam Hale, Alistair Vane and Daniel Keane).

### Zeile 80, Node 2: Hold-2, the Workshop

**alt:** - **Clue for Soldier:** An Echo roll in the workshop shows that the silver in the Hold has been restless since the visor resurfaced. A previous owner warns of a man in a dark coat who wants to lock the piece away (leads to Miriam Hale, to the Collegium).

**neu:** - **Clue:** The quartermaster says the Psionics Core has been reporting a young man in Splott for three days, whose gift has awakened and who hears names at night (leads to Node 5). - **Clue for Soldier:** An Echo roll in the workshop shows that the silver in the Hold has been restless since the visor resurfaced. A previous owner warns of a man in a dark coat who wants to lock the piece away (leads to Node 4, to the art dealer from Bath).

- ergänzen: Clue: The quartermaster says the Psionics Core has been reporting a young man in Splott for three days, whose gift has awakened and who hears names at night (leads to Node 5).
- streichen oder ersetzen: Clue for Soldier: An Echo roll in the workshop shows that the silver in the Hold has been restless since the visor resurfaced.

### Zeile 84, Node 2: Hold-2, the Workshop

**alt:** **Tests:** Echo against Hard (3) to sense that the silver in the Hold has been restless since the visor resurfaced. Thaumaturgy against Doable (2) to recognise that the visor is not a dangerous artefact but a carrier. Shining classes: Soldier, Thaumaturge, Investigator.

**neu:** **Tests:** Echo roll, only for Soldiers with Echo: the game master secretly rolls a D6. If the result is equal to or less than the Echo, the Soldier senses that the silver in the Hold has been restless since the visor resurfaced. Thaumaturgy against Doable (2) to recognise that the visor is not a dangerous artefact but a carrier. Shining classes: Soldier, Thaumaturge, Investigator.

- ergänzen: Tests: Echo roll, only for Soldiers with Echo: the game master secretly rolls a D6.
- ergänzen: If the result is equal to or less than the Echo, the Soldier senses that the silver in the Hold has been restless since the visor resurfaced.

### Zeile 92, Node 3: The Street in Front of the Pawnshop

**alt:** 

**neu:** - **Clue:** Keane says that the quartermasters scatter salt in front of the armoury and leave the light on when the silver hums at night (leads to What works?).

- ergänzen: Clue: Keane says that the quartermasters scatter salt in front of the armoury and leave the light on when the silver hums at night (leads to What works?).

### Zeile 121, Node 5: The Foster Family in Splott

**alt:** **What works?** The visor is not an opponent. It wants to be worn, or it wants to return to those who understand it. Salt, light and silver work against the Echo, but they do not destroy it. An end to the unfinished work: Pryce’s wish that someone wears and understands the piece. Clues in Node 1, 2.

**neu:** **What works?** The visor is not an opponent. It wants to be worn, or it wants to return to those who understand it. Salt, light and silver work against the Echo, but they do not destroy it. An end to the unfinished work: Pryce’s wish that someone wears and understands the piece. Clues in Node 1, 2, 3.

- ergänzen: Clues in Node 1, 2, 3.
- streichen oder ersetzen: Clues in Node 1, 2.

### Zeile 167, Owen Gwynne

**alt:** [entry - | Owen Gwynne | Pawnbroker · Human]

**neu:** [entry - | Owen Gwynne | Pawnbroker · Humans]

- ergänzen: [entry - Owen Gwynne Pawnbroker · Humans]
- streichen oder ersetzen: [entry - Owen Gwynne Pawnbroker · Human]

### Zeile 181, Alistair Vane

**alt:** [entry - | Alistair Vane | Former antiques dealer · Human]

**neu:** [entry - | Alistair Vane | Former antiques dealer · Humans]

- ergänzen: [entry - Alistair Vane Former antiques dealer · Humans]
- streichen oder ersetzen: [entry - Alistair Vane Former antiques dealer · Human]

### Zeile 195, Mr Hartley

**alt:** [entry - | Mr Hartley | Art dealer of the Collegium · Human]

**neu:** [entry - | Mr Hartley | Art dealer of the Collegium · Humans]

- ergänzen: [entry - Mr Hartley Art dealer of the Collegium · Humans]
- streichen oder ersetzen: [entry - Mr Hartley Art dealer of the Collegium · Human]

### Zeile 209, Daniel Keane

**alt:** [entry - | Daniel Keane | Former Soldier, security consultant · Human]

**neu:** [entry - | Daniel Keane | Former Soldier, security consultant · Humans]

- ergänzen: [entry - Daniel Keane Former Soldier, security consultant · Humans]
- streichen oder ersetzen: [entry - Daniel Keane Former Soldier, security consultant · Human]

### Zeile 223, Rhys Bowen

**alt:** [entry - | Rhys Bowen | Psion with unopened gift · Human]

**neu:** [entry - | Rhys Bowen | Psion with unopened gift · Humans]

- ergänzen: [entry - Rhys Bowen Psion with unopened gift · Humans]
- streichen oder ersetzen: [entry - Rhys Bowen Psion with unopened gift · Human]

### Zeile 243, Aftermath

**alt:** **Experience:** 5 XP per character, +1 for a solution without combat, +1 for the decision to give the visor to Rhys Bowen or to leave it to the quartermaster.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the visor is secured without two O.D.I.N. offices shooting at each other. At most +1 XP personal bonus, for example for a solution without combat. +1 XP for each thread the cell takes up, for example Rhys Bowen and the name he hears.

- ergänzen: +1 XP if the visor is secured without two O.D.I.N. offices shooting at each other.
- ergänzen: +1 XP for each thread the cell takes up, for example Rhys Bowen and the name he hears.
- streichen oder ersetzen: Experience: 5 XP per character, +1 for a solution without combat, +1 for the decision to give the visor to Rhys Bowen or to leave it to the quartermaster.

### Zeile 245, Aftermath

**alt:** **Skulls:** None, as long as the cell does not destroy the visor or sell it to a collector. If the visor, sealed in lead, goes to the archive in Wales, the Collegium receives a skull for it, because it encloses an artefact that wants to be worn. If the visor goes to Vane, Grey Meridian receives a skull for it, as soon as the resale becomes known.

**neu:** **Skulls:** None, as long as the cell does not destroy the visor or sell it to a collector. If it is destroyed or sold, it counts as a lost piece of ashsilver (one skull for every ten lost pieces, Game Master’s Book). If it goes to Vane and from him to a collector, the Evening receives a skull as soon as the resale becomes known.

- ergänzen: If it is destroyed or sold, it counts as a lost piece of ashsilver (one skull for every ten lost pieces, Game Master's Book).
- ergänzen: If it goes to Vane and from him to a collector, the Evening receives a skull as soon as the resale becomes known.
- streichen oder ersetzen: If the visor, sealed in lead, goes to the archive in Wales, the Collegium receives a skull for it, because it encloses an artefact that wants to be worn.
- streichen oder ersetzen: If the visor goes to Vane, Grey Meridian receives a skull for it, as soon as the resale becomes known.

### Zeile 12, What It Is About

**alt:** The “Sammlung und Bewahrung” Foundation in Basel has been buying up crystals for decades to seal them in lead. An elderly lady named Renate Albers sits on the Foundation board. Martin Kessler, a quiet man with a tie with reindeer, has worked in accounting for four years. Six months ago, Kessler became ill, very ill, and no one was allowed to visit him. Now he is back. Sabine from accounting asked him why he doesn’t remember Otto, the caretaker’s dog, which Kessler fed every morning. Kessler smiled and said the illness had taken his memory. Sabine doesn’t believe him. She called the police, and the police passed the call on to an agency that doesn’t exist.

**neu:** The “Sammlung und Bewahrung” Foundation in Basel has been buying up crystals for decades to seal them in lead. An elderly lady named Renate Albers sits on the Foundation board. Martin Kessler, a quiet man with a tie with reindeer, worked in accounting for four years. In March 2025, Kessler became ill, very ill, and no one was allowed to visit him. In January he came back. Sabine from accounting asked him why he doesn’t remember Otto, the caretaker’s dog, which Kessler fed every morning. Kessler smiled and said the illness had taken his memory. In March the Foundation had reported him missing to the police. By January the missing man had become a long-term patient, and the report had been withdrawn. Sabine witnessed both. Sabine doesn’t believe him. She called the police, and the police passed the call on to an agency that doesn’t exist.

- ergänzen: In March 2025, Kessler became ill, very ill, and no one was allowed to visit him.
- ergänzen: In January he came back.
- ergänzen: In March the Foundation had reported him missing to the police.
- ergänzen: By January the missing man had become a long-term patient, and the report had been withdrawn.
- ergänzen: Sabine witnessed both.
- streichen oder ersetzen: Six months ago, Kessler became ill, very ill, and no one was allowed to visit him.
- streichen oder ersetzen: Now he is back.

### Zeile 22, What Really Happened

**alt:** Elster, who sits on the Foundation board and is in truth the child the Hands did not take in 1952, recognised Kuckuck’s legend after three weeks. She let him work for four years and watched him. Then she had a photo from the summer party placed where an accountant would find it: a photo showing Kuckuck in the role of Martin Kessler, taken at the 2024 summer party. Elster wanted Kuckuck to stumble. She wanted him to ask questions. She wanted him to finish the article about the drowning in the Elbe.

**neu:** Elster, who sits on the Foundation board and is in truth the child the Hands did not take in 1952, recognised Kuckuck’s legend after three weeks. She let him work for four years and watched him. Then she had a folder of photos from the 2024 summer party at the director’s villa put in the Foundation’s cellar, among the restoration files, where an accountant would find it. In one of the pictures she herself stands next to the director. Elster wanted Kuckuck to stumble. She wanted him to ask questions. She wanted him to finish the article about the drowning in the Elbe.

- ergänzen: Then she had a folder of photos from the 2024 summer party at the director's villa put in the Foundation's cellar, among the restoration files, where an accountant would find it.
- ergänzen: In one of the pictures she herself stands next to the director.
- streichen oder ersetzen: Then she had a photo from the summer party placed where an accountant would find it: a photo showing Kuckuck in the role of Martin Kessler, taken at the 2024 summer party.

### Zeile 49, Herr Leuenberger

**alt:** Late sixties, director of the Foundation, formerly one of the Hands himself, considered dead since 1990. He buys crystals and locks them in lead. He wants the Foundation to continue its work, and he does not want the Council to get Elster. He knows that Brunner is not Kuckuck, because he observed Kuckuck for four years. He conceals that he has known Elster since 1990. He speaks kindly, thoroughly, and he smiles when he lies.

**neu:** Late sixties, director of the Foundation, formerly one of the Hands himself, considered dead since 1990. He buys crystals and locks them in lead. He wants the Foundation to continue its work, and he does not want the Council to get Elster. He knows that Brunner is not Kuckuck, because he observed Kuckuck for four years. He knows Brunner from his own time with the Hands. He conceals that he has known Elster since 1990. He speaks kindly, thoroughly, and he smiles when he lies.

- ergänzen: He knows Brunner from his own time with the Hands.

### Zeile 63, Briefing

**alt:** **What the file contains:** Address of the Foundation, name of the accountant (Sabine Wirz), name of the director (Herr Leuenberger), an older staff photo from Kuckuck’s legend file, taken in 2021 when the legend was taken over. A note: “Kuckuck, Tobias Lenz, legend Martin Kessler, in Basel since 2021. Last report six months ago. Since then ill. Return reported by Sabine Wirz.”

**neu:** **What the file contains:** Address of the Foundation, name of the accountant (Sabine Wirz), name of the director (Herr Leuenberger), an older staff photo from Kuckuck’s legend file, taken in 2021 when the legend was taken over. A note: “Kuckuck, Tobias Lenz, legend Martin Kessler, in Basel since 2021. Last report in March 2025. Since then ill. Return in January 2026, reported by Sabine Wirz.”

- ergänzen: Last report in March 2025.
- streichen oder ersetzen: Last report six months ago.

### Zeile 78, Node 1: The Foundation

**alt:** - **Clue:** The photo from the 2024 summer party is in a drawer in accounting. An Investigator with Investigation or an Agent with Deception notices the discrepancy. (leads to Node 2)

**neu:** - **Clue:** In the cellar, among the restoration files, stands a folder of photos from the 2024 summer party. One picture is missing, another shows Martin Kessler. An Investigator with Investigation or an Agent with Insight notices the discrepancy. (leads to Node 2)

- ergänzen: Clue: In the cellar, among the restoration files, stands a folder of photos from the 2024 summer party.
- ergänzen: One picture is missing, another shows Martin Kessler.
- streichen oder ersetzen: Clue: The photo from the 2024 summer party is in a drawer in accounting.

### Zeile 80, Node 1: The Foundation

**alt:** 

**neu:** - **Clue:** Kessler’s personnel file contains not a single doctor’s note for ten months of illness. Sabine has noticed. (leads to Node 5) - **Clue:** Leuenberger recognises Brunner from his time with the Hands. He only says the name Viktor Brunner if the cell promises not to hand Elster over. (leads to Node 3)

- ergänzen: Clue: Kessler's personnel file contains not a single doctor's note for ten months of illness.
- ergänzen: Sabine has noticed.
- ergänzen: (leads to Node 5) - Clue: Leuenberger recognises Brunner from his time with the Hands.
- ergänzen: He only says the name Viktor Brunner if the cell promises not to hand Elster over.
- ergänzen: (leads to Node 3)

### Zeile 85, Node 1: The Foundation

**alt:** **Tests:** Insight against Hard (3), to recognise that Sabine knows more than she says. Investigation against Doable (2), to find the photo. Thought Whisper (WIL + Telepathy), Brunner resists.

**neu:** **Tests:** Insight against Hard (3), to recognise that Sabine knows more than she says. Investigation against Doable (2), to find the folder. Thought Whisper (WIL + Telepathy), Brunner resists.

- ergänzen: Investigation against Doable (2), to find the folder.
- streichen oder ersetzen: Investigation against Doable (2), to find the photo.

### Zeile 91, Node 2: The Photo

**alt:** The photo from the 2024 summer party, taken in the courtyard of the Foundation. It shows Martin Kessler with a tie with reindeer, a glass in his hand, a smile that doesn’t quite suit him. The photo is attached as Handout 4.1.

**neu:** The photo from the 2024 summer party, taken in the garden of the director’s villa. It shows Martin Kessler with the tie with reindeer and a smile that doesn’t quite suit him. At the edge, cut off, an old woman with white hair. The photo is attached as Handout 4.1.

- ergänzen: The photo from the 2024 summer party, taken in the garden of the director's villa.
- ergänzen: At the edge, cut off, an old woman with white hair.
- streichen oder ersetzen: The photo from the 2024 summer party, taken in the courtyard of the Foundation.

### Zeile 93, Node 2: The Photo

**alt:** - **Clue:** An Investigator with Investigation or an Agent with Deception recognises that the man in the photo is not the same as the man who works in the Foundation today. (leads to Node 1) - **Clue:** On the back, written in pencil: “Summer party 2024, Martin Kessler.” The handwriting is not Sabine’s. An Investigator with Investigation or an Agent with Deception recognises that the handwriting is old, very old. (leads to Node 3) - **Clue:** The photo was in a drawer that Kuckuck used every day. An Investigator with Investigation recognises that someone placed it where he would find it. (leads to Node 3)

**neu:** - **Clue:** An Investigator with Investigation or an Agent with Insight recognises that the man in the photo is not the same as the man who works in the Foundation today. (leads to Node 1) - **Clue:** On the back, written in pencil: “Summer party 2024, Martin Kessler.” The handwriting is not Sabine’s. An Investigator with Investigation or an Agent with Perception recognises that the handwriting is old, very old. (leads to Node 3) - **Clue:** The folder stood among files that only accounting needs. An Investigator with Investigation recognises that someone put it where an accountant would find it. (leads to Node 3)

- ergänzen: (leads to Node 3) - Clue: The folder stood among files that only accounting needs.
- streichen oder ersetzen: (leads to Node 3) - Clue: The photo was in a drawer that Kuckuck used every day.

### Zeile 105, Node 3: Elster’s House

**alt:** - **Clue:** Elster says: “Tell your handler that I have been carrying the legend Renate Albers since 1952. He will know what that means.” (leads to Node 4)

**neu:** - **Clue:** Elster says: “Tell your handler that I have been carrying the legend Renate Albers since 1989 and that it was written for me in 1952. He will know what that means.” (leads to Node 4)

- ergänzen: Clue: Elster says: "Tell your handler that I have been carrying the legend Renate Albers since 1989 and that it was written for me in 1952.
- streichen oder ersetzen: Clue: Elster says: "Tell your handler that I have been carrying the legend Renate Albers since 1952.

### Zeile 124, Node 4: The Print Shop in Zurich

**alt:** - **Clue:** The note in the file is enclosed as Handout 4.3.

**neu:** - **Clue:** The Cadet note from Kuckuck’s file, an extract from the Registry, is enclosed as Handout 4.3.

- ergänzen: Clue: The Cadet note from Kuckuck's file, an extract from the Registry, is enclosed as Handout 4.3.
- streichen oder ersetzen: Clue: The note in the file is enclosed as Handout 4.3.

### Zeile 132, Node 5: The Dead Drop

**alt:** A locker at Basel SBB station, which Brunner uses for messages to the Council. An Agent with access to the Branch’s dead drop finds the handwriting of a secretary of Prometheus.

**neu:** A locker at Basel SBB station, which Brunner uses for messages to the Council, and the Branch’s old dead drop in the city park, in the crack of the wall behind the bandstand. Kuckuck reported through it. An Agent with access to the Branch’s papers finds the handwriting of a secretary of Prometheus.

- ergänzen: A locker at Basel SBB station, which Brunner uses for messages to the Council, and the Branch's old dead drop in the city park, in the crack of the wall behind the bandstand.
- ergänzen: Kuckuck reported through it.
- streichen oder ersetzen: A locker at Basel SBB station, which Brunner uses for messages to the Council.

### Zeile 135, Node 5: The Dead Drop

**alt:** - **Clue:** In Mulhouse, two men of the Hands are waiting. A Soldier or Investigator reconstructing Kuckuck’s travel movements finds that he came via Constance, not via Mulhouse. (leads to Node 1) - **Clue:** Brunner has his own dead drop. An Agent with Stealth finds it. (leads to Node 1)

**neu:** - **Clue:** In Mulhouse, two men of the Hands were waiting. A Soldier or Investigator reconstructing Kuckuck’s travel movements finds that he came via Constance, not via Mulhouse. (leads to Node 1) - **Clue:** The messages in the locker are initialled “V. B.” Whoever checks the initials against the old lists of the Hands finds a Viktor Brunner, died 2005. An Agent who follows Brunner with Stealth finds the locker. (leads to Node 1)

- ergänzen: (leads to Node 1) - Clue: The messages in the locker are initialled "V.
- ergänzen: B." Whoever checks the initials against the old lists of the Hands finds a Viktor Brunner, died 2005.
- ergänzen: An Agent who follows Brunner with Stealth finds the locker.
- streichen oder ersetzen: (leads to Node 1) - Clue: Brunner has his own dead drop.
- streichen oder ersetzen: An Agent with Stealth finds it.

### Zeile 209, Aftermath

**alt:** **Experience:** 5 per character, +1 for a solution without combat, +1 for a solution that brings Elster to the Nursery.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the cell finds out who Kessler is. At most +1 XP personal bonus, for example for a solution without combat or one that brings Elster to the Nursery. +1 XP for each thread the cell takes up, for example the Nexus crystal in Elster’s house.

- ergänzen: +1 XP for each thread the cell takes up, for example the Nexus crystal in Elster's house.

### Zeile 218, Aftermath

**alt:** - Handout 4.3: The note in the file, in Node 4, in the Registry of the Print Shop, in Kuckuck’s file. - Map 4: Die Stiftung Sammlung und Bewahrung, Basel, with all rooms, doors, windows, and paths for the Confrontation.

**neu:** - Handout 4.3: The Cadet note, an extract from the Registry, in Node 4, in the Print Shop’s archive, in Kuckuck’s file. - Map 4: The Foundation in Basel, with all rooms, doors, windows, and paths for the Confrontation.

- ergänzen: Handout 4.3: The Cadet note, an extract from the Registry, in Node 4, in the Print Shop's archive, in Kuckuck's file.
- streichen oder ersetzen: Handout 4.3: The note in the file, in Node 4, in the Registry of the Print Shop, in Kuckuck's file.

### Zeile 54, Paul Reiter, 66

**alt:** ### Paul Reiter, 63

**neu:** ### Paul Reiter, 66

- ergänzen: ### Paul Reiter, 66
- streichen oder ersetzen: ### Paul Reiter, 63

### Zeile 74, Node 1: The Anger with the Market Well

**alt:** The central square in Oberwölz, cobblestones, the well from the 17th century with a stone figure of Saint Florian. The water is clear, at the bottom something glitters. All around: the inn, the primary school, the church.

**neu:** The central square in Oberwölz, cobblestones, the well from the 17th century with a stone figure of Saint Florian. The water is clear, at the bottom something glitters: below the basin a bricked shaft leads six metres down to the spring catchment, and down there lies the light. All around: the inn, the primary school, the church.

- ergänzen: The water is clear, at the bottom something glitters: below the basin a bricked shaft leads six metres down to the spring catchment, and down there lies the light.
- streichen oder ersetzen: The water is clear, at the bottom something glitters.

### Zeile 95, Node 2: The Inn “Zum Goldenen Hirschen”

**alt:** - **Clue:** Paul Reiter hands the cell a photo from 1977 with an inscription on the back. (Handout 5.3)

**neu:** - **Clue:** Whoever notices Reiter’s hesitation with Insight against Hard (3) and asks gets a photo from 1977 from him with an inscription on the back. (Handout 5.3)

- ergänzen: Clue: Whoever notices Reiter's hesitation with Insight against Hard (3) and asks gets a photo from 1977 from him with an inscription on the back.
- streichen oder ersetzen: Clue: Paul Reiter hands the cell a photo from 1977 with an inscription on the back.

### Zeile 107, Node 3: The Laboratory in the Leitners’ House

**alt:** - **Clue:** A Biochemist or Chemist analyses the medicines. Test on Chemistry against Hard (3): It is a suppressant that suppresses the effect of the Contamination. It is not harmless, but causes no permanent damage. (leads to Nodes 4, 5) - **Clue:** A handwritten laboratory log, measurement no. 7, with falling pulse frequency and the recommendation for recovery within 48 hours due to risk of discovery. (Handout 5.2)

**neu:** - **Clue:** A Biochemist or Chemist analyses the medicines. Test on Chemistry against Hard (3): It is a suppressant that suppresses the effect of the Contamination. It is not harmless, but causes no permanent damage if it is stopped soon. (leads to Nodes 4, 5) - **Clue:** A handwritten laboratory log, measurement no. 7, with a falling pulse interval and the recommendation for recovery within 48 hours due to risk of discovery. (Handout 5.2)

- ergänzen: It is not harmless, but causes no permanent damage if it is stopped soon.
- streichen oder ersetzen: It is not harmless, but causes no permanent damage.

### Zeile 128, Node 5: The Market Well at Night

**alt:** - **Clue:** A Psion with Telepathy hears the children’s choir as a single humming that comes from the well. Test on WIL + Telepathy against Very Hard (4): The crystal “sings” through the children, and it wants to be heard. (leads to the Confrontation)

**neu:** - **Clue:** A Psion with Telepathy hears the children’s choir as a single humming that comes from the well. Test on WIL + Telepathy against Very Hard (4): The crystal “sings” through the children, and it wants to be heard. Whoever silences it silences them too. (leads to the Confrontation)

- ergänzen: Whoever silences it silences them too.

### Zeile 141, Node 5: The Market Well at Night

**alt:** 1. An EMF detector shows pulses in time with Nordlicht, every four minutes. (Nodes 3, 5)

**neu:** 1. An EMF detector shows pulses in time with Nordlicht, every four minutes. (Nodes 1, 3, 5)

- ergänzen: (Nodes 1, 3, 5)
- streichen oder ersetzen: (Nodes 3, 5)

### Zeile 143, Node 5: The Market Well at Night

**alt:** 3. The crystal in the well is a rift fragment, clear with a milky core. (Nodes 3, 5)

**neu:** 3. The water sample contains crystal dust, and children singing in their sleep are a known omen of the Voice. (Nodes 1, 2)

- ergänzen: The water sample contains crystal dust, and children singing in their sleep are a known omen of the Voice.
- ergänzen: (Nodes 1, 2)
- streichen oder ersetzen: The crystal in the well is a rift fragment, clear with a milky core.
- streichen oder ersetzen: (Nodes 3, 5)

### Zeile 200, Dr. Eva Leitner, alias Eva Lechner

**alt:** [entry - | Dr. Eva Leitner, alias Eva Lechner | Non-player character · Scientist]

**neu:** [entry - | Dr. Eva Leitner, alias Eva Lechner | Biochemist · Humans]

- ergänzen: Eva Leitner, alias Eva Lechner Biochemist · Humans]
- streichen oder ersetzen: Eva Leitner, alias Eva Lechner Non-player character · Scientist]

### Zeile 213, Thomas Leitner, alias Thomas Lechner

**alt:** [entry - | Thomas Leitner, alias Thomas Lechner | Non-player character · Engineer]

**neu:** [entry - | Thomas Leitner, alias Thomas Lechner | Engineer · Humans]

- ergänzen: [entry - Thomas Leitner, alias Thomas Lechner Engineer · Humans]
- streichen oder ersetzen: [entry - Thomas Leitner, alias Thomas Lechner Non-player character · Engineer]

### Zeile 219, Thomas Leitner, alias Thomas Lechner

**alt:** **Horror** | none

**neu:** **Horror** | None

- streichen oder ersetzen: Horror none

### Zeile 234, Aftermath

**alt:** **Experience:** 5 per character, +1 for the solution without combat, +1 for the recovery at the right moment.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the crystal is recovered and isolated. At most +1 XP personal bonus, for example for the solution without combat or the recovery at the right moment. +1 XP for each thread the cell takes up, for example Paul Reiter’s night in 1977.

- ergänzen: +1 XP for each thread the cell takes up, for example Paul Reiter's night in 1977.

### Zeile 11, What It Is About

**alt:** At Lake Solberg, a runestone bearing the same circles as on the wall of the manor house is found during construction work. For a week, the children in the village have been singing in their sleep. The cell is sent to find out what is happening before the situation escalates. On site, they find an unsettled site manager, parents who no longer want to wake their children, and a wall in the manor house that is warm beneath the wallpaper. Solberg is a restricted zone. The cell enters with a permit from the Council, disguised as employees of a foundation for monument preservation that is to document the runestone.

**neu:** At Lake Solberg, a runestone bearing the same circles as on the wall of the manor house is found during construction work. For a week, the children in the village have been singing in their sleep. The cell is sent to find out what is happening before the situation escalates. On site, they find an unsettled site manager, parents who no longer want to wake their children, and a wall in the manor house that is warm beneath the wallpaper. The manor house by the lake is a restricted zone, otherwise accessible only with a Black File. The cell enters with a permit from the Council, disguised as employees of a foundation for monument preservation that is to document the runestone.

- ergänzen: The manor house by the lake is a restricted zone, otherwise accessible only with a Black File.
- streichen oder ersetzen: Solberg is a restricted zone.

### Zeile 51, Node 1: The Building Site by the Lake

**alt:** The excavation pit, the runestone under a tarpaulin, construction workers, Jens Harder. The stone lies half in the mud, the circles are clearly visible. At the forest edge the trees stand close together, the ground is churned up.

**neu:** The excavation pit at the forest edge, construction workers, Jens Harder. Next to it lies the runestone under a tarpaulin, half in the mud, where the excavator set it down. The circles are clearly visible. It was found fifty metres further into the forest, in a clearing. The manor house is a kilometre away. At the forest edge the trees stand close together, the ground is churned up.

- ergänzen: Next to it lies the runestone under a tarpaulin, half in the mud, where the excavator set it down.
- ergänzen: It was found fifty metres further into the forest, in a clearing.
- ergänzen: The manor house is a kilometre away.

### Zeile 69, Node 2: The Village and the Children

**alt:** 

**neu:** - **Clue:** Dr. Lindqvist tells what the old people in the village teach the children: in the forest you do not whistle, you do not shout, and you take nothing with you (leads to “What works”).

- ergänzen: Clue: Dr.
- ergänzen: Lindqvist tells what the old people in the village teach the children: in the forest you do not whistle, you do not shout, and you take nothing with you (leads to "What works").

### Zeile 74, Node 3: The Church Register and the Vicarage

**alt:** The old church register of Solberg, Pastor Mattias Berg, a small archive in the vicarage. The church register has an entry from 1871 that breaks off in the middle of a sentence. In the archive there is a box with old papers, including the newspaper article from 1872 (Handout 6.1) and the pastor’s letter (Handout 6.2).

**neu:** Pastor Mattias Berg, a small archive in the vicarage and in it a certified copy of the old church register of Solberg. The original lies in the Uppsala Regional Archive. The entry from 1871 breaks off in the middle of a sentence in the copy too. In the archive there is a box with old papers, including the newspaper article from 1872 (Handout 6.1) and the pastor’s letter (Handout 6.2).

- ergänzen: The entry from 1871 breaks off in the middle of a sentence in the copy too.
- streichen oder ersetzen: The church register has an entry from 1871 that breaks off in the middle of a sentence.

### Zeile 95, Node 5: The Manor House

**alt:** The old manor house, the wall with the circles, behind wallpaper or paint. A caretaker lives in the adjacent building. The house is empty, the air is still. The wall in the dining room is warm, the wallpaper is peeling in one spot.

**neu:** The old manor house, the wall with the circles, behind wallpaper or paint. No one lives here. The house is empty, the air is still. The wall in the dining room is warm, the wallpaper is peeling in one spot.

- ergänzen: No one lives here.
- streichen oder ersetzen: A caretaker lives in the adjacent building.

### Zeile 104, Node 5: The Manor House

**alt:** Test: Thaumaturge or Paranormal Detective, Ritualism against Hard (3), to read the circles.

**neu:** Test: Thaumaturge with Ritualism or Paranormal Detective with Occultism, each against Hard (3), to read the circles.

- ergänzen: Test: Thaumaturge with Ritualism or Paranormal Detective with Occultism, each against Hard (3), to read the circles.

### Zeile 170, Non-Player Characters

**alt:** **Alfred Sundberg, antiquarian.** They are old and frail. They carry a heavy walking stick. If the cell exposes them, they become quiet and quote from old books. They can strike with the stick: Attack 2 + 2, damage 2. They are not a fighter, but they are desperate.

**neu:** **Alfred Sundberg, antiquarian.** They are old and frail. They carry a heavy walking stick. If the cell exposes them, they become quiet and quote from old books. In their despair they raise the stick, but they do not strike. They have no attack.

- ergänzen: In their despair they raise the stick, but they do not strike.
- ergänzen: They have no attack.
- streichen oder ersetzen: They can strike with the stick: Attack 2 + 2, damage 2.
- streichen oder ersetzen: They are not a fighter, but they are desperate.

### Zeile 179, Aftermath

**alt:** **What O.D.I.N. gets:** The runestone or a copy of the circles. The stone remains in the forest, but a rubbing of the circles goes to the Registry. The open file from 1871 remains open, with new threads: the missing page, the lodge, the name of the tutor. The red herring around Sundberg is noted. The lodge Zum Schweigenden Kreis is marked as an active organisation.

**neu:** **What O.D.I.N. gets:** A rubbing of the circles for the Registry. The runestone only if the cell does not bring it back, and then the Forest Walker returns every night. The open file from 1871 remains open, with new threads: the missing page, the lodge, the name of the tutor. The red herring around Sundberg is noted. The lodge Zum Schweigenden Kreis is marked as an active organisation.

- ergänzen: What O.D.I.N. gets: A rubbing of the circles for the Registry.
- ergänzen: The runestone only if the cell does not bring it back, and then the Forest Walker returns every night.
- streichen oder ersetzen: What O.D.I.N. gets: The runestone or a copy of the circles.
- streichen oder ersetzen: The stone remains in the forest, but a rubbing of the circles goes to the Registry.

### Zeile 181, Aftermath

**alt:** **Experience:** 5 per character, +1 for a peaceful solution, +1 for following the trail of the missing page to the family Bible. Additionally +1 for an Investigator who makes the connection between 1871 and the open file from 1938.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the stone is back in the forest and the children are quiet. At most +1 XP personal bonus, for example for a peaceful solution. +1 XP for each thread the cell takes up, for example the trail of the missing page to the family Bible or the connection between 1871 and the open file from 1938.

- ergänzen: +1 XP if the stone is back in the forest and the children are quiet.
- ergänzen: At most +1 XP personal bonus, for example for a peaceful solution.
- ergänzen: +1 XP for each thread the cell takes up, for example the trail of the missing page to the family Bible or the connection between 1871 and the open file from 1938.
- streichen oder ersetzen: Experience: 5 per character, +1 for a peaceful solution, +1 for following the trail of the missing page to the family Bible.
- streichen oder ersetzen: Additionally +1 for an Investigator who makes the connection between 1871 and the open file from 1938.

### Zeile 20, What Really Happened

**alt:** In December 1938, on the night of the 3rd, a girl named Liese Hartmann, ten years old, died in Bad Grund. She was the daughter of the mine foreman Wilhelm Hartmann, who worked in the “Silberner Hirsch” shaft. On the evening of 2 December her father brought home a crystal he had found in the mine on 1 December: a fist-sized, milky stone, unusually warm. Liese took it to bed with her. That night, when in Solberg the children sang and nineteen adults disappeared, Liese died in her room. The doctor wrote “cardiac arrest”. The father sold the crystal on 6 December to the collector Hermann Wegener and disappeared the same day in the shaft. He was never found.

**neu:** In December 1938, on the night of the 3rd, a girl named Liese Hartmann, ten years old, died in Bad Grund. She was the daughter of the mine foreman Wilhelm Hartmann, who worked in the “Silberner Hirsch” shaft. On the evening of 2 December her father brought home a crystal he had found in the mine on 1 December: a fist-sized, milky stone, unusually warm. Liese took it to bed with her. That night, when in Solberg the children sang and nineteen adults disappeared, Liese died in her room. That same night two more children in Bad Grund died in their sleep. The doctor wrote “cardiac arrest” three times. The father sold the crystal on 6 December to the collector Hermann Wegener and disappeared the same day in the shaft. He was never found.

- ergänzen: That same night two more children in Bad Grund died in their sleep.
- ergänzen: The doctor wrote "cardiac arrest" three times.
- streichen oder ersetzen: The doctor wrote "cardiac arrest".

### Zeile 124, Node 5: The City Archive (Bad Grund City Archive)

**alt:** - **Clue:** A file note from the Registry about hauntings: A haunting disappears when one finds what it repeats and puts an end to it. (leads to: What works, Confrontation)

**neu:** - **Clue:** A call to the Registry produces a file note about hauntings: A haunting disappears when one finds what it repeats and puts an end to it. (leads to: What works, Confrontation)

- ergänzen: Clue: A call to the Registry produces a file note about hauntings: A haunting disappears when one finds what it repeats and puts an end to it.
- streichen oder ersetzen: Clue: A file note from the Registry about hauntings: A haunting disappears when one finds what it repeats and puts an end to it.

### Zeile 157, Sequence

**alt:** 1. The cell enters the museum or observes it from outside. The director is in the “Mining and Minerals” room, reading aloud. Her voice is monotonous. Jule stands next to her, holding her hand. The granddaughter is visiting this weekend because her mother brought her to her grandmother for two days.

**neu:** 1. The cell enters the museum or observes it from outside. The director is in the “Mining and Minerals” room, reading aloud. Her voice is monotonous. Jule stands next to her, holding her hand. The granddaughter is still visiting her grandmother.

- ergänzen: The granddaughter is still visiting her grandmother.
- streichen oder ersetzen: The granddaughter is visiting this weekend because her mother brought her to her grandmother for two days.

### Zeile 196, Dr. Marianne Weber

**alt:** [entry - | Dr. Marianne Weber | Non-player character · Museum Director]

**neu:** [entry - | Dr. Marianne Weber | Museum Director · Humans]

- ergänzen: Marianne Weber Museum Director · Humans]
- streichen oder ersetzen: Marianne Weber Non-player character · Museum Director]

### Zeile 220, Aftermath

**alt:** **Experience:** 5 XP per character, +1 for the solution with the truth, +1 for saving the director and the granddaughter.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if Liese is released and the director and granddaughter are unharmed. At most +1 XP personal bonus, for example for the solution with the truth. +1 XP for each thread the cell takes up, for example the second crystal in the shaft.

- ergänzen: +1 XP if Liese is released and the director and granddaughter are unharmed.
- ergänzen: At most +1 XP personal bonus, for example for the solution with the truth.
- ergänzen: +1 XP for each thread the cell takes up, for example the second crystal in the shaft.
- streichen oder ersetzen: Experience: 5 XP per character, +1 for the solution with the truth, +1 for saving the director and the granddaughter.

### Zeile 222, Aftermath

**alt:** **Skulls:** If the cell gives the crystal to O.D.I.N., the foundation in Basel loses a skull, because the stone does not reach the market. If they give it to the Collegium, O.D.I.N. loses a skull, because the Council does not get a Nexus crystal.

**neu:** **Skulls:** If the cell hands the crystal over, to the Council or to the Collegium, the foundation in Basel loses a skull, because the stone does not reach the market. If they give it to the Collegium instead of the Council, the handler gets into trouble: Trust −1.

- ergänzen: If they give it to the Collegium instead of the Council, the handler gets into trouble: Trust −1.
- streichen oder ersetzen: If they give it to the Collegium, O.D.I.N. loses a skull, because the Council does not get a Nexus crystal.

### Zeile 34, Jonas Vermeulen, 41

**alt:** Accountant, Freemason, disappeared. He was the most cautious member, had cancelled the lodge evening to drive to Maarten’s. His lodge calendar is the red herring. He knows nothing of the ritual.

**neu:** Accountant, Freemason, disappeared. He was the most cautious member, had cancelled the lodge evening to drive to Maarten’s. His lodge calendar is the red herring. He thought the ritual was a game.

- ergänzen: He thought the ritual was a game.

### Zeile 37, Aylin Demir, 31

**alt:** Nurse, disappeared. She had last posted in the group: “The light is not a light. It is an eye.” She suspected something, but too late.

**neu:** Nurse, disappeared. Her last post in the group ends with: “Tell him the light is not a light.” She had dreamt that the light was an eye. She suspected something, but too late.

- ergänzen: Her last post in the group ends with: "Tell him the light is not a light." She had dreamt that the light was an eye.
- ergänzen: She suspected something, but too late.
- streichen oder ersetzen: She had last posted in the group: "The light is not a light.
- streichen oder ersetzen: It is an eye." She suspected something, but too late.

### Zeile 53, Briefing

**alt:** **What the file contains:** Names and addresses of the three missing persons, printouts from the forum “Illuminati Europa”, the ritual “The Second Light” as a PDF, the address of Maarten de Vries, a photo of the cellar from an online listing of the house. The Observer who intercepted the report has recorded all Belgian members of the group with their addresses and attached them to the file. **Expenses:** €2,000. **Requisition:** An EMF detector, salt, a multispectral scanner. A Thaumaturge can create a warding circle themselves if they have the Ritualism skill. Common items without waiting time.

**neu:** **What the file contains:** Names and addresses of the three missing persons, printouts from the forum “Illuminati Europa”, the ritual “The Second Light” as a PDF. The Observer who intercepted the report has recorded all Belgian members of the group with their addresses and attached them to the file. **Expenses:** €2,000. **Requisition:** An EMF detector, salt, a multispectral scanner. A Thaumaturge can create a warding circle themselves if they have the Ritualism skill. Common items without waiting time.

- ergänzen: What the file contains: Names and addresses of the three missing persons, printouts from the forum "Illuminati Europa", the ritual "The Second Light" as a PDF.
- streichen oder ersetzen: What the file contains: Names and addresses of the three missing persons, printouts from the forum "Illuminati Europa", the ritual "The Second Light" as a PDF, the address of Maarten de Vries, a photo of the cellar from an online listing of the house.

### Zeile 75, Node 2: The Forum “Illuminati Europa”

**alt:** 

**neu:** - **Clue:** Nadia shows Maarten’s last private message to her: “It is coming back through me. I am the door.” (leads to Node 5)

- ergänzen: Clue: Nadia shows Maarten's last private message to her: "It is coming back through me.
- ergänzen: I am the door." (leads to Node 5)

### Zeile 90, Node 4: The Archive of the Print Shop

**alt:** - **Clue:** The ritual “The Second Light” comes from MS Arcana 114, an internal compendium from 1971. A marginal note by the Typesetter: “Decoration. Do not use.” (Handout 8.2) (leads to Node 5)

**neu:** - **Clue:** The ritual “The Second Light” is found in an internal compendium of the Print Shop from 1971, its circle copied from the Collegium’s manuscript MS Arcana 114. A marginal note by the Typesetter: “Decoration. Do not use.” (Handout 8.2) (leads to Node 5)

- ergänzen: Clue: The ritual "The Second Light" is found in an internal compendium of the Print Shop from 1971, its circle copied from the Collegium's manuscript MS Arcana 114.
- streichen oder ersetzen: Clue: The ritual "The Second Light" comes from MS Arcana 114, an internal compendium from 1971.

### Zeile 98, Node 5: The Cellar of the Terraced House

**alt:** The cellar is a rectangular room, about 4 by 5 metres, with a staircase from above. The circle is painted with chalk and ash on the concrete floor, about 2 metres in diameter. In the centre lies a fist-sized crystal. The circle is warm, as if there were a heater underneath.

**neu:** The cellar is a rectangular room, about 4 by 5 metres, with a staircase from above. The circle is painted with chalk and ash on the concrete floor, about 2 metres in diameter. In the centre lies a fist-sized crystal. The circle is warm, as if there were a heater underneath. During the day Maarten sleeps upstairs. Whoever is quiet (Stealth against Doable (2)) can examine the cellar without him noticing.

- ergänzen: During the day Maarten sleeps upstairs.
- ergänzen: Whoever is quiet (Stealth against Doable (2)) can examine the cellar without him noticing.

### Zeile 104, Node 5: The Cellar of the Terraced House

**alt:** - **Test:** A Thaumaturge with Ritualism analyses the circle. Difficulty: Hard (3). A Scientist with Physics measures the heat. Difficulty: Doable (2). A Psion with Telepathy hears the Voice. Difficulty: Hard (3). A Soldier with Tactics recognises that the cellar has only one exit. Difficulty: Easy (1).

**neu:** - **Test:** A Thaumaturge with Ritualism analyses the circle. Difficulty: Hard (3). A Scientist with Physics measures the heat. Difficulty: Doable (2). A Psion with Telepathy hears the Voice. Difficulty: Hard (3). A Soldier with Tactics recognises that apart from the stairs only the garden window leads out. Difficulty: Easy (1).

- ergänzen: A Soldier with Tactics recognises that apart from the stairs only the garden window leads out.

### Zeile 111, Node 5: The Cellar of the Terraced House

**alt:** **What does it want?** The Voice wants to return through the circle and use Maarten as a gate. Clues in Node 5, 5, 5.

**neu:** **What does it want?** The Voice wants to return through the circle and use Maarten as a gate. Clues in Node 2, 5, 5.

- ergänzen: Clues in Node 2, 5, 5.
- streichen oder ersetzen: Clues in Node 5, 5, 5.

### Zeile 155, Solutions

**alt:** 

**neu:** **Without a Thaumaturge.** Whoever takes the crystal out of the circle and puts it in beryllium or salt closes the circle for one night. The Riftlings crumble. The next day the Collegium sends a Thaumaturge who seals it.

- ergänzen: Without a Thaumaturge.
- ergänzen: Whoever takes the crystal out of the circle and puts it in beryllium or salt closes the circle for one night.
- ergänzen: The Riftlings crumble.
- ergänzen: The next day the Collegium sends a Thaumaturge who seals it.

### Zeile 196, Aftermath

**alt:** **Experience:** 5 XP per character. +1 XP for the solution without combat. +1 XP for the sealing of the circle.

**neu:** **The three missing:** Sophie Renard, Jonas Vermeulen and Aylin Demir do not come back. If the circle is sealed, Sophie’s voice in the cellar falls silent. Their files remain open at the Registry.

- ergänzen: The three missing: Sophie Renard, Jonas Vermeulen and Aylin Demir do not come back.
- ergänzen: If the circle is sealed, Sophie's voice in the cellar falls silent.
- ergänzen: Their files remain open at the Registry.
- streichen oder ersetzen: +1 XP for the solution without combat.
- streichen oder ersetzen: +1 XP for the sealing of the circle.

### Zeile 198, Aftermath

**alt:** **Skulls:** The Enlightened lose one skull because the ritual was ended. The Enlightened thereby drop from three to two skulls.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the circle is sealed and Maarten stopped. At most +1 XP personal bonus, for example for the solution without combat. +1 XP for each thread the cell takes up, for example the amateur geologist with the remaining stones. **Skulls:** The Enlightened lose two skulls because their key figure Maarten de Vries has been eliminated, and drop from three to one. After the next mission the game master does not roll for this plan.

- ergänzen: +1 XP if the circle is sealed and Maarten stopped.
- ergänzen: At most +1 XP personal bonus, for example for the solution without combat.
- ergänzen: +1 XP for each thread the cell takes up, for example the amateur geologist with the remaining stones.
- ergänzen: After the next mission the game master does not roll for this plan.
- streichen oder ersetzen: The Enlightened thereby drop from three to two skulls.
