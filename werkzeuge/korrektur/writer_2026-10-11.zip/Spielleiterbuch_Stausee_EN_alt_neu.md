# Spielleiterbuch Stausee EN: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 2 Stellen.

## 15_anhang.md (Sicherung vor_stausee_2026-10-11)

### Zeile 48, Node 2: The First Guests

**alt:** - **Clue:** They have a mobile phone photo of the window. A Paranormal Detective or Investigator with Crime Scene Investigation sees in the glass a reflection that is not a piece of furniture. (Origin: the dead)

**neu:** - **Clue:** They have a mobile phone photo of the window. A Paranormal Detective or Investigator with Crime Scene Examination sees in the glass a reflection that is not a piece of furniture. (Origin: the dead)

### Zeile 103, Aftermath

**alt:** - **XP:** 5 per character, +1 for the solution with the truth.

**neu:** - **XP:** Grey File, base value 4 XP. Plus 1 XP if the family leaves the house alive, at most 1 XP personal bonus, for example for the solution with the truth, and 1 XP if the cell finds the crystal in the lake bed (a thread).
