# Nachträge zu den Vorschlagslisten: Die Tuer

Stand 11.10.2026, ODIN Writer. Hier stehen die Stellen, die das Vorschlagswerkzeug nicht abdeckt: Sätze, die im Band neu dazugekommen sind, und Sätze, die im Band weggefallen sind. Ermittelt aus dem Vergleich der Buchquellen vor und nach der Durchsicht (Listen in writer_2026-10-11), abzüglich aller Sätze, die in den Vorschlagslisten schon mit „ja“ stehen. Je Stelle der ganze Absatz alt und neu; „ergänzen“ und „streichen“ nennen die Sätze, die nach dem Übernehmen der Vorschläge noch fehlen oder übrig sind.

## Deutsch

### Zeile 73, Die Zelle

**alt:** **Erfahrung und Rang.** Nach jeder Mission gibt es EP nach der Tabelle in „Kampagnen führen": 3 für eine Weiße Akte, 5 für eine Graue, 6 für eine Rote, 8 für eine Schwarze, 3 für eine Mission ohne Akte, und +1 für jeden Faden, den die Zelle aufnimmt, dazu höchstens 1 EP persönlicher Bonus. So wird sie im Lauf von Akt I zu Agenten befördert, in Akt II zu Senior-Agenten und vielleicht vor der letzten Nacht zu Veteranen. Beförderungen sind Szenen: Behr übergibt sie, und manchmal eine Wahrheit dazu.

**neu:** **Erfahrung und Rang.** Nach jeder Mission gibt es EP wie im Grundregelwerk und in „Kampagnen führen": den Grundwert der Aktenfarbe (Weiß 2, Grau 4, Rot 5, Schwarz 7, ohne Akte 2), +1 für das erreichte Ziel, höchstens +1 persönlichen Bonus und +1 für jeden Faden, den die Zelle aufnimmt. So wird sie im Lauf von Akt I zu Agenten befördert, in Akt II zu Senior-Agenten und vielleicht vor der letzten Nacht zu Veteranen. Beförderungen sind Szenen: Behr übergibt sie, und manchmal eine Wahrheit dazu.

- ergänzen: Nach jeder Mission gibt es EP wie im Grundregelwerk und in "Kampagnen führen": den Grundwert der Aktenfarbe (Weiß 2, Grau 4, Rot 5, Schwarz 7, ohne Akte 2), +1 für das erreichte Ziel, höchstens +1 persönlichen Bonus und +1 für jeden Faden, den die Zelle aufnimmt.
- streichen oder ersetzen: Nach jeder Mission gibt es EP nach der Tabelle in "Kampagnen führen": 3 für eine Weiße Akte, 5 für eine Graue, 6 für eine Rote, 8 für eine Schwarze, 3 für eine Mission ohne Akte, und +1 für jeden Faden, den die Zelle aufnimmt, dazu höchstens 1 EP persönlicher Bonus.

### Zeile 160, Konfrontation

**alt:** Wie die Zelle die Szene löst, ist die erste große Wahl der Kampagne. Lio beruhigen und dem Beobachter übergeben. Lio dem Offenen überlassen. Lio verstecken und niemandem übergeben. Lio beruhigen kann ein Telepath oder Psychic Healer mit WK + Telepathie gegen Schwer (3), mit einem Helm, einer Kappe oder einem Stück Legierung S eine Stufe leichter.

**neu:** Wie die Zelle die Szene löst, ist die erste große Wahl der Kampagne. Lio beruhigen und dem Beobachter übergeben. Lio dem Offenen überlassen. Lio verstecken und niemandem übergeben. Lio beruhigen kann ein Telepath oder Psychic Healer mit WK + Telepathie gegen Schwer (3), mit einem Helm, einer Kappe oder einem Stück Legierung S eine Stufe leichter. Fehlt ein Psion, beruhigt ihn auch, wer mit ihm redet: CH + Überzeugen gegen Sehr schwer (4).

- ergänzen: Fehlt ein Psion, beruhigt ihn auch, wer mit ihm redet: CH + Überzeugen gegen Sehr schwer (4).

### Zeile 652, Die anderen Türen

**alt:** 

**neu:** Steht ein Zeiger unter 3, bleibt seine Tür in dieser Nacht geschlossen.

- ergänzen: Steht ein Zeiger unter 3, bleibt seine Tür in dieser Nacht geschlossen.

## Englisch

### Zeile 110, The Cell

**alt:** **Experience and Rank.** After each mission there are XP according to the table in “Running Campaigns”: 3 for a White File, 5 for a Grey, 6 for a Red, 8 for a Black, 3 for a mission without a file, and +1 for each thread the cell picks up, plus at most 1 XP personal bonus. Thus they are promoted to Agents during Act I, to Senior Agents in Act II, and perhaps to Veterans before the last night. Promotions are scenes: Behr hands them over, and sometimes a truth with them.

**neu:** **Experience and Rank.** After each mission there are XP as in the core rulebook and in “Running Campaigns”: the base value of the file colour (White 2, Grey 4, Red 5, Black 7, no file 2), +1 for reaching the objective, at most +1 personal bonus, and +1 for each thread the cell picks up. Thus they are promoted to Agents during Act I, to Senior Agents in Act II, and perhaps to Veterans before the last night. Promotions are scenes: Behr hands them over, and sometimes a truth with them.

- streichen oder ersetzen: After each mission there are XP according to the table in "Running Campaigns": 3 for a White File, 5 for a Grey, 6 for a Red, 8 for a Black, 3 for a mission without a file, and +1 for each thread the cell picks up, plus at most 1 XP personal bonus.

### Zeile 278, Confrontation

**alt:** How the cell resolves the scene is the first major choice of the campaign. Calm Lio and hand him over to the Observer. Leave Lio to the Open One. Hide Lio and hand him over to no one. A Telepath or Psychic Healer can calm Lio with WIL + Telepathy against Hard (3), one step easier with a helmet, a cap or a piece of Alloy S.

**neu:** How the cell resolves the scene is the first major choice of the campaign. Calm Lio and hand him over to the Observer. Leave Lio to the Open One. Hide Lio and hand him over to no one. A Telepath or Psychic Healer can calm Lio with WIL + Telepathy against Hard (3), one step easier with a helmet, a cap or a piece of Alloy S. Without a Psion, anyone who talks to him can calm him: CHA + Persuasion against Very Hard (4).

- ergänzen: Without a Psion, anyone who talks to him can calm him: CHA + Persuasion against Very Hard (4).

### Zeile 1198, The Other Doors

**alt:** 

**neu:** If a pointer is below 3, its door stays closed this night.

- ergänzen: If a pointer is below 3, its door stays closed this night.
