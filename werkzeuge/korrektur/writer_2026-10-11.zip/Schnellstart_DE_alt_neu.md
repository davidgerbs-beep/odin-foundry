# Schnellstart DE: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 8 Stellen.

## 04_einsatz.md (Sicherung vor_spielersicht_2026-10-11)

### Zeile 47, Knoten 1: Der Makler

**alt:** Ein Agent oder Negotiator bekommt mit einer Probe auf Menschenkenntnis gegen Machbar (2) heraus, dass er etwas verschweigt: dass im Grundbuch ein Vermerk steht. Er ist der rote Hering. Wer ihn für den Täter hält, verliert Zeit.

**neu:** Wer ihn mit einer Probe auf Menschenkenntnis gegen Machbar (2) liest, etwa Echo oder Raven, merkt, dass er etwas verschweigt: dass im Grundbuch ein Vermerk steht. Er ist der rote Hering. Wer ihn für den Täter hält, verliert Zeit.

### Zeile 56, Knoten 2: Die ersten Gäste

**alt:** - **Hinweis:** Sie haben ein Handyfoto vom Fenster. Ein Paranormal Detective oder Investigator mit Tatortbegehung sieht im Glas eine Spiegelung, die kein Möbelstück ist. (Ursprung Tote)

**neu:** - **Hinweis:** Sie haben ein Handyfoto vom Fenster. Wer das Foto genau ansieht, Wahrnehmung gegen Machbar (2), entdeckt im Glas eine Spiegelung, die kein Möbelstück ist. Ravens Geistersichtung gibt hier 2 Bonuswürfel. (Ursprung Tote)

### Zeile 65, Knoten 3: Das Dorf am See

**alt:** - **Hinweis:** Bei Niedrigwasser hört man vom See eine Kirchenglocke. Ein Physicist mit Messgeräten oder ein Thaumaturg mit Kristalldetektor bemerkt am Ufer einen Ausschlag. (Spur zur Stimme, optional)

**neu:** - **Hinweis:** Bei Niedrigwasser hört man vom See eine Kirchenglocke. Ein Thaumaturg hört am Ufer ein leises Flüstern aus dem Wasser, wie in der Nähe jedes Nexus-Kristalls. (Spur zur Stimme, optional)

### Zeile 69, Knoten 4: Das Archiv

**alt:** Das Kreisarchiv oder das Kirchenbuch der gefluteten Gemeinde. Ein Antiquarian ist hier in seinem Element.

**neu:** Das Kreisarchiv oder das Kirchenbuch der gefluteten Gemeinde. Wer Geschichte oder Akademisches Wissen mitbringt, wie Folio, findet hier schnell, was er sucht.

### Zeile 87, Die Nacht

**alt:** Wer bis zum Abend im Haus bleibt, erlebt die Wartende. Die Türen schließen sich, die Fenster zeigen nur Wasser, und am Fenster sitzt eine alte Frau in einer Strickjacke und wartet. Sie ist freundlich zu Paul und eisig zu allen anderen.

**neu:** Wer bis zum Abend im Haus bleibt, erlebt die Wartende. Die Türen schließen sich, die Fenster zeigen nur Wasser, und am Fenster sitzt eine alte Frau in einer Strickjacke und wartet. Sie ist freundlich zu Paul und eisig zu allen anderen. Wer sie zum ersten Mal sieht, legt eine Grauen-Probe gegen Grauenhaft (3) ab.

### Zeile 115, Nachspiel

**alt:** - **EP:** 5 pro Charakter, +1 für die Lösung mit der Wahrheit.

**neu:** - **EP:** Graue Akte, Grundwert 4 EP. Dazu +1 EP, wenn die Familie lebend aus dem Haus kommt, höchstens +1 EP persönlicher Bonus, etwa für die Lösung mit der Wahrheit, und +1 EP, wenn die Zelle den Kristall im Seegrund findet (ein Faden).

## 09_weiter.md (Sicherung vor_spielersicht_2026-10-11)

### Zeile 7, Wie es weitergeht

**alt:** Das Grundregelwerk umfasst 88 Seiten und ist kostenlos. Es enthält das vollständige Würfelsystem, die Charaktererschaffung in neun Schritten, sechs Klassen mit dreißig Subklassen, 63 Fertigkeiten, Psi-Kräfte, Zauber, Ausrüstung und die Regeln für den Aufstieg. Wer das System vollständig nutzen will, findet dort alles Notwendige. Die Datei steht unter odin-rpg.pages.dev bereit.

**neu:** Das Grundregelwerk ist kostenlos. Es enthält das vollständige Würfelsystem, die Charaktererschaffung in neun Schritten, sechs Klassen mit dreißig Subklassen, 63 Fertigkeiten, Psi-Kräfte, Zauber, Ausrüstung und die Regeln für den Aufstieg. Wer das System vollständig nutzen will, findet dort alles Notwendige. Die Datei steht unter odin-rpg.pages.dev bereit.

### Zeile 11, Wie es weitergeht

**alt:** Wer tiefer einsteigen will, findet sechs Klassenbücher, ein Arsenal mit 201 Gegenständen, ein Spielleiterbuch und die Kampagne „Die Tür“. Die Kampagne beginnt in derselben Villa am Stausee, in der dieser Einsatz spielt. Die Örtlichkeiten sind bereits bekannt. Die Ereignisse dieses Abends können als Vorgeschichte dienen oder unberührt bleiben. Die Kampagne setzt keine Kenntnis des Schnellstarts voraus, aber sie verträgt sie.

**neu:** Wer tiefer einsteigen will, findet sechs Klassenbücher, das Ausrüstungsbuch Arsenal, ein Spielleiterbuch und die Kampagne „Die Tür“. Ihre erste Mission ist genau dieser Einsatz, mit einer Ergänzung im Nachspiel. Wer den Schnellstart gespielt hat, steigt mit Mission 2 ein. Was die Zelle mit Martha Kellner und dem Kristall getan hat, zählt dann für die Kampagne, und die Messingkapsel an der Glocke schickt der Taucher des Horts eine Woche später.
