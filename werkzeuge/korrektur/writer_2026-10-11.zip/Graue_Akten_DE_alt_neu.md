# Graue Akten DE: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 132 Stellen.

## Stellen mit Gegnerwerten

- 03_nummer341.md:174 (Owen Gwynne)
- 03_nummer341.md:188 (Alistair Vane)
- 03_nummer341.md:200 (Mr. Hartley)
- 03_nummer341.md:202 (Mr. Hartley)
- 03_nummer341.md:214 (Daniel Keane)
- 03_nummer341.md:216 (Daniel Keane)
- 03_nummer341.md:230 (Rhys Bowen)
- 05_zweiter_kreis.md:219 (Thomas Leitner, alias Thomas Lechner)

## 00_einfuehrung.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 31, Die acht Akten

**alt:** 3 | Nummer 341 | Cardiff, Grangetown | Die Toten, Menschen | Grau

**neu:** 3 | Nummer 341 | Cardiff, Grangetown | Die Toten, Menschen | Grau, kann rot werden

### Zeile 36, Die acht Akten

**alt:** 8 | Das Zweite Licht | Brüssel, Anderlecht | Menschen, Stimme | Grau

**neu:** 8 | Das Zweite Licht | Brüssel, Anderlecht | Menschen, Stimme | Grau, kann rot werden

### Zeile 45, Die acht Akten

**alt:** **Akte 4: Kessler.** In einer Basler Stiftung sitzt seit vier Jahren ein stiller Buchhalter. Vor sechs Monaten wurde er krank, jetzt ist er zurück, und eine Kollegin glaubt ihm seine Gedächtnislücken nicht. Die Zelle soll diskret herausfinden, wer der Mann ist, der sich Martin Kessler nennt.

**neu:** **Akte 4: Kessler.** In einer Basler Stiftung saß vier Jahre lang ein stiller Buchhalter. Im März 2025 wurde er krank, im Januar kam er zurück, und eine Kollegin glaubt ihm seine Gedächtnislücken nicht. Die Zelle soll diskret herausfinden, wer der Mann ist, der sich Martin Kessler nennt.

### Zeile 63, Akten verbinden

**alt:** Einige Akten teilen offene Fäden. Das Lied der Kinder taucht in den Akten 5, 6 und 7 auf. Die Uhrzeit 22:10 erscheint in den Akten 2 und 3. Das unbekannte Kürzel im Kristallbuch verbindet Akte 1 mit Akte 2. Die Spielleitung kann diese Fäden aufgreifen, wenn sie die Akten in eine Kampagne einstreut. Jede Akte funktioniert auch allein.

**neu:** Einige Akten teilen offene Fäden. Das Lied der Kinder taucht in den Akten 5, 6 und 7 auf. Die Uhrzeit 22:10 erscheint in den Akten 2, 3 und 6. Das unbekannte Kürzel im Kristallbuch verbindet Akte 1 mit Akte 2. Die Spielleitung kann diese Fäden aufgreifen, wenn sie die Akten in eine Kampagne einstreut. Jede Akte funktioniert auch allein.

## 01_pflegefall.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 22, Was wirklich geschah

**alt:** Seit einigen Wochen hört Linus ein Summen, das lauter wird. Er schläft schlecht, isst wenig, und wenn er sich konzentriert, werden Dinge warm. Vor drei Wochen fand er am Elbufer einen kleinen, milchigen Kristall, der das Summen dämpfte, wenn er ihn festhielt. Er nahm ihn mit nach Hause und versteckte ihn unter der Matratze. Gestern Abend war er bei den Kowalskis, um den Fischen beim Schwimmen zuzusehen. Er dachte an nichts, nur an das Wasser, und das Wasser begann zu kochen. Linus rannte nach Hause, packte seinen Rucksack und verschwand. Er will nicht, dass seine Eltern seinetwegen Ärger bekommen. Er ist zu Fuß Richtung S-Bahn, dann in die Innenstadt, und sucht einen Ort, an dem es still ist. Er hat sich im alten Elbtunnel versteckt, in der Oströhre, wo das Summen leiser ist.

**neu:** Seit einigen Wochen hört Linus ein Summen, das lauter wird. Er schläft schlecht, isst wenig, und wenn er sich konzentriert, werden Dinge warm. Vor drei Wochen fand er am Elbufer einen kleinen, milchigen Kristall, der das Summen dämpfte, solange er ihn festhielt. Ließ er ihn los, kam das Summen lauter zurück: Der Stein nährt die Gabe. Linus nahm ihn mit nach Hause und versteckte ihn unter der Matratze. Gestern Abend war er bei den Kowalskis, um den Fischen beim Schwimmen zuzusehen. Er dachte an nichts, nur an das Wasser, und das Wasser begann zu kochen. Linus rannte nach Hause, packte seinen Rucksack und verschwand. Er will nicht, dass seine Eltern seinetwegen Ärger bekommen. Er ist zu Fuß Richtung S-Bahn, dann in die Innenstadt, und sucht einen Ort, an dem es still ist. Er hat sich im alten Elbtunnel versteckt, in der Oströhre, wo das Summen leiser ist.

### Zeile 44, Herr Kowalski, 52

**alt:** Nachbar, Versicherungskaufmann. Will Ruhe und eine Erklärung für das tote Aquarium. Weiß nichts Übernatürliches, verdächtigt einen ehemaligen Mieter. Verschweigt, dass er die Polizei doch gerufen hat, weil er den Vossens nicht traut. Redet laut, empört, wiederholt sich.

**neu:** Nachbar, Versicherungskaufmann. Will Ruhe und eine Erklärung für das tote Aquarium. Weiß nichts Übernatürliches, verdächtigt einen ehemaligen Mieter. Verschweigt, dass er gestern Abend wegen des Aquariums doch die Polizei gerufen hat, weil er den Vossens nicht traut. Die Streife kam, fand nichts und fuhr wieder. Redet laut, empört, wiederholt sich.

### Zeile 83, Knoten 2: Linus' Zimmer

**alt:** - **Hinweis:** Der Rucksack fehlt, die S-Bahn-Karte ist weg (führt zu Linus' Aufenthaltsort, Schlussfolgerung 3).

**neu:** - **Hinweis:** Der Rucksack fehlt, die Spardose ist leer (führt zu Linus' Aufenthaltsort, Schlussfolgerung 3).

### Zeile 100, Knoten 4: S-Bahn-Station Neugraben

**alt:** Kleine Station, ein Kiosk, eine Überwachungskamera. Hier wurde Linus zuletzt gesehen.

**neu:** Kleine Station, ein Kiosk, vier Überwachungskameras. Hier wurde Linus zuletzt gesehen.

### Zeile 127, Eskalation

**alt:** Die Akte wird rot, wenn die Zelle zu langsam ist oder wenn Jonas Vogt sie bemerkt. Vogt ist kein Mörder, aber er wird Linus nicht kampflos gehen lassen. Wenn die Zelle den alten Elbtunnel betritt, ohne sich zu verbergen, spricht Vogt sie mit Namen an und stellt sich zwischen sie und Linus. Linus' Gabe reagiert auf die Anspannung: Die Lampen im Tunnel flackern, das Wasser in den Pfützen beginnt zu dampfen.

**neu:** Die Akte wird rot, wenn die Zelle zu langsam ist oder wenn Jonas Vogt sie bemerkt. Zu langsam ist sie, wenn sie mehr als drei Knoten besucht, bevor sie zum alten Elbtunnel aufbricht. Vogt ist kein Mörder, aber er wird Linus nicht kampflos gehen lassen. Wenn die Zelle den alten Elbtunnel betritt, ohne sich zu verbergen, spricht Vogt sie mit Namen an und stellt sich zwischen sie und Linus. Linus' Gabe reagiert auf die Anspannung: Die Lampen im Tunnel flackern, das Wasser in den Pfützen beginnt zu dampfen.

### Zeile 197, Linus Voss

**alt:** Die Offenen als Organisation, ihre Ziele und weitere Gegner stehen im Bedrohungsatlas. Die Werte des Offenen (Elite) stammen aus dem Baustein Psion, die Werte für Linus aus dem Eintrag Chorkind im Bedrohungsatlas. Maren Falk, die Beobachterin, erscheint nur, wenn die Zelle sie anfordert. Sie hat keine Kampfwerte, kann aber am Telefon Hinweise geben.

**neu:** Die Offenen als Organisation und ihre Ziele stehen im Kapitel „Die Welt hinter dem Schleier“ des Spielleiterbuchs, weitere Gegner im Bedrohungsatlas. Die Werte des Offenen (Elite) stammen aus dem Baustein Psion, die Werte für Linus aus dem Eintrag Chorkind im Bedrohungsatlas. Maren Falk, die Beobachterin, erscheint nur, wenn die Zelle sie anfordert. Sie hat keine Kampfwerte, kann aber am Telefon Hinweise geben.

### Zeile 201, Nachspiel

**alt:** **Der Schleier:** Die Nachbarn haben das kochende Aquarium gesehen, aber die Polizei wurde nicht gerufen, außer von Herrn Kowalski, der einen Einbruch meldete. Ein Agent kann die Akte schließen: Die Kowalskis bekommen eine Erklärung: ein defekter Heizstab. Die Vossens bekommen eine neue Legende für Linus' Verschwinden: ein Internat, eine Kur. Die S-Bahn-Aufnahmen werden gesichert und gelöscht.

**neu:** **Der Schleier:** Die Nachbarn haben das kochende Aquarium gesehen, aber die Polizei wurde nicht gerufen, außer von Herrn Kowalski, der vor zwei Wochen einen Einbruch meldete und gestern Abend die Streife rief. Ein Agent kann die Akte schließen: Die Kowalskis bekommen eine Erklärung: ein defekter Heizstab. Die Vossens bekommen eine neue Legende für Linus' Verschwinden: ein Internat, eine Kur. Die S-Bahn-Aufnahmen werden gesichert und gelöscht.

### Zeile 205, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter. Plus 1 EP für eine Lösung ohne Kampf. Plus 1 EP für die Rettung des Kristalls.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn Linus in Sicherheit ist. Höchstens +1 EP persönlicher Bonus, etwa für eine Lösung ohne Kampf. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa das Kürzel im Kristallbuch.

## 02_fundort.md (Sicherung vor_handoutcheck_2026-10-10)

### Zeile 14, Worum es geht

**alt:** Dort, im Keller des Horts, gibt es laut alten Bauplänen einen Raum mit der Nummer 4/12. In den offiziellen Begehungen existiert er nicht. Die Zelle soll herausfinden, was es mit dem Raum auf sich hat, ohne den Hort zu alarmieren. Der Führungsoffizier der Zelle weiß nichts von dem Auftrag.

**neu:** Dort, im Keller des Horts, gibt es laut alten Bauplänen einen Raum mit der Nummer 4/12. Im aktuellen Grundriss fehlt er. Die Zelle soll herausfinden, was es mit dem Raum auf sich hat, ohne den Hort zu alarmieren. Der Führungsoffizier der Zelle weiß nichts von dem Auftrag.

### Zeile 20, Was wirklich geschah

**alt:** **Die Vorgeschichte:** Hort-9 in Prag wurde 1992 gegründet, in einem alten Kellergewölbe unter der Altstadt. Der Bauplan von 1991 zeigt zwölf Räume im Untergeschoss. Gebaut wurden elf. Der zwölfte Raum, Nummer 4/12, existiert nur auf dem Papier, aber nicht in der Realität. So steht es in den offiziellen Unterlagen.

**neu:** **Die Vorgeschichte:** Hort-9 in Prag wurde 1992 gegründet, in einem alten Kellergewölbe unter der Altstadt. Der Umbauplan von 1991 übernimmt die Zählung des alten Luftschutzkellers und zeigt zwölf Räume im Untergeschoss. Ausgebaut wurden elf. Der zwölfte Raum, Nummer 4/12, existiert nur auf dem Papier, aber nicht in der Realität. So steht es im aktuellen Grundriss.

### Zeile 30, Was wirklich geschah

**alt:** **Der rote Hering:** Der Hortleiter von Hort-9, Major Pavel Černý, ein Soldier alter Schule, hält den Raum für ein Artefakt der kommunistischen Vergangenheit: ein ehemaliger Abhörraum des tschechoslowakischen Geheimdienstes, der in den Plänen fehlt, weil er nie offiziell existierte. Er hat den Raum vor Jahren gefunden, aber nie betreten, weil er glaubt, er sei eine Falle. Er hat die Tür mit einem Vorhängeschloss versehen und den Raum aus den aktuellen Plänen streichen lassen. Er verschweigt das, weil er befürchtet, dass O.D.I.N. den Hort schließen würde, wenn bekannt wird, dass es dort einen unbekannten Raum gibt.

**neu:** **Der rote Hering:** Der Hortleiter von Hort-9, Major Pavel Černý, ein Soldier alter Schule, hält den Raum für ein Artefakt der kommunistischen Vergangenheit: ein ehemaliger Abhörraum des tschechoslowakischen Geheimdienstes, der in den Plänen fehlt, weil er nie offiziell existierte. Er hat den Raum vor Jahren gefunden, aber nie betreten, weil er glaubt, er sei eine Falle. Er hat die Tür mit einem Vorhängeschloss versehen und den Raum aus den aktuellen Plänen streichen lassen, von einer Baufirma, die es nicht gibt, bezahlt aus der Hortkasse. Er verschweigt das, weil er befürchtet, dass O.D.I.N. den Hort schließen würde, wenn bekannt wird, dass es dort einen unbekannten Raum gibt.

### Zeile 48, Ing. Marta Nováková, 47

**alt:** Bauingenieurin und Horttechnikerin. Sie kennt die Pläne des Horts besser als jeder andere. Sie will, dass die Pläne stimmen, und es beunruhigt sie, dass Raum 4/12 im aktuellen Plan fehlt. Sie weiß, dass Černý den Raum gefunden hat, aber sie hat ihn nie betreten. Sie verschweigt, dass sie einmal nachts ein Klopfen aus dem Raum gehört hat, obwohl er leer sein müsste. Sie redet schnell, technisch, mit vielen Zahlen.

**neu:** Bauingenieurin und Horttechnikerin. Sie kennt die Pläne des Horts besser als jeder andere. Sie will, dass die Pläne stimmen, und es beunruhigt sie, dass Raum 4/12 im aktuellen Plan fehlt. Sie weiß, dass Černý den Raum gefunden hat, aber sie hat ihn nie betreten. Sie verschweigt, dass sie einmal nachts ein Klopfen aus dem Raum gehört hat, obwohl er leer sein müsste. Ing. K. Svoboda, der die alten Pläne mit Bleistift ergänzt und 1992 die erste Begehung gemacht hat, war ihr Lehrmeister. Sie weiß, dass er Raum 4/12 nie öffnen wollte. Sie redet schnell, technisch, mit vielen Zahlen.

### Zeile 56, Eliška, 12

**alt:** Tochter eines externen Dienstleisters. Ihr Vater wartet die Heizungsanlage des Horts, und sie begleitet ihn manchmal in den Keller. Sie hat den Hort oft erkundet. Sie will Abenteuer erleben und von den Agenten ernst genommen werden. Sie weiß, dass der Raum 4/12 manchmal da ist und manchmal nicht. Sie verschweigt, dass sie einmal durch das Schlüsselloch gesehen hat, dass der Raum innen größer ist als außen. Sie redet schnell, neugierig, mit kindlicher Direktheit.

**neu:** Tochter eines Zivilangestellten des Horts. Ihr Vater hilft Marta Nováková bei der Wartung der Heizung, und sie begleitet ihn manchmal in den Keller. Sie hat den Hort oft erkundet. Sie will Abenteuer erleben und von den Agenten ernst genommen werden. Sie weiß, dass der Raum 4/12 manchmal da ist und manchmal nicht. Sie verschweigt, dass sie einmal durch das Schlüsselloch gesehen hat, dass der Raum innen größer ist als außen. Sie redet schnell, neugierig, mit kindlicher Direktheit.

### Zeile 74, Briefing

**alt:** **Der private Gefallen:** Dr. Brandl kontaktiert die Zelle vor dem Briefing, über einen toten Briefkasten oder ein persönliches Treffen. Sie gibt der Zelle einen Zettel mit dem Kürzel „Stille 4/12“ und dem Hinweis auf Hort-9 (Handout 2.1). Sie bittet die Zelle, herauszufinden, was das Kürzel bedeutet, und ihr zu berichten. Sie bietet als Gegenleistung einen Gefallen: Zugang zum Kristallarchiv in Oxford oder ein Empfehlungsschreiben an die Siegelwahrer.

**neu:** **Der private Gefallen:** Dr. Brandl kontaktiert die Zelle vor dem Briefing, über einen toten Briefkasten oder ein persönliches Treffen. Sie gibt der Zelle einen Zettel mit dem Kürzel „Stille 4/12“ und dem Hinweis auf Hort-9 (Handout 2.1). Sie bittet die Zelle, herauszufinden, was das Kürzel bedeutet, und ihr zu berichten. Sie bietet als Gegenleistung einen Gefallen: Zugang zum Kristallarchiv in Oxford oder ein Empfehlungsschreiben an die Siegelwahrer. Fragt die Zelle nach Ausrüstung, gibt Brandl ihr einen Beryllium-Isolierbehälter aus der Werkstatt von Hort-7 mit.

### Zeile 84, Knoten 1: Das Hortarchiv

**alt:** - **Hinweis:** Der aktuelle Grundriss zeigt elf Räume, aber der Bauplan von 1991 zeigt zwölf. (führt zu Raum 4/12)

**neu:** - **Hinweis:** Der aktuelle Grundriss zeigt elf Räume, aber der Umbauplan von 1991 zeigt zwölf. (führt zu Raum 4/12)

### Zeile 86, Knoten 1: Das Hortarchiv

**alt:** - **Hinweis:** Ein Begehungsprotokoll von 1992 erwähnt „Unregelmäßigkeiten im Untergeschoss, Raum 4/12 nicht betreten“ (Handout 2.2). (führt zu Černý, Knoten 2)

**neu:** - **Hinweis:** Ein Begehungsprotokoll von 1992 vermerkt: „Raum 4/12 nicht betreten. Tür verschlossen, Schlüssel nicht auffindbar.“ (Handout 2.2). (führt zu Černý, Knoten 2)

### Zeile 104, Knoten 3: Die Kantine

**alt:** - **Hinweis:** Eliška erzählt, dass der Raum manchmal da ist und manchmal nicht. (führt zu Raum 4/12)

**alt:** - **Hinweis:** Eliška hat durch das Schlüsselloch gesehen, dass der Raum innen größer ist als außen. (führt zu Raum 4/12)

**neu:** - **Hinweis:** Eliška erzählt, dass der Raum manchmal da ist und manchmal nicht. (führt zu Raum 4/12, Schlussfolgerung 2)

**neu:** - **Hinweis:** Eliška hat durch das Schlüsselloch gesehen, dass der Raum innen größer ist als außen. (führt zu Raum 4/12, Schlussfolgerung 2)

### Zeile 107, Knoten 3: Die Kantine

**alt:** - **Hinweis:** Ein Agent findet in Černýs Dienstakte Unregelmäßigkeiten in den Hortfinanzen: Zahlungen an eine Baufirma, die es nicht gibt. (führt zu Černý, Knoten 2)

**neu:** - **Hinweis:** Die Hortköchin, die auch die Kasse führt, wundert sich über Zahlungen an eine Baufirma, die nie im Hort war. (führt zu Černý, Knoten 2)

### Zeile 115, Knoten 4: Der Kellerflur vor Raum 4/12

**alt:** - **Hinweis:** Ein Psion hört in der Nähe des Raums eine Stille, die tiefer ist als jede Abschirmung: keine Gedanken, kein Summen, nichts. (führt zu Raum 4/12)

**neu:** - **Hinweis:** Ein Psion hört in der Nähe des Raums die eigenen Gedanken einen Herzschlag zu spät zurückkommen, als hallten sie aus einer anderen Zeit. (führt zu Raum 4/12, Schlussfolgerung 2)

### Zeile 118, Knoten 4: Der Kellerflur vor Raum 4/12

**alt:** - **Probe:** Wahrnehmung oder Telepathie gegen Schwer (3), um die Stille zu spüren. Psion mit Subklasse Telepath: Machbar (2).

**neu:** - **Probe:** Wahrnehmung oder Telepathie gegen Schwer (3), um das Echo zu spüren. Psion mit Subklasse Telepath: Machbar (2).

### Zeile 127, Knoten 5: Raum 4/12 und der Raum hinter der Tür

**alt:** - **Hinweis:** Ein Scientist mit Physik erkennt, dass die Raumgeometrie nicht stimmt: Der Raum ist innen 1,2 Meter länger als außen. (führt zu Schlussfolgerung 4)

**alt:** - **Hinweis:** Ein Thaumaturg, der den Stein berührt, spürt, dass er warm ist und flüstert, und dass das Flüstern lauter wird, wenn man ihn anhebt. (führt zu Schlussfolgerung 4)

**neu:** - **Hinweis:** Ein Scientist mit Physik erkennt, dass die Raumgeometrie nicht stimmt: Der Raum ist innen 1,2 Meter länger als außen, und am stärksten verzieht sich die Geometrie um den Tisch mit dem Stein. (führt zu Schlussfolgerung 2 und 4)

**neu:** - **Hinweis:** Ein Thaumaturg, der den Stein berührt, spürt, dass er warm ist und flüstert, und dass das Flüstern lauter wird, wenn man ihn anhebt. Dabei verziehen sich die Wände des Raums. (führt zu Schlussfolgerung 4)

### Zeile 137, Knoten 5: Raum 4/12 und der Raum hinter der Tür

**alt:** **2. Welcher Ursprung?** | Das Verschobene. Der Raum ist eine Falte in der Welt, entstanden in der Nacht von Nordlicht 1977. | Hinweise in Knoten 4, 5

**neu:** **2. Welcher Ursprung?** | Das Verschobene. Der Raum ist eine Falte in der Welt, entstanden in der Nacht von Nordlicht 1977. | Hinweise in Knoten 3, 4, 5

### Zeile 165, Ablauf

**alt:** 3. Die Zelle muss den Anker finden: den Nordlichtstein. Wer ihn berührt, hört eine Männerstimme, die auf Norwegisch zählt. Ein Thaumaturg kann den Stein untersuchen, ein Scientist kann die Geometrie des Raums vermessen, ein Psion kann die Stille spüren.

**neu:** 3. Die Zelle muss den Anker finden: den Nordlichtstein. Wer ihn berührt, hört eine Männerstimme, die auf Norwegisch zählt. Ein Thaumaturg kann den Stein untersuchen, ein Scientist kann die Geometrie des Raums vermessen, ein Psion kann das Echo spüren.

### Zeile 167, Ablauf

**alt:** 5. Wird der Stein nicht gesichert, zählt der Countdown schneller. Kurz vor 22:10 bricht die Stimme ab, die Tür am Ende des Flurs öffnet sich flackernd einen Spalt weit, und dahinter ist nichts. Dann springt der Zähler auf sechzig zurück, die Tür schließt sich, und die Zählung beginnt von vorn. Der Stein erreicht das Ende nie.

**neu:** 5. Wird der Stein nicht gesichert, zählt der Countdown schneller. Kurz vor 22:10 bricht die Stimme ab, die Tür des Archivraums öffnet sich flackernd einen Spalt weit, und dahinter ist kein Flur mehr, nur Dunkel. Dann springt der Zähler auf sechzig zurück, die Tür schließt sich, und die Zählung beginnt von vorn. Der Stein erreicht das Ende nie.

### Zeile 173, Lösungen

**alt:** **Mit Kampf:** Wenn die Zelle den Stein nicht sichern kann, öffnet sich die Tür am Ende des Flurs, und ein Rissling tritt heraus. Die Zelle muss ihn abwehren, während sie den Stein sichert. Der Rissling ist ein Handlanger, aber er kommt nicht allein: Ein Trupp zu dritt, wie im Bedrohungsatlas beschrieben.

**neu:** **Mit Kampf:** Wenn die Zelle den Stein nicht sichern kann, öffnet sich die Tür des Archivraums, und aus dem Dunkel dahinter tritt ein Rissling. Die Zelle muss ihn abwehren, während sie den Stein sichert. Der Rissling ist ein Handlanger, aber er kommt nicht allein: Ein Trupp zu dritt, wie im Bedrohungsatlas beschrieben.

### Zeile 177, Lösungen

**alt:** **Wissen aus der Ermittlung belohnen:** Wer den alten Bauplan von 1977 gefunden hat, weiß, dass der Raum ursprünglich ein Lagerraum war. Wer die offene Akte über Nordlicht kennt, erkennt den Stein als Nordlichtstein. Wer das Kürzel „Stille 4/12“ gesehen hat, weiß, dass der Raum im Kristallbuch vermerkt ist und die Angelegenheit für die Siegelwahrer bedeutsam sein muss. Keines dieser Hinweise verrät, dass der Stein der Anker ist. Das muss die Zelle selbst erkennen.

**neu:** **Wissen aus der Ermittlung belohnen:** Wer den alten Bauplan von 1977 gefunden hat, weiß, dass der Raum ursprünglich ein Lagerraum war. Wer die offene Akte über Nordlicht kennt, erkennt den Stein als Nordlichtstein. Wer das Kürzel „Stille 4/12“ gesehen hat, weiß, dass der Raum im Kristallbuch vermerkt ist und die Angelegenheit für die Siegelwahrer bedeutsam sein muss. Wer dazu die Messungen am Stein aus Knoten 5 kennt, erkennt in ihm den Anker.

### Zeile 181, Gegner

**alt:** Die Falte selbst ist kein Wesen, sondern ein Ort. Wer den Raum betritt, kämpft gegen die Zeit, nicht gegen einen Feind. Wenn die Zelle den Stein berührt, kann ein Rissling erscheinen (Bedrohungsatlas, Spielleiterbuch). Er ist ein Handlanger der Stimme und sickert durch die Tür am Ende des Flurs, aber er ist nicht der eigentliche Gegner. Ein Trupp Risslinge besteht aus drei Wesen, wie im Bedrohungsatlas beschrieben.

**neu:** Die Falte selbst ist kein Wesen, sondern ein Ort. Wer den Raum betritt, kämpft gegen die Zeit, nicht gegen einen Feind. Wenn die Zelle den Stein berührt, kann ein Rissling erscheinen (Bedrohungsatlas, Spielleiterbuch). Er ist ein Handlanger der Stimme und sickert durch die Tür des Archivraums, aber er ist nicht der eigentliche Gegner. Ein Trupp Risslinge besteht aus drei Wesen, wie im Bedrohungsatlas beschrieben.

### Zeile 183, Gegner

**alt:** Major Pavel Černý ist kein Feind, solange die Zelle den Hort nicht alarmiert. Stellt er die Zelle im Keller, wird er laut und verlangt eine Erklärung. Er greift nur an, wenn die Zelle den Raum öffnet oder den Stein mitnimmt. Seine Werte stehen unten.

**neu:** Major Pavel Černý ist kein Feind, solange die Zelle den Hort nicht alarmiert. Stellt er die Zelle im Keller, wird er laut und verlangt eine Erklärung. Er greift nur an, wenn die Zelle mit dem Stein den Hort verlassen will, ohne ihm zu sagen, was er ist. Seine Werte stehen unten.

### Zeile 204, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter. +1 EP für die Lösung ohne Kampf. +1 EP für die Sicherung des Steins.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn die Zelle den Stein gesichert hat. Höchstens +1 EP persönlicher Bonus, etwa für die Lösung ohne Kampf. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den Stein, der rückwärts zählt.

## 03_nummer341.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 42, Daniel Keane, 44

**alt:** Ehemaliger Soldier, jetzt Sicherheitsberater. Breitschultrig, Lederjacke, Stiefel, ein Stück Aschesilber an einer Kette um den Hals. Will das Visier für den Rüstmeister sichern, weil er Idris Pryce einen Gefallen schuldet. Weiß, dass das Visier summt, wenn man es aufsetzt, und dass es Tote anzieht. Verschweigt, dass er seit seiner Dienstzeit nachts Stimmen hört, wenn er sein Silber berührt. Redet wenig, beobachtet viel, steht gern im Dunkeln.

**neu:** Ehemaliger Soldier, jetzt Sicherheitsberater. Breitschultrig, Lederjacke, Stiefel, ein Stück Aschesilber an einer Kette um den Hals, das Idris Pryce ihm für diesen Auftrag geliehen hat. Will das Visier für den Rüstmeister sichern, weil er Idris Pryce einen Gefallen schuldet. Weiß, dass das Visier summt, wenn man es aufsetzt, und dass es Tote anzieht. Verschweigt, dass er seit seiner Dienstzeit nachts Stimmen hört, wenn er Silber berührt. Redet wenig, beobachtet viel, steht gern im Dunkeln.

### Zeile 52, Briefing

**alt:** **Was die Akte enthält:** Adresse des Pfandhandels, Name des Pfandleihers, Foto des Visiers aus einem Onlineinserat, eine kurze Notiz des Rüstmeisters: „Stück ist seit 1989 verschollen, hergestellt von Evan Pryce, Innenseite trägt seinen Namen, nicht öffnen, nicht aufsetzen“, eine Notiz des Kollegiums: „Aschesilber mit Echo, sicherstellen, in Blei verpacken, nach Wales bringen“. **Spesen:** 2.000 Euro. **Anfordern:** Ein EMF-Detektor, Salz, ein Beryllium-Isolierbehälter, ein Fahrzeug mit Tarnkennzeichen. Der Führungsoffizier sagt nicht, dass der Rüstmeister und das Kollegium bereits eigene Leute geschickt haben.

**neu:** **Was die Akte enthält:** Adresse des Pfandhandels, Name des Pfandleihers, Foto des Visiers aus einem Onlineinserat, eine kurze Notiz des Rüstmeisters: „Stück ist seit 1989 verschollen, hergestellt von Evan Pryce, Innenseite trägt seinen Namen, nicht öffnen, nicht aufsetzen“. **Spesen:** 2.000 Euro. **Anfordern:** Ein EMF-Detektor, Salz, ein Beryllium-Isolierbehälter, ein Fahrzeug mit Tarnkennzeichen. Der Führungsoffizier sagt nicht, dass der Rüstmeister und das Kollegium bereits eigene Leute geschickt haben.

### Zeile 62, Knoten 1: Das Pfandhaus in Grangetown

**alt:** - **Hinweis:** Gwynne erzählt von drei Interessenten: einem Kunsthändler aus Bath, einem Antiquitätenhändler aus Bristol und einem stummen Mann in Lederjacke, der nur einmal hereinkam und wieder ging (führt zu Miriam Hale, Alistair Vane und Daniel Keane).

**neu:** - **Hinweis:** Nach Menschenkenntnis gegen Machbar (2) erzählt Gwynne von drei Interessenten: einem Kunsthändler aus Bath, einem Antiquitätenhändler aus Bristol und einem stummen Mann in Lederjacke, der nur einmal hereinkam und wieder ging (führt zu Knoten 4, zu Alistair Vane und zu Knoten 3).

### Zeile 66, Knoten 1: Das Pfandhaus in Grangetown

**alt:** - **Hinweis für Investigator:** Ein Abgleich der Nummer 341 mit alten Akten des Ermittlungszweigs zeigt, dass die Nummer in einer Liste von Aschesilberstücken aus Hort-2 auftaucht, die 1989 als verschlossen gemeldet wurden (führt zu Hort-2, zum Rüstmeister).

**neu:** - **Hinweis für Investigator:** Ein Abgleich der Nummer 341 mit alten Akten des Ermittlungszweigs zeigt, dass die Nummer in einer Liste von Aschesilberstücken aus Hort-2 auftaucht, die 1989 als verschollen gemeldet wurden (führt zu Hort-2, zum Rüstmeister).

### Zeile 76, Knoten 2: Hort-2, die Werkstatt

**alt:** - **Hinweis:** Der Rüstmeister bestätigt, dass das Visier seit 1989 fehlt und von seinem Großvater Evan Pryce geschmiedet wurde (führt zu Was wirklich geschah).

**neu:** - **Hinweis:** Der Rüstmeister bestätigt, dass das Visier seit 1989 fehlt und von seinem Großvater Evan Pryce geschmiedet wurde (führt zu Was ist geschehen?).

### Zeile 80, Knoten 2: Hort-2, die Werkstatt

**alt:** - **Hinweis für Soldier:** Ein Nachhall-Wurf in der Werkstatt zeigt, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist. Ein Vorbesitzer warnt vor einem Mann in einem dunklen Mantel, der das Stück einschließen will (führt zu Miriam Hale, zum Kollegium).

**neu:** - **Hinweis:** Der Rüstmeister erzählt, der Psionik-Kern melde seit drei Tagen einen jungen Mann in Splott, dessen Gabe erwacht ist und der nachts Namen hört (führt zu Knoten 5).

**neu:** - **Hinweis für Soldier:** Ein Nachhall-Wurf in der Werkstatt zeigt, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist. Ein Vorbesitzer warnt vor einem Mann in einem dunklen Mantel, der das Stück einschließen will (führt zu Knoten 4, zum Kunsthändler aus Bath).

### Zeile 84, Knoten 2: Hort-2, die Werkstatt

**alt:** **Proben:** Nachhall gegen Schwer (3), um zu spüren, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist. Thaumaturgie gegen Machbar (2), um zu erkennen, dass das Visier kein gefährliches Artefakt ist, sondern ein Träger. Glänzende Klassen: Soldier, Thaumaturg, Investigator.

**neu:** **Proben:** Nachhall-Wurf, nur für Soldiers mit Nachhall: Die Spielleitung würfelt verdeckt einen W6. Ist das Ergebnis gleich oder kleiner als der Nachhall, spürt der Soldier, dass das Silber im Hort unruhig ist, seit das Visier wieder aufgetaucht ist. Thaumaturgie gegen Machbar (2), um zu erkennen, dass das Visier kein gefährliches Artefakt ist, sondern ein Träger. Glänzende Klassen: Soldier, Thaumaturg, Investigator.

### Zeile 90, Knoten 3: Die Straße vor dem Pfandhaus

**alt:** - **Hinweis:** Keane hat gesehen, wie ein Mann in einem dunklen Mantel den Laden betrat, mit Gwynne sprach und mit leeren Händen wieder ging (führt zu Miriam Hale, zum Kunsthändler aus Bath).

**neu:** - **Hinweis:** Keane hat gesehen, wie ein Mann in einem dunklen Mantel den Laden betrat, mit Gwynne sprach und mit leeren Händen wieder ging (führt zu Knoten 4, zum Kunsthändler aus Bath).

### Zeile 92, Knoten 3: Die Straße vor dem Pfandhaus

**neu:** - **Hinweis:** Keane erzählt, dass die Rüstmeister Salz vor die Waffenkammer streuen und das Licht brennen lassen, wenn das Silber nachts summt (führt zu Was wirkt?).

### Zeile 121, Knoten 5: Die Pflegefamilie in Splott

**alt:** **Was wirkt?** Das Visier ist kein Gegner. Es will getragen werden, oder es will zurück zu denen, die es verstehen. Salz, Licht und Silber wirken gegen das Echo, aber sie zerstören es nicht. Ein Ende für das offene Werk: Pryces Wunsch, dass jemand das Stück trägt und versteht. Hinweise in Knoten 1, 2.

**neu:** **Was wirkt?** Das Visier ist kein Gegner. Es will getragen werden, oder es will zurück zu denen, die es verstehen. Salz, Licht und Silber wirken gegen das Echo, aber sie zerstören es nicht. Ein Ende für das offene Werk: Pryces Wunsch, dass jemand das Stück trägt und versteht. Hinweise in Knoten 1, 2, 3.

### Zeile 129, Eskalation

**alt:** - **Nach 24 Stunden:** Alistair Vane erhöht sein Angebot auf 8.000 Pfund und lässt seinen Anwalt bei Gwynne anrufen. Gwynne wird nervös und beschließt, das Visier noch in derselben Nacht zu verkaufen, an wen auch immer.

**neu:** - **Nach 24 Stunden:** Alistair Vane erhöht sein Angebot auf 8.000 Pfund und lässt seinen Anwalt bei Gwynne anrufen. Gwynne wird nervös und bestellt alle Interessenten für diese Nacht nach Ladenschluss in den Laden: Wer am meisten bietet, nimmt das Stück mit.

### Zeile 167, Owen Gwynne

**alt:** [entry - | Owen Gwynne | Pfandleiher · Mensch]

**neu:** [entry - | Owen Gwynne | Pfandleiher · Menschen]

### Zeile 174, Owen Gwynne

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint

### Zeile 181, Alistair Vane

**alt:** [entry - | Alistair Vane | Ehemaliger Antiquitätenhändler · Mensch]

**neu:** [entry - | Alistair Vane | Ehemaliger Antiquitätenhändler · Menschen]

### Zeile 188, Alistair Vane

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint

### Zeile 195, Mr. Hartley

**alt:** [entry - | Mr. Hartley | Kunsthändler des Kollegiums · Mensch]

**neu:** [entry - | Mr. Hartley | Kunsthändler des Kollegiums · Menschen]

### Zeile 200, Mr. Hartley

**alt:** **Angriff** | Kompaktpistole 3 + 2, Schaden 2, Verdeckt, oder Betäubungsstab 2 + 2, Schaden 1, betäubt

**neu:** **Angriff** | Kompaktpistole 3 + 2, Schaden 2, Verdeckt, oder Totschläger 2 + 2, Schaden 2, Betäubend, Verdeckt

### Zeile 202, Mr. Hartley

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint

### Zeile 209, Daniel Keane

**alt:** [entry - | Daniel Keane | Ehemaliger Soldier, Sicherheitsberater · Mensch]

**neu:** [entry - | Daniel Keane | Ehemaliger Soldier, Sicherheitsberater · Menschen]

### Zeile 214, Daniel Keane

**alt:** **Angriff** | Klinge der Eskorte 4 + 3, Schaden 3, oder Dienstpistole 4 + 3, Schaden 3

**neu:** **Angriff** | Klinge der Eskorte 4 + 3, Schaden 2, 3 gegen Wesen aus Rissen, oder Dienstpistole 4 + 3, Schaden 3

### Zeile 216, Daniel Keane

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint. Er hat Schlimmeres gesehen.

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint. Er hat Schlimmeres gesehen.

### Zeile 223, Rhys Bowen

**alt:** [entry - | Rhys Bowen | Psion mit ungeöffneter Gabe · Mensch]

**neu:** [entry - | Rhys Bowen | Psion mit ungeöffneter Gabe · Menschen]

### Zeile 230, Rhys Bowen

**alt:** **Grauen** | Unheimlich (1), wenn der Spuk erscheint

**neu:** **Grauen** | Keines. Würfelt selbst gegen Unheimlich (1), wenn der Spuk erscheint

### Zeile 243, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter, +1 für eine Lösung ohne Kampf, +1 für die Entscheidung, das Visier an Rhys Bowen zu geben oder es dem Rüstmeister zu überlassen.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn das Visier sichergestellt ist, ohne dass zwei Stellen von O.D.I.N. aufeinander schießen. Höchstens +1 EP persönlicher Bonus, etwa für eine Lösung ohne Kampf. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa Rhys Bowen und den Namen, den er hört.

### Zeile 245, Nachspiel

**alt:** **Totenköpfe:** Keine, solange die Zelle das Visier nicht zerstört oder an einen Sammler verkauft. Wenn das Visier in Blei eingeschlossen ins Archiv nach Wales geht, erhält das Kollegium einen Totenkopf dazu, weil es ein Artefakt einschließt, das getragen werden will. Wenn das Visier an Vane geht, erhält Grey Meridian einen Totenkopf dazu, sobald der Weiterverkauf bekannt wird.

**neu:** **Totenköpfe:** Keine, solange die Zelle das Visier nicht zerstört oder an einen Sammler verkauft. Wird es zerstört oder verkauft, zählt es als verlorenes Stück Aschesilber (ein Totenkopf für jeweils zehn verlorene Stücke, Spielleiterbuch). Geht es an Vane und von ihm an einen Sammler, erhält der Abend einen Totenkopf dazu, sobald der Weiterverkauf bekannt wird.

## 04_kessler.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 12, Worum es geht

**alt:** Die Stiftung „Sammlung und Bewahrung“ in Basel kauft seit Jahrzehnten Kristalle auf, um sie in Blei einzuschließen. Im Stiftungsrat sitzt eine alte Dame namens Renate Albers. In der Buchhaltung arbeitet seit vier Jahren Martin Kessler, ein stiller Mann mit einer Krawatte mit Rentieren. Vor sechs Monaten wurde Kessler krank, sehr krank, und niemand durfte ihn besuchen. Jetzt ist er zurück. Sabine aus der Buchhaltung hat ihn gefragt, warum er sich nicht an Otto erinnert, den Hund des Hausmeisters, den Kessler jeden Morgen gefüttert hat. Kessler hat gelächelt und gesagt, die Krankheit habe ihm das Gedächtnis genommen. Sabine glaubt ihm nicht. Sie hat bei der Polizei angerufen, und die Polizei hat den Anruf an eine Stelle weitergegeben, die es nicht gibt.

**neu:** Die Stiftung „Sammlung und Bewahrung“ in Basel kauft seit Jahrzehnten Kristalle auf, um sie in Blei einzuschließen. Im Stiftungsrat sitzt eine alte Dame namens Renate Albers. In der Buchhaltung arbeitete vier Jahre lang Martin Kessler, ein stiller Mann mit einer Krawatte mit Rentieren. Im März 2025 wurde Kessler krank, sehr krank, und niemand durfte ihn besuchen. Im Januar kam er zurück. Sabine aus der Buchhaltung hat ihn gefragt, warum er sich nicht an Otto erinnert, den Hund des Hausmeisters, den Kessler jeden Morgen gefüttert hat. Kessler hat gelächelt und gesagt, die Krankheit habe ihm das Gedächtnis genommen. Im März hatte die Stiftung ihn der Polizei als verschwunden gemeldet. Im Januar war aus dem Vermissten ein Langzeitkranker geworden, und die Meldung wurde zurückgezogen. Sabine hat beides mitbekommen. Sabine glaubt ihm nicht. Sie hat bei der Polizei angerufen, und die Polizei hat den Anruf an eine Stelle weitergegeben, die es nicht gibt.

### Zeile 22, Was wirklich geschah

**alt:** Elster, die im Stiftungsrat sitzt und in Wahrheit das Kind ist, das die Hände 1952 nicht geholt haben, erkannte Kuckucks Legende nach drei Wochen. Sie ließ ihn vier Jahre arbeiten und sah ihm zu. Dann ließ sie ein Foto vom Sommerfest dort ablegen, wo ein Buchhalter es finden würde: ein Foto, das Kuckuck in der Rolle Martin Kessler zeigt, aufgenommen beim Sommerfest 2024. Elster wollte, dass Kuckuck stolpert. Sie wollte, dass er Fragen stellt. Sie wollte, dass er den Artikel über das Ertrinken in der Elbe zu Ende schreibt.

**neu:** Elster, die im Stiftungsrat sitzt und in Wahrheit das Kind ist, das die Hände 1952 nicht geholt haben, erkannte Kuckucks Legende nach drei Wochen. Sie ließ ihn vier Jahre arbeiten und sah ihm zu. Dann ließ sie einen Ordner mit Fotos vom Sommerfest 2024 in der Villa des Direktors in den Keller der Stiftung stellen, zu den Akten der Restaurierungen, wo ein Buchhalter ihn finden würde. Auf einem der Bilder steht sie selbst neben dem Direktor. Elster wollte, dass Kuckuck stolpert. Sie wollte, dass er Fragen stellt. Sie wollte, dass er den Artikel über das Ertrinken in der Elbe zu Ende schreibt.

### Zeile 24, Was wirklich geschah

**alt:** Kuckuck fand das Foto und meldete es. Seine Meldung ging nach oben, und weil sie Elster betraf, ging sie an Prometheus. Die Antwort schrieb ein Sekretär. In Mulhouse warteten zwei Männer der Hände, um Kuckuck zu holen. Er kam nicht in Mulhouse an. Er kam über Konstanz, und seitdem folgt ihm jemand.

**neu:** Kuckuck fand das Bild, nahm es mit und meldete es. Seine Meldung ging nach oben, und weil sie Elster betraf, ging sie an Prometheus. Die Antwort schrieb ein Sekretär. In Mulhouse warteten zwei Männer der Hände, um Kuckuck zu holen. Er kam nicht in Mulhouse an. Er kam über Konstanz, und seitdem folgt ihm jemand.

### Zeile 30, Was wirklich geschah

**alt:** **Der rote Hering:** Viktor Brunner hat in der Stiftung eine Akte über einen Kristallkauf aus dem Jahr 2019 gefunden, bei dem die Stiftung einen Nexus-Kristall von einem Sammler in Genf erwarb. Die Akte ist unvollständig, und Brunner glaubt, dass Elster den Kristall nicht in Blei eingeschlossen hat, sondern für sich behalten will. Er hat recht, aber es ist nicht der Grund, warum die Zelle hier ist. Der Kristall liegt in Elsters Haus, in einem Bleikasten, und er summt leise. Wer ihm folgt, findet einen Nexus-Kristall und eine alte Frau, die keine Angst hat. Wer ihn für den eigentlichen Fall hält, verliert Zeit.

**neu:** **Der rote Hering:** Viktor Brunner hat in der Stiftung eine Akte über einen Kristallkauf aus dem Jahr 2019 gefunden, bei dem die Stiftung einen Nexus-Kristall von einem Sammler in Genf erwarb. Die Akte ist unvollständig, und Brunner glaubt, dass Elster den Kristall nicht ins Bleiarchiv der Stiftung gebracht hat, sondern für sich behalten will. Er hat recht, aber es ist nicht der Grund, warum die Zelle hier ist. Der Kristall liegt in Elsters Haus, in einem Bleikasten, und er summt leise. Wer ihm folgt, findet einen Nexus-Kristall und eine alte Frau, die keine Angst hat. Wer ihn für den eigentlichen Fall hält, verliert Zeit.

### Zeile 40, Renate Albers, genannt Elster

**alt:** 80 Jahre alt, weißes Haar, Perlenkette. Sie sitzt im Stiftungsrat und erkennt jede Lüge in der ersten Minute. Sie will, dass jemand aus dem Zweig das Kinderzimmer mit eigenen Augen sieht. Sie weiß, dass Brunner nicht Kuckuck ist, und sie weiß, dass der Rat sie holen will. Sie verschweigt, dass sie das Foto vom Sommerfest absichtlich abgelegt hat. Sie redet höflich, geduldig, in vollständigen Sätzen, und sie sieht jedem zuerst in die Augen, bevor sie antwortet.

**neu:** 80 Jahre alt, weißes Haar, Perlenkette. Sie sitzt im Stiftungsrat und erkennt jede Lüge in der ersten Minute. Sie will, dass jemand aus dem Zweig das Kinderzimmer mit eigenen Augen sieht. Sie weiß, dass Brunner nicht Kuckuck ist, und sie weiß, dass der Rat sie holen will. Sie verschweigt, dass sie die Fotos vom Sommerfest absichtlich in den Keller stellen ließ. Sie redet höflich, geduldig, in vollständigen Sätzen, und sie sieht jedem zuerst in die Augen, bevor sie antwortet.

### Zeile 49, Herr Leuenberger

**alt:** Ende sechzig, Direktor der Stiftung, früher selbst bei den Händen, gilt seit 1990 als tot. Er kauft Kristalle und schließt sie in Blei ein. Er will, dass die Stiftung weiterarbeitet, und er will nicht, dass der Rat Elster bekommt. Er weiß, dass Brunner nicht Kuckuck ist, weil er Kuckuck vier Jahre lang beobachtet hat. Er verschweigt, dass er Elster seit 1990 kennt. Er redet freundlich, gründlich, und er lächelt, wenn er lügt.

**neu:** Ende sechzig, Direktor der Stiftung, früher selbst bei den Händen, gilt seit 1990 als tot. Er kauft Kristalle und schließt sie in Blei ein. Er will, dass die Stiftung weiterarbeitet, und er will nicht, dass der Rat Elster bekommt. Er weiß, dass Brunner nicht Kuckuck ist, weil er Kuckuck vier Jahre lang beobachtet hat. Brunner kennt er aus seiner eigenen Zeit bei den Händen. Er verschweigt, dass er Elster seit 1990 kennt. Er redet freundlich, gründlich, und er lächelt, wenn er lügt.

### Zeile 63, Briefing

**alt:** **Was die Akte enthält:** Adresse der Stiftung, Name der Buchhalterin (Sabine Wirz), Name des Direktors (Herr Leuenberger), ein älteres Personalbild aus Kuckucks Legendenakte, aufgenommen 2021 bei der Übernahme der Legende. Ein Vermerk: „Kuckuck, Tobias Lenz, Legende Martin Kessler, seit 2021 in Basel. Letzte Meldung vor sechs Monaten. Seitdem krank. Rückkehr gemeldet von Sabine Wirz.“

**neu:** **Was die Akte enthält:** Adresse der Stiftung, Name der Buchhalterin (Sabine Wirz), Name des Direktors (Herr Leuenberger), ein älteres Personalbild aus Kuckucks Legendenakte, aufgenommen 2021 bei der Übernahme der Legende. Ein Vermerk: „Kuckuck, Tobias Lenz, Legende Martin Kessler, seit 2021 in Basel. Letzte Meldung im März 2025. Seitdem krank. Rückkehr im Januar 2026, gemeldet von Sabine Wirz.“

### Zeile 78, Knoten 1: Die Stiftung

**alt:** - **Hinweis:** Das Foto vom Sommerfest 2024 liegt in einer Schublade in der Buchhaltung. Ein Investigator mit Ermittlung oder ein Agent mit Täuschung erkennt die Abweichung. (führt zu Knoten 2)

**neu:** - **Hinweis:** Im Keller, bei den Akten der Restaurierungen, steht ein Ordner mit Fotos vom Sommerfest 2024. Ein Bild fehlt, auf einem anderen steht Martin Kessler. Ein Investigator mit Ermittlung oder ein Agent mit Menschenkenntnis erkennt die Abweichung. (führt zu Knoten 2)

### Zeile 80, Knoten 1: Die Stiftung

**neu:** - **Hinweis:** In Kesslers Personalakte liegt für zehn Monate Krankheit kein einziges Attest. Sabine hat es bemerkt. (führt zu Knoten 5)

**neu:** - **Hinweis:** Leuenberger erkennt Brunner aus seiner Zeit bei den Händen. Den Namen Viktor Brunner sagt er nur, wenn die Zelle ihm verspricht, Elster nicht auszuliefern. (führt zu Knoten 3)

### Zeile 85, Knoten 1: Die Stiftung

**alt:** **Proben:** Menschenkenntnis gegen Schwer (3), um zu erkennen, dass Sabine mehr weiß, als sie sagt. Ermittlung gegen Machbar (2), um das Foto zu finden. Gedankenflüstern (WK + Telepathie), Brunner leistet Widerstand.

**neu:** **Proben:** Menschenkenntnis gegen Schwer (3), um zu erkennen, dass Sabine mehr weiß, als sie sagt. Ermittlung gegen Machbar (2), um den Ordner zu finden. Gedankenflüstern (WK + Telepathie), Brunner leistet Widerstand.

### Zeile 91, Knoten 2: Das Foto

**alt:** Das Foto vom Sommerfest 2024, aufgenommen im Innenhof der Stiftung. Es zeigt Martin Kessler mit einer Krawatte mit Rentieren, ein Glas in der Hand, ein Lächeln, das nicht ganz zu ihm passt. Das Foto ist als Handout 4.1 beigelegt.

**neu:** Das Foto vom Sommerfest 2024, aufgenommen im Garten der Villa des Direktors. Es zeigt Martin Kessler mit der Krawatte mit Rentieren und einem Lächeln, das nicht ganz zu ihm passt. Am Rand, angeschnitten, eine alte Frau mit weißem Haar. Das Foto ist als Handout 4.1 beigelegt.

### Zeile 93, Knoten 2: Das Foto

**alt:** - **Hinweis:** Ein Investigator mit Ermittlung oder ein Agent mit Täuschung erkennt, dass der Mann auf dem Foto nicht derselbe ist wie der Mann, der heute in der Stiftung arbeitet. (führt zu Knoten 1)

**alt:** - **Hinweis:** Auf der Rückseite steht mit Bleistift: „Sommerfest 2024, Martin Kessler.“ Die Handschrift ist nicht von Sabine. Ein Investigator mit Ermittlung oder ein Agent mit Täuschung erkennt, dass die Handschrift alt ist, sehr alt. (führt zu Knoten 3)

**alt:** - **Hinweis:** Das Foto lag in einer Schublade, die Kuckuck jeden Tag benutzt hat. Ein Investigator mit Ermittlung erkennt, dass jemand es dort abgelegt hat, wo er es finden würde. (führt zu Knoten 3)

**neu:** - **Hinweis:** Ein Investigator mit Ermittlung oder ein Agent mit Menschenkenntnis erkennt, dass der Mann auf dem Foto nicht derselbe ist wie der Mann, der heute in der Stiftung arbeitet. (führt zu Knoten 1)

**neu:** - **Hinweis:** Auf der Rückseite steht mit Bleistift: „Sommerfest 2024, Martin Kessler.“ Die Handschrift ist nicht von Sabine. Ein Investigator mit Ermittlung oder ein Agent mit Wahrnehmung erkennt, dass die Handschrift alt ist, sehr alt. (führt zu Knoten 3)

**neu:** - **Hinweis:** Der Ordner stand zwischen Akten, die nur die Buchhaltung braucht. Ein Investigator mit Ermittlung erkennt, dass jemand ihn dort abgestellt hat, wo ein Buchhalter ihn finden würde. (führt zu Knoten 3)

### Zeile 103, Knoten 3: Elsters Haus

**alt:** Ein altes Haus im Basler Quartier Gundeldingen, nahe der Gellertkirche, mit einem Garten, in dem Rosen wachsen, und einer Tür, die nie abgeschlossen ist. Im Wohnzimmer steht ein Bleikasten, in dem ein Kristall summt.

**neu:** Ein altes Haus im Basler Quartier Gundeldingen, nahe der Heiliggeistkirche, mit einem Garten, in dem Rosen wachsen, und einer Tür, die nie abgeschlossen ist. Im Wohnzimmer steht ein Bleikasten, in dem ein Kristall summt.

### Zeile 105, Knoten 3: Elsters Haus

**alt:** - **Hinweis:** Elster sagt: „Sagen Sie Ihrem Führungsoffizier, dass ich die Legende Renate Albers seit 1952 trage. Er wird wissen, was das bedeutet.“ (führt zu Knoten 4)

**neu:** - **Hinweis:** Elster sagt: „Sagen Sie Ihrem Führungsoffizier, dass ich die Legende Renate Albers seit 1989 trage und dass sie 1952 für mich geschrieben wurde. Er wird wissen, was das bedeutet.“ (führt zu Knoten 4)

### Zeile 120, Knoten 4: Die Druckerei in Zürich

**alt:** - **Hinweis:** Die Akte der Legende Martin Kessler ist nicht geschlossen. Ein Agent oder Investigator findet den Vermerk: „Übergabe an Retrieval, Januar 2026.“ (führt zu Knoten 5)

**neu:** - **Hinweis:** Die Akte der Legende Martin Kessler ist nicht geschlossen. Ein Agent oder Investigator findet den Vermerk: „Übergabe an Retrieval, Januar 2026. Neuer Träger: V. B.“ (führt zu Knoten 5)

### Zeile 124, Knoten 4: Die Druckerei in Zürich

**alt:** - **Hinweis:** Der Vermerk in der Akte ist als Handout 4.3 beigelegt.

**neu:** - **Hinweis:** Der Kadett-Vermerk aus Kuckucks Akte, ein Auszug der Registratur, ist als Handout 4.3 beigelegt.

### Zeile 132, Knoten 5: Der tote Briefkasten

**alt:** Ein Schließfach im Bahnhof Basel SBB, das Brunner für Meldungen an den Rat benutzt. Ein Agent mit Zugang zum toten Briefkasten des Zweigs findet die Handschrift eines Sekretärs von Prometheus.

**neu:** Ein Schließfach im Bahnhof Basel SBB, das Brunner für Meldungen an den Rat benutzt, und der alte tote Briefkasten des Zweigs im Stadtpark, in der Ritze der Mauer hinter dem Musikpavillon. Über ihn hat Kuckuck gemeldet. Ein Agent mit Zugang zu den Unterlagen des Zweigs findet die Handschrift eines Sekretärs von Prometheus.

### Zeile 135, Knoten 5: Der tote Briefkasten

**alt:** - **Hinweis:** In Mulhouse warten zwei Männer der Hände. Ein Soldier oder Investigator, der die Reisebewegungen von Kuckuck rekonstruiert, findet, dass er über Konstanz kam, nicht über Mulhouse. (führt zu Knoten 1)

**alt:** - **Hinweis:** Brunner hat einen eigenen toten Briefkasten. Ein Agent mit Heimlichkeit findet ihn. (führt zu Knoten 1)

**neu:** - **Hinweis:** In Mulhouse warteten zwei Männer der Hände. Ein Soldier oder Investigator, der die Reisebewegungen von Kuckuck rekonstruiert, findet, dass er über Konstanz kam, nicht über Mulhouse. (führt zu Knoten 1)

**neu:** - **Hinweis:** Die Meldungen im Schließfach sind mit „V. B.“ abgezeichnet. Wer das Kürzel mit den alten Listen der Hände abgleicht, findet einen Viktor Brunner, gestorben 2005. Das Schließfach findet ein Agent, der Brunner mit Heimlichkeit folgt. (führt zu Knoten 1)

### Zeile 179, Lösungen

**alt:** **Lösungsweg ohne Kampf:** Die Zelle konfrontiert Brunner mit dem Foto vom Sommerfest und der fehlenden Krankenakte. Ein Agent oder Negotiator mit Überzeugen gegen Schwer (3) bringt ihn dazu, die Männer der Hände zurückzurufen. Brunner ist kein Fanatiker. Er ist ein Profi, der weiß, wann ein Plan gescheitert ist. Er senkt die Waffe, nickt der Zelle zu und geht über den Hinterausgang zum Rhein. Die Männer der Hände folgen ihm, wenn er ihnen sagt, dass der Einsatz abgebrochen ist. Vorher verlangt Brunner eines: dass die Zelle schweigt, gegenüber dem Rat und gegenüber dem Zweig. Er will nicht gejagt werden. Er will nur verschwinden.

**neu:** **Lösungsweg ohne Kampf:** Die Zelle konfrontiert Brunner mit dem Foto vom Sommerfest und den fehlenden Attesten. Ein Agent oder Negotiator mit Überzeugen gegen Schwer (3) bringt ihn dazu, die Männer der Hände zurückzurufen. Brunner ist kein Fanatiker. Er ist ein Profi, der weiß, wann ein Plan gescheitert ist. Er senkt die Waffe, nickt der Zelle zu und geht über den Hinterausgang zum Rhein. Die Männer der Hände folgen ihm, wenn er ihnen sagt, dass der Einsatz abgebrochen ist. Vorher verlangt Brunner eines: dass die Zelle schweigt, gegenüber dem Rat und gegenüber dem Zweig. Er will nicht gejagt werden. Er will nur verschwinden.

### Zeile 209, Nachspiel

**alt:** **Erfahrung:** 5 pro Charakter, +1 für eine Lösung ohne Kampf, +1 für eine Lösung, die Elster ins Kinderzimmer bringt.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn die Zelle herausfindet, wer Kessler ist. Höchstens +1 EP persönlicher Bonus, etwa für eine Lösung ohne Kampf oder eine, die Elster ins Kinderzimmer bringt. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den Nexus-Kristall in Elsters Haus.

### Zeile 216, Nachspiel

**alt:** - Handout 4.1: Das Foto vom Sommerfest, in Knoten 2, in einer Schublade in der Buchhaltung der Stiftung.

**neu:** - Handout 4.1: Das Foto vom Sommerfest, in Knoten 1 und 2, im Ordner im Keller der Stiftung.

### Zeile 218, Nachspiel

**alt:** - Handout 4.3: Der Vermerk in der Akte, in Knoten 4, in der Registratur der Druckerei, in der Akte von Kuckuck.

**neu:** - Handout 4.3: Der Kadett-Vermerk, ein Auszug der Registratur, in Knoten 4, im Archiv der Druckerei, in der Akte von Kuckuck.

## 05_zweiter_kreis.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 28, Was wirklich geschah

**alt:** Eva Leitner besitzt einen modifizierten Multispektralscanner, den sie aus Teilen von Morrow gebaut hat. Das Gerät schlug vor sieben Tagen auf das Signal des Kristalls an. Seitdem fährt sie jede Nacht nach Oberwölz, parkt am Waldrand und misst. Sie will den Kristall bergen, bevor O.D.I.N. oder Morrow ihn findet. In der ersten Nacht nach dem Auftauchen des Signals brachte Eva kontaminierte Wasserproben ins Haus, um sie zu analysieren. Seitdem gibt sie ihren Kindern jeden Abend ein von ihr entwickeltes Suppressivum, das die Wirkung der Kontamination unterdrückt. Das Mittel ist ein Beruhigungsmittel ohne dauerhaften Schaden, aber gefährlich genug, dass die Zelle eingreifen muss, wenn sie davon erfährt. Eva glaubt, ihre Kinder seien geschützt. In Wahrheit riskiert sie ihre Gesundheit.

**neu:** Eva Leitner besitzt einen modifizierten Multispektralscanner, den sie aus Teilen von Morrow gebaut hat. Das Gerät schlug vor sieben Tagen auf das Signal des Kristalls an. Seitdem fährt sie jede Nacht nach Oberwölz, parkt am Waldrand und misst. Sie will den Kristall bergen, bevor O.D.I.N. oder Morrow ihn findet. In der ersten Nacht nach dem Auftauchen des Signals brachte Eva kontaminierte Wasserproben ins Haus, um sie zu analysieren. Seitdem gibt sie ihren Kindern jeden Abend ein von ihr entwickeltes Suppressivum, das die Wirkung der Kontamination unterdrückt. Das Mittel ist ein Beruhigungsmittel ohne dauerhaften Schaden, aber gefährlich genug, dass die Zelle eingreifen muss, wenn sie davon erfährt. Eva glaubt, ihre Kinder seien geschützt. In Wahrheit riskiert sie die Gesundheit der beiden: Jede weitere Woche macht sie träger und blasser.

### Zeile 30, Was wirklich geschah

**alt:** **Der rote Hering:** Der Dorfarzt Dr. Franz Pichler, 58, hat vor drei Jahren eine Patientin verloren, ein Mädchen mit einer seltenen Schlafstörung. Seitdem glaubt er, dass hinter unerklärlichen Symptomen immer eine psychische Ursache steckt. Er hat den Eltern geraten, die Kinder nicht zu wecken, und der Gemeinde empfohlen, den Brunnen zu reinigen. Er verschweigt, dass er selbst seit einer Woche nachts das Summen hört, weil er aus dem Brunnen getrunken hat. Er ist kein Täter, aber er lenkt die Ermittlung in die falsche Richtung: auf eine Massenhysterie.

**neu:** **Der rote Hering:** Der Dorfarzt Dr. Franz Pichler, 58, hat vor drei Jahren eine Patientin verloren, ein Mädchen mit einer seltenen Schlafstörung. Seitdem glaubt er, dass hinter unerklärlichen Symptomen immer eine psychische Ursache steckt. Er hat den Eltern geraten, die Kinder nicht zu wecken, und der Gemeinde empfohlen, den Brunnen zu reinigen. Er verschweigt, dass er selbst seit einer Woche nachts das Summen hört, weil er jeden Morgen vor Sonnenaufgang aus dem Brunnen trinkt. Er ist kein Täter, aber er lenkt die Ermittlung in die falsche Richtung: auf eine Massenhysterie.

### Zeile 54, Paul Reiter, 66

**alt:** ### Paul Reiter, 63

**neu:** ### Paul Reiter, 66

### Zeile 74, Knoten 1: Der Anger mit dem Marktbrunnen

**alt:** Der zentrale Platz in Oberwölz, Kopfsteinpflaster, der Brunnen aus dem 17. Jahrhundert mit einer Steinfigur des heiligen Florian. Das Wasser ist klar, am Grund glitzert es. Rundherum: das Gasthaus, die Volksschule, die Kirche.

**neu:** Der zentrale Platz in Oberwölz, Kopfsteinpflaster, der Brunnen aus dem 17. Jahrhundert mit einer Steinfigur des heiligen Florian. Das Wasser ist klar, am Grund glitzert es: Unter dem Becken führt ein gemauerter Schacht sechs Meter tief zur Quellfassung, und dort unten liegt das Licht. Rundherum: das Gasthaus, die Volksschule, die Kirche.

### Zeile 77, Knoten 1: Der Anger mit dem Marktbrunnen

**alt:** - **Hinweis:** Ein Psion mit Telepathie oder ein Paranormal Detective hört in der Nähe des Brunnens ein Summen, das aus der Tiefe kommt. Probe auf WK + Telepathie gegen Schwer (3): Es ist kein Gedanke, sondern ein Rhythmus, der sich alle vier Minuten wiederholt. (führt zu Knoten 3)

**neu:** - **Hinweis:** Ein Psion mit Telepathie hört in der Nähe des Brunnens ein Summen, das aus der Tiefe kommt, ein Paranormal Detective mit EMF-Detektor ebenso. Probe auf WK + Telepathie oder IN + Okkultismus gegen Schwer (3): Es ist kein Gedanke, sondern ein Rhythmus, der sich alle vier Minuten wiederholt. (führt zu Knoten 3)

### Zeile 95, Knoten 2: Das Gasthaus „Zum Goldenen Hirschen“

**alt:** - **Hinweis:** Paul Reiter übergibt der Zelle ein Foto von 1977 mit einer Beschriftung auf der Rückseite. (Handout 5.3)

**neu:** - **Hinweis:** Wer Reiters Zögern mit Menschenkenntnis gegen Schwer (3) bemerkt und nachfragt, bekommt von ihm ein Foto von 1977 mit einer Beschriftung auf der Rückseite. (Handout 5.3)

### Zeile 107, Knoten 3: Das Labor im Haus der Leitners

**alt:** - **Hinweis:** Ein Biochemist oder Chemiker analysiert die Medikamente. Probe auf Chemie gegen Schwer (3): Es handelt sich um ein Suppressivum, das die Wirkung der Kontamination unterdrückt. Es ist nicht harmlos, aber ohne dauerhaften Schaden. (führt zu Knoten 4, 5)

**alt:** - **Hinweis:** Ein handschriftliches Laborprotokoll, Messung Nr. 7, mit fallender Pulsfrequenz und der Empfehlung zur Bergung innerhalb von 48 Stunden wegen Entdeckungsrisiko. (Handout 5.2)

**neu:** - **Hinweis:** Ein Biochemist oder Chemiker analysiert die Medikamente. Probe auf Chemie gegen Schwer (3): Es handelt sich um ein Suppressivum, das die Wirkung der Kontamination unterdrückt. Es ist nicht harmlos, aber ohne dauerhaften Schaden, wenn es bald abgesetzt wird. (führt zu Knoten 4, 5)

**neu:** - **Hinweis:** Ein handschriftliches Laborprotokoll, Messung Nr. 7, mit fallendem Pulsabstand und der Empfehlung zur Bergung innerhalb von 48 Stunden wegen Entdeckungsrisiko. (Handout 5.2)

### Zeile 128, Knoten 5: Der Marktbrunnen bei Nacht

**alt:** - **Hinweis:** Ein Psion mit Telepathie hört den Chor der Kinder als ein einziges Summen, das aus dem Brunnen kommt. Probe auf WK + Telepathie gegen Sehr schwer (4): Der Kristall „singt“ durch die Kinder, und er will gehört werden. (führt zu Konfrontation)

**neu:** - **Hinweis:** Ein Psion mit Telepathie hört den Chor der Kinder als ein einziges Summen, das aus dem Brunnen kommt. Probe auf WK + Telepathie gegen Sehr schwer (4): Der Kristall „singt“ durch die Kinder, und er will gehört werden. Wer ihn zum Schweigen bringt, bringt auch sie zum Schweigen. (führt zu Konfrontation)

### Zeile 141, Knoten 5: Der Marktbrunnen bei Nacht

**alt:** 1. Ein EMF-Detektor zeigt Pulse im Takt von Nordlicht, alle vier Minuten. (Knoten 3, 5)

**neu:** 1. Ein EMF-Detektor zeigt Pulse im Takt von Nordlicht, alle vier Minuten. (Knoten 1, 3, 5)

### Zeile 143, Knoten 5: Der Marktbrunnen bei Nacht

**alt:** 3. Der Kristall im Brunnen ist ein Rissfragment, klar mit milchigem Kern. (Knoten 3, 5)

**neu:** 3. Die Wasserprobe enthält Kristallstaub, und Kinder, die im Schlaf singen, sind ein bekanntes Vorzeichen der Stimme. (Knoten 1, 2)

### Zeile 200, Dr. Eva Leitner, alias Eva Lechner

**alt:** [entry - | Dr. Eva Leitner, alias Eva Lechner | Nichtspielercharakter · Wissenschaftlerin]

**neu:** [entry - | Dr. Eva Leitner, alias Eva Lechner | Biochemikerin · Menschen]

### Zeile 213, Thomas Leitner, alias Thomas Lechner

**alt:** [entry - | Thomas Leitner, alias Thomas Lechner | Nichtspielercharakter · Ingenieur]

**neu:** [entry - | Thomas Leitner, alias Thomas Lechner | Ingenieur · Menschen]

### Zeile 219, Thomas Leitner, alias Thomas Lechner

**alt:** **Grauen** | kein

**neu:** **Grauen** | Keines

### Zeile 234, Nachspiel

**alt:** **Erfahrung:** 5 pro Charakter, +1 für die Lösung ohne Kampf, +1 für die Bergung im richtigen Moment.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn der Kristall geborgen und isoliert ist. Höchstens +1 EP persönlicher Bonus, etwa für die Lösung ohne Kampf oder die Bergung im richtigen Moment. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa Paul Reiters Nacht von 1977.

## 06_hauslehrer.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 11, Worum es geht

**alt:** Am Solbergsee wird bei Bauarbeiten ein Runenstein mit denselben Kreisen gefunden wie an der Wand des Gutshauses. Seit einer Woche singen im Dorf die Kinder im Schlaf. Die Zelle wird geschickt, um herauszufinden, was geschieht, bevor die Lage eskaliert. Vor Ort findet sie einen verunsicherten Bauleiter, Eltern, die ihre Kinder nicht mehr wecken wollen, und eine Wand im Gutshaus, die unter der Tapete warm ist. Solberg ist Sperrzone. Die Zelle reist mit einer Genehmigung des Rates ein, getarnt als Mitarbeiter einer Stiftung für Denkmalpflege, die den Runenstein dokumentieren soll.

**neu:** Am Solbergsee wird bei Bauarbeiten ein Runenstein mit denselben Kreisen gefunden wie an der Wand des Gutshauses. Seit einer Woche singen im Dorf die Kinder im Schlaf. Die Zelle wird geschickt, um herauszufinden, was geschieht, bevor die Lage eskaliert. Vor Ort findet sie einen verunsicherten Bauleiter, Eltern, die ihre Kinder nicht mehr wecken wollen, und eine Wand im Gutshaus, die unter der Tapete warm ist. Das Gutshaus am See ist Sperrzone, sonst nur mit Schwarzer Akte zugänglich. Die Zelle reist mit einer Genehmigung des Rates ein, getarnt als Mitarbeiter einer Stiftung für Denkmalpflege, die den Runenstein dokumentieren soll.

### Zeile 51, Knoten 1: Die Baustelle am See

**alt:** Die Baugrube, der Runenstein unter einer Plane, Bauarbeiter, Jens Harder. Der Stein liegt halb im Schlamm, die Kreise sind deutlich sichtbar. Am Waldrand stehen die Bäume dicht, der Boden ist aufgewühlt.

**neu:** Die Baugrube am Waldrand, Bauarbeiter, Jens Harder. Daneben liegt der Runenstein unter einer Plane, halb im Schlamm, wo der Bagger ihn abgesetzt hat. Die Kreise sind deutlich sichtbar. Gefunden wurde er fünfzig Meter weiter im Wald, auf einer Lichtung. Das Gutshaus liegt einen Kilometer entfernt. Am Waldrand stehen die Bäume dicht, der Boden ist aufgewühlt.

### Zeile 69, Knoten 2: Das Dorf und die Kinder

**neu:** - **Hinweis:** Dr. Lindqvist erzählt, was die Alten im Dorf den Kindern beibringen: Im Wald pfeift man nicht, man ruft nicht, und man nimmt nichts mit (führt zu „Was wirkt“).

### Zeile 74, Knoten 3: Das Kirchenbuch und das Pfarrhaus

**alt:** Das alte Kirchenbuch von Solberg, Pfarrer Mattias Berg, ein kleines Archiv im Pfarrhaus. Das Kirchenbuch hat einen Eintrag von 1871, der mitten im Satz abbricht. Im Archiv liegt eine Kiste mit alten Papieren, darunter der Zeitungsartikel von 1872 (Handout 6.1) und der Brief des Pfarrers (Handout 6.2).

**neu:** Pfarrer Mattias Berg, ein kleines Archiv im Pfarrhaus und darin eine beglaubigte Abschrift des alten Kirchenbuchs von Solberg. Das Original liegt im Landesarchiv Uppsala. Der Eintrag von 1871 bricht auch in der Abschrift mitten im Satz ab. Im Archiv liegt eine Kiste mit alten Papieren, darunter der Zeitungsartikel von 1872 (Handout 6.1) und der Brief des Pfarrers (Handout 6.2).

### Zeile 90, Knoten 4: Die Loge Zum Schweigenden Kreis

**alt:** - **Hinweis:** Der Antiquar weiß, dass der Waldgänger Abmachungen wörtlich hält (führt zu „Was wirkt“).

**neu:** - **Hinweis:** Der Antiquar weiß, dass der Waldgänger Abmachungen wörtlich hält und drei Regeln kennt: nicht pfeifen, nicht rufen, nichts mitnehmen (führt zu „Was wirkt“).

### Zeile 95, Knoten 5: Das Gutshaus

**alt:** Das alte Gutshaus, die Wand mit den Kreisen, hinter Tapete oder Farbe. Ein Verwalter wohnt im Nebengebäude. Das Haus ist leer, die Luft steht. Die Wand im Speisesaal ist warm, die Tapete löst sich an einer Stelle.

**neu:** Das alte Gutshaus, die Wand mit den Kreisen, hinter Tapete oder Farbe. Niemand wohnt hier. Das Haus ist leer, die Luft steht. Die Wand im Speisesaal ist warm, die Tapete löst sich an einer Stelle.

### Zeile 104, Knoten 5: Das Gutshaus

**alt:** Probe: Thaumaturg oder Paranormal Detective, Ritualismus gegen Schwer (3), um die Kreise zu lesen.

**neu:** Probe: Thaumaturg mit Ritualismus oder Paranormal Detective mit Okkultismus, jeweils gegen Schwer (3), um die Kreise zu lesen.

### Zeile 134, Ablauf

**alt:** 3. Er verlangt den Stein zurück. Er sagt: „Der Stein liegt falsch. Bringt ihn zurück in den Wald, wo er lag, oder ich nehme ihn mir, und dann nehme ich auch, was ihr liebt.“ Wer den Stein nicht herausgibt, wird geprüft. Der Waldgänger sieht jeden der Reihe nach an. Wer seinem Blick standhält, ohne wegzusehen, hat bestanden. Wer wegsieht, wird nicht mehr angesprochen.

**neu:** 3. Er verlangt den Stein zurück. Er sagt: „Der Stein liegt falsch. Bringt ihn zurück in den Wald, wo er lag, oder ich nehme ihn mir, und dann nehme ich auch, was ihr liebt.“ Wer den Stein nicht herausgibt, wird geprüft. Der Waldgänger sieht jeden der Reihe nach an. Wer seinem Blick standhält, ohne wegzusehen (Grauen-Probe gegen Verstörend (2)), hat bestanden. Wer wegsieht, wird nicht mehr angesprochen.

### Zeile 158, Der Waldgänger am Solbergsee

**alt:** **Schwäche** | Eisen, Feuer am Waldrand, Salz. Wer seine Regeln kennt, nicht pfeift, nicht ruft, nichts mitnimmt, ist für ihn tabu. Ein Mensch, der seine Kleidung links herum trägt, kann von ihm nicht irreführt werden

**neu:** **Schwäche** | Eisen, Feuer am Waldrand, Salz. Wer seine Regeln kennt, nicht pfeift, nicht ruft, nichts mitnimmt, ist für ihn tabu. Ein Mensch, der seine Kleidung links herum trägt, kann von ihm nicht irregeführt werden

### Zeile 170, Nichtspielercharaktere

**alt:** **Alfred Sundberg, Antiquar.** Er ist alt und gebrechlich. Er trägt einen schweren Spazierstock. Wenn die Zelle ihn enttarnt, wird er leise und zitiert aus alten Büchern. Er kann mit dem Stock zuschlagen: Angriff 2 + 2, Schaden 2. Er ist kein Kämpfer, aber er ist verzweifelt.

**neu:** **Alfred Sundberg, Antiquar.** Er ist alt und gebrechlich. Er trägt einen schweren Spazierstock. Wenn die Zelle ihn enttarnt, wird er leise und zitiert aus alten Büchern. Er hebt in seiner Verzweiflung den Stock, aber er schlägt nicht zu. Er hat keinen Angriff.

### Zeile 179, Nachspiel

**alt:** **Was O.D.I.N. bekommt:** Den Runenstein oder eine Kopie der Kreise. Der Stein bleibt im Wald, aber ein Abrieb der Kreise geht an die Registratur. Die offene Akte von 1871 bleibt offen, mit neuen Fäden: die fehlende Seite, die Loge, der Name des Hauslehrers. Der rote Hering um Sundberg wird notiert. Die Loge Zum Schweigenden Kreis wird als aktive Organisation markiert.

**neu:** **Was O.D.I.N. bekommt:** Einen Abrieb der Kreise für die Registratur. Den Runenstein nur, wenn die Zelle ihn nicht zurückbringt, und dann kommt der Waldgänger jede Nacht wieder. Die offene Akte von 1871 bleibt offen, mit neuen Fäden: die fehlende Seite, die Loge, der Name des Hauslehrers. Der rote Hering um Sundberg wird notiert. Die Loge Zum Schweigenden Kreis wird als aktive Organisation markiert.

### Zeile 181, Nachspiel

**alt:** **Erfahrung:** 5 pro Charakter, +1 für eine friedliche Lösung, +1 für das Verfolgen der Spur der fehlenden Seite bis zur Hausbibel. Zusätzlich +1 für einen Investigator, der die Verbindung zwischen 1871 und der offenen Akte von 1938 herstellt.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn der Stein zurück im Wald ist und die Kinder still sind. Höchstens +1 EP persönlicher Bonus, etwa für eine friedliche Lösung. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa die Spur der fehlenden Seite bis zur Hausbibel oder die Verbindung zwischen 1871 und der offenen Akte von 1938.

## 07_vitrine.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 16, Worum es geht

**alt:** Die Zelle kommt als Besuchergruppe, als Denkmalschutzbeauftragte oder als Journalisten. Der Führungsoffizier gibt ihr eine dünne Akte: Meldung, Zeitungsausschnitt, ein Foto der Vitrine. Die Lage ist ruhig. Noch ist niemand verletzt. Aber die Kinder singen jede Nacht, und seit einer Woche singt auch die Enkelin Jule, die in einer anderen Stadt wohnt, im Schlaf.

**neu:** Die Zelle kommt als Besuchergruppe, als Denkmalschutzbeauftragte oder als Journalisten. Der Führungsoffizier gibt ihr eine dünne Akte: Meldung, Zeitungsausschnitt, ein Foto der Vitrine. Die Lage ist ruhig. Noch ist niemand verletzt. Aber die Kinder singen jede Nacht, und seit einer Woche singt auch die Enkelin der Direktorin im Schlaf, Jule, die in einer anderen Stadt wohnt und seit ein paar Tagen bei ihrer Großmutter zu Besuch ist.

### Zeile 20, Was wirklich geschah

**alt:** Im Dezember 1938, in der Nacht zum 3., starb in Bad Grund ein Mädchen namens Liese Hartmann, zehn Jahre alt. Sie war die Tochter des Steigers Wilhelm Hartmann, der im Schacht „Silberner Hirsch“ arbeitete. Am Abend des 2. Dezember brachte ihr Vater einen Kristall mit nach Hause, den er am 1. Dezember in der Grube gefunden hatte: einen faustgroßen, milchigen Stein, ungewöhnlich warm. Liese nahm ihn mit ins Bett. In jener Nacht, in der in Solberg die Kinder sangen und neunzehn Erwachsene verschwanden, starb Liese in ihrem Zimmer. Der Arzt schrieb „Herzschlag“. Der Vater verkaufte den Kristall am 6. Dezember an den Sammler Hermann Wegener und verschwand am selben Tag im Schacht. Er wurde nie gefunden.

**neu:** Im Dezember 1938, in der Nacht zum 3., starb in Bad Grund ein Mädchen namens Liese Hartmann, zehn Jahre alt. Sie war die Tochter des Steigers Wilhelm Hartmann, der im Schacht „Silberner Hirsch“ arbeitete. Am Abend des 2. Dezember brachte ihr Vater einen Kristall mit nach Hause, den er am 1. Dezember in der Grube gefunden hatte: einen faustgroßen, milchigen Stein, ungewöhnlich warm. Liese nahm ihn mit ins Bett. In jener Nacht, in der in Solberg die Kinder sangen und neunzehn Erwachsene verschwanden, starb Liese in ihrem Zimmer. In derselben Nacht starben in Bad Grund zwei weitere Kinder im Schlaf. Der Arzt schrieb dreimal „Herzschlag“. Der Vater verkaufte den Kristall am 6. Dezember an den Sammler Hermann Wegener und verschwand am selben Tag im Schacht. Er wurde nie gefunden.

### Zeile 49, Inge Lorenz, 58

**alt:** Lehrerin an der Grundschule. Sie will, dass die Kinder ihrer Klasse aufhören, im Schlaf zu singen. Sie weiß, dass drei Kinder aus ihrer Klasse betroffen sind, und dass alle drei in der Woche nach der Ausstellungseröffnung im Museum waren. Sie verschweigt, dass sie das Lied als altes Bad Grunder Lied von ihrer Großmutter kennt, die es 1938 von einem Mädchen namens Liese gehört hat. Sie redet schnell, besorgt, mit vielen Fragen. Sie sagt: „Die Kinder singen dasselbe Lied. Ich kenne es. Meine Großmutter hat es mir vorgesungen.“

**neu:** Lehrerin an der Grundschule. Sie will, dass die Kinder ihrer Klasse aufhören, im Schlaf zu singen. Sie weiß, dass drei Kinder aus ihrer Klasse betroffen sind, und dass alle drei in der Woche nach der Ausstellungseröffnung im Museum waren. Sie verschweigt, dass sie das Lied als altes Bad Grunder Lied von ihrer Großmutter kennt, die es in der Nacht zum 3. Dezember 1938 durch die Wand aus dem Nachbarhaus der Hartmanns gehört hat, von einem Mädchen namens Liese. Sie redet schnell, besorgt, mit vielen Fragen. Sie sagt: „Die Kinder singen dasselbe Lied. Ich kenne es. Meine Großmutter hat es mir vorgesungen.“

### Zeile 62, Briefing

**alt:** **Anfordern:** EMF-Detektor, Salz, ein Diktiergerät mit Rauschfilter, ein Multispektralscanner, einen Beryllium-Isolierbehälter, ein Fahrzeug. Häufiges ohne Wartezeit. Ein Thaumaturg kann zusätzlich einen Kristallsplitter aus dem Hort anfordern, wenn er es begründet. Der Multispektralscanner ist sehr selten und braucht einen Senior-Agenten mit Begründung oder einen Punkt Vertrauen.

**neu:** **Anfordern:** EMF-Detektor, Salz, ein Diktiergerät mit Rauschfilter, ein Multispektralscanner, einen Beryllium-Isolierbehälter, ein Fahrzeug. Häufiges ohne Wartezeit. Ein Thaumaturg kann zusätzlich einen Kristallsplitter aus dem Hort anfordern, wenn er es begründet. Der Multispektralscanner ist sehr selten: ab Senior-Agent, mit Begründung, drei Tage Wartezeit. Ein Punkt Vertrauen hebt die Rangschwelle um eine Stufe, ein weiterer streicht die Wartezeit.

### Zeile 124, Knoten 5: Das Archiv der Stadt (Stadtarchiv Bad Grund)

**alt:** - **Hinweis:** Ein Aktenvermerk der Registratur über Spuke: Ein Spuk verschwindet, wenn man findet, was er wiederholt, und es beendet. (führt zu: Was wirkt, Konfrontation)

**neu:** - **Hinweis:** Ein Anruf bei der Registratur ergibt einen Aktenvermerk über Spuke: Ein Spuk verschwindet, wenn man findet, was er wiederholt, und es beendet. (führt zu: Was wirkt, Konfrontation)

### Zeile 140, Eskalation

**alt:** **Zweite Nacht:** Die Akte wird rot. Liese erscheint nicht mehr nur als Kälte und Stimme. Sie zeigt sich: ein Mädchen in einem Nachthemd, barfuß, das im Museum umhergeht und die Türen öffnet. Die Vitrine springt auf, der Kristall liegt auf dem Boden. Die Direktorin ist wie in Trance und will den Kristall in den Schacht „Silberner Hirsch“ tragen, der seit 1945 verschlossen ist. Die Zelle muss sie aufhalten.

**neu:** **Zweite Nacht:** Die Akte wird rot. Liese erscheint nicht mehr nur als Kälte und Stimme. Sie zeigt sich: ein Mädchen in einem Nachthemd, unter dem Saum nur Nebel, das im Museum umhergeht und die Türen öffnet. Die Vitrine springt auf, der Kristall liegt auf dem Boden. Die Direktorin ist wie in Trance und will den Kristall in den Schacht „Silberner Hirsch“ tragen, der seit 1945 verschlossen ist. Die Zelle muss sie aufhalten.

### Zeile 157, Ablauf

**alt:** 1. Die Zelle betritt das Museum oder beobachtet es von außen. Die Direktorin ist im Raum „Bergbau und Mineralien“ und liest vor. Ihre Stimme ist monoton. Jule steht neben ihr und hält ihre Hand. Die Enkelin ist an diesem Wochenende zu Besuch, weil ihre Mutter sie für zwei Tage zur Großmutter gebracht hat.

**neu:** 1. Die Zelle betritt das Museum oder beobachtet es von außen. Die Direktorin ist im Raum „Bergbau und Mineralien“ und liest vor. Ihre Stimme ist monoton. Jule steht neben ihr und hält ihre Hand. Die Enkelin ist noch bei ihrer Großmutter zu Besuch.

### Zeile 196, Dr. Marianne Weber

**alt:** [entry - | Dr. Marianne Weber | Nichtspielercharakter · Museumsdirektorin]

**neu:** [entry - | Dr. Marianne Weber | Museumsdirektorin · Menschen]

### Zeile 220, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter, +1 für die Lösung mit der Wahrheit, +1 für die Rettung der Direktorin und der Enkelin.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn Liese erlöst ist und Direktorin und Enkelin unversehrt sind. Höchstens +1 EP persönlicher Bonus, etwa für die Lösung mit der Wahrheit. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den zweiten Kristall im Schacht.

### Zeile 222, Nachspiel

**alt:** **Totenköpfe:** Wenn die Zelle den Kristall an O.D.I.N. gibt, verliert die Stiftung in Basel einen Totenkopf, weil der Stein nicht auf den Markt kommt. Gibt sie ihn an das Kollegium, verliert O.D.I.N. einen Totenkopf, weil der Rat einen Nexus-Kristall nicht bekommt.

**neu:** **Totenköpfe:** Wenn die Zelle den Kristall abgibt, an den Rat oder an das Kollegium, verliert die Stiftung in Basel einen Totenkopf, weil der Stein nicht auf den Markt kommt. Gibt sie ihn dem Kollegium statt dem Rat, bekommt der Führungsoffizier Ärger: Vertrauen −1.

## 08_zweites_licht.md (Sicherung vor_handoutcheck_2026-10-10)

### Zeile 14, Was wirklich geschah

**alt:** Die Erleuchteten sind eine Legende der Druckerei, 1968 geschrieben, um Gerüchte über O.D.I.N. aufzusaugen. Die Druckerei erfand Mitgliedslisten, Rituale, Bücher, später Webseiten. Das funktionierte zu gut. Echte Menschen traten der erfundenen Geheimgesellschaft bei, und einige begannen, die Rituale ernst zu nehmen. Das Ritual „Das Zweite Licht“ stammt aus MS Arcana 114, einem internen Kompendium der Druckerei von 1971. Es enthält den siebten Kreis als Ornament, abgeschrieben aus einem älteren Manuskript, das die Druckerei für dekorativ hielt. Der siebte Kreis ist kein Ornament. Er ist eine Anrufung.

**neu:** Die Erleuchteten sind eine Legende der Druckerei, 1968 geschrieben, um Gerüchte über O.D.I.N. aufzusaugen. Die Druckerei erfand Mitgliedslisten, Rituale, Bücher, später Webseiten. Das funktionierte zu gut. Echte Menschen traten der erfundenen Geheimgesellschaft bei, und einige begannen, die Rituale ernst zu nehmen. Das Ritual „Das Zweite Licht“ steht in einem internen Kompendium der Druckerei von 1971. Es enthält den siebten Kreis als Ornament, abgeschrieben aus MS Arcana 114, einer Handschrift des Kollegiums, die die Druckerei für dekorativ hielt. Der siebte Kreis ist kein Ornament. Er ist eine Anrufung.

### Zeile 18, Was wirklich geschah

**alt:** Ein Mitglied der Internetgruppe, Maarten de Vries, 34, ein arbeitsloser Grafikdesigner aus Anderlecht, hat das Ritual gelesen und danach durchgeführt. Er glaubte, die Illuminaten würden ihn zum „Erleuchteten“ machen. Er lud drei andere Mitglieder der Gruppe in sein Reihenhaus ein: Sophie Renard, 28, Studentin der Kunstgeschichte; Jonas Vermeulen, 41, Buchhalter; und Aylin Demir, 31, Krankenschwester. In der Nacht vom 17. Oktober 2026, einem Samstag, führte er das Ritual im Keller durch. Er hatte den siebten Kreis mit Kreide und Asche auf den Boden gemalt und in die Mitte einen kleinen Kristall gelegt, den er im Internet als „Bergkristall, aufgeladen“ gekauft hatte. Der Kristall war echt.

**neu:** Ein Mitglied der Internetgruppe, Maarten de Vries, 34, ein arbeitsloser Grafikdesigner aus Anderlecht, hat das Ritual gelesen und danach durchgeführt. Er glaubte, die Illuminaten würden ihn zum „Erleuchteten“ machen. Er lud drei andere Mitglieder der Gruppe in sein Reihenhaus ein: Sophie Renard, 28, Studentin der Kunstgeschichte; Jonas Vermeulen, 41, Buchhalter; und Aylin Demir, 31, Krankenschwester. In der Nacht vom 17. Oktober 2026, einem Samstag, führte er das Ritual im Keller durch. Er hatte den siebten Kreis mit Kreide und Asche auf den Boden gemalt und in die Mitte einen faustgroßen Kristall gelegt, den er im Internet als „Bergkristall, aufgeladen“ gekauft hatte. Der Kristall war echt.

### Zeile 34, Jonas Vermeulen, 41

**alt:** Buchhalter, Freimaurer, verschwunden. Er war das vorsichtigste Mitglied, hatte den Logenabend abgesagt, um zu Maarten zu fahren. Sein Logenkalender ist der rote Hering. Er weiß nichts vom Ritual.

**neu:** Buchhalter, Freimaurer, verschwunden. Er war das vorsichtigste Mitglied, hatte den Logenabend abgesagt, um zu Maarten zu fahren. Sein Logenkalender ist der rote Hering. Er hielt das Ritual für ein Spiel.

### Zeile 37, Aylin Demir, 31

**alt:** Krankenschwester, verschwunden. Sie hatte in der Gruppe zuletzt gepostet: „Das Licht ist kein Licht. Es ist ein Auge.“ Sie ahnte etwas, aber zu spät.

**neu:** Krankenschwester, verschwunden. Ihr letzter Beitrag in der Gruppe endet mit: „Sagt ihm, das Licht ist kein Licht.“ Sie hatte geträumt, das Licht sei ein Auge. Sie ahnte etwas, aber zu spät.

### Zeile 51, Briefing

**alt:** > „Drei Vermisste in Brüssel, alle in derselben Internetgruppe. Auf ihren Rechnern liegt ein Dokument, das aus unserer Druckerei stammt. Es ist ein Ritual, das nie hätte geschrieben werden dürfen. Findet heraus, wer es benutzt hat, und beendet es, bevor ein viertes Mitglied verschwindet. Die belgische Polizei hat noch keine Spur vom Ritual. Haltet es so.“ || Führungsoffizier

**neu:** > „Drei Vermisste in Brüssel, alle in derselben Internetgruppe. Auf ihren Rechnern liegt ein Dokument, das aus unserer Druckerei stammt. Es ist ein Ritual, das nie hätte geschrieben werden dürfen. Findet heraus, wer es benutzt hat, und beendet es, bevor ein viertes Mitglied verschwindet. Die belgische Polizei hält das Ritual für einen Scherz. Haltet es so.“ || Führungsoffizier

### Zeile 53, Briefing

**alt:** **Was die Akte enthält:** Namen und Adressen der drei Vermissten, Ausdrucke aus dem Forum „Illuminati Europa“, das Ritual „Das Zweite Licht“ als PDF, die Adresse von Maarten de Vries, ein Foto des Kellers aus einem Online-Inserat des Hauses. Der Beobachter, der die Meldung abgefangen hat, hat alle belgischen Mitglieder der Gruppe samt Adressen erfasst und der Akte beigelegt. **Spesen:** 2.000 €. **Anfordern:** Ein EMF-Detektor, Salz, ein Multispektralscanner. Ein Thaumaturg kann einen Bannkreis selbst errichten, wenn er die Fertigkeit Ritualismus beherrscht. Häufiges ohne Wartezeit.

**neu:** **Was die Akte enthält:** Namen und Adressen der drei Vermissten, Ausdrucke aus dem Forum „Illuminati Europa“, das Ritual „Das Zweite Licht“ als PDF. Der Beobachter, der die Meldung abgefangen hat, hat alle belgischen Mitglieder der Gruppe samt Adressen erfasst und der Akte beigelegt. **Spesen:** 2.000 €. **Anfordern:** Ein EMF-Detektor, Salz, ein Multispektralscanner. Ein Thaumaturg kann einen Bannkreis selbst errichten, wenn er die Fertigkeit Ritualismus beherrscht. Häufiges ohne Wartezeit.

### Zeile 64, Knoten 1: Die Wohnungen der Vermissten

**alt:** - **Hinweis:** Aylin Demirs letzter Forenbeitrag: „Das Licht ist kein Licht. Es ist ein Auge.“ Ein Investigator mit Menschenkenntnis erkennt, dass sie als Einzige Angst hatte. (führt zu Knoten 2)

**neu:** - **Hinweis:** Aylin Demirs letzter Forenbeitrag: „Sagt ihm, das Licht ist kein Licht.“ Ein Investigator mit Menschenkenntnis erkennt, dass sie als Einzige Angst hatte. (führt zu Knoten 2)

### Zeile 75, Knoten 2: Das Forum „Illuminati Europa“

**neu:** - **Hinweis:** Nadia zeigt Maartens letzte private Nachricht an sie: „Es kommt durch mich zurück. Ich bin die Tür.“ (führt zu Knoten 5)

### Zeile 83, Knoten 3: Das Reihenhaus in Anderlecht

**alt:** - **Hinweis:** Ein Soldier mit Taktik erkennt, dass der Keller ein einziger Zugang ist, aber ein Fenster zum Garten hat, das mit Pappe verklebt ist. (führt zu Knoten 5)

**neu:** - **Hinweis:** Ein Soldier mit Taktik erkennt, dass der Keller nur über die Treppe zu erreichen ist. Das Fenster zum Garten ist mit Pappe verklebt, lässt sich aber von außen öffnen. (führt zu Knoten 5)

### Zeile 90, Knoten 4: Das Archiv der Druckerei

**alt:** - **Hinweis:** Das Ritual „Das Zweite Licht“ stammt aus MS Arcana 114, einem internen Kompendium von 1971. Ein Randvermerk der Setzerin: „Dekoration. Nicht verwenden.“ (Handout 8.2) (führt zu Knoten 5)

**neu:** - **Hinweis:** Das Ritual „Das Zweite Licht“ steht in einem internen Kompendium der Druckerei von 1971, der Kreis darin ist aus der Handschrift MS Arcana 114 des Kollegiums abgeschrieben. Ein Randvermerk der Setzerin: „Dekoration. Nicht verwenden.“ (Handout 8.2) (führt zu Knoten 5)

### Zeile 98, Knoten 5: Der Keller des Reihenhauses

**alt:** Der Keller ist ein rechteckiger Raum, etwa 4 mal 5 Meter, mit einer Treppe von oben. Der Kreis ist mit Kreide und Asche auf den Betonboden gemalt, etwa 2 Meter im Durchmesser. In der Mitte liegt ein faustgroßer Kristall. Der Kreis ist warm, als läge eine Heizung darunter.

**neu:** Der Keller ist ein rechteckiger Raum, etwa 4 mal 5 Meter, mit einer Treppe von oben. Der Kreis ist mit Kreide und Asche auf den Betonboden gemalt, etwa 2 Meter im Durchmesser. In der Mitte liegt ein faustgroßer Kristall. Der Kreis ist warm, als läge eine Heizung darunter. Tagsüber schläft Maarten im Obergeschoss. Wer leise ist (Heimlichkeit gegen Machbar (2)), kann den Keller untersuchen, ohne dass er es merkt.

### Zeile 104, Knoten 5: Der Keller des Reihenhauses

**alt:** - **Probe:** Ein Thaumaturg mit Ritualismus analysiert den Kreis. Schwierigkeit: Schwer (3). Ein Scientist mit Physik misst die Wärme. Schwierigkeit: Machbar (2). Ein Psion mit Telepathie hört die Stimme. Schwierigkeit: Schwer (3). Ein Soldier mit Taktik erkennt, dass der Keller nur einen Ausgang hat. Schwierigkeit: Einfach (1).

**neu:** - **Probe:** Ein Thaumaturg mit Ritualismus analysiert den Kreis. Schwierigkeit: Schwer (3). Ein Scientist mit Physik misst die Wärme. Schwierigkeit: Machbar (2). Ein Psion mit Telepathie hört die Stimme. Schwierigkeit: Schwer (3). Ein Soldier mit Taktik erkennt, dass außer der Treppe nur das Gartenfenster hinausführt. Schwierigkeit: Einfach (1).

### Zeile 111, Knoten 5: Der Keller des Reihenhauses

**alt:** **Was will es?** Die Stimme will durch den Kreis zurückkehren und Maarten als Tor benutzen. Hinweise in Knoten 5, 5, 5.

**neu:** **Was will es?** Die Stimme will durch den Kreis zurückkehren und Maarten als Tor benutzen. Hinweise in Knoten 2, 5, 5.

### Zeile 155, Lösungen

**neu:** **Ohne Thaumaturg.** Wer den Kristall aus dem Kreis nimmt und in Beryllium oder Salz legt, schließt den Kreis für eine Nacht. Die Risslinge zerfallen. Am nächsten Tag schickt das Kollegium einen Thaumaturgen, der ihn versiegelt.

### Zeile 196, Nachspiel

**alt:** **Erfahrung:** 5 EP pro Charakter. +1 EP für die Lösung ohne Kampf. +1 EP für die Versiegelung des Kreises.

**neu:** **Die drei Verschwundenen:** Sophie Renard, Jonas Vermeulen und Aylin Demir kommen nicht zurück. Wird der Kreis versiegelt, verstummt Sophies Stimme im Keller. Ihre Akten bleiben bei der Registratur offen.

### Zeile 198, Nachspiel

**alt:** **Totenköpfe:** Die Erleuchteten verlieren einen Totenkopf, weil das Ritual beendet wurde. Die Erleuchteten sinken damit von drei auf zwei Totenköpfe.

**neu:** **Erfahrung:** 4 EP pro Charakter, 5, wenn die Akte rot geworden ist. +1 EP, wenn der Kreis versiegelt und Maarten aufgehalten ist. Höchstens +1 EP persönlicher Bonus, etwa für die Lösung ohne Kampf. +1 EP für jeden Faden, den die Zelle aufnimmt, etwa den Hobbygeologen mit den übrigen Steinen.

**neu:** **Totenköpfe:** Die Erleuchteten verlieren zwei Totenköpfe, weil ihr Schlüsselkopf Maarten de Vries ausgeschaltet ist, und sinken von drei auf einen. Nach der nächsten Mission würfelt die Spielleitung für diesen Plan nicht.
