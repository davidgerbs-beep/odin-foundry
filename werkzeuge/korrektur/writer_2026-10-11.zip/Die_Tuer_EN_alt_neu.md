# Die Tuer EN: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 4 Stellen.

## 01_kampagne.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 110, The Cell

**alt:** **Experience and Rank.** After each mission there are XP according to the table in “Running Campaigns”: 3 for a White File, 5 for a Grey, 6 for a Red, 8 for a Black, 3 for a mission without a file, and +1 for each thread the cell picks up, plus at most 1 XP personal bonus. Thus they are promoted to Agents during Act I, to Senior Agents in Act II, and perhaps to Veterans before the last night. Promotions are scenes: Behr hands them over, and sometimes a truth with them.

**neu:** **Experience and Rank.** After each mission there are XP as in the core rulebook and in “Running Campaigns”: the base value of the file colour (White 2, Grey 4, Red 5, Black 7, no file 2), +1 for reaching the objective, at most +1 personal bonus, and +1 for each thread the cell picks up. Thus they are promoted to Agents during Act I, to Senior Agents in Act II, and perhaps to Veterans before the last night. Promotions are scenes: Behr hands them over, and sometimes a truth with them.

### Zeile 278, Confrontation

**alt:** How the cell resolves the scene is the first major choice of the campaign. Calm Lio and hand him over to the Observer. Leave Lio to the Open One. Hide Lio and hand him over to no one. A Telepath or Psychic Healer can calm Lio with WIL + Telepathy against Hard (3), one step easier with a helmet, a cap or a piece of Alloy S.

**neu:** How the cell resolves the scene is the first major choice of the campaign. Calm Lio and hand him over to the Observer. Leave Lio to the Open One. Hide Lio and hand him over to no one. A Telepath or Psychic Healer can calm Lio with WIL + Telepathy against Hard (3), one step easier with a helmet, a cap or a piece of Alloy S. Without a Psion, anyone who talks to him can calm him: CHA + Persuasion against Very Hard (4).

### Zeile 377, The Three Curves

**alt:** In the morning after the night, Planck sits with the cell in the canteen and has three sheets of paper in front of her. On the first, her curve of the pulses. On the second, the numbers from the station that the cell’s Registry sent, with the interval between transmissions, which is also getting shorter. On the third, the running of the wall clock from the canteen at Nordlicht, which hangs in a display case two floors above the Institute’s canteen and runs backwards. Planck has long since calculated when it will arrive, and had taken the date for a coincidence.

**neu:** In the morning after the night, Planck sits with the cell in the canteen and has three sheets of paper in front of her. On the first, her curve of the pulses. On the second, the numbers from the station that the cell’s Registry sent, with the pauses between the number groups, which are also getting shorter. On the third, the running of the wall clock from the canteen at Nordlicht, which hangs in a display case two floors above the Institute’s canteen and runs backwards. Planck has long since calculated when it will arrive, and had taken the date for a coincidence.

### Zeile 1198, The Other Doors

**neu:** If a pointer is below 3, its door stays closed this night.
