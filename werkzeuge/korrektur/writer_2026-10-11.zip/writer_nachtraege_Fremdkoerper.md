# Nachträge zu den Vorschlagslisten: Fremdkoerper

Stand 11.10.2026, ODIN Writer. Hier stehen die Stellen, die das Vorschlagswerkzeug nicht abdeckt: Sätze, die im Band neu dazugekommen sind, und Sätze, die im Band weggefallen sind. Ermittelt aus dem Vergleich der Buchquellen vor und nach der Durchsicht (Listen in writer_2026-10-11), abzüglich aller Sätze, die in den Vorschlagslisten schon mit „ja“ stehen. Je Stelle der ganze Absatz alt und neu; „ergänzen“ und „streichen“ nennen die Sätze, die nach dem Übernehmen der Vorschläge noch fehlen oder übrig sind.

## Deutsch

### Zeile 47, Kampf gegen das Fremde

**alt:** - **Kälte legt Keimlinge still.** Ein stillgelegter Keimling ist wehrlos. Wie kalt es sein muss, entscheidet die Spielleitung nach dem Atlas.

**neu:** - **Kälte legt Keimlinge still.** Ein stillgelegter Keimling ist wehrlos. Kühle macht sie träge, Frost legt sie nach wenigen Runden still. Die Missionen nennen die Werte.

- ergänzen: Kühle macht sie träge, Frost legt sie nach wenigen Runden still.
- ergänzen: Die Missionen nennen die Werte.
- streichen oder ersetzen: Wie kalt es sein muss, entscheidet die Spielleitung nach dem Atlas.

### Zeile 53, Kampf

**alt:** - **Was hilft:** Kälte. Wer Türen und Fenster aufreißt und den Herd ausmacht, legt die Keimlinge nach zwei Runden still. Többen hat in der Milchkammer eine Kiste Viehsalz, und wer auf die Idee kommt, es in einem Eimer aufzulösen, hat die beste Waffe des Abends.

**neu:** - **Was hilft:** Kälte. Wer Türen und Fenster aufreißt und den Herd ausmacht, hat nach zwei Runden eine kalte Küche: Die Keimlinge werden träge, −2 Würfel auf alles, ab der vierten Runde liegen sie still. Többen hat in der Milchkammer eine Kiste Viehsalz, und wer auf die Idee kommt, es in einem Eimer aufzulösen, hat die beste Waffe des Abends.

- ergänzen: Wer Türen und Fenster aufreißt und den Herd ausmacht, hat nach zwei Runden eine kalte Küche: Die Keimlinge werden träge, −2 Würfel auf alles, ab der vierten Runde liegen sie still.
- streichen oder ersetzen: Wer Türen und Fenster aufreißt und den Herd ausmacht, legt die Keimlinge nach zwei Runden still.

### Zeile 99, Knoten

**alt:** - **Hinweis:** Bruns erzählt, die Schnucken hätten Anfang Februar drei Nächte lang draußen gestanden, still, alle mit dem Kopf nach oben. „Wie bei Gewitter. Nur ohne Gewitter.“ (Die Kugel, Spuren aus dem Atlas)

**neu:** - **Hinweis:** Bruns erzählt, die Schnucken hätten Anfang Februar drei Nächte lang draußen gestanden, still, alle mit dem Kopf nach oben. „Wie bei Gewitter. Nur ohne Gewitter.“ (Die Kugel, Spuren aus der Registratur)

- ergänzen: Nur ohne Gewitter." (Die Kugel, Spuren aus der Registratur)
- streichen oder ersetzen: Nur ohne Gewitter." (Die Kugel, Spuren aus dem Atlas)

### Zeile 110, Kampf

**alt:** - **Gegner:** **Keimlinge** (Anhang), 2W6, dazu jede Gruppe, die in Mission 1 entkommen ist, in der zweiten Häutung.

**neu:** - **Gegner:** **Keimlinge** (Anhang), 1W6 aus dem Stein im Stroh, dazu jede Gruppe, die in Mission 1 entkommen ist, in der zweiten Häutung.

- ergänzen: Gegner: Keimlinge (Anhang), 1W6 aus dem Stein im Stroh, dazu jede Gruppe, die in Mission 1 entkommen ist, in der zweiten Häutung.
- streichen oder ersetzen: Gegner: Keimlinge (Anhang), 2W6, dazu jede Gruppe, die in Mission 1 entkommen ist, in der zweiten Häutung.

### Zeile 144, Worum es geht

**alt:** Eine davon ist Femke de Graaf in Utrecht, 68, pensionierte Physiklehrerin. Ihr Stein liegt seit November in einer Vitrine über der Heizung, und seit zwei Wochen tickt er. Sie hat in einem Sammlerforum gefragt, warum. Ihre Katze Pim sitzt seit Tagen vor der Vitrine. Gestern waren zwei Männer da und haben 2.000 € für den Stein geboten. Sie hat abgelehnt, weil sie wissen will, was da tickt. Die Männer arbeiten für Grey Meridian, und sie kommen heute Nacht wieder.

**neu:** Eine davon ist Femke de Graaf in Utrecht, 68, pensionierte Physiklehrerin. Ihr Stein liegt seit November in einer Vitrine über der Heizung, und seit zwei Wochen tickt er. Sie hat in einem Sammlerforum gefragt, warum. Ihr Kater Pim sitzt seit Tagen vor der Vitrine. Gestern waren zwei Männer da und haben 2.000 € für den Stein geboten. Sie hat abgelehnt, weil sie wissen will, was da tickt. Die Männer arbeiten für Grey Meridian, und sie kommen heute Nacht wieder.

- ergänzen: Ihr Kater Pim sitzt seit Tagen vor der Vitrine.
- streichen oder ersetzen: Ihre Katze Pim sitzt seit Tagen vor der Vitrine.

### Zeile 43, Knoten

**alt:** - **Hinweis:** In den Eierkartons im Tank liegen 44 Steine, wenn die Zelle in Mission 1 zwanzig mitgenommen hat, sonst mehr. Sie sind warm wie Haut. Keiner tickt laut, aber wer das Ohr an den Tank legt, hört ein leises Prasseln, wie Regen. (In Tagen, nicht Wochen)

**neu:** - **Hinweis:** In den Eierkartons im Tank liegen 24 Steine, wenn die Zelle in Mission 1 zwanzig mitgenommen hat, sonst mehr. Sie sind warm wie Haut. Keiner tickt laut, aber wer das Ohr an den Tank legt, hört ein leises Prasseln, wie Regen. (In Tagen, nicht Wochen)

- ergänzen: Hinweis: In den Eierkartons im Tank liegen 24 Steine, wenn die Zelle in Mission 1 zwanzig mitgenommen hat, sonst mehr.
- streichen oder ersetzen: Hinweis: In den Eierkartons im Tank liegen 44 Steine, wenn die Zelle in Mission 1 zwanzig mitgenommen hat, sonst mehr.

### Zeile 47, Kampf

**alt:** Gegen ein Uhr nachts rollt der Lastwagen von Grey Meridian durchs Tor, ein Kranwagen mit britischen Fahrern und vier Männern in Arbeitsjacken, die keine Arbeiter sind. Fast gleichzeitig schlüpfen im Bürocontainer die Steine auf dem Fensterbrett.

**neu:** Gegen ein Uhr nachts rollt der Lastwagen von Grey Meridian durchs Tor, ein Kranwagen mit britischen Fahrern und vier Männern in Arbeitsjacken, die keine Arbeiter sind. Fast gleichzeitig schlüpfen im Bürocontainer drei der Steine auf dem Fensterbrett.

- ergänzen: Fast gleichzeitig schlüpfen im Bürocontainer drei der Steine auf dem Fensterbrett.
- streichen oder ersetzen: Fast gleichzeitig schlüpfen im Bürocontainer die Steine auf dem Fensterbrett.

### Zeile 59, Nachspiel

**alt:** Fährt der Lastwagen mit dem Tank vom Hof, hat van der Hoeven 44 oder mehr Steine mehr, und „Die Sammlung“ gewinnt zwei Totenköpfe. Behält die Zelle den Tank, verliert der Plan zwei.

**neu:** Fährt der Lastwagen mit dem Tank vom Hof, hat van der Hoeven 24 oder mehr Steine mehr, und „Die Sammlung“ gewinnt zwei Totenköpfe. Behält die Zelle den Tank, verliert der Plan zwei.

- ergänzen: Fährt der Lastwagen mit dem Tank vom Hof, hat van der Hoeven 24 oder mehr Steine mehr, und "Die Sammlung" gewinnt zwei Totenköpfe.
- streichen oder ersetzen: Fährt der Lastwagen mit dem Tank vom Hof, hat van der Hoeven 44 oder mehr Steine mehr, und "Die Sammlung" gewinnt zwei Totenköpfe.

### Zeile 78, Worum es geht

**alt:** Um Mitternacht fällt im Achterhoek der Strom aus, für zwei Stunden. Das hat der Netzbetreiber angekündigt, und wenn er es nicht tut, sorgt die Zelle selbst dafür. Mit dem Strom fallen die Wachsysteme aus, die Flutlichter, und die Kühlvitrinen in der Bibliothek. Die meisten Steine darin brauchen Tage, um aufzuwachen. Aber einige haben im Mai im warmen Container eines Kutters gelegen oder im Juli zwei Stunden bei 19 °C. Für sie reicht eine Stunde.

**neu:** Um Mitternacht fällt im Achterhoek der Strom aus, für zwei Stunden. Das hat der Netzbetreiber angekündigt, und wenn er es nicht tut, sorgt die Zelle selbst dafür. Mit dem Strom fallen die Wachsysteme aus, die Flutlichter, und die Kühlvitrinen in der Bibliothek. Die meisten Steine darin brauchen Tage, um aufzuwachen. Aber einige haben im Juni im warmen Container eines Kutters gelegen oder im Juli zwei Stunden bei 19 °C. Für sie reicht eine Stunde.

- ergänzen: Aber einige haben im Juni im warmen Container eines Kutters gelegen oder im Juli zwei Stunden bei 19 °C.
- streichen oder ersetzen: Aber einige haben im Mai im warmen Container eines Kutters gelegen oder im Juli zwei Stunden bei 19 °C.

### Zeile 108, Zweite Phase: ein Uhr, die Bibliothek

**alt:** - **Was hilft:** Sole aus Kanistern und Sprühflaschen. CO₂-Feuerlöscher aus dem Flur, wenn die Spielleitung die Kälte nach dem Atlas reichen lässt. Die Gräfte ist Süßwasser und tötet nichts, aber mit 17 °C ist sie kälter als die Nacht. Wer die Vitrinen mit den Steinen, die noch nicht geschlüpft sind, in die Kühlboxen räumt, hat die Liste der Steine gerettet.

**neu:** - **Was hilft:** Sole aus Kanistern und Sprühflaschen. CO₂-Feuerlöscher aus dem Flur, wenn die Spielleitung die Kälte reichen lässt. Die Gräfte ist Süßwasser und tötet nichts, aber mit 17 °C ist sie kälter als die Nacht. Wer die Vitrinen mit den Steinen, die noch nicht geschlüpft sind, in die Kühlboxen räumt, hat die Liste der Steine gerettet.

- ergänzen: CO₂-Feuerlöscher aus dem Flur, wenn die Spielleitung die Kälte reichen lässt.
- streichen oder ersetzen: CO₂-Feuerlöscher aus dem Flur, wenn die Spielleitung die Kälte nach dem Atlas reichen lässt.

### Zeile 33, Was aus ihnen wird

**alt:** - **Dana Whitlock** wird nach Boston versetzt. Was sie über diesen Sommer an Elaine Mercer schreibt, hängt davon ab, was sie am Krater gesehen hat.

**neu:** - **Dana Whitlock** geht zurück nach Boston. Was sie über diesen Sommer an Elaine Mercer schreibt, hängt davon ab, was sie am Krater gesehen hat.

- ergänzen: Dana Whitlock geht zurück nach Boston.
- streichen oder ersetzen: Dana Whitlock wird nach Boston versetzt.

### Zeile 4, Gegner

**alt:** Die Werte der Kreaturen stammen aus dem Bedrohungsatlas des Spielleiterbuchs und aus der Registratur. Sie stehen hier noch einmal, damit am Tisch nicht geblättert werden muss. Wo der Atlas und dieser Band sich unterscheiden würden, gilt der Atlas.

**neu:** Die Werte der Kreaturen stammen aus dem Bedrohungsatlas des Spielleiterbuchs und aus der Registratur. Sie stehen hier noch einmal, damit am Tisch nicht geblättert werden muss. Wo der Atlas und dieser Band sich unterscheiden würden, gilt der Atlas. Ausgenommen ist die Zahl der Keimlinge je Stein: Sie steht in der Registratur und gilt hier.

- ergänzen: Ausgenommen ist die Zahl der Keimlinge je Stein: Sie steht in der Registratur und gilt hier.

### Zeile 7, Keimling

**alt:** Eine Larve, die in Meteoriten und Eisbohrkernen die Zeit überdauert hat und in einem warmen Körper erwacht. Keimlinge fressen, wachsen und häuten sich. Wenn sie schlüpfen, sind sie so groß wie eine Hand: blass, glatt, mit einem Maul, das sich in vier Richtungen öffnet. In Fremdkörper kommen sie aus den Sternsteinen, 1W6 aus jedem Stein.

**neu:** Eine Larve, die in Meteoriten und Eisbohrkernen die Zeit überdauert hat und in einem warmen Körper erwacht. Keimlinge fressen, wachsen und häuten sich. Wenn sie schlüpfen, sind sie so groß wie eine Hand: blass, glatt, mit einem Maul, das sich in vier Richtungen öffnet. In Fremdkörper kommen sie aus den Sternsteinen, 1W6 aus jedem Stein. Der Atlas nennt Gruppen von 2W6. Das ist der übliche Fund aus zwei Steinen. Hier zählt der Stein, und jede Mission nennt die Summe.

- ergänzen: Der Atlas nennt Gruppen von 2W6.
- ergänzen: Das ist der übliche Fund aus zwei Steinen.
- ergänzen: Hier zählt der Stein, und jede Mission nennt die Summe.

### Zeile 13, Keimling

**alt:** **Besonderheit** | Tritt in Gruppen von 2W6 auf. Wächst mit jedem Wirt: Nach jeder Szene, in der er fressen konnte, +2 LP

**neu:** **Besonderheit** | Schlüpft zu 1W6 aus jedem Stein. Wächst mit jedem Wirt: Nach jeder Szene, in der er fressen konnte, +2 LP

- ergänzen: Besonderheit Schlüpft zu 1W6 aus jedem Stein.
- streichen oder ersetzen: Besonderheit Tritt in Gruppen von 2W6 auf.

## Englisch

### Zeile 48, Fighting the Alien

**alt:** - **Cold immobilises Germlings.** An immobilised Germling is defenceless. How cold it must be is decided by the Game Master according to the Atlas.

**neu:** - **Cold immobilises Germlings.** An immobilised Germling is defenceless. Coolness makes them sluggish, frost stops them within a few rounds. The missions give the numbers.

- ergänzen: Coolness makes them sluggish, frost stops them within a few rounds.
- ergänzen: The missions give the numbers.
- streichen oder ersetzen: How cold it must be is decided by the Game Master according to the Atlas.

### Zeile 53, Fight

**alt:** - **What helps:** Cold. Anyone who throws open doors and windows and turns off the stove stops the Germlings after two rounds. Többen has a crate of cattle salt in the milk room, and anyone who thinks of dissolving it in a bucket has the best weapon of the evening.

**neu:** - **What helps:** Cold. Anyone who throws open doors and windows and turns off the stove has a cold kitchen after two rounds: the Germlings become sluggish, −2 dice on everything, and from the fourth round they lie still. Többen has a crate of cattle salt in the milk room, and anyone who thinks of dissolving it in a bucket has the best weapon of the evening.

- ergänzen: Anyone who throws open doors and windows and turns off the stove has a cold kitchen after two rounds: the Germlings become sluggish, −2 dice on everything, and from the fourth round they lie still.
- streichen oder ersetzen: Anyone who throws open doors and windows and turns off the stove stops the Germlings after two rounds.

### Zeile 99, Nodes

**alt:** - **Clue:** Bruns tells that the sheep stood outside for three nights at the beginning of February, still, all with their heads up. “Like during a thunderstorm. Only without a thunderstorm.” (The Sphere, traces from the Atlas)

**neu:** - **Clue:** Bruns tells that the sheep stood outside for three nights at the beginning of February, still, all with their heads up. “Like during a thunderstorm. Only without a thunderstorm.” (The Sphere, traces from the Registry)

- ergänzen: Only without a thunderstorm." (The Sphere, traces from the Registry)
- streichen oder ersetzen: Only without a thunderstorm." (The Sphere, traces from the Atlas)

### Zeile 110, Fight

**alt:** - **Opponents:** **Germlings** (Appendix), 2D6, plus any group that escaped in Mission 1, in the second moult.

**neu:** - **Opponents:** **Germlings** (Appendix), 1D6 from the stone in the straw, plus any group that escaped in Mission 1, in the second moult.

- ergänzen: Opponents: Germlings (Appendix), 1D6 from the stone in the straw, plus any group that escaped in Mission 1, in the second moult.
- streichen oder ersetzen: Opponents: Germlings (Appendix), 2D6, plus any group that escaped in Mission 1, in the second moult.

### Zeile 129, Aftermath

**alt:** **Plans:** “The Collection” rolls according to the Core Rulebook. *Clue:* the map of Stichting Hemelsteen from Winterswijk.

**neu:** **Plans:** “The Collection” rolls according to the Core Rulebook. *Lead:* the map of Stichting Hemelsteen from Winterswijk.

- ergänzen: Lead: the map of Stichting Hemelsteen from Winterswijk.
- streichen oder ersetzen: Clue: the map of Stichting Hemelsteen from Winterswijk.

### Zeile 43, Nodes

**alt:** - **Clue:** In the egg cartons in the tank there are 44 stones, if the cell took twenty in Mission 1, otherwise more. They are warm like skin. None ticks loudly, but anyone who puts an ear to the tank hears a soft patter, like rain. (In days, not weeks)

**neu:** - **Clue:** In the egg cartons in the tank there are 24 stones, if the cell took twenty in Mission 1, otherwise more. They are warm like skin. None ticks loudly, but anyone who puts an ear to the tank hears a soft patter, like rain. (In days, not weeks)

- ergänzen: Clue: In the egg cartons in the tank there are 24 stones, if the cell took twenty in Mission 1, otherwise more.
- streichen oder ersetzen: Clue: In the egg cartons in the tank there are 44 stones, if the cell took twenty in Mission 1, otherwise more.

### Zeile 47, Fight

**alt:** Around one o’clock at night the lorry from Grey Meridian rolls through the gate, a crane lorry with British drivers and four men in work jackets who are not workers. Almost at the same time, the stones on the windowsill in the office container hatch.

**neu:** Around one o’clock at night the lorry from Grey Meridian rolls through the gate, a crane lorry with British drivers and four men in work jackets who are not workers. Almost at the same time, three of the stones on the windowsill in the office container hatch.

- ergänzen: Almost at the same time, three of the stones on the windowsill in the office container hatch.
- streichen oder ersetzen: Almost at the same time, the stones on the windowsill in the office container hatch.

### Zeile 59, Aftermath

**alt:** If the lorry with the tank leaves the yard, van der Hoeven has 44 or more additional stones, and “The Collection” gains two skulls. If the cell keeps the tank, the plan loses two.

**neu:** If the lorry with the tank leaves the yard, van der Hoeven has 24 or more additional stones, and “The Collection” gains two skulls. If the cell keeps the tank, the plan loses two.

- ergänzen: If the lorry with the tank leaves the yard, van der Hoeven has 24 or more additional stones, and "The Collection" gains two skulls.
- streichen oder ersetzen: If the lorry with the tank leaves the yard, van der Hoeven has 44 or more additional stones, and "The Collection" gains two skulls.

### Zeile 78, What It Is About

**alt:** At midnight the power fails in the Achterhoek for two hours. The network operator has announced this, and if he does not do it, the cell sees to it itself. With the power, the security systems fail, the floodlights, and the cooling display cases in the library. Most stones inside need days to wake up. But some lay in the warm container of a cutter in May or for two hours at 19 °C in July. For them one hour is enough.

**neu:** At midnight the power fails in the Achterhoek for two hours. The network operator has announced this, and if he does not do it, the cell sees to it itself. With the power, the security systems fail, the floodlights, and the cooling display cases in the library. Most stones inside need days to wake up. But some lay in the warm container of a cutter in June or for two hours at 19 °C in July. For them one hour is enough.

- ergänzen: But some lay in the warm container of a cutter in June or for two hours at 19 °C in July.
- streichen oder ersetzen: But some lay in the warm container of a cutter in May or for two hours at 19 °C in July.

### Zeile 108, Second Phase: One O’Clock, the Library

**alt:** - **What helps:** brine from canisters and spray bottles. CO₂ fire extinguishers from the corridor, if the Game Master allows the cold according to the Threat Atlas. The moat is fresh water and kills nothing, but at 17 °C it is colder than the night. Whoever puts the display cases with the stones that have not yet hatched into the cool boxes has saved the list of stones.

**neu:** - **What helps:** brine from canisters and spray bottles. CO₂ fire extinguishers from the corridor, if the Game Master allows the cold to be enough. The moat is fresh water and kills nothing, but at 17 °C it is colder than the night. Whoever puts the display cases with the stones that have not yet hatched into the cool boxes has saved the list of stones.

- ergänzen: CO₂ fire extinguishers from the corridor, if the Game Master allows the cold to be enough.
- streichen oder ersetzen: CO₂ fire extinguishers from the corridor, if the Game Master allows the cold according to the Threat Atlas.

### Zeile 33, What Becomes of Them

**alt:** - **Dana Whitlock** is transferred to Boston. What she writes to Elaine Mercer about this summer depends on what she saw at the crater.

**neu:** - **Dana Whitlock** goes back to Boston. What she writes to Elaine Mercer about this summer depends on what she saw at the crater.

- ergänzen: Dana Whitlock goes back to Boston.
- streichen oder ersetzen: Dana Whitlock is transferred to Boston.

### Zeile 4, Opponents

**alt:** The creatures' stats come from the Threat Atlas in the Game Master's Book and from the Registry. They are repeated here so that the table does not have to be flipped through. Where the Atlas and this volume would differ, the Atlas takes precedence.

**neu:** The creatures' stats come from the Threat Atlas in the Game Master's Book and from the Registry. They are repeated here so that the table does not have to be flipped through. Where the Atlas and this volume would differ, the Atlas takes precedence. Excepted is the number of Germlings per stone: it comes from the Registry and applies here.

- ergänzen: Excepted is the number of Germlings per stone: it comes from the Registry and applies here.

### Zeile 7, Germling

**alt:** A larva that has survived time in meteorites and ice cores and awakens in a warm body. Germlings eat, grow and moult. When they hatch, they are the size of a hand: pale, smooth, with a mouth that opens in four directions. In Foreign Bodies they come from the star stones, 1D6 from each stone.

**neu:** A larva that has survived time in meteorites and ice cores and awakens in a warm body. Germlings eat, grow and moult. When they hatch, they are the size of a hand: pale, smooth, with a mouth that opens in four directions. In Foreign Bodies they come from the star stones, 1D6 from each stone. The Atlas gives groups of 2D6. That is the usual find from two stones. Here the stone counts, and each mission gives the total.

- ergänzen: The Atlas gives groups of 2D6.
- ergänzen: That is the usual find from two stones.
- ergänzen: Here the stone counts, and each mission gives the total.

### Zeile 13, Germling

**alt:** **Special** | Appears in groups of 2D6. Grows with each host: After each scene in which it could feed, +2 HP

**neu:** **Special** | Hatches 1D6 from each stone. Grows with each host: After each scene in which it could feed, +2 HP

- ergänzen: Special Hatches 1D6 from each stone.
- streichen oder ersetzen: Special Appears in groups of 2D6.

### Zeile 116, The Plan: “The Collection”

**alt:** {skull:1} | He has the first nine star stones. He has noticed that they tick in warmth and has cooling display cases built. *Clue:* A Dutchman in a Range Rover offered Többen €5,000 for the tank. {skull:2} | The Stichting buys systematically. Grey Meridian collects stones from buyers, and in the forum “hemelsteen” replies to every post. *Clue:* A business card of the Stichting Hemelsteen in a sheep barn. {skull:3} | Van der Hoeven has more than thirty stones and wants everything connected with them. *Clue:* A boat with divers searches the same sandbank in the mudflats every day. {skull:4} | He has the Pilot or is close to it, and he has a vault converted under the moat. *Clue:* An invitation to the Night of the Shooting Stars, black paper with gold edging. {skull:5} | The collection is complete: all open stones, the Pilot, part of the wreck. Van der Hoeven shows it to his guests on the Night of the Shooting Stars. *Clue:* In a display case in Huis te Velde it ticks, and 120 guests stand in front of it.

**neu:** {skull:1} | He has the first nine star stones. He has noticed that they tick in warmth and has cooling display cases built. *Lead:* A Dutchman in a Range Rover offered Többen €5,000 for the tank. {skull:2} | The Stichting buys systematically. Grey Meridian collects stones from buyers, and in the forum “hemelsteen” replies to every post. *Lead:* A business card of the Stichting Hemelsteen in a sheep barn. {skull:3} | Van der Hoeven has more than thirty stones and wants everything connected with them. *Lead:* A boat with divers searches the same sandbank in the mudflats every day. {skull:4} | He has the Pilot or is close to it, and he has a vault converted under the moat. *Lead:* An invitation to the Night of the Shooting Stars, black paper with gold edging. {skull:5} | The collection is complete: all open stones, the Pilot, part of the wreck. Van der Hoeven shows it to his guests on the Night of the Shooting Stars. *Lead:* In a display case in Huis te Velde it ticks, and 120 guests stand in front of it.

- ergänzen: Lead: A Dutchman in a Range Rover offered Többen €5,000 for the tank. {skull:2} The Stichting buys systematically.
- ergänzen: Lead: A business card of the Stichting Hemelsteen in a sheep barn. {skull:3} Van der Hoeven has more than thirty stones and wants everything connected with them.
- ergänzen: Lead: A boat with divers searches the same sandbank in the mudflats every day. {skull:4} He has the Pilot or is close to it, and he has a vault converted under the moat.
- ergänzen: Lead: An invitation to the Night of the Shooting Stars, black paper with gold edging. {skull:5} The collection is complete: all open stones, the Pilot, part of the wreck.
- ergänzen: Lead: In a display case in Huis te Velde it ticks, and 120 guests stand in front of it.
- streichen oder ersetzen: Clue: A Dutchman in a Range Rover offered Többen €5,000 for the tank. {skull:2} The Stichting buys systematically.
- streichen oder ersetzen: Clue: A business card of the Stichting Hemelsteen in a sheep barn. {skull:3} Van der Hoeven has more than thirty stones and wants everything connected with them.
- streichen oder ersetzen: Clue: A boat with divers searches the same sandbank in the mudflats every day. {skull:4} He has the Pilot or is close to it, and he has a vault converted under the moat.
- streichen oder ersetzen: Clue: An invitation to the Night of the Shooting Stars, black paper with gold edging. {skull:5} The collection is complete: all open stones, the Pilot, part of the wreck.
- streichen oder ersetzen: Clue: In a display case in Huis te Velde it ticks, and 120 guests stand in front of it.

### Zeile 143, The Plan: “The Wreck”

**alt:** {skull:1} | STILLWATER sees the flash of light on a satellite image and sends Whitlock. *Clue:* Americans in the inn “Zum Moorkrug” who pass themselves off as accident investigators. {skull:2} | Grey Meridian closes off the forest and lays tarpaulins over the crater. *Clue:* Signs saying “Munitions clearance” from a company that does not exist. {skull:3} | The wreck is recovered and in Antwerp. STILLWATER is looking for the Pilot. *Clue:* Freight papers to Baltimore, recipient “National Atmospheric Data Center”. {skull:4} | The wreck is loaded. STILLWATER is preparing an operation against the Pilot. *Clue:* A helicopter that is on no flight plan over the Achterhoek. {skull:5} | STILLWATER has the wreck and the Pilot. Both are on the way to Maryland. *Clue:* A blank: Whitlock no longer answers.

**neu:** {skull:1} | STILLWATER sees the flash of light on a satellite image and sends Whitlock. *Lead:* Americans in the inn “Zum Moorkrug” who pass themselves off as accident investigators. {skull:2} | Grey Meridian closes off the forest and lays tarpaulins over the crater. *Lead:* Signs saying “Munitions clearance” from a company that does not exist. {skull:3} | The wreck is recovered and in Antwerp. STILLWATER is looking for the Pilot. *Lead:* Freight papers to Baltimore, recipient “National Atmospheric Data Center”. {skull:4} | The wreck is loaded. STILLWATER is preparing an operation against the Pilot. *Lead:* A helicopter that is on no flight plan over the Achterhoek. {skull:5} | STILLWATER has the wreck and the Pilot. Both are on the way to Maryland. *Lead:* A blank: Whitlock no longer answers.

- ergänzen: Lead: Americans in the inn "Zum Moorkrug" who pass themselves off as accident investigators. {skull:2} Grey Meridian closes off the forest and lays tarpaulins over the crater.
- ergänzen: Lead: Signs saying "Munitions clearance" from a company that does not exist. {skull:3} The wreck is recovered and in Antwerp.
- ergänzen: Lead: Freight papers to Baltimore, recipient "National Atmospheric Data Center". {skull:4} The wreck is loaded.
- ergänzen: Lead: A helicopter that is on no flight plan over the Achterhoek. {skull:5} STILLWATER has the wreck and the Pilot.
- ergänzen: Lead: A blank: Whitlock no longer answers.
- streichen oder ersetzen: Clue: Americans in the inn "Zum Moorkrug" who pass themselves off as accident investigators. {skull:2} Grey Meridian closes off the forest and lays tarpaulins over the crater.
- streichen oder ersetzen: Clue: Signs saying "Munitions clearance" from a company that does not exist. {skull:3} The wreck is recovered and in Antwerp.
- streichen oder ersetzen: Clue: Freight papers to Baltimore, recipient "National Atmospheric Data Center". {skull:4} The wreck is loaded.
- streichen oder ersetzen: Clue: A helicopter that is on no flight plan over the Achterhoek. {skull:5} STILLWATER has the wreck and the Pilot.
- streichen oder ersetzen: Clue: A blank: Whitlock no longer answers.
