# Spielleiterbuch Stausee DE: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 1 Stellen.

## 15_anhang.md (Sicherung vor_stausee_2026-10-11)

### Zeile 64, Nachspiel

**alt:** - **EP:** 5 pro Charakter, +1 für die Lösung mit der Wahrheit.

**neu:** - **EP:** Grundwert 4 (Graue Akte), +1, wenn die Familie lebend herauskommt, höchstens +1 Bonus (etwa für die Wahrheit), +1 für den Kristall (ein Faden).
