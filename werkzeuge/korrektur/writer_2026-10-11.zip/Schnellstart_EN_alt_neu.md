# Schnellstart EN: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 8 Stellen.

## 04_einsatz.md (Sicherung vor_spielersicht_2026-10-11)

### Zeile 47, Node 1: The Estate Agent

**alt:** An Agent or Negotiator finds out with a test on Insight against Doable (2) that he is concealing something: that there is a note in the land register. He is the red herring. Whoever takes him for the perpetrator loses time.

**neu:** Whoever reads him with a test on Insight against Doable (2), Echo or Raven for instance, notices that he is concealing something: that there is a note in the land register. He is the red herring. Whoever takes him for the perpetrator loses time.

### Zeile 56, Node 2: The First Guests

**alt:** - **Clue:** They have a mobile phone photo of the window. A Paranormal Detective or Investigator with Crime Scene Investigation sees in the glass a reflection that is not a piece of furniture. (Origin: the dead)

**neu:** - **Clue:** They have a mobile phone photo of the window. Whoever studies the photo closely, Perception against Doable (2), spots in the glass a reflection that is not a piece of furniture. Raven’s Ghost Sight gives 2 bonus dice here. (Origin: the dead)

### Zeile 65, Node 3: The Village by the Lake

**alt:** - **Clue:** At low water one hears a church bell from the lake. A Physicist with measuring instruments or a Thaumaturge with a crystal detector notices a reading on the shore. (lead to the voice, optional)

**neu:** - **Clue:** At low water one hears a church bell from the lake. A Thaumaturge on the shore hears a faint whisper from the water, as near any Nexus crystal. (lead to the voice, optional)

### Zeile 69, Node 4: The Archive

**alt:** The district archive or the church register of the flooded parish. An Antiquarian is in their element here.

**neu:** The district archive or the church register of the flooded parish. Whoever brings History or Academic Knowledge, like Folio, quickly finds what they are looking for.

### Zeile 87, The Night

**alt:** Anyone who stays in the house until evening experiences the Waiting One. The doors close, the windows show only water, and at the window sits an old woman in a cardigan, waiting. She is friendly to Paul and icy to everyone else.

**neu:** Anyone who stays in the house until evening experiences the Waiting One. The doors close, the windows show only water, and at the window sits an old woman in a cardigan, waiting. She is friendly to Paul and icy to everyone else. Anyone who sees her for the first time makes a horror test against Horrifying (3).

### Zeile 115, Aftermath

**alt:** - **XP:** 5 per character, +1 for the solution with the truth.

**neu:** - **XP:** Grey File, base value 4 XP. Plus 1 XP if the family leaves the house alive, at most 1 XP personal bonus, for example for the solution with the truth, and 1 XP if the cell finds the crystal in the lake bed (a thread).

## 09_weiter.md (Sicherung vor_spielersicht_2026-10-11)

### Zeile 7, What Happens Next

**alt:** The core rulebook comprises 88 pages and is free. It contains the complete dice system, character creation in nine steps, six classes with thirty subclasses, 63 skills, psi powers, spells, equipment and the rules for advancement. Anyone who wants to use the system fully will find everything necessary there. The file is available at odin-rpg.pages.dev.

**neu:** The core rulebook is free. It contains the complete dice system, character creation in nine steps, six classes with thirty subclasses, 63 skills, psi powers, spells, equipment and the rules for advancement. Anyone who wants to use the system fully will find everything necessary there. The file is available at odin-rpg.pages.dev.

### Zeile 11, What Happens Next

**alt:** Those who want to go deeper will find six class books, an arsenal with 201 items, a game master book and the campaign “The Door”. The campaign begins in the same villa by the reservoir where this mission takes place. The locations are already known. The events of this evening can serve as backstory or remain untouched. The campaign does not require knowledge of the Quickstart, but it can accommodate it.

**neu:** Those who want to go deeper will find six class books, the equipment book Arsenal, a game master book and the campaign “The Door”. Its first mission is exactly this one, with an addition in the aftermath. Groups that have played the Quickstart start with Mission 2. What the cell did with Martha Kellner and the crystal then counts for the campaign, and the Hold’s diver sends the brass capsule from the bell a week later.
