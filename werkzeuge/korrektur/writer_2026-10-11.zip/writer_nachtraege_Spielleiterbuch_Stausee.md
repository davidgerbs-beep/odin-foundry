# Nachträge zu den Vorschlagslisten: Spielleiterbuch Stausee

Stand 11.10.2026, ODIN Writer. Hier stehen die Stellen, die das Vorschlagswerkzeug nicht abdeckt: Sätze, die im Band neu dazugekommen sind, und Sätze, die im Band weggefallen sind. Ermittelt aus dem Vergleich der Buchquellen vor und nach der Durchsicht (Listen in writer_2026-10-11), abzüglich aller Sätze, die in den Vorschlagslisten schon mit „ja“ stehen. Je Stelle der ganze Absatz alt und neu; „ergänzen“ und „streichen“ nennen die Sätze, die nach dem Übernehmen der Vorschläge noch fehlen oder übrig sind.

## Deutsch

### Zeile 64, Nachspiel

**alt:** - **EP:** 5 pro Charakter, +1 für die Lösung mit der Wahrheit.

**neu:** - **EP:** Grundwert 4 (Graue Akte), +1, wenn die Familie lebend herauskommt, höchstens +1 Bonus (etwa für die Wahrheit), +1 für den Kristall (ein Faden).

- ergänzen: EP: Grundwert 4 (Graue Akte), +1, wenn die Familie lebend herauskommt, höchstens +1 Bonus (etwa für die Wahrheit), +1 für den Kristall (ein Faden).
- streichen oder ersetzen: EP: 5 pro Charakter, +1 für die Lösung mit der Wahrheit.

## Englisch

### Zeile 48, Node 2: The First Guests

**alt:** - **Clue:** They have a mobile phone photo of the window. A Paranormal Detective or Investigator with Crime Scene Investigation sees in the glass a reflection that is not a piece of furniture. (Origin: the dead)

**neu:** - **Clue:** They have a mobile phone photo of the window. A Paranormal Detective or Investigator with Crime Scene Examination sees in the glass a reflection that is not a piece of furniture. (Origin: the dead)

- ergänzen: A Paranormal Detective or Investigator with Crime Scene Examination sees in the glass a reflection that is not a piece of furniture.
- streichen oder ersetzen: A Paranormal Detective or Investigator with Crime Scene Investigation sees in the glass a reflection that is not a piece of furniture.

### Zeile 103, Aftermath

**alt:** - **XP:** 5 per character, +1 for the solution with the truth.

**neu:** - **XP:** Grey File, base value 4 XP. Plus 1 XP if the family leaves the house alive, at most 1 XP personal bonus, for example for the solution with the truth, and 1 XP if the cell finds the crystal in the lake bed (a thread).

- ergänzen: XP: Grey File, base value 4 XP.
- ergänzen: Plus 1 XP if the family leaves the house alive, at most 1 XP personal bonus, for example for the solution with the truth, and 1 XP if the cell finds the crystal in the lake bed (a thread).
- streichen oder ersetzen: XP: 5 per character, +1 for the solution with the truth.
