# Fremdkoerper DE: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 14 Stellen.

## 00_einf.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 47, Kampf gegen das Fremde

**alt:** - **Kälte legt Keimlinge still.** Ein stillgelegter Keimling ist wehrlos. Wie kalt es sein muss, entscheidet die Spielleitung nach dem Atlas.

**neu:** - **Kälte legt Keimlinge still.** Ein stillgelegter Keimling ist wehrlos. Kühle macht sie träge, Frost legt sie nach wenigen Runden still. Die Missionen nennen die Werte.

## 01_akt1.md (Sicherung vor_handoutcheck_2026-10-10)

### Zeile 53, Kampf

**alt:** - **Was hilft:** Kälte. Wer Türen und Fenster aufreißt und den Herd ausmacht, legt die Keimlinge nach zwei Runden still. Többen hat in der Milchkammer eine Kiste Viehsalz, und wer auf die Idee kommt, es in einem Eimer aufzulösen, hat die beste Waffe des Abends.

**neu:** - **Was hilft:** Kälte. Wer Türen und Fenster aufreißt und den Herd ausmacht, hat nach zwei Runden eine kalte Küche: Die Keimlinge werden träge, −2 Würfel auf alles, ab der vierten Runde liegen sie still. Többen hat in der Milchkammer eine Kiste Viehsalz, und wer auf die Idee kommt, es in einem Eimer aufzulösen, hat die beste Waffe des Abends.

### Zeile 99, Knoten

**alt:** - **Hinweis:** Bruns erzählt, die Schnucken hätten Anfang Februar drei Nächte lang draußen gestanden, still, alle mit dem Kopf nach oben. „Wie bei Gewitter. Nur ohne Gewitter.“ (Die Kugel, Spuren aus dem Atlas)

**neu:** - **Hinweis:** Bruns erzählt, die Schnucken hätten Anfang Februar drei Nächte lang draußen gestanden, still, alle mit dem Kopf nach oben. „Wie bei Gewitter. Nur ohne Gewitter.“ (Die Kugel, Spuren aus der Registratur)

### Zeile 110, Kampf

**alt:** - **Gegner:** **Keimlinge** (Anhang), 2W6, dazu jede Gruppe, die in Mission 1 entkommen ist, in der zweiten Häutung.

**neu:** - **Gegner:** **Keimlinge** (Anhang), 1W6 aus dem Stein im Stroh, dazu jede Gruppe, die in Mission 1 entkommen ist, in der zweiten Häutung.

### Zeile 144, Worum es geht

**alt:** Eine davon ist Femke de Graaf in Utrecht, 68, pensionierte Physiklehrerin. Ihr Stein liegt seit November in einer Vitrine über der Heizung, und seit zwei Wochen tickt er. Sie hat in einem Sammlerforum gefragt, warum. Ihre Katze Pim sitzt seit Tagen vor der Vitrine. Gestern waren zwei Männer da und haben 2.000 € für den Stein geboten. Sie hat abgelehnt, weil sie wissen will, was da tickt. Die Männer arbeiten für Grey Meridian, und sie kommen heute Nacht wieder.

**neu:** Eine davon ist Femke de Graaf in Utrecht, 68, pensionierte Physiklehrerin. Ihr Stein liegt seit November in einer Vitrine über der Heizung, und seit zwei Wochen tickt er. Sie hat in einem Sammlerforum gefragt, warum. Ihr Kater Pim sitzt seit Tagen vor der Vitrine. Gestern waren zwei Männer da und haben 2.000 € für den Stein geboten. Sie hat abgelehnt, weil sie wissen will, was da tickt. Die Männer arbeiten für Grey Meridian, und sie kommen heute Nacht wieder.

## 02_akt2.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 43, Knoten

**alt:** - **Hinweis:** In den Eierkartons im Tank liegen 44 Steine, wenn die Zelle in Mission 1 zwanzig mitgenommen hat, sonst mehr. Sie sind warm wie Haut. Keiner tickt laut, aber wer das Ohr an den Tank legt, hört ein leises Prasseln, wie Regen. (In Tagen, nicht Wochen)

**neu:** - **Hinweis:** In den Eierkartons im Tank liegen 24 Steine, wenn die Zelle in Mission 1 zwanzig mitgenommen hat, sonst mehr. Sie sind warm wie Haut. Keiner tickt laut, aber wer das Ohr an den Tank legt, hört ein leises Prasseln, wie Regen. (In Tagen, nicht Wochen)

### Zeile 47, Kampf

**alt:** Gegen ein Uhr nachts rollt der Lastwagen von Grey Meridian durchs Tor, ein Kranwagen mit britischen Fahrern und vier Männern in Arbeitsjacken, die keine Arbeiter sind. Fast gleichzeitig schlüpfen im Bürocontainer die Steine auf dem Fensterbrett.

**neu:** Gegen ein Uhr nachts rollt der Lastwagen von Grey Meridian durchs Tor, ein Kranwagen mit britischen Fahrern und vier Männern in Arbeitsjacken, die keine Arbeiter sind. Fast gleichzeitig schlüpfen im Bürocontainer drei der Steine auf dem Fensterbrett.

### Zeile 59, Nachspiel

**alt:** Fährt der Lastwagen mit dem Tank vom Hof, hat van der Hoeven 44 oder mehr Steine mehr, und „Die Sammlung“ gewinnt zwei Totenköpfe. Behält die Zelle den Tank, verliert der Plan zwei.

**neu:** Fährt der Lastwagen mit dem Tank vom Hof, hat van der Hoeven 24 oder mehr Steine mehr, und „Die Sammlung“ gewinnt zwei Totenköpfe. Behält die Zelle den Tank, verliert der Plan zwei.

## 04_akt4.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 78, Worum es geht

**alt:** Um Mitternacht fällt im Achterhoek der Strom aus, für zwei Stunden. Das hat der Netzbetreiber angekündigt, und wenn er es nicht tut, sorgt die Zelle selbst dafür. Mit dem Strom fallen die Wachsysteme aus, die Flutlichter, und die Kühlvitrinen in der Bibliothek. Die meisten Steine darin brauchen Tage, um aufzuwachen. Aber einige haben im Mai im warmen Container eines Kutters gelegen oder im Juli zwei Stunden bei 19 °C. Für sie reicht eine Stunde.

**neu:** Um Mitternacht fällt im Achterhoek der Strom aus, für zwei Stunden. Das hat der Netzbetreiber angekündigt, und wenn er es nicht tut, sorgt die Zelle selbst dafür. Mit dem Strom fallen die Wachsysteme aus, die Flutlichter, und die Kühlvitrinen in der Bibliothek. Die meisten Steine darin brauchen Tage, um aufzuwachen. Aber einige haben im Juni im warmen Container eines Kutters gelegen oder im Juli zwei Stunden bei 19 °C. Für sie reicht eine Stunde.

### Zeile 108, Zweite Phase: ein Uhr, die Bibliothek

**alt:** - **Was hilft:** Sole aus Kanistern und Sprühflaschen. CO₂-Feuerlöscher aus dem Flur, wenn die Spielleitung die Kälte nach dem Atlas reichen lässt. Die Gräfte ist Süßwasser und tötet nichts, aber mit 17 °C ist sie kälter als die Nacht. Wer die Vitrinen mit den Steinen, die noch nicht geschlüpft sind, in die Kühlboxen räumt, hat die Liste der Steine gerettet.

**neu:** - **Was hilft:** Sole aus Kanistern und Sprühflaschen. CO₂-Feuerlöscher aus dem Flur, wenn die Spielleitung die Kälte reichen lässt. Die Gräfte ist Süßwasser und tötet nichts, aber mit 17 °C ist sie kälter als die Nacht. Wer die Vitrinen mit den Steinen, die noch nicht geschlüpft sind, in die Kühlboxen räumt, hat die Liste der Steine gerettet.

## 05_nach.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 33, Was aus ihnen wird

**alt:** - **Dana Whitlock** wird nach Boston versetzt. Was sie über diesen Sommer an Elaine Mercer schreibt, hängt davon ab, was sie am Krater gesehen hat.

**neu:** - **Dana Whitlock** geht zurück nach Boston. Was sie über diesen Sommer an Elaine Mercer schreibt, hängt davon ab, was sie am Krater gesehen hat.

## 06_anhang.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 4, Gegner

**alt:** Die Werte der Kreaturen stammen aus dem Bedrohungsatlas des Spielleiterbuchs und aus der Registratur. Sie stehen hier noch einmal, damit am Tisch nicht geblättert werden muss. Wo der Atlas und dieser Band sich unterscheiden würden, gilt der Atlas.

**neu:** Die Werte der Kreaturen stammen aus dem Bedrohungsatlas des Spielleiterbuchs und aus der Registratur. Sie stehen hier noch einmal, damit am Tisch nicht geblättert werden muss. Wo der Atlas und dieser Band sich unterscheiden würden, gilt der Atlas. Ausgenommen ist die Zahl der Keimlinge je Stein: Sie steht in der Registratur und gilt hier.

### Zeile 7, Keimling

**alt:** Eine Larve, die in Meteoriten und Eisbohrkernen die Zeit überdauert hat und in einem warmen Körper erwacht. Keimlinge fressen, wachsen und häuten sich. Wenn sie schlüpfen, sind sie so groß wie eine Hand: blass, glatt, mit einem Maul, das sich in vier Richtungen öffnet. In Fremdkörper kommen sie aus den Sternsteinen, 1W6 aus jedem Stein.

**neu:** Eine Larve, die in Meteoriten und Eisbohrkernen die Zeit überdauert hat und in einem warmen Körper erwacht. Keimlinge fressen, wachsen und häuten sich. Wenn sie schlüpfen, sind sie so groß wie eine Hand: blass, glatt, mit einem Maul, das sich in vier Richtungen öffnet. In Fremdkörper kommen sie aus den Sternsteinen, 1W6 aus jedem Stein. Der Atlas nennt Gruppen von 2W6. Das ist der übliche Fund aus zwei Steinen. Hier zählt der Stein, und jede Mission nennt die Summe.

### Zeile 13, Keimling

**alt:** **Besonderheit** | Tritt in Gruppen von 2W6 auf. Wächst mit jedem Wirt: Nach jeder Szene, in der er fressen konnte, +2 LP

**neu:** **Besonderheit** | Schlüpft zu 1W6 aus jedem Stein. Wächst mit jedem Wirt: Nach jeder Szene, in der er fressen konnte, +2 LP
