# Die Tuer DE: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 4 Stellen.

## 01_kampagne.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 73, Die Zelle

**alt:** **Erfahrung und Rang.** Nach jeder Mission gibt es EP nach der Tabelle in „Kampagnen führen": 3 für eine Weiße Akte, 5 für eine Graue, 6 für eine Rote, 8 für eine Schwarze, 3 für eine Mission ohne Akte, und +1 für jeden Faden, den die Zelle aufnimmt, dazu höchstens 1 EP persönlicher Bonus. So wird sie im Lauf von Akt I zu Agenten befördert, in Akt II zu Senior-Agenten und vielleicht vor der letzten Nacht zu Veteranen. Beförderungen sind Szenen: Behr übergibt sie, und manchmal eine Wahrheit dazu.

**neu:** **Erfahrung und Rang.** Nach jeder Mission gibt es EP wie im Grundregelwerk und in „Kampagnen führen": den Grundwert der Aktenfarbe (Weiß 2, Grau 4, Rot 5, Schwarz 7, ohne Akte 2), +1 für das erreichte Ziel, höchstens +1 persönlichen Bonus und +1 für jeden Faden, den die Zelle aufnimmt. So wird sie im Lauf von Akt I zu Agenten befördert, in Akt II zu Senior-Agenten und vielleicht vor der letzten Nacht zu Veteranen. Beförderungen sind Szenen: Behr übergibt sie, und manchmal eine Wahrheit dazu.

### Zeile 160, Konfrontation

**alt:** Wie die Zelle die Szene löst, ist die erste große Wahl der Kampagne. Lio beruhigen und dem Beobachter übergeben. Lio dem Offenen überlassen. Lio verstecken und niemandem übergeben. Lio beruhigen kann ein Telepath oder Psychic Healer mit WK + Telepathie gegen Schwer (3), mit einem Helm, einer Kappe oder einem Stück Legierung S eine Stufe leichter.

**neu:** Wie die Zelle die Szene löst, ist die erste große Wahl der Kampagne. Lio beruhigen und dem Beobachter übergeben. Lio dem Offenen überlassen. Lio verstecken und niemandem übergeben. Lio beruhigen kann ein Telepath oder Psychic Healer mit WK + Telepathie gegen Schwer (3), mit einem Helm, einer Kappe oder einem Stück Legierung S eine Stufe leichter. Fehlt ein Psion, beruhigt ihn auch, wer mit ihm redet: CH + Überzeugen gegen Sehr schwer (4).

### Zeile 212, Die drei Kurven

**alt:** Am Morgen nach der Nacht sitzt Planck mit der Zelle in der Kantine und hat drei Blätter vor sich. Auf dem ersten ihre Kurve der Pulse. Auf dem zweiten die Zahlen der Station, die die Registratur der Zelle geschickt hat, mit dem Abstand der Sendungen, der ebenfalls kürzer wird. Auf dem dritten der Gang der Wanduhr aus der Kantine von Nordlicht, die zwei Stockwerke über der Kantine des Instituts in einer Vitrine hängt und rückwärts läuft. Planck hat längst ausgerechnet, wann sie ankommt, und das Datum für einen Zufall gehalten.

**neu:** Am Morgen nach der Nacht sitzt Planck mit der Zelle in der Kantine und hat drei Blätter vor sich. Auf dem ersten ihre Kurve der Pulse. Auf dem zweiten die Zahlen der Station, die die Registratur der Zelle geschickt hat, mit den Pausen zwischen den Zahlengruppen, die ebenfalls kürzer werden. Auf dem dritten der Gang der Wanduhr aus der Kantine von Nordlicht, die zwei Stockwerke über der Kantine des Instituts in einer Vitrine hängt und rückwärts läuft. Planck hat längst ausgerechnet, wann sie ankommt, und das Datum für einen Zufall gehalten.

### Zeile 652, Die anderen Türen

**neu:** Steht ein Zeiger unter 3, bleibt seine Tür in dieser Nacht geschlossen.
