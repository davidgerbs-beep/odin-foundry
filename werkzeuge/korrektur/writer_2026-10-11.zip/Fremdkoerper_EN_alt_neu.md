# Fremdkoerper EN: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 16 Stellen.

## 00_einf.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 48, Fighting the Alien

**alt:** - **Cold immobilises Germlings.** An immobilised Germling is defenceless. How cold it must be is decided by the Game Master according to the Atlas.

**neu:** - **Cold immobilises Germlings.** An immobilised Germling is defenceless. Coolness makes them sluggish, frost stops them within a few rounds. The missions give the numbers.

## 01_akt1.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 53, Fight

**alt:** - **What helps:** Cold. Anyone who throws open doors and windows and turns off the stove stops the Germlings after two rounds. Többen has a crate of cattle salt in the milk room, and anyone who thinks of dissolving it in a bucket has the best weapon of the evening.

**neu:** - **What helps:** Cold. Anyone who throws open doors and windows and turns off the stove has a cold kitchen after two rounds: the Germlings become sluggish, −2 dice on everything, and from the fourth round they lie still. Többen has a crate of cattle salt in the milk room, and anyone who thinks of dissolving it in a bucket has the best weapon of the evening.

### Zeile 99, Nodes

**alt:** - **Clue:** Bruns tells that the sheep stood outside for three nights at the beginning of February, still, all with their heads up. “Like during a thunderstorm. Only without a thunderstorm.” (The Sphere, traces from the Atlas)

**neu:** - **Clue:** Bruns tells that the sheep stood outside for three nights at the beginning of February, still, all with their heads up. “Like during a thunderstorm. Only without a thunderstorm.” (The Sphere, traces from the Registry)

### Zeile 110, Fight

**alt:** - **Opponents:** **Germlings** (Appendix), 2D6, plus any group that escaped in Mission 1, in the second moult.

**neu:** - **Opponents:** **Germlings** (Appendix), 1D6 from the stone in the straw, plus any group that escaped in Mission 1, in the second moult.

### Zeile 129, Aftermath

**alt:** **Plans:** “The Collection” rolls according to the Core Rulebook. *Clue:* the map of Stichting Hemelsteen from Winterswijk.

**neu:** **Plans:** “The Collection” rolls according to the Core Rulebook. *Lead:* the map of Stichting Hemelsteen from Winterswijk.

## 02_akt2.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 43, Nodes

**alt:** - **Clue:** In the egg cartons in the tank there are 44 stones, if the cell took twenty in Mission 1, otherwise more. They are warm like skin. None ticks loudly, but anyone who puts an ear to the tank hears a soft patter, like rain. (In days, not weeks)

**neu:** - **Clue:** In the egg cartons in the tank there are 24 stones, if the cell took twenty in Mission 1, otherwise more. They are warm like skin. None ticks loudly, but anyone who puts an ear to the tank hears a soft patter, like rain. (In days, not weeks)

### Zeile 47, Fight

**alt:** Around one o’clock at night the lorry from Grey Meridian rolls through the gate, a crane lorry with British drivers and four men in work jackets who are not workers. Almost at the same time, the stones on the windowsill in the office container hatch.

**neu:** Around one o’clock at night the lorry from Grey Meridian rolls through the gate, a crane lorry with British drivers and four men in work jackets who are not workers. Almost at the same time, three of the stones on the windowsill in the office container hatch.

### Zeile 59, Aftermath

**alt:** If the lorry with the tank leaves the yard, van der Hoeven has 44 or more additional stones, and “The Collection” gains two skulls. If the cell keeps the tank, the plan loses two.

**neu:** If the lorry with the tank leaves the yard, van der Hoeven has 24 or more additional stones, and “The Collection” gains two skulls. If the cell keeps the tank, the plan loses two.

## 04_akt4.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 78, What It Is About

**alt:** At midnight the power fails in the Achterhoek for two hours. The network operator has announced this, and if he does not do it, the cell sees to it itself. With the power, the security systems fail, the floodlights, and the cooling display cases in the library. Most stones inside need days to wake up. But some lay in the warm container of a cutter in May or for two hours at 19 °C in July. For them one hour is enough.

**neu:** At midnight the power fails in the Achterhoek for two hours. The network operator has announced this, and if he does not do it, the cell sees to it itself. With the power, the security systems fail, the floodlights, and the cooling display cases in the library. Most stones inside need days to wake up. But some lay in the warm container of a cutter in June or for two hours at 19 °C in July. For them one hour is enough.

### Zeile 108, Second Phase: One O’Clock, the Library

**alt:** - **What helps:** brine from canisters and spray bottles. CO₂ fire extinguishers from the corridor, if the Game Master allows the cold according to the Threat Atlas. The moat is fresh water and kills nothing, but at 17 °C it is colder than the night. Whoever puts the display cases with the stones that have not yet hatched into the cool boxes has saved the list of stones.

**neu:** - **What helps:** brine from canisters and spray bottles. CO₂ fire extinguishers from the corridor, if the Game Master allows the cold to be enough. The moat is fresh water and kills nothing, but at 17 °C it is colder than the night. Whoever puts the display cases with the stones that have not yet hatched into the cool boxes has saved the list of stones.

## 05_nach.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 33, What Becomes of Them

**alt:** - **Dana Whitlock** is transferred to Boston. What she writes to Elaine Mercer about this summer depends on what she saw at the crater.

**neu:** - **Dana Whitlock** goes back to Boston. What she writes to Elaine Mercer about this summer depends on what she saw at the crater.

## 06_anhang.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 4, Opponents

**alt:** The creatures' stats come from the Threat Atlas in the Game Master's Book and from the Registry. They are repeated here so that the table does not have to be flipped through. Where the Atlas and this volume would differ, the Atlas takes precedence.

**neu:** The creatures' stats come from the Threat Atlas in the Game Master's Book and from the Registry. They are repeated here so that the table does not have to be flipped through. Where the Atlas and this volume would differ, the Atlas takes precedence. Excepted is the number of Germlings per stone: it comes from the Registry and applies here.

### Zeile 7, Germling

**alt:** A larva that has survived time in meteorites and ice cores and awakens in a warm body. Germlings eat, grow and moult. When they hatch, they are the size of a hand: pale, smooth, with a mouth that opens in four directions. In Foreign Bodies they come from the star stones, 1D6 from each stone.

**neu:** A larva that has survived time in meteorites and ice cores and awakens in a warm body. Germlings eat, grow and moult. When they hatch, they are the size of a hand: pale, smooth, with a mouth that opens in four directions. In Foreign Bodies they come from the star stones, 1D6 from each stone. The Atlas gives groups of 2D6. That is the usual find from two stones. Here the stone counts, and each mission gives the total.

### Zeile 13, Germling

**alt:** **Special** | Appears in groups of 2D6. Grows with each host: After each scene in which it could feed, +2 HP

**neu:** **Special** | Hatches 1D6 from each stone. Grows with each host: After each scene in which it could feed, +2 HP

### Zeile 116, The Plan: “The Collection”

**alt:** {skull:1} | He has the first nine star stones. He has noticed that they tick in warmth and has cooling display cases built. *Clue:* A Dutchman in a Range Rover offered Többen €5,000 for the tank.

**alt:** {skull:2} | The Stichting buys systematically. Grey Meridian collects stones from buyers, and in the forum “hemelsteen” replies to every post. *Clue:* A business card of the Stichting Hemelsteen in a sheep barn.

**alt:** {skull:3} | Van der Hoeven has more than thirty stones and wants everything connected with them. *Clue:* A boat with divers searches the same sandbank in the mudflats every day.

**alt:** {skull:4} | He has the Pilot or is close to it, and he has a vault converted under the moat. *Clue:* An invitation to the Night of the Shooting Stars, black paper with gold edging.

**alt:** {skull:5} | The collection is complete: all open stones, the Pilot, part of the wreck. Van der Hoeven shows it to his guests on the Night of the Shooting Stars. *Clue:* In a display case in Huis te Velde it ticks, and 120 guests stand in front of it.

**neu:** {skull:1} | He has the first nine star stones. He has noticed that they tick in warmth and has cooling display cases built. *Lead:* A Dutchman in a Range Rover offered Többen €5,000 for the tank.

**neu:** {skull:2} | The Stichting buys systematically. Grey Meridian collects stones from buyers, and in the forum “hemelsteen” replies to every post. *Lead:* A business card of the Stichting Hemelsteen in a sheep barn.

**neu:** {skull:3} | Van der Hoeven has more than thirty stones and wants everything connected with them. *Lead:* A boat with divers searches the same sandbank in the mudflats every day.

**neu:** {skull:4} | He has the Pilot or is close to it, and he has a vault converted under the moat. *Lead:* An invitation to the Night of the Shooting Stars, black paper with gold edging.

**neu:** {skull:5} | The collection is complete: all open stones, the Pilot, part of the wreck. Van der Hoeven shows it to his guests on the Night of the Shooting Stars. *Lead:* In a display case in Huis te Velde it ticks, and 120 guests stand in front of it.

### Zeile 143, The Plan: “The Wreck”

**alt:** {skull:1} | STILLWATER sees the flash of light on a satellite image and sends Whitlock. *Clue:* Americans in the inn “Zum Moorkrug” who pass themselves off as accident investigators.

**alt:** {skull:2} | Grey Meridian closes off the forest and lays tarpaulins over the crater. *Clue:* Signs saying “Munitions clearance” from a company that does not exist.

**alt:** {skull:3} | The wreck is recovered and in Antwerp. STILLWATER is looking for the Pilot. *Clue:* Freight papers to Baltimore, recipient “National Atmospheric Data Center”.

**alt:** {skull:4} | The wreck is loaded. STILLWATER is preparing an operation against the Pilot. *Clue:* A helicopter that is on no flight plan over the Achterhoek.

**alt:** {skull:5} | STILLWATER has the wreck and the Pilot. Both are on the way to Maryland. *Clue:* A blank: Whitlock no longer answers.

**neu:** {skull:1} | STILLWATER sees the flash of light on a satellite image and sends Whitlock. *Lead:* Americans in the inn “Zum Moorkrug” who pass themselves off as accident investigators.

**neu:** {skull:2} | Grey Meridian closes off the forest and lays tarpaulins over the crater. *Lead:* Signs saying “Munitions clearance” from a company that does not exist.

**neu:** {skull:3} | The wreck is recovered and in Antwerp. STILLWATER is looking for the Pilot. *Lead:* Freight papers to Baltimore, recipient “National Atmospheric Data Center”.

**neu:** {skull:4} | The wreck is loaded. STILLWATER is preparing an operation against the Pilot. *Lead:* A helicopter that is on no flight plan over the Achterhoek.

**neu:** {skull:5} | STILLWATER has the wreck and the Pilot. Both are on the way to Maryland. *Lead:* A blank: Whitlock no longer answers.
