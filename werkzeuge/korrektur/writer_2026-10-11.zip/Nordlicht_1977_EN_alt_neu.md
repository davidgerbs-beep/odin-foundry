# Nordlicht 1977 EN: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 161 Stellen.

## Stellen mit Gegnerwerten

- 04_gruendung.md:437 (The Crowd)
- 04_gruendung.md:718 (Liaison Officer of a Partner Service)
- 06_kaskade.md:777 (Hunters of Department 13)
- 07_nordlicht.md:523 (Kjell Haugen)

## 00_einf.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 7, What It Is About

**alt:** The guiding sentence of this book is: What is written in the Game Master’s Book timeline happens. How it happened is decided by the table. That is the central rule. The fixed points of the chronicle are non-negotiable. The path there is open. The players know this. They do not play against the timeline, but within it.

**neu:** The guiding sentence of this book is: What is written in the Game Master’s Book chronicle happens. How it happened is decided by the table. That is the central rule. The fixed points of the chronicle are non-negotiable. The path there is open. The players know this. They do not play against the chronicle, but within it.

### Zeile 21, The Thirty Years at a Glance

**alt:** 1947 | First use of the acronym O.D.I.N., treaty on crystal sovereignty, Waybill, Hold-1 London, silent cavity near Kiruna (November) | 1: Waybill; 2: Silence (Part A)

**neu:** 1947 | First use of the acronym O.D.I.N., treaty on crystal sovereignty, Waybill, Hold-1 London, silent cavity near Kiruna (new: November) | 1: Waybill; 2: Silence (Part A)

### Zeile 58, What This Book Requires

**alt:** To play, the game master needs the core rulebook and the Game Master’s Book. The core rulebook provides the skills, tests, and damage rules. The Game Master’s Book provides the timeline, the organisation, and the open secrets. Without these two books, this book lacks its foundation.

**neu:** To play, the game master needs the core rulebook and the Game Master’s Book. The core rulebook provides the skills, tests, and damage rules. The Game Master’s Book provides the chronicle, the organisation, and the open secrets. Without these two books, this book lacks its foundation.

## 01_spielweise.md (Sicherung vor_handoutcheck_2026-10-10)

### Zeile 5, Fixed Points and Open Points

**alt:** This volume is set from March 1947 to 14 February 1977, 22:10. In this time, everything that is in the timeline of the Game Master’s Book happens. That is the guiding sentence of this volume. It stands over every session, every mission, every interlude-years scene.

**neu:** This volume is set from March 1947 to 14 February 1977, 22:10. In this time, everything that is in the chronicle of the Game Master’s Book happens. That is the guiding sentence of this volume. It stands over every session, every mission, every interlude-years scene.

### Zeile 17, Fixed Points and Open Points

**alt:** The price. The table can change the how of a fixed point if it is willing to pay for it. An agent who saves a man in Kiruna who should have fallen saves him. But someone else goes in his place. Or the agent carries a strain from then on. Or a protégé is sent on a mission too early. The price is never a rules penalty. The price is a story.

**neu:** The price. The table can change the how of a fixed point if it is willing to pay for it. An agent who saves a man in Kiruna who should have fallen saves him. But someone else goes in his place. Or the agent carries a strain from then on. Or a protégé is sent on a mission too early. The price is never a rules penalty. The price is a story. Where a mission names “trust” as the price, it means the relationship with that figure, not the group’s Trust value.

### Zeile 49, The Waybill Group

**alt:** The group’s connections are the figures of the era. Evelyn Marsh gives the missions of the Operations Branch. She recruits by stories, not by files. Ashgrove gives the missions of the escort and later of the Tactical Branch. He does not like the nickname Hammer, but he endures it. Hallström gives the missions of the Registry from 1948, and of the Investigation Branch from 1961. In 1947 he is himself the target of Mission 1. He asks questions no one wants to answer. Marek gives the missions of the psions, only until 1970. She insists on the Cap and does not say why. The Seal Keepers give the missions of the Collegium. They speak rarely, and when they speak, they speak in circles.

**neu:** The group’s connections are the figures of the era. Evelyn Marsh gives the missions of the Operations Branch. She recruits by stories, not by files. Ashgrove gives the missions of the escort and later of the Tactical Branch. He does not like the nickname Hammer, which the corridor gossip gives his branch from 1954, but he endures it. Hallström gives the missions of the Registry from 1948, and of the Investigation Branch from 1961. In 1947 he is himself the target of Mission 1. He asks questions no one wants to answer. Marek gives the missions of the psions, only until 1970. She insists on the Cap and does not say why. The Seal Keepers give the missions of the Collegium. They speak rarely, and when they speak, they speak in circles.

### Zeile 63, Time Jumps and Interlude Years

**alt:** 1950 | Sundqvist arrives; Wendland puts up the apothecary’s protocol | Sundqvist asks about the circles of Kiruna

**neu:** 1950 | Sundqvist arrives; Wendland puts up the apothecary’s protocol | Sundqvist asks about the circles of Solberg

### Zeile 73, Time Jumps and Interlude Years

**alt:** 1968 | Liège; Adeyemi; Dorje dies; the watchmaker’s special train; the Enlightened | the Print Shop has a hundred signet rings made (GF “Second Light”)

**neu:** 1968 | Liège; Adeyemi; Dorje dies; the watchmaker’s special train; the Enlightened | the Print Shop has a hundred signet rings made (GF, File 8 “The Second Light”)

### Zeile 98, The Succession System

**alt:** III Cascade | 1969 | 110 | +20 | around 150 | Senior Agent to Veteran

**neu:** III Cascade | 1969 | 110 | +20 | around 150 | Veteran

### Zeile 107, The Succession System

**alt:** Handover. The protégé takes over when the agent dies, passes over, burns out, must enter a silence, switches to the Open Ones, disappears into a legend or steps down. Their XP is the accumulated protégé XP, but at least the minimum XP of the current Section. In addition they receive a legacy. The legacy is plus 1 to a skill of the mentor if that skill is 4 or higher. Or an object: a piece of ashsilver with the mentor’s name on its inside. A notebook. A cap or a helmet. A crystal only with the Collegium’s consent. Or a contact. Or, after death or retirement, the codename as a series, such as Salz-2, following the model of the Folio series. The handover is a scene. It is played, not ticked off.

**neu:** Handover. The protégé takes over when the agent dies, passes over, burns out, must enter a silence, switches to the Open Ones, disappears into a legend or steps down. Their XP is the accumulated protégé XP, but at least the minimum XP of the current Section. In addition they receive a legacy. The legacy is plus 1 to a skill of the mentor if that skill is 4 or higher. Or an object: a piece of ashsilver with the mentor’s name on its inside. A notebook. A cap or a helmet. A crystal only with the Collegium’s consent. Or a contact. Or, after death or retirement, the codename as a series, such as Salz-2, following the model of the Folio series; in the Investigation Branch only Folio is inherited. The handover is a scene. It is played, not ticked off.

### Zeile 119, The Succession System

**alt:** Thaumaturge | Collegium apprentice (crystal only according to the Crystal Ledger) | from 1956 Chronomancer as Solheim’s student | all schools

**neu:** Thaumaturge | Collegium apprentice (crystal only according to the Crystal Ledger) | from 1956 Chronomancer, from about 1960 as Solheim’s student | all schools

### Zeile 125, The Succession System

**neu:** For new agents and protégés, the booklet “Nordlicht 1977: Handouts” has three blank forms, one for each era: the index card of 1948 (Handout N55), the Council personnel form of 1961 (N56) and the computer printout of 1977 (N57).

### Zeile 143, The Duty Log

**alt:** The Duty Log is not a rulebook. It is a document. In the final session the game master reads from it aloud. Then each player decides where their character stands, on Saturday, 12 February 1977, according to the placeholder rule from Chapter “The Night”.

**neu:** The Duty Log is not a rulebook. It is a document. In the final session the game master reads from it aloud. Then each player decides where their character stands, on Saturday, 12 February 1977, according to the swap-slot rule from Chapter “The Night”.

### Zeile 166, Structure of a Mission

**alt:** The canon points that the table does not change. For Eleven: The escort goes into the tunnel with 14 men. Three survive. Eleven soldiers do not come back. The Collegium sends two Thaumaturges. One draws the warding circle, answers and remains on the other side; the other never speaks of Kiruna again. The mask is found. On 12 March Hallström introduces the White File. Ashgrove survives and does not write down the names.

**neu:** The canon points that the table does not change. For Eleven: The escort goes into the tunnel with 14 men. Three survive. Eleven soldiers do not come back. The Collegium sends two Thaumaturges. One draws a circle that is not a warding circle, answers the thing in the wall and remains on the other side; the other never speaks of Kiruna again. The mask is found. On 12 March Hallström introduces the White File. Ashgrove survives and does not write down the names.

### Zeile 177, Rules at the Table

**alt:** Tests are always stated as skill against difficulty, with a number in brackets. The names come from the core rulebook. The difficulties are levels from Easy (1) to Impossible (5). Perception against Doable (2). Athletics against Hard (3). Occultism against Very Hard (4). No new rules.

**neu:** Tests are always stated as skill against difficulty, with a number in brackets. The names come from the core rulebook. The difficulties are levels from Easy (1) to Impossible (5). Perception against Doable (2). Athletics against Hard (3). Occultism against Very Hard (4). No new test rules.

## 02_epoche.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 25, Ranks and Forms of Address

**alt:** For the players this means: In the first Section they are war returnees, scientists, Psions, Thaumaturges. They have names, not numbers. In the second Section they receive titles. In the third Section they are Senior Agents and Veterans. In the fourth Section individual Shadow Officers.

**neu:** For the players this means: In the first Section they are war returnees, scientists, Psions, Thaumaturges. They have names, not numbers. In the second Section they receive titles. In the third Section they are Veterans. In the fourth Section individual Shadow Officers.

### Zeile 116, Incendiary Ammunition from 1953

**alt:** Before the first batch in autumn 1953, the Kiruna Rule applies. After that, the quartermaster issues one magazine per mission. Incendiary ammunition works against the Voice, not against the Dead or the Alien. Against the Dead it helps as little as ordinary ammunition. Against the Alien, the only thing that helps is what the game master decides for the individual alien.

**neu:** Before the first batch in autumn 1953, the Kiruna Rule applies. After that, the quartermaster issues one magazine per mission. Incendiary ammunition works against the Voice, not against the Dead or the Alien. Against the Dead it helps as little as ordinary ammunition. Against the Alien, ordinary weapons work in full; incendiary ammunition helps no better.

### Zeile 119, Incendiary Ammunition from 1953

**alt:** Before the first batch of incendiary ammunition in autumn 1953, ordinary weapons cause no damage against beings from rifts. Only warding circles, spells and retreat offer protection. Salt may hold them off. No one knows whether it might have helped after all. Those who were there in Kiruna say nothing. Those who survived count the names.

**neu:** Before the first batch of incendiary ammunition in autumn 1953, ordinary weapons cause no damage against beings from rifts. Only warding circles, spells and retreat offer protection. Salt may hold them off. No one knows whether it might have helped after all. Those who were there in Kiruna say nothing. Those who survived count the names. From autumn 1953, the Threat Atlas values apply to ordinary weapons.

### Zeile 132, Subclasses by Year

**alt:** Agent | Infiltrator, Negotiator, Assassin, Spy, Saboteur | No new subclasses in this volume

**neu:** Agent | Infiltrator, Negotiator, Assassin, Spy; Saboteur from 1957 (Graz workshop) | No new subclasses in this volume

### Zeile 145, Subclasses by Year

**alt:** Skills: +1 Firearms, +1 Endurance, +1 Tactics.

**neu:** Skills: +2 Firearms, +1 Endurance, +1 Tactics.

### Zeile 163, Exchange List for Starting Equipment

**neu:** Assault rifle, combat suit with helmet, high-explosive grenades | Carbine or submachine gun, steel helmet, hand grenades of the era | Assault rifles only in 1977

**neu:** Light armour, stealth armour | As protective vest | Depending on year

**neu:** Bio-scanner, portable scanner | Microscope, magnifying glass, forensic kit | No scanner in the field

**neu:** Document scanner | Minox or 35 mm camera | Photographs on film

**neu:** Reinforced communication device | Field telephone or shortwave radio | Depending on location

**neu:** Prediction device, data crystal | Omitted | Does not exist before 1977

### Zeile 191, Exchange List for Starting Equipment

**alt:** Mental focus device | Cap or helmet | Depending on year

**neu:** Mental focus device, Neuro-Helm | None before 1949, every Psi test is then one level harder; from 1949 Cap, from 1963 Mk. I, from 1972 Mk. II | The Cap does not protect against psionic attacks

### Zeile 206, Money and Expenses

**alt:** Pay and expenses follow the rules of the core rulebook, adapted to the era. Before 1961 there is no rank ladder; pay is based on Section: in the first Section the pay of an Agent, €4,500 per month, in the second until 1961 that of a Senior Agent, €6,000. From 1961 pay by rank applies as in the core rulebook. No handler approves expenses; Marsh, Ashgrove, Hallström or the Council does. Expenses for a White File are €500, for a Grey File €2,000, for a Red File €10,000. For a Black File the rule is: as much as necessary. Every receipt ends up with the Audit.

**neu:** Pay and expenses follow the rules of the core rulebook, adapted to the era. Before 1961 there is no rank ladder; pay is based on Section: in the first Section the pay of an Agent, €4,500 per month, in the second until 1961 that of a Senior Agent, €6,000. From 1961 pay by rank applies as in the core rulebook. Clearances and requisitions follow the accumulated XP as in the core rulebook even before 1961; only titles and forms of address are missing. No handler approves expenses; Marsh, Ashgrove, Hallström or the Council does. Expenses for a White File are €500, for a Grey File €2,000, for a Red File €10,000. For a Black File the rule is: as much as necessary. Every receipt ends up with the Audit.

## 03_figuren.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 51, Viktor Hallström

**alt:** Hallström is a man of files. He wears grey suits, a magnifying glass in his breast pocket, a salt tin in his coat pocket. His hands are steady. His voice is quiet and precise. He asks questions to which he already knows the answer. He listens without interrupting. He writes in black oilcloth notebooks, sixty-one of them by 1979. He refuses to touch a computer. His steel cabinet has two locks and two compartments. In the second lie Notebook Zero, the page from 1871, the Black File Nordlicht with the comparison of the two times, Sander’s letter from 1957.

**neu:** Hallström is a man of files. He wears grey suits, a magnifying glass in his breast pocket, a salt tin in his coat pocket. His hands are steady. His voice is quiet and precise. He asks questions to which he already knows the answer. He listens without interrupting. He writes in black oilcloth notebooks, sixty-one of them, from 1938 to 1985. He refuses to touch a computer. His steel cabinet has two locks and two compartments. In the second lie Notebook Zero, the page from 1871, the Black File Nordlicht with the comparison of the two times, Sander’s letter from 1957.

### Zeile 83, Thomas Ashgrove

**alt:** Ashgrove is a man of command. He wears uniform, even when there is none. His voice is calm, deep, unhurried. He rarely speaks about feelings, never about fear. He calls the men by name, not by rank. He eats with them, sleeps beside them, carries the wounded himself. He does not like the nickname “Hammer”. He says: “A hammer breaks. I do not want to break.” In 1955 he receives Knife No. 1 made of ashsilver. He wears it until 1988. He says it is warm. He says that will pass. It has not passed.

**neu:** Ashgrove is a man of command. He wears uniform, even when there is none. His voice is calm, deep, unhurried. He rarely speaks about feelings, never about fear. He calls the men by name, not by rank. He eats with them, sleeps beside them, carries the wounded himself. He does not like the nickname the corridor gossip gives his branch from 1954: “Hammer”. He says: “A hammer knows only one problem.” In 1955 he receives Knife No. 1 made of ashsilver. He wears it until 1988. He says it is warm. He says that will pass. It has not passed.

### Zeile 117, Evelyn Marsh

**alt:** Marsh gives the group cover. She shows how to disappear, how to lie, how to survive. She takes naivety from the players by showing what cover costs. She takes security from them by showing that no one knows the whole truth. She appears in missions 1, 3, 7, 8, 9 and 11. Mostly as a voice, as a letter, as a woman standing at the edge and watching.

**neu:** Marsh gives the group cover. She shows how to disappear, how to lie, how to survive. She takes naivety from the players by showing what cover costs. She takes security from them by showing that no one knows the whole truth. She appears in missions 1, 3, 7, 8, 9, 10 and 11. Mostly as a voice, as a letter, as a woman standing at the edge and watching.

### Zeile 217, Astrid Solheim

**alt:** In 1947 Astrid is thirteen. She lives in Bergen, learns the watchmaking trade. In 1954 she finds the crystal. In 1956 she joins the Collegium. Penhallow establishes the rule: every Chronomancer only under the supervision of a second. Astrid mostly follows it. In the sixties she becomes a teacher. She trains a handful of students, all Chronomancers. She designs the time-measuring installation for Nordlicht. She works for the station but is not stationed there. She is not on the duty roster. In 1977, on 14 February, she sits with Ingrid on the delayed train to Narvik. At 22:10 Ingrid’s pocket watch runs through a whole night in under a minute. Astrid arrives a good three hours too late.

**neu:** In 1947 Astrid is thirteen. She lives in Bergen, learns the watchmaking trade. In 1954 she finds the crystal. In 1956 she joins the Collegium. Penhallow establishes the rule: every Chronomancer only under the supervision of a second. Astrid mostly follows it. In the sixties she becomes a teacher. She trains a handful of students, all Chronomancers. She designs the time-measuring installation for Nordlicht. She works for the station but is not stationed there. She is not on the duty roster. In 1977, on 14 February, she sits with Ingrid on the delayed train to Narvik. At 22:10 the pocket watch in Ingrid’s hand runs through a whole night in under a minute. Astrid arrives a good three hours too late.

### Zeile 239, Further Figures

**alt:** [table Name | Role | Missions @ 30 40 30]

**neu:** [table Name | Role | Fits mission @ 30 40 30]

### Zeile 249, Further Figures

**alt:** Martin Hofer | Engineer, builds prototype 0417 | 9, 10, 11, 12

**neu:** Dr. Martin Hofer | Physicist of the Institute, builds detector 0417 | 9, 10, 11, 12

### Zeile 272, Further Figures

**alt:** These figures are not fixed entities like the portraits. They can appear in missions, give information, accompany the group or hinder it. Their fates are canon. The game master uses them as supporting characters, as witnesses, as voices at the edge. They fill the world without carrying it.

**neu:** These figures are not fixed entities like the portraits. They can appear in missions, give information, accompany the group or hinder it. Their fates are canon. The game master uses them as supporting characters, as witnesses, as voices at the edge. They fill the world without carrying it. The column names missions a figure fits; the mission texts do not always mention them.

## 04_gruendung.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 51, What Really Happened

**alt:** - **The waybill with the abbreviation O.D.I.N. exists and returns to London receipted.** The game master ensures this by having the letter go to London by courier after the receipt, whether the group is watching or not. If the group loses the letter, a copy appears that someone made in Stockholm. The price: Marsh loses trust, the group receives less advance pay for the next mission.

**neu:** - **The waybill with the abbreviation O.D.I.N. exists and returns to London receipted.** The game master ensures this by having the letter go to London by courier after the receipt, whether the group is watching or not. If the group loses the letter, a copy appears that someone made in Stockholm. The price: Marsh trusts the group less, and it receives less advance pay for the next mission.

### Zeile 60, What Really Happened

**alt:** - **How the crate travels.** By lorry, ship or train. If the group decides to take the land route via Denmark and Sweden, with the ferry from Harwich to Esbjerg, the mission is extended and the Collector has more chances. If they decide on the sea route, play the crossing over the North Sea and Skagerrak. Duty Log entry: transport route, incidents.

**neu:** - **How the crate travels.** By lorry, ship or train. If the group decides to take the land route via Denmark and Sweden, with the ferry from Harwich to Esbjerg, the mission is extended and the Collector has more chances. On the land route, Node 4 takes place on the ferry to Esbjerg, the Swedish customs in Helsingborg issue the customs transit document (N4), and the confrontation takes place at night in the ferry port of Helsingborg. If they decide on the sea route, play the crossing over the North Sea and Skagerrak. Duty Log entry: transport route, incidents.

### Zeile 81, Viktor Hallström, 46

**alt:** Detective inspector from Stockholm, with File Zero since 1938. Wants to know who is behind O.D.I.N. Knows that the house without a number exists, conceals that he has kept a private file for eight years. Speaks Swedish-accented English, asks questions he answers himself.

**neu:** Detective inspector from Stockholm, with File Zero since 1938. Wants to know who is behind O.D.I.N. Knows that the house without a number exists, conceals that he has kept a private file for nine years. Speaks Swedish-accented English, asks questions he answers himself.

### Zeile 179, Escalation

**alt:** If the Collector gets the crate, he does not open it. He wants to take it to Zurich, to a villa with display cases. He does not get that far, because the fixed point holds: On Tuesday, the young man in the grey coat stands at the Centralstation, at the train to the south, and takes the crate, without the group seeing how (detour from the box WHAT IS FIXED). The group finds the waybill receipted at their poste restante the next morning. The price: Marsh loses trust, and the Collector now knows what he will bid for in later years.

**neu:** If the Collector gets the crate, he does not open it. He wants to take it to Zurich, to a villa with display cases. He does not get that far, because the fixed point holds: On Tuesday, the young man in the grey coat stands at the station where the Collector boards the train to the south, and takes the crate, without the group seeing how (detour from the box WHAT IS FIXED). The group finds the waybill receipted at their poste restante the next morning. The price: Marsh loses trust, and the Collector now knows what he will bid for in later years.

### Zeile 196, Solutions

**alt:** - **Without a fight:** An Agent with Negotiation or Deception against Hard (3) convinces the Collector that the crate is worthless, a trap, an empty lead. They compare their dice with the Collector’s Persuasion and Deception (5 + 4). If the test succeeds, the Collector laughs quietly, straightens his coat and leaves. He says: “We’ll meet again.” The mercenaries follow him into the fog. The group loses an hour because they have to take another route to the lorry.

**neu:** - **Without a fight:** An Agent makes an opposed test with Negotiation or Deception against the Collector’s Persuasion and Deception (5 + 4) and convinces him that the crate is worthless, a trap, an empty lead. If the test succeeds, the Collector laughs quietly, straightens his coat and leaves. He says: “We’ll meet again.” The mercenaries follow him into the fog. The group loses an hour because they have to take another route to the lorry.

### Zeile 202, Collector’s Mercenary

**alt:** [entry - | Collector’s Mercenary | Professional · Humans]

**neu:** [entry - | Collector’s Mercenary | Henchman · Humans]

### Zeile 339, Node 1: The Mine and the Cavity

**alt:** November 1947, polar night. A cage descends into the depths, the mine manager leads the group through wet workings to level 5, location 12 (Map K3). Among his papers is the report to the mining authority (Handout N5). Miners with carbide lamps wait in front of the cavity, a mine dog lies before it. Behind it, a round cave with dull grey walls, on a stone a stopped pocket watch.

**neu:** November 1947, shortly before the polar night. A cage descends into the depths, the mine manager leads the group through wet workings to level 5, location 12 (Map K3). Among his papers is the report to the mining authority (Handout N5). Miners with carbide lamps wait in front of the cavity, a mine dog lies before it. Behind it, a round cave with dull grey walls, on a stone a stopped pocket watch.

### Zeile 342, Node 1: The Mine and the Cavity

**alt:** - **Clue:** The miners say that the radio in the cavity only hisses and that the mine dog is not the first dog to lie down there. Agent: Insight against Doable (2). (leads to: The cavity is an anomaly)

**neu:** - **Clue:** The miners say that the radio in the cavity does not even hiss and that the mine dog is not the first dog to lie down there. Agent: Insight against Doable (2). (leads to: The cavity is an anomaly)

### Zeile 397, Escalation

**alt:** If someone enters the cavity, the game master calls for a horror test against Eerie (1). Whoever botches the test suffers strain and wants to leave the room at once. Whoever stays longer than one minute rolls Concentration against Very Hard (4). If the test fails, the character lies down and barely breathes any more. The others pull them out with a rope without going in themselves. Outside, after a few seconds, they breathe deeply again, and the watch on their wrist keeps running as if nothing had happened.

**neu:** If someone enters the cavity, the game master calls for a horror test against Eerie (1). Whoever fails the test suffers strain and wants to leave the room at once. Whoever stays longer than one minute rolls Concentration against Very Hard (4). If the test fails, the character lies down and barely breathes any more. The others pull them out with a rope without going in themselves. Outside, after a few seconds, they breathe deeply again, and the watch on their wrist keeps running as if nothing had happened.

### Zeile 413, Sequence

**alt:** 3. The crowd turns at the same moment. The game master calls for a horror test against Disturbing (2) for everyone who sees it. Whoever botches the test suffers strain and wants only to get away.

**neu:** 3. The crowd turns at the same moment. The game master calls for a horror test against Disturbing (2) for everyone who sees it. Whoever fails the test suffers strain and wants only to get away.

### Zeile 437, The Crowd

**alt:** **Horror** | Eerie (1), when they all turn round at the same time

**neu:** **Horror** | Disturbing (2), when they all turn round at the same time

### Zeile 460, Aftermath

**alt:** **Until the next mission:** In 1950 Greta Sundqvist comes to the Registry and asks about the circles of Kiruna; Marek writes to Wendland: “We won’t build them cages …” In 1951 Lerche kills three men of a foreign service in Gothenburg; from the summer every Psion gets an Observer. In 1952 Lerche wears the first Blocking Helmet. The Legend Office and the dog report only follow in Mission 3 and after. Each of these scenes is a short interlude, not a mission of its own.

**neu:** **Until the next mission:** In 1950 Greta Sundqvist comes to the Registry and asks about the circles of Solberg; Marek writes to Wendland: “We won’t build them cages …” In 1951 Lerche kills three men of a foreign service in Gothenburg; from the summer every Psion gets an Observer. In 1952 Lerche wears the first Blocking Helmet. The Legend Office and the dog report only follow in Mission 3 and after. Each of these scenes is a short interlude, not a mission of its own.

### Zeile 613, Node 3: The Courtyard in Leipzig

**alt:** - **Clue:** The cobbler wears a leather pouch around his neck that is warm to the touch. A Scientist recognises with Physics against Hard (3) that the shard inside is lighter than it should be. (leads to: the Collegium’s lost crystal)

**neu:** - **Clue:** The cobbler wears a leather pouch around his neck that is warm to the touch. A Scientist recognises with Physics against Hard (3) that the shard inside is lighter than it should be. (leads to: the Collegium’s lost crystal; The shard holds the Name-Eater)

### Zeile 636, Node 5: The Young State Security

**alt:** - **Clue:** In his card index lies a photo of the group, taken by the observation post. (leads to: the observation post) An Agent finds this with Perception against Hard (3).

**neu:** - **Clue:** In his card index lies a photo of the group, taken by the observation post. (leads to: The young State Security watches the courtyard) An Agent finds this with Perception against Hard (3).

### Zeile 646, Node 6: West Berlin, Emergency Reception Centre

**alt:** - **Clue:** The uncle from Salzgitter carries a form for new papers. The field for the name is still empty. (leads to: the name is discarded) An Agent finds this with Perception against Hard (3) or with Sleight of Hand against Hard (3), an Investigator with Perception against Doable (2).

**alt:** - **Clue:** The woman at the counter says: “The family has been sent to Lower Saxony. Where exactly is not in my card index.” (leads to: the trail ends) An Agent finds this with Persuasion against Doable (2).

**neu:** - **Clue:** The uncle from Salzgitter carries a form for new papers. The field for the name is still empty. (leads to: The girl’s trail ends in West Berlin) An Agent finds this with Perception against Hard (3) or with Sleight of Hand against Hard (3), an Investigator with Perception against Doable (2).

**neu:** - **Clue:** The woman at the counter says: “The family has been sent to Lower Saxony. Where exactly is not in my card index.” (leads to: The girl’s trail ends in West Berlin) An Agent finds this with Persuasion against Doable (2).

### Zeile 655, Node 6: West Berlin, Emergency Reception Centre

**neu:** - **The shard holds the Name-Eater in the courtyard; locked in lead, it loses its hold.** Clues: The cobbler wears a warm shard in a leather pouch (Node 3). The cobbler’s children closest to the pouch lost their names first (Node 3). Marsh gives the group the little lead box “for anything that whispers” (Briefing).

### Zeile 667, Escalation

**alt:** **Stage 3: Summons.** The liaison officer of the young State Security summons the group to his office in central Leipzig, door without a sign, two floors, one room with a card index. He asks about the purpose of the journey, the interest in the courtyard, the family. Whoever gets tangled in contradictions stays 48 hours in a cell in police headquarters. Afterwards the group is expelled. The camera and the films are confiscated. The photograph still exists: an agent took the first film out of the Leica after the first visit and hid it in the lining of their coat; the People’s Police find only the second (detour).

**neu:** **Stage 3: Summons.** The liaison officer of the young State Security summons the group to his office in central Leipzig, door without a sign, two floors, one room with a card index. He asks about the purpose of the journey, the interest in the courtyard, the family. Whoever gets tangled in contradictions stays 48 hours in a cell in police headquarters. Afterwards the group is released on condition that it leaves the GDR within a week; it is expelled only after the confrontation in the courtyard. The camera and the films are confiscated. The photograph still exists: an agent took the first film out of the Leica after the first visit and hid it in the lining of their coat; the People’s Police find only the second (detour).

### Zeile 700, Name Eater

**alt:** A creature of the Voice that followed Elster’s tone to Leipzig and has settled in the back courtyard because the shard of the Collegium draws it like an open window. It first eats the names of the cobbler’s children. It addresses people with their own voices. It has no face that can be kept.

**neu:** A creature of the Voice that followed Elster’s tone in Leipzig and has settled in the back courtyard because the shard of the Collegium draws it like an open window. It first eats the names of the cobbler’s children. It addresses people with their own voices. It has no face that can be kept.

### Zeile 718, Liaison Officer of a Partner Service

**alt:** **Initiative** | 4

**neu:** **Initiative** | 3

### Zeile 766, Aftermath

**alt:** - N11: Legend sheet “Renate Albers” with passport form, found: in the cupboard of the Nursery, Node 1.

**neu:** - N11: Legend sheet “Renate Albers” with passport form. It is the life the Nursery writes for the girl from Leipzig, not a legend for the group. Found: in the cupboard of the Nursery, Node 1, only once the group is back in Zurich after the first visit.

### Zeile 852, Briefing

**alt:** **What the group gets:** A train pass to Kiruna, a map of the mine that does not show the tunnel (Map K3), expenses in Swedish kronor.

**neu:** **What the group gets:** A train pass to Kiruna, a map of the mine that does not show the tunnel (of Map K3 the game master shows only the cage, main gallery and cavity), expenses in Swedish kronor.

### Zeile 987, Hybrid Dogs of Kiruna

**alt:** **Special** | Pack of 4 to 6, as a squad according to the core rulebook rules. Regenerate 1 HP per round. Smell blood over a kilometre

**neu:** **Special** | Pack of 3 to 6, as a squad according to the core rulebook rules. Regenerate 1 HP per round. Smell blood over a kilometre

### Zeile 1016, Crystal Guardian of Kiruna

**alt:** **Weakness** | Ordinary weapons cause no damage (Kiruna rule). The tuning fork from Wales makes them freeze for one round

**neu:** **Weakness** | Ordinary weapons cause no damage (Kiruna rule). The tuning fork from Wales makes them freeze for one round; in 1953 it lies in the Chamber and comes along only if a Thaumaturge requests it from the Collegium (price: every Psion within 100 m suffers 2 strain)

### Zeile 1029, Aftermath

**alt:** **Experience:** Red File: 5 XP, +1 for the objective achieved, at most +1 personal bonus, plus 1 for each thread taken up. Duration: two to three sessions.

**neu:** **Experience:** Red File: 5 XP, +1 for the objective achieved, at most +1 personal bonus, plus 1 for each thread taken up. Threads taken up are: the mask, Ashgrove’s compass, the name Solheim (Narvik). Duration: two to three sessions.

### Zeile 1033, Aftermath

**alt:** **Handover:** Every player agent who is over there is out of the game. Their protégé takes over with the protégé XP collected, but at least with the minimum XP of the current Section, and with a legacy according to the rules of the campaign plan.

**neu:** **Handover:** Every player agent who is over there is out of the game. Their protégé takes over with the protégé XP collected, but at least with the minimum XP of the current Section, and with a legacy according to the rules of the successor system (Chapter 2).

### Zeile 1071, 1950: Sundqvist and the Record

**alt:** Sundqvist asks about the circles of Kiruna. She wants to know whether the arrangement of the plates on the Cap matches the circles on the wall of Solberg.

**neu:** Sundqvist asks about the circles of Solberg. She wants to know whether the arrangement of the plates on the Cap matches the circles on the wall of Solberg.

## 05_silber.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 145, Node 7: The Old Quarry, at Night

**alt:** 3. Ashsilver touches the dead, but only with a name on the inside. (Clues: N18 marginal note “Name holds”, the piece becomes calm with a carved name, Ashgrove notices the restlessness without a name)

**neu:** 3. Ashsilver touches the dead, but only with a name on the inside. (Clues: N18 marginal note “Name holds”, the piece becomes calm with a carved name, Node 4: the piece becomes restless without a name and calm with a carved name, Node 7: the piece with a name stays evenly warm at the quarry)

### Zeile 151, Escalation

**alt:** If the group is too slow, nothing spectacular happens. The Waiting One waits. But the callers grow louder. Every night the group spends in the valley increases the pressure: all agents who hear the call make a horror test against **Eerie (1)**. Anyone who answers suffers 1 strain and hears their own name in their sleep for a week.

**neu:** If the group is too slow, nothing spectacular happens. The Waiting One waits. But the callers grow louder. Every night the group spends in the valley increases the pressure: whoever hears the callers for the first time makes a horror test against **Eerie (1)**. Every further night requires everyone who hears the call to roll WIL + Mental Resistance against Doable (2), otherwise 1 strain. Anyone who answers suffers 1 strain and hears their own name in their sleep for a week.

### Zeile 170, Sequence in Numbered Steps

**alt:** 6. The piece of silver stays warm and calm. From now on it bears the name of the dead.

**neu:** 6. The piece of silver stays warm and calm. It bears a name only if the group carves it in themselves.

### Zeile 228, Aftermath

**alt:** If Vaughan is at the table: her grandmother kept watch in Cwm Llwyd in 1909. Vaughan knows the stories of the dead and of the Waiting One from tales. The game master gives her this thread as a personal strain, not as a handout.

**neu:** If Vaughan is at the table: her grandmother kept watch in Cwm Llwyd in 1909. Vaughan knows the stories of the dead and of the Waiting One from tales. The game master gives her this story as personal background, not as strain points and not as a handout.

### Zeile 233, Aftermath

**alt:** - No map.

**neu:** - Map K2 (The Chamber in Wales) belongs to Mission 8; there is no map for the valley.

### Zeile 295, Walter Gysin, 42

**alt:** Staff member of the Institute, chemist. Carries the measuring case, keeps the logs, measures everything three times. Wants the measurement to be flawless. Knows that the case is not built for long measurements. Conceals that he wanted to correct the ozone value of 3 September after the fact because it seemed too high to him, and then did not. Speaks in short sentences, with a Swiss accent. Says “log” and “deviation”.

**neu:** Staff member of the Institute, electrical engineer from Zurich; he built the measuring case. Carries the measuring case, keeps the logs, measures everything three times. Wants the measurement to be flawless. Knows that the case is not built for long measurements. Conceals that he wanted to correct the ozone value of 3 September after the fact because it seemed too high to him, and then did not. Speaks in short sentences, with a Swiss accent. Says “log” and “deviation”.

### Zeile 337, Node 2: The Beach and the Bay

**neu:** - **Clue:** On the beach Pennington labels a tag by hand: K-1957-003 (Handout N21). (leads to Node 5)

### Zeile 366, Node 6: Uppsala, December 1957

**alt:** A cellar room beneath a house in Uppsala that belongs to the Lodge. Hallström leads the Investigator there at night. What is there: a man in a white coat, round glasses, a visitors’ book.

**neu:** A cellar room in the Uppsala Regional Archive, where the Solberg church register lies. Hallström leads the Investigator there at night. What is there: a man in a white coat, round glasses, the archive’s visitors’ book.

### Zeile 438, The Spectator

**alt:** For other non-player characters, use the values from the Threat Atlas or the core rulebook. Wendland, Pennington, Gysin, Astrid and the villagers are not combat opponents. Should it come to physical altercations with constables, the game master uses the values for ordinary police officers from the core rulebook.

**neu:** For other non-player characters, use the values from the Threat Atlas or the core rulebook. Wendland, Pennington, Gysin, Astrid and the villagers are not combat opponents. Should it come to physical altercations with constables, the game master uses Henchman values for the constables, following the core rulebook’s rule of thumb: Initiative 3, truncheon 2 + 2, damage 2, Defence / Armour / HP 1 / 0 / 5.

### Zeile 545, Briefing

**alt:** **What the group gets:** an official car (grey Peugeot 403, papers for a shell company), cash, at the table 25,000 francs (internally converted €600), a map of the Vosges, the number of the hotel room in Reims, a Minox.

**neu:** **What the group gets:** an official car (grey Peugeot 403, papers for a shell company), cash, at the table 25,000 francs, a map of the Vosges, the number of the hotel room in Reims, a Minox.

### Zeile 547, Briefing

**alt:** **Expenses:** at the table in francs, internally in euros.

**neu:** **Expenses:** at the table in francs, internally €10,000 like any Red File.

### Zeile 731, Aftermath

**alt:** **Handover:** Whoever dies, passes over, burns out, defects or steps down is replaced by a protégé. The handover is a scene according to the rules of the campaign plan. In this mission no one necessarily dies, but the forest can swallow someone for hours or days. An agent who is missing without being dead gives cause for an entry in the Duty Log.

**neu:** **Handover:** Whoever dies, passes over, burns out, defects or steps down is replaced by a protégé. The handover is a scene according to the rules of the successor system (Chapter 2). In this mission no one necessarily dies, but the forest can swallow someone for hours or days. An agent who is missing without being dead gives cause for an entry in the Duty Log.

### Zeile 1009, Aftermath

**alt:** **Experience:** Black File: 7 XP, +1 for the achieved objective, at most +1 personal bonus, plus +1 per thread taken up. The threads: the twelfth party (open), Holloway’s letter (open), the numbers station (open).

**neu:** **Experience:** Once for both parts, by the higher colour: Black File: 7 XP, +1 for the achieved objective, at most +1 personal bonus, plus +1 per thread taken up. The threads: the twelfth party (open), Holloway’s letter (open), the numbers station (open).

### Zeile 1017, Aftermath

**alt:** **Until the next mission:** 1960: Of the Thirty-One, 22 are still alive. The Lavigne, who calls herself Margot, marries. 1961: The Typesetter begins in the Nursery. Hold-4 Oxford is established. In September the first Shadow Paratroopers jump in Lima (“I want men who can fall.”). Ekberg leaves the Institute without farewell. 1962: Nachtigall in Vienna, Britt Holm drives into the Harz on 21 December and does not return. 1963: Berglund, Neuro-Helm Mk. I, helmet day. 1964 to 1966: Hold-5 Vienna, training helmet, Hold-6 Lagos. 1968: Liège, Adeyemi, Dorje dies. 1969: Mission 9, “Elster”.

**neu:** **Until the next mission:** 1960: Of the Thirty-One, 22 are still alive. The Lavigne, who calls herself Margot, marries. 1961: The Typesetter begins in the Nursery. Hold-4 Oxford is established. In September a squad near Lima needs three days on foot to reach a rift that has closed by then; Ashgrove writes: “I want men who can fall.” In 1961 the branch trains the first Shadow Paratroopers. Ekberg leaves the Institute without farewell. 1962: Nachtigall in Vienna, Britt Holm drives into the Harz on 21 December and does not return. 1963: Berglund, Neuro-Helm Mk. I, helmet day. 1964 to 1966: Hold-5 Vienna, training helmet, Hold-6 Lagos. 1968: Liège, Adeyemi, Dorje dies. 1969: Mission 9, “Elster”.

### Zeile 1033, 1954

**alt:** In Lisbon a closed auction takes place. No auction house. No catalogues. A hall in a private house, three interpreters, ten bidders from six countries. Three crystals from old European private ownership are offered. The Collegium has asked the group to bid on its behalf. Those involved call the event only “the Evening”.

**neu:** In Lisbon a closed auction takes place. No auction house. No catalogues. A hall in the back building of an antiques dealer, after nightfall, three bidders: two private collectors and an Agent of the group bidding for the Collegium. Three crystals from Anatolia are offered. Because the auction only begins after nightfall, the dealer calls it “the Evening”.

### Zeile 1035, 1954

**alt:** Possible scene: An Agent of the group sits in the hall. They wear an inconspicuous suit and a cardboard number. The crystals lie in lead boxes on a walnut table. The auctioneer speaks quietly. The bids rise in small steps. For one crystal the room stays silent. It is milky and small. Two bidders raise their hands. Whether the group’s Agent wins the bid is decided by the table. What they experience on the way to the harbour and to whom they hand the case is told by the player.

**neu:** Possible scene: An Agent of the group sits in the hall. They wear an inconspicuous suit and a cardboard number. The crystals lie in lead boxes on a walnut table. The auctioneer speaks quietly. The bids rise in small steps. For one crystal the room stays silent. It is milky and small. Two bidders raise their hands. Each of the three bidders gets one stone; which one the Agent wins and what they pay for it is decided by the table. What they experience on the way to the harbour and to whom they hand the case is told by the player.

### Zeile 1041, 1956

**alt:** The legend “Ferdinand Aigner” is created. It is a single legend, worn successively by four Agents of the Operations Branch from 1956 to 1991. The first is an Agent of the group. Ferdinand Aigner is a sewing machine salesman from Graz, born in 1919. He drives a grey Opel. He smokes cigarillos. He has three stories he tells on request: one about the roads of Styria, one about a widow in Wiener Neustadt, one about a customs officer in Salzburg. He has a hat rule: when entering a shop he takes off his hat, when entering a flat he keeps it on until a woman gives him her hand. The Print Shop in Zurich has not prepared a wallet with a photograph. Aigner has no wife, no child, no siblings. Whoever wears him learns the name, the biography, the signature. They practise the walk, the voice, the way of folding a map. A legend is not a costume. It is a second memory.

**neu:** The legend “Ferdinand Aigner” is created. It is a single legend, worn successively by four Agents of the Operations Branch from 1956 to 1991. The first is an Agent of the group. Ferdinand Aigner is a sewing machine salesman from Graz, born in 1919. He drives a grey Opel. He smokes cigarillos. He has three stories he tells on request: one about the roads of Styria, one about a widow in Wiener Neustadt, one about a customs officer in Salzburg. He has a habit with his hat: when entering a shop he takes off his hat, when entering a flat he keeps it on until a woman gives him her hand. The Print Shop in Zurich has not prepared a wallet with a photograph. Aigner has no wife, no child, no siblings. Whoever wears him learns the name, the biography, the signature. They practise the walk, the voice, the way of folding a map. A legend is not a costume. It is a second memory.

### Zeile 1061, 1962

**alt:** Nachtigall reads one hundred and forty guests in Vienna. She wears a black dress. She does not speak. She stands at the edge of the hall and listens. Afterwards she writes fourteen pages. The Investigation Branch sends the group. An agent reads the pages. They contain names, fears, lies. One name is underlined three times. The agent does not ask who underlined it. He places the pages in a grey envelope. The envelope goes to Hallström. At the Institute, beryllium isolation begins. After twelve years, Greta Sundqvist finishes her work on the circles: not a code, but a language.

**neu:** Nachtigall reads one hundred and forty guests at an embassy reception in Vienna. She wears a black dress and sits at the grand piano as a pianist, between Chopin and Schubert. She does not speak. She plays and listens. Afterwards she writes fourteen pages. The Investigation Branch sends the group. An agent reads the pages. They contain names, fears, lies. One name is underlined three times. The agent does not ask who underlined it. He places the pages in a grey envelope. The envelope goes to Hallström. At the Institute, beryllium isolation begins. After twelve years, Greta Sundqvist finishes her work on the circles: not a code, but a language.

### Zeile 1063, 1962

**alt:** On 20 December 1962, Britt Holm travels from Stockholm to the Harz. She is a secretary in the Registry. She wears a coat and carries a small bag. Hallström gave her the assignment: “Who is fetching her? Do not ask Marek. Ask the Print Shop.” It is about a Harz village with singing children. The group takes her to the train in Stockholm. One agent lifts her bag into the compartment. Another hands her a thermos flask. She smiles. She says: “I’ll come back.” The train departs. On 21 December 1962 it derails in the Harz. Thirty-six dead. Britt Holm’s name is on the list.

**neu:** On 20 December 1962, Britt Holm takes the night train from Stockholm to Hamburg; on 21 December she changes there to the train into the Harz. She is a secretary in the Registry. She wears a coat and carries a small bag. Hallström gave her the assignment: “Who is fetching her? Do not ask Marek. Ask the Print Shop.” It is about a Harz village with singing children. The group takes her to the train in Stockholm. One agent lifts her bag into the compartment. Another hands her a thermos flask. She smiles. She says: “I’ll come back.” The train departs. On 21 December 1962 her connecting train from Hamburg derails in the Harz. Thirty-six dead. Britt Holm’s name is on the list.

### Zeile 1087, 1968

**alt:** Dorje dies. He was one of the founders of the Collegium. He found crystals in the Himalayas in 1923. In 1940 he could “call”. Now he is dead. The Chamber is silent for a day. Then the archivists read on in the circles. The Collegium does not mourn. It works. That is its mourning.

**neu:** Dorje dies. He brought the crystal from the abandoned monastery in the Himalayas to London, where the Collegium began. In 1940 he could “call”. Now he is dead. The Chamber is silent for a day. Then the archivists read on in the circles. The Collegium does not mourn. It works. That is its mourning.

## 06_kaskade.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 53, What Really Happened

**alt:** **The loose thread:** The group can find out that the numbers are answers, not questions. Whoever compares the groups of five with the old transcripts from 1961 sees that they change when someone writes to the house without a number. This leads to 1971, when the broadcast ends, and to 2026, when the Grey File Kessler and The Door M7 Basel need Elster’s code.

**neu:** **The loose thread:** The group can find out that the numbers are answers, not questions. Whoever compares the groups of five with the old transcripts from 1961 sees that they change when someone writes to the house without a number. This leads to 1971, when the broadcast ends, and to 2026, when Elster reappears in the Grey File Kessler and in The Door, M7 Basel.

### Zeile 86, Ilse Marek, 58

**alt:** Head of the Psionic Core, last appearance in the volume. She is in Berlin because the listeners remind her of the children of Solberg. She does not want to drag the group into it, but she wants to protect the psions who are listening. She knows that the broadcast is not a voice. She conceals that she herself considers the five-digit groups a language, not a code. She speaks in a motherly way, but with a hardness that comes from the Night of Solberg.

**neu:** Head of the Psionic Core, last mission in the volume; the interlude years tell her farewell in 1970. She is in Berlin because the listeners remind her of the children of Solberg. She does not want to drag the group into it, but she wants to protect the psions who are listening. She knows that the broadcast is not a voice. She conceals that she herself considers the five-digit groups a language, not a code. She speaks in a motherly way, but with a hardness that comes from the Night of Solberg.

### Zeile 117, Node 1: The West Berlin Telephone Exchange

**alt:** - **Clue for Psion:** A Psion with a Neuro-Helm Mk. I does not hear the broadcast in the switchboard room until they take off the helmet. Then they hear it twice. Test: Telepathy against Doable (2) to understand: the broadcast is for unprotected ears. (leads to K3)

**neu:** - **Clue for Psion:** A Psion with a Neuro-Helm Mk. I does not hear the broadcast in the switchboard room until they take off the helmet. Then they hear it twice. Test: Telepathy against Doable (2), without the helmet therefore Hard (3), to understand: the broadcast is for unprotected ears. (leads to K3)

### Zeile 128, Node 2: Elster’s Flat in Charlottenburg

**alt:** - **Clue:** Her flat door is smeared with salt that she did not put there herself. Test: Occultism against Easy (1) to recognise: someone is protecting her, the operator who writes the numbers on her own door. (leads to K4, conclusion 2)

**neu:** - **Clue:** On Elster’s threshold lies salt she did not scatter. Test: Occultism against Easy (1). Elster says her colleague, the listener, was here at night, scattered it and wrote the same numbers on her own door without remembering. (leads to K4, conclusion 2)

### Zeile 171, Node 6: Marsh’s Hotel Room Near the Zoo

**alt:** - **Clue:** Hallström’s transcript from 1961 lies on the table. Test: Cryptography against Doable (2) to recognise: the broadcast answers, it does not ask. (leads to the loose thread “Numbers station: answers, not questions”)

**neu:** - **Clue:** If the group asks Hallström about 1961, he puts his transcript on the table. Test: Cryptography against Doable (2) to recognise: the broadcast answers, it does not ask. (leads to the loose thread “Numbers station: answers, not questions”)

### Zeile 200, The Location

**alt:** The group needs a legend to get to East Berlin. The way there leads through the border crossing point at Friedrichstraße station or through Checkpoint Charlie. The way back leads through the Tränenpalast, the exit hall from East to West.

**neu:** The group needs a legend to get to East Berlin. The way there leads through the border crossing point at Friedrichstraße station or through Checkpoint Charlie. The way back leads over the same crossing; whoever came via Friedrichstraße station goes through the Tränenpalast, the exit hall from East to West.

### Zeile 215, Solutions

**alt:** **With retreat:** The group takes Elster and disappears before reinforcements arrive. The listening post remains. Elster is safe. The broadcast continues until 1971.

**neu:** **With retreat:** The group breaks off before reinforcements arrive and brings Elster to safety in West Berlin. The listening post remains. Elster is safe. The broadcast continues until 1971.

### Zeile 265, Aftermath

**alt:** The numbers are answers. Anyone who writes to the house without a number receives a broadcast. This leads to Mission 10, when the last broadcast runs, and to 2026, when the Grey File Kessler and “The Door” M7 Basel need Elster’s code.

**neu:** The numbers are answers. Anyone who writes to the house without a number receives a broadcast. This leads to Mission 10, when the last broadcast runs, and to 2026, when Elster reappears in the Grey File Kessler and in “The Door”, M7 Basel.

### Zeile 303, What Really Happened

**alt:** In September 1971 Uhrwerk, a precognitive with a Neuro-Helm Mk. II in Vienna, writes a warning on an index card. She sends it to the Core. Kantor reads it and sets it aside. He considers Uhrwerk a woman who never sat in the circle and therefore does not understand what the circle means.

**neu:** In September 1971 Uhrwerk, a precognitive with a Neuro-Helm Mk. I in Vienna, writes a warning on an index card. She sends it to the Core. Kantor reads it and sets it aside. He considers Uhrwerk a woman who never sat in the circle and therefore does not understand what the circle means.

### Zeile 313, What Really Happened

**alt:** **The loose thread:** The numbers station falls silent on 14 October 1971 at 3:00. The last transcript is a document the group can hold in their hands. The valve of a shortwave transmitter is found on 20 October in a burned-out farmhouse in Sweden. The house stands, the number is missing. This thread leads to the later missions and after 2026 to “The Door” and “Grey Files”.

**neu:** **The loose thread:** The numbers station falls silent on 14 October 1971 at 3:00. The last transcript is a document the group can hold in their hands. The valve of a shortwave transmitter is found in October in a burned-out farmhouse in Sweden. On 20 October Hallström walks past the house in Vasastan to which Kantor wrote: the house stands, the number is missing. This thread leads to the later missions and after 2026 to “The Door” and “Grey Files”.

### Zeile 349, Uhrwerk, 41

**alt:** Ottilie Brandauer, born 1930. She lives in Vienna and is a precognitive of the Choir with a Neuro-Helm Mk. II. She wrote the warning because she had a premonition: three dead, seven burned out, one sentence. She wants to prevent the Cascade, but she has no proof. She conceals that she has barely slept since the premonition. She speaks precisely, like someone accustomed to noting date and time. Language of the time: “The Voice does not lie. It only repeats what it hears.”

**neu:** Ottilie Brandauer, born 1930. She lives in Vienna and is a precognitive of the Choir with a Neuro-Helm Mk. I. She wrote the warning because she had a premonition: three dead, seven burned out, one sentence. She wants to prevent the Cascade, but she has no proof. She conceals that she has barely slept since the premonition. She speaks precisely, like someone accustomed to noting date and time. Language of the time: “The Voice does not lie. It only repeats what it hears.”

### Zeile 400, Node 2: Stockholm, Investigation Branch, Hallström’s Office

**alt:** - **Clue:** Hallström shows the group the transcripts of the summer broadcasts and explains how the numbers are coordinates. He has the last broadcast of 14 October brought to the group in Wales by courier. (leads to: Conclusion 2)

**neu:** - **Clue:** Hallström shows the group the transcripts of the summer broadcasts and explains how the numbers are coordinates. He has the last broadcast of 14 October brought to the group in Wales by courier. The agent who transcribed the first broadcast in 1961 (Handout N27) recognises the last one first, without a test: they lay N27 next to N33 and see that the voice falls silent where it began back then. (leads to: Conclusion 2)

### Zeile 407, Node 3: Vienna, Uhrwerk’s Flat

**alt:** A small flat near the Westbahnhof. Index cards lie everywhere, written in pencil, each with date and time. Uhrwerk sits at a table, the Mk. II beside her, writing down her premonitions.

**neu:** A small flat near the Westbahnhof. Index cards lie everywhere, written in pencil, each with date and time. Uhrwerk sits at a table, the Mk. I beside her, writing down her premonitions.

### Zeile 501, Psion of the Circle

**alt:** For Kantor, Rees, Ashgrove, Pryce, Hallström and Uhrwerk: they are not fighters in this mission. Kantor is unconscious. Rees carries, Ashgrove secures, Pryce waits in the workshop. They need no stats. Uhrwerk is a precognitive with Mk. II and remains in Vienna.

**neu:** For Kantor, Rees, Ashgrove, Pryce, Hallström and Uhrwerk: they are not fighters in this mission. Kantor is unconscious. Rees carries, Ashgrove secures, Pryce waits in the workshop. They need no stats. Uhrwerk is a precognitive with Mk. I and remains in Vienna.

### Zeile 509, Aftermath

**alt:** **Experience:** Red File: 5 XP, +1 for the achieved objective, at most +1 personal bonus, plus 1 XP for each thread taken up. Possible threads: the tapes, Uhrwerk’s warning, the forty-first voice, the question about Märta, the last transcript of the numbers station.

**neu:** **Experience:** Red File that turns black: 7 XP like a Black File, +1 for the achieved objective, at most +1 personal bonus, plus 1 XP for each thread taken up. Possible threads: the tapes, Uhrwerk’s warning, the forty-first voice, the question about Märta, the last transcript of the numbers station.

### Zeile 521, Aftermath

**alt:** - N33: Last transcript of the numbers station, 14 October 1971, 3 a.m. Handwritten transcript, 26 groups of five, typo “RUHIG”. A courier from the Investigation Branch brings it to Wales on 14 October.

**neu:** - N33: Last transcript of the numbers station, 14 October 1971, 3 a.m. Handwritten transcript, 26 groups of five, slip of the pen “RUHIG”. A courier from the Investigation Branch brings it to Wales on 14 October.

### Zeile 649, Node 3: The Old Wine Cellar in Vienna

**alt:** A cellar beneath the building next door to Hold-5. Damp, dark, voices from somewhere. The walls are coated with salt. No beds, no children. Only voices singing in their sleep.

**neu:** An old wine cellar two houses further on, not the embassy cellar of Hold-5. Damp, dark, voices from somewhere. The walls are coated with salt. No beds, no children. Only voices singing in their sleep.

### Zeile 671, Interlude: December 1974 to February 1976

**alt:** Between Part A and Part B lies an interlude year. It connects the two parts; it contains no clue to the monastery. Each player tells one thing their agent did during this time; the game master tells the fixed events. After that, ageing and handovers as in Chapter 2.

**neu:** Between Part A and Part B lies an interlude year. It connects the two parts; it contains no clue to the monastery. Each player tells one thing their agent did during this time; the game master tells the fixed events. After that, handovers as in Chapter 2. Ageing applies only at the start of Section IV.

### Zeile 732, Sequence

**alt:** 4. Mercier gives the signal. The devices switch on. A deep tone, not loud, but everyone in the room feels it. The Open Ones fall unconscious, one after another, without a shot, without resistance. The fifteen-year-old looks at Mercier before he collapses. A player Psion with Mk. II is also hit by the overlay: They roll WIL + Mental Resistance against Hard (3), otherwise they lose consciousness for one round.

**neu:** 4. Mercier gives the signal. The devices switch on. A deep tone, not loud, but everyone in the room feels it. The Open Ones fall unconscious, one after another, without a shot, without resistance. The fifteen-year-old looks at Mercier before he collapses. A player Psion with Mk. II is also hit by the overlay: forewarned, they roll all Psi tests with −1 die for three rounds.

### Zeile 747, Kantor, 1974

**alt:** [entry - | Kantor, 1976 | Elite · the Voice]

**alt:** A former head of the Psionic Core who disappeared in 1974 and founded the Open Ones. He appears in Part A at the border. He does not fight. He talks.

**neu:** [entry - | Kantor, 1974 | Elite · the Voice]

**neu:** A former head of the Psionic Core who disappears in 1974 and then founds the Open Ones. He appears in Part A at the border. He does not fight. He talks.

### Zeile 777, Hunters of Department 13

**alt:** **Attack** | Assault rifle 4 + 4, damage 4, or melee 4 + 3, damage 3

**alt:** **Defence / Armour / HP** | 3 / 2 / 12

**neu:** **Attack** | AKM with suppressor 4 + 4, damage 4, Silent, or melee 4 + 3, damage 3

**neu:** **Defence / Armour / HP** | 3 / 3 / 12

### Zeile 845, 1972: Letter from the Seven Burned-Out

**alt:** The players tell what their agents have done in the two years since the Cascade. One thing each. A journey. A conversation. A report. A protégé who passed a test.

**neu:** The players tell what their agents have done in the year since the Cascade. One thing each. A journey. A conversation. A report. A protégé who passed a test.

## 07_nordlicht.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 9, The Station

**alt:** When the group arrives on 7 February, it first sees the duty roster. 41 names, in pencil, in neat columns. The column for 14 February is still empty. The game master shows Handout N42; the erasure marks appear only from Saturday, the ticks only at the roll call on 14 February. The agents see the canteen with the wall clock and the kitchen radio on the serving hatch. They see the workshop where Gunnar is repairing a generator that never gets finished. They see the sick bay with the note: Aspirin is running low. They see the steel door in the basement with two keys. If the group’s Scientist set up the probe in January, they see the probe at the stairwell. They see 212 small lead boxes. They hear the whispering. Nothing more.

**neu:** When the group arrives on 7 February, it first sees the duty roster. 41 names, in pencil, in neat columns. The column for 14 February is still empty. The game master shows Handout N42; the erasure marks appear only from Saturday, the ticks only at the roll call on 14 February. The agents see the canteen with the wall clock and the kitchen radio on the serving hatch. They see the workshop where Gunnar is repairing a generator that never gets finished. They see the sick bay with the note: Aspirin is running low. They see the steel door in the basement with two keys. They see the probe at the stairwell, which the Institute has been running since December. They see 212 small lead boxes. They hear the whispering. Nothing more.

### Zeile 26, How to Play the Section

**alt:** At roll call on 14 February 1977 at seven o’clock, all 41 names on the duty roster receive their tick. On 14 February 1977 at 22:10, a Door opens in Nordlicht station. The eleven Thaumaturges read the seventh circle. All 212 stones speak at the same time. The 41 people walk through. All clocks in the station stop. All 212 crystals are afterwards grey as slate. Gunnar Solheim is among the 41. Astrid Solheim arrives too late. Her train is standing beyond Kiruna at 22:10. Ingrid’s pocket watch runs down over a whole night. The search party under Lieutenant Kjell Haugen lands on 15 February at 6:40. They find the door unlocked, the heating on, the radio on, eleven cups on the table, ten half full and warm. Haugen’s watch stands at 22:10. The radio plays a choir. Haugen leaves the choir out of the report. The Print Shop invents 41 deaths over half a year in three countries. The radio log at 22:08 reads: “All quiet. Snow.” For every Chronomancer, at 22:10 the clocks stop and the stone turns grey. In the Crystal Ledger, the exhaustion time for all Nordlicht entries is 22:10. No player agent changes these facts.

**neu:** At roll call on 14 February 1977 at seven o’clock, all 41 names on the duty roster receive their tick. On 14 February 1977 at 22:10, a Door opens in Nordlicht station. The eleven Thaumaturges read the seventh circle. All 212 stones speak at the same time. The 41 people walk through. All clocks in the station stop. All 212 crystals are afterwards grey as slate. Gunnar Solheim is among the 41. Astrid Solheim arrives too late. Her train is standing beyond Kiruna at 22:10. The pocket watch in Ingrid’s hand runs down over a whole night. The search party under Lieutenant Kjell Haugen lands on 15 February at 6:40. They find the door unlocked, the heating on, the radio on, eleven cups on the table, ten half full and warm. Haugen’s watch stands at 22:10. The radio plays a choir. Haugen leaves the choir out of the report. The Print Shop invents 41 deaths over half a year in three countries. The radio log at 22:08 reads: “All quiet. Snow.” For every Chronomancer, at 22:10 the clocks stop and the stone turns grey. In the Crystal Ledger, the exhaustion time for all Nordlicht entries is 22:10. No player agent changes these facts.

### Zeile 61, What Really Happened

**alt:** The Department’s plan is not to destroy the stones. It wants them. Eleven crates, a dozen crystals, enough for the Tunguska pieces that lie in a cellar in Leningrad and have not spoken since 1957. The order is: stop the train, take the lead crates, no witnesses. The hunters know the route. They know that the radio dead zone lies between Abisko and Riksgränsen and that the snow is deep.

**neu:** The Department’s plan is not to destroy the stones. It wants them. Eleven crates, a dozen crystals, enough for the Tunguska shards that have hummed since 1957 but do not speak. The order is: stop the train, take the lead crates, no witnesses. The hunters know the route. They know that the radio dead zone lies between Abisko and Riksgränsen and that the snow is deep.

### Zeile 84, What Really Happened

**alt:** - **Whether the group’s Scientist sets up the Nordlicht probe in January.** Consequence: Rask or a Scientist player may test the probe in January. Whoever sets it up records the measurement strip from 14 February. Whoever does not set it up arrives too late and sees only the printout.

**alt:** - **What the group tells Gunnar about his father.** Consequence: Gunnar carries it into the night. Haugen later knows two names: Rønning and Gunnar. If a player agent Haugen met in Mission 12 remained, they replace one of the two.

**neu:** - **Whether the group’s Scientist works on the Nordlicht probe in January.** Consequence: Rask or a Scientist player may test the probe in January. Whoever worked on it and stays stands at the probe on 14 February. Whoever travels sees only the printout later.

**neu:** - **What the group tells Gunnar about his father.** Consequence: Gunnar carries it into the night. Haugen later knows two names: Rønning and Gunnar. If a player agent Haugen met in Mission 12 remained, they replace Rønning.

### Zeile 155, Node 3: Stockholm

**neu:** - **Clue:** Haugen has further crates of the same weight loaded alongside the 26. (leads to the confrontation)

### Zeile 159, Node 4: The Night Train on the Iron Ore Line

**alt:** #### Node 4: The Night Train on the Ofotbanen

**neu:** #### Node 4: The Night Train on the Iron Ore Line

### Zeile 203, Escalation

**alt:** If an agent gets off in Kiruna and follows the voices, they miss the train. The Ofotbanen does not wait. There is no road from Kiruna to Narvik. They take the next train or an ore train to rejoin the group in Narvik. The voices do not want to stop them. They call to them. Whoever stays hears longer than they wanted.

**neu:** If an agent gets off in Kiruna and follows the voices, they miss the train. The Iron Ore Line does not wait. There is no road from Kiruna to Narvik. They take the next train or an ore train to rejoin the group in Narvik. The voices do not want to stop them. They call to them. Whoever stays hears longer than they wanted.

### Zeile 217, The Location

**alt:** The night train on the Ofotbanen, between Abisko and Riksgränsen. Polar night, snow, wind. The crates stand in the goods wagon, Haugen and the group in the passenger carriage behind it. The hunters come from the side on snowmobiles, four men, Elite, assault rifles with suppressors. The train is moving slowly because a signal is at red. The line is a dead zone. No call, no backup, no witness.

**neu:** The night train on the Iron Ore Line, between Abisko and Riksgränsen. Polar night, snow, wind. The crates stand in the goods wagon, Haugen and the group in the passenger carriage behind it. The hunters come from the side on snowmobiles, four men, Elite, assault rifles with suppressors. The train is moving slowly because a signal is at red. The line is a dead zone. No call, no backup, no witness.

### Zeile 221, The Location

**alt:** The route is shown on the map of the Ofotbanen (Map K10).

**neu:** The route is shown on Map K10.

### Zeile 236, Solutions

**alt:** **Without a fight:** The group lets the hunters take the crates and follows them. The crates are not the real ones. Ashgrove had dummy crates loaded in Stockholm with sand and weights, the ones listed on the freight papers. The real crates stand in a second wagon that was reloaded in Kiruna. The group continues to Narvik and collects the real crates from the warehouse. Haugen learns that retreat is not a loss. The price: the Department now knows that O.D.I.N. expected them. The next attempt will be quieter.

**neu:** **Without a fight:** The group lets the hunters take the crates and follows them. The crates are not the real ones. On Ashgrove’s instruction, Haugen had dummy crates with sand and weights put in the goods wagon in Stockholm; they are listed that way on the freight papers. The real crates travel in a second goods wagon that Haugen had uncoupled in Kiruna and that comes to Narvik with the next ore train. The group continues and collects the real crates from the warehouse the next day. If Department 13 attacks before Kiruna, this solution is not available. Haugen learns that retreat is not a loss. The price: the Department now knows that O.D.I.N. expected them. The next attempt will be quieter.

### Zeile 293, Aftermath

**alt:** **Duty Log:** Who got off in Kiruna, who answered, who survived the raid and how, who said what to Gunnar. The game master notes which two names Haugen later knows on the duty roster: Rønning and Gunnar, or Rønning and a player agent who stayed. Without player agents, Haugen always knows Rønning and Gunnar, regardless of what the group tells Gunnar. The acquaintance between Haugen and Gunnar shows Node 6: Gunnar collects the crates with the station’s vehicle at the warehouse in Narvik, and the two talk about the generator while unloading.

**neu:** **Duty Log:** Who got off in Kiruna, who answered, who survived the raid and how, who said what to Gunnar. The game master notes which two names Haugen later knows on the duty roster: Rønning and Gunnar, or Gunnar and a player agent who stayed. Without player agents, Haugen always knows Rønning and Gunnar, regardless of what the group tells Gunnar. The acquaintance between Haugen and Gunnar shows Node 6: Gunnar collects the crates with the station’s vehicle at the warehouse in Narvik, and the two talk about the generator while unloading.

### Zeile 295, Aftermath

**alt:** **Handover:** A Soldier protégé who was present on Mission 12 takes over arm guard No. 114 when their mentor steps down. A Thaumaturge protégé who kept the Crystal Ledger helps enter the arrivals at Nordlicht and thereafter knows every position up to 212.

**neu:** **Handover:** Haugen keeps arm guard No. 114; it passes on only in 1990. A Soldier protégé who was present on Mission 12 knows Haugen and the route afterwards. A Thaumaturge protégé who kept the Crystal Ledger helps enter the arrivals at Nordlicht and thereafter knows every position up to 212.

### Zeile 297, Aftermath

**alt:** **The loose thread:** The men in the mountain and the question of whether they can be brought back. For the game master running “The Door”: one of the stones from the Vosges, an ordinary position in the Crystal Ledger, is stolen from Nordlicht decades later and reaches an auction via an estate in Tromsø (“The Door”, Mission 3).

**neu:** **The loose thread:** The men in the mountain and the question of whether they can be brought back. For the game master running “The Door”: one of the stones from the Vosges, an ordinary position in the Crystal Ledger, goes after the clearance to one of the archives among which the Collegium distributes the Nordlicht stones, is stolen there decades later and reaches an auction via an estate in Tromsø (“The Door”, Mission 3).

### Zeile 305, Aftermath

**alt:** Map: K10, the Ofotbanen from Stockholm via Kiruna to Narvik.

**neu:** Map: K10, the night train from Stockholm via Kiruna to Narvik.

### Zeile 326, What It Is About

**alt:** The group finds a station with 41 people, a kitchen radio playing pop songs, a wall clock that keeps the right time, and 212 stones in the cellar that whisper louder this week than usual. The eleven Thaumaturges are preparing something, but only on Saturday do they ask for the canteen to be kept free on Monday evening. On Saturday the group must decide, following the placeholder rule, who flies to Stockholm on Sunday to collect Astrid Solheim and the parts of the time-measuring installation. Whoever stays takes a swap slot on the duty roster. Whoever travels arrives too late with Astrid. The decision is binary: whoever is at the station that night goes with it. Whoever travels grows old.

**neu:** The group finds a station with 41 people, a kitchen radio playing pop songs, a wall clock that keeps the right time, and 212 stones in the cellar that whisper louder this week than usual. The eleven Thaumaturges are preparing something, but only on Saturday do they ask for the canteen to be kept free on Monday evening. On Saturday the group must decide, following the swap-slot rule, who flies to Stockholm on Sunday to collect Astrid Solheim and the parts of the time-measuring installation. Whoever stays takes a swap slot on the duty roster. Whoever travels arrives too late with Astrid. The decision is binary: whoever is at the station that night goes with it. Whoever travels grows old.

### Zeile 336, What Really Happened

**alt:** **The loose thread:** The eleven Thaumaturges are among the 41. Their eleven files turn up in Stockholm in 2014 and disappear. The school class that is in the valley on Thursday hears the melody. The Registry file on the boy who asks about the song is never closed. The letter from the radio operator’s wife in Tromsø is answered every February after 1977. The widow writes to the station’s front company. The same agent has been answering since 1978. In 2027 the boy from the school class is a man who still hears the melody.

**neu:** **The loose thread:** The eleven Thaumaturges are among the 41. Their eleven files turn up in Stockholm in 2014 and disappear. The school class that has been in the valley since Thursday hears the melody in the night. The Registry file on the boy who asks about the song is never closed. The letter from the radio operator’s wife in Tromsø is answered every February after 1977. The widow writes to the station’s front company. The same agent has been answering since 1978. In 2027 the boy from the school class is a man who still hears the melody.

### Zeile 416, Node 1: Station Chief’s Office (Duty Roster)

**alt:** Tests: Investigation, Stealth, Insight, Perception. Classes: Investigator, Agent, Soldier.

**neu:** Tests: Investigation, Stealth, Tactics, Perception. Classes: Investigator, Agent, Soldier.

### Zeile 428, Node 2: Canteen with Kitchen and Serving Hatch

**alt:** Tests: Ritualism, Telepathy, Insight, Perception. Classes: Thaumaturge, Psion, Agent, Scientist.

**neu:** Tests: Ritualism, Telepathy, Insight, Perception, Persuasion. Classes: Thaumaturge, Psion, Agent, Scientist.

### Zeile 468, Node 6: Sick Bay and Post

**alt:** - **Clue:** The letter from the radio operator’s wife in Tromsø: she asks when he is coming home. She only knows of a company weather station with a post box in Oslo. (leads to: the 41) An Agent reads it with Sleight of Hand against Easy (1).

**alt:** - **Clue:** Ingrid’s drawing “Ingrid, 3 years old. For Papa.” lies on the table. (leads to: Gunnar Solheim) A Soldier sees it with Perception against Easy (1).

**neu:** - **Clue:** The letter from the radio operator’s wife in Tromsø: she asks when he is coming home. She only knows of a company weather station with a post box in Oslo. (Handout N43, leads to: the 41) An Agent reads it with Sleight of Hand against Easy (1).

**neu:** - **Clue:** Ingrid’s drawing “Ingrid, 3 years old. For Papa.” lies on the table. (Handout N44, leads to: Gunnar Solheim) A Soldier sees it with Perception against Easy (1).

### Zeile 486, Escalation

**alt:** - **Thursday, 10 February:** The school class in the valley. A boy asks about the song he heard at night. If the group is not there, they hear about it on Friday. Horror test: Disturbing (2) if they realise that the song is not from here.

**neu:** - **Thursday, 10 February:** A German school class moves into the hut in the valley. A boy asks about the station with the antennas. If the group is not there, they hear about it on Friday.

### Zeile 495, The Location

**alt:** The canteen of Nordlicht, Monday, 14 February 1977, 21:45 to 22:10. The long table, the eleven Thaumaturges, the chalk circle on the tabletop, eleven cups of coffee. The kitchen radio plays pop songs. The wall clock above the door. For all those who travel: the night train from Stockholm to Narvik, beyond Kiruna, at 22:10. (Map K12)

**neu:** The canteen of Nordlicht, Monday, 14 February 1977, 21:45 to 22:10. The long table, the eleven Thaumaturges, the chalk circle on the tabletop, eleven cups of coffee. The kitchen radio plays pop songs. The wall clock above the door (Map K12). For all those who travel: the night train from Stockholm to Narvik, beyond Kiruna, at 22:10.

### Zeile 504, Sequence

**alt:** 7. **22:10, night train.** All clocks on the train stop, only Ingrid’s pocket watch runs through a whole night in under a minute. Astrid’s crystal turns cold and grey from the centre; the whisper she heard for 23 years falls silent. The train stands beyond Kiruna within sight of the mine, a good three hours from the station.

**neu:** 7. **22:10, night train.** All clocks on the train stop, only the pocket watch in Ingrid’s hand runs through a whole night in under a minute. Astrid’s crystal turns cold and grey from the centre; the whisper she heard for 23 years falls silent. The train stands beyond Kiruna within sight of the mine, a good three hours from the station.

### Zeile 518, Kjell Haugen

**alt:** [entry - | Kjell Haugen | Professional · Humans]

**neu:** [entry - | Kjell Haugen | Elite · Humans]

### Zeile 523, Kjell Haugen

**alt:** **Defence / Armour / HP** | 3 / 2 / 15

**alt:** **Horror** | Disturbing (2) if he hears the choir on the radio

**neu:** **Defence / Armour / HP** | 3 / 2 / 14

**neu:** **Horror** | None. If he hears the choir on the radio, he makes a horror test against Disturbing (2) himself

### Zeile 536, Aftermath

**alt:** **What O.D.I.N. gets:** Haugen’s report SA-1977-02. The wall clock from the canteen, stopped at 22:10. The kitchen radio, which plays a choir in the morning. The 212 grey crystals. The probe that measures 41 people over there. The eleven files of the night worker. The Black File Nordlicht.

**neu:** **What O.D.I.N. gets:** Haugen’s report SA-1977-02. The wall clock from the canteen, stopped at 22:10. The kitchen radio, which plays a choir in the morning. The 212 grey crystals. The probe that measures 41 people over there. The personnel files of the eleven Thaumaturges (in 2014 the eleven files of the night worker). The Black File Nordlicht.

### Zeile 553, Aftermath

**alt:** - Map K12: Nordlicht Station, Floor Plan ground floor and basement: canteen above the archive, probe at the stairway, workshop on the ground floor, corrugated-iron shed as a separate building, eleven sleeping rooms with four beds each, assigned according to the duty roster, one guest room for the group.

**neu:** - Map K11: Nordlicht Station, site plan: main building, corrugated-iron shed, landing site, road to Narvik.

**neu:** - Map K12: Nordlicht Station, Floor Plan ground floor and basement: canteen above the archive, probe at the stairway, workshop on the ground floor, corrugated-iron shed as a separate building, ten sleeping rooms with four beds each and a room for the station chief, assigned according to the duty roster, one guest room for the group.

## 08_nacht.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 63, The Duty Roster

**alt:** **How a player agent gets onto the roster.** On Saturday, 12 February, each player decides individually whether their agent stays or travels. Whoever stays takes a swap slot of a suitable function: T1 liaison, T2 Thaumaturge, T3 archive assistant, T4 physicist, T5 radio operator, T6 guard, T7 Listener. A player Thaumaturge on T2 belongs to the eleven and reads along. Whoever wants to stay but not read takes T3. If more player agents of the same function are available than swap slots, they replace further names of suitable function. The number 41 does not break.

**neu:** **How a player agent gets onto the roster.** On Saturday, 12 February, each player decides individually whether their agent stays or travels. Whoever stays takes a swap slot of a suitable function: T1 liaison, T2 Thaumaturge, T3 archive assistant, T4 physicist, T5 radio operator, T6 guard, T7 Listener. A player Thaumaturge on T2 belongs to the eleven and reads along. Whoever wants to stay but not read takes T3. If more player agents of the same function are available than swap slots, they replace further names of suitable function, but never Einar Vatne or Arne Kvalvik. The number 41 does not break.

### Zeile 178, 14 February, During the Day

**alt:** In these hours every agent on the train has a scene with Astrid or Ingrid. Astrid talks about the workshop in Bergen and Gunnar’s plans for the summer. Whoever asks her about her stone hears that it whispers as always: like a beat. Ingrid shows everyone her pocket watch and does not let go of it.

**neu:** In these hours every agent on the train has a scene with Astrid or Ingrid. Astrid talks about the workshop in Bergen and Gunnar’s plans for the summer. Whoever asks her about her stone hears that it whispers as always: like a beat. Ingrid shows everyone her mother’s pocket watch and does not let go of it.

### Zeile 190, 22:10, Beyond Kiruna

**alt:** All clocks on the train stop. Only Ingrid’s pocket watch runs through a whole night in under a minute. Astrid’s crystal turns cold and grey from the centre. The whisper she heard for 23 years falls silent. The train stands beyond Kiruna within sight of the mine, a good three hours from the station.

**neu:** All clocks on the train stop. Only the pocket watch in Ingrid’s hand runs through a whole night in under a minute. Astrid’s crystal turns cold and grey from the centre. The whisper she heard for 23 years falls silent. The train stands beyond Kiruna within sight of the mine, a good three hours from the station.

### Zeile 194, 22:10, Beyond Kiruna

**alt:** Ingrid sleeps. She does not wake.

**neu:** Ingrid sleeps on. She notices nothing.

### Zeile 210, 4:00, Narvik Station

**alt:** Astrid puts Ingrid’s pocket watch into her coat pocket and asks no one for the time again. After that she never repairs a clock again. Her workshop in Bergen remains closed.

**neu:** Astrid puts the pocket watch into her coat pocket and asks no one for the time again. After that she never repairs a clock again. Her workshop in Bergen remains closed.

### Zeile 226, In the Station

**alt:** Haugen counts his men twice. In the station chief’s office he reads the duty roster, the 41 names, one after another, each with a tick. He knows two: Magnus Rønning from Camp Ashgrove and Gunnar Solheim from Narvik, December 1976. If a player agent whom Haugen met in Mission 12 remained, their name stands in place of one of the two.

**neu:** Haugen counts his men twice. In the station chief’s office he reads the duty roster, the 41 names, one after another, each with a tick. He knows two: Magnus Rønning from Camp Ashgrove and Gunnar Solheim from Narvik, December 1976. If a player agent whom Haugen met in Mission 12 remained, their name stands in place of Rønning’s.

## 09_nach.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 3, 

**alt:** On 15 February 1977 the search party of the Tactical Branch lands outside Nordlicht at 6:40. The door is unlocked. The heating is running. A Norwegian pop song is playing on the radio. On the kitchen table stand eleven coffee cups, ten half full and warm. The beds are made. In the sick bay lies a note: aspirin is running low. In the archive lie 212 crystals, grey as slate, catalogued, packed, in their places. Lieutenant Kjell Haugen reports: station intact, 41 persons missing, no losses of our own. The Council replies: recommendation accepted. Sealing after clearance by the Institute and the Collegium.

**neu:** On 15 February 1977 the search party of the Tactical Branch lands outside Nordlicht at 6:40. The door is unlocked. The heating is running. A Norwegian pop song is playing on the radio. On the long table in the canteen stand eleven coffee cups, ten half full and warm. The beds are made. In the sick bay lies a note: aspirin is running low. In the archive lie 212 crystals, grey as slate, catalogued, packed, in their places. Lieutenant Kjell Haugen reports: station intact, 41 persons missing, no losses of our own. The Council replies: recommendation accepted. Sealing after clearance by the Institute and the Collegium.

### Zeile 17, Hallström, 16 February 1977

**alt:** Anyone whose player agent works in the Registry can be present in this scene. Hallström explains nothing. Anyone who asks gets the answer: “Write down what you saw. In your own words. Not for the file.” That is the only test of the scene: no skill, only the decision about what the agent writes down and what not.

**neu:** Anyone whose player agent works in the Registry and arrived too late experiences the scene after returning from the north: Hallström still has the page open when the agent enters his office. Hallström explains nothing. Anyone who asks gets the answer: “Write down what you saw. In your own words. Not for the file.” That is the only test of the scene: no skill, only the decision about what the agent writes down and what not.

## 10_anhang.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 11, Appendix A: Six Ready-Made Agents

**alt:** The protégés listed here are the late ones who stand at the agents’ side in 1977. From mission 2 each agent has a protégé; before mission 4 in 1953 everyone should have one. Earlier suggestions: for Ness, a recruit of the escort from the first transport, perhaps a young Norwegian from Kompani Linge (named 1949, falls in Kiruna in 1953, successor is Tove). For Marchais, a recruit from Marsh’s network in Lyon (named 1949, leaves with the convoy in 1958, successor is Arnaud). For Rask, a member of the Institute from the very beginning (named 1949, stays in Bern, successor is Lindqvist). For Ozola, another of the Thirty-One (named 1949, goes into the silence in 1971, successor is Sula). For Vaughan, an apprentice of the Collegium (named 1949, goes through the Door with Holloway in 1959, successor is Rhodri). For Ekvall, a secretary of the Registry (named 1949, dies in Bad Grund in 1962, successor is Lönn).

**neu:** The protégés listed here are the late ones who stand at the agents’ side in 1977. From mission 2 each agent has a protégé; before mission 4 in 1953 everyone should have one. Earlier suggestions: for Ness, a recruit of the escort from the first transport, perhaps a young Norwegian from Kompani Linge (named 1949, falls in Kiruna in 1953, successor is Tove). For Marchais, a recruit from Marsh’s network in Lyon (named 1949, leaves with the convoy in 1958, successor is Arnaud). For Rask, a member of the Institute from the very beginning (named 1949, stays in Bern, successor is Lindqvist). For Ozola, another of the Thirty-One (named 1949, goes into the silence in 1971, successor is Sula). For Vaughan, an apprentice of the Collegium (named 1949, keeps watch with the group in 1959 when Holloway goes and leaves the Collegium afterwards; successor is Rhodri). For Ekvall, a secretary of the Registry (named 1949, dies in Bad Grund in 1962, successor is Lönn).

### Zeile 51, Harald Ness, “Salz”

**alt:** **Skills 1947:** Firearms 4, Endurance 4, Tactics 3, Survival 3, Athletics 2, Melee 2, Perception 2, Dodge 2, Mental Resistance 2, Toughness 2, Driving 1, Craft 1, Stealth 1, Medicine 1.

**neu:** **Skills 1947:** Firearms 5, Endurance 4, Tactics 3, Survival 3, Athletics 2, Melee 3, Perception 3, Dodge 2, Mental Resistance 2, Toughness 2, Stealth 2, Medicine 2, Driving 1, Craft 1.

### Zeile 53, Harald Ness, “Salz”

**alt:** **Skills 1977:** Firearms 5, Tactics 5, Endurance 4, Survival 4, Perception 3, Mental Resistance 3, Dodge 3, Toughness 2, Athletics 2, Melee 2, Leadership 4, Driving 1, Craft 1, Stealth 1, Medicine 1.

**neu:** **Skills 1977:** Firearms 6, Tactics 5, Endurance 4, Survival 4, Perception 4, Leadership 4, Mental Resistance 3, Dodge 3, Melee 3, Toughness 2, Athletics 2, Stealth 2, Medicine 2, Driving 1, Craft 1.

### Zeile 88, Colette Marchais, “Garn”

**alt:** **Skills 1947:** Deception 4, Disguise 3, Etiquette 3, Stealth 3, Perception 2, Firearms 2, Persuasion 2, Dodge 1, Mental Resistance 1, Insight 2, Driving 1, Cryptography 1, Performance 1, Hacking 1 (subclass bonus, of no use in this volume).

**neu:** **Skills 1947:** Deception 4, Insight 4, Disguise 3, Etiquette 3, Stealth 3, Persuasion 3, Firearms 3, Perception 2, Sleight of Hand 2, Cryptography 2, Driving 2, Dodge 1, Mental Resistance 1, Performance 1, Hacking 1 (subclass bonus, of no use in this volume).

### Zeile 90, Colette Marchais, “Garn”

**alt:** **Skills 1977:** Deception 6, Insight 4, Cryptography 3, Disguise 4, Etiquette 4, Stealth 4, Perception 3, Dodge 2, Mental Resistance 2, Firearms 2, Persuasion 2, Driving 1, Performance 1, Hacking 1.

**neu:** **Skills 1977:** Deception 6, Insight 6, Cryptography 4, Disguise 4, Etiquette 4, Stealth 4, Perception 3, Persuasion 3, Firearms 3, Sleight of Hand 2, Driving 2, Dodge 2, Mental Resistance 2, Performance 1, Hacking 1.

### Zeile 98, Colette Marchais, “Garn”

**alt:** **Protégé:** Jean-Luc Arnaud, born 1944. A former Foreign Legionnaire who deserted in Paris in 1968. Marsh finds him in a back room in Marseille, playing cards. He is no spy, but he can talk. Marchais trains him as a Negotiator: Negotiation, Insight, Leadership. Arnaud has his first missions behind him in 1977. He speaks four languages, always carries a fountain pen with him, and writes letters that are never sent.

**neu:** **Protégé:** Jean-Luc Arnaud, born 1944. A former Foreign Legionnaire who deserted in Paris in 1968. Marsh finds him in a back room in Marseille, playing cards. He is no spy, but he can talk. Marchais trains him as a Negotiator: Insight, Deception, Etiquette. Arnaud has his first missions behind him in 1977. He speaks four languages, always carries a fountain pen with him, and writes letters that are never sent.

### Zeile 125, Dr. Ingeborg Rask, “Lot”

**alt:** **Skills 1947:** Physics 4, Technology 3, Academic Knowledge 3, Navigation 2, Perception 2, Chemistry 2, Dodge 1, Mental Resistance 1, Toughness 1, Engineering 2, Energy Manipulation 1, Craft 1.

**neu:** **Skills 1947:** Physics 4, Technology 4, Academic Knowledge 4, Chemistry 3, Engineering 3, Navigation 3, Perception 3, Energy Manipulation 2, Medicine 2, Craft 2, Dodge 1, Mental Resistance 1, Toughness 1, Investigation 1, Driving 1.

### Zeile 127, Dr. Ingeborg Rask, “Lot”

**alt:** **Skills 1977:** Physics 6, Technology 5, Energy Manipulation 3, Academic Knowledge 4, Navigation 3, Chemistry 3, Dodge 2, Mental Resistance 2, Toughness 1, Engineering 3, Craft 1, Perception 3.

**neu:** **Skills 1977:** Physics 6, Technology 6, Academic Knowledge 5, Energy Manipulation 4, Chemistry 4, Engineering 4, Navigation 4, Perception 4, Medicine 2, Craft 2, Dodge 2, Mental Resistance 2, Toughness 1, Investigation 1, Driving 1.

### Zeile 135, Dr. Ingeborg Rask, “Lot”

**alt:** **Protégé:** Beate Lindqvist, born 1946. An engineer from Gothenburg who joins the Institute in 1969. Rask trains her as an Engineer: Engineering, Technology, Craft. Lindqvist builds the probe’s cabling in 1976. She is the one who brings the probe’s printout to the basement. In 1977 she waits in Bern for Rask’s return. If Rask returns, Lindqvist asks: “What did the probe count?” Rask answers: “People. Hopefully.”

**neu:** **Protégé:** Beate Lindqvist, born 1946. An engineer from Gothenburg who joins the Institute in 1969. Rask trains her as an Engineer: Technology, Engineering, Physics. Lindqvist builds the probe’s cabling in 1976. She is the one who brings the probe’s printout to the basement. In 1977 she waits in Bern for Rask’s return. If Rask returns, Lindqvist asks: “What did the probe count?” Rask answers: “People. Hopefully.”

### Zeile 164, Ilga Ozola, “Möwe”

**alt:** **Skills 1947:** Telepathy 5, Insight 4, Concentration 3, Mental Resistance 3, Perception 2, Dodge 1, Psi Combat 1, Persuasion 1, Stealth 1, Medicine 1.

**neu:** **Skills 1947:** Telepathy 5, Insight 4, Concentration 4, Mental Resistance 3, Persuasion 3, Perception 3, Deception 2, Psi Combat 2, Stealth 2, Medicine 2, Dodge 1, Etiquette 1, Academic Knowledge 1, History 1, Driving 1.

### Zeile 166, Ilga Ozola, “Möwe”

**alt:** **Skills 1977:** Telepathy 6, Concentration 5, Psi Combat 3, Insight 5, Mental Resistance 4, Perception 3, Dodge 2, Persuasion 1, Stealth 1, Medicine 1.

**neu:** **Skills 1977:** Telepathy 6, Concentration 6, Insight 5, Psi Combat 4, Mental Resistance 4, Perception 4, Persuasion 3, Deception 2, Stealth 2, Medicine 2, Dodge 2, Etiquette 1, Academic Knowledge 1, History 1, Driving 1.

### Zeile 203, Dilys Vaughan, “Schiefer”

**alt:** **Skills 1947:** Thaumaturgy 4, Ritualism 4, Occultism 4, Concentration 3, Academic Knowledge 2, Dodge 1, Mental Resistance 1, Perception 1, Alchemy 1, History 1.

**neu:** **Skills 1947:** Thaumaturgy 4, Ritualism 4, Occultism 4, Concentration 4, Academic Knowledge 4, Alchemy 3, History 3, Insight 2, Perception 2, Dodge 1, Mental Resistance 1, Persuasion 1, Medicine 1, Craft 1.

### Zeile 205, Dilys Vaughan, “Schiefer”

**alt:** **Skills 1977:** Thaumaturgy 6, Ritualism 6, Occultism 5, Concentration 4, Academic Knowledge 3, Dodge 2, Mental Resistance 2, Perception 2, Alchemy 1, History 1.

**neu:** **Skills 1977:** Thaumaturgy 6, Ritualism 6, Occultism 5, Concentration 5, Academic Knowledge 5, Alchemy 3, History 3, Perception 3, Insight 2, Dodge 2, Mental Resistance 2, Persuasion 1, Medicine 1, Craft 1.

### Zeile 211, Dilys Vaughan, “Schiefer”

**alt:** **Threads:** If Vaughan is in Kiruna in 1953, she survives because she remains outside the warding circle. The other Thaumaturge draws the circle, answers the thing and walks through the rock. She sees him walk through the rock. Since then she draws every warding circle twice. In 1957 she becomes Astrid Solheim’s supervisor, one year after the first Chronomancer came to the Collegium. Vaughan teaches her: “Time is a circle. Whoever leaves it comes back different.” In 1977 Vaughan can be one of the eleven Thaumaturges who read the seventh circle in the canteen above the archive. She knows what happened in 1953. She reads anyway. At 22:10 the Door opens. Vaughan can step through. Her watch stops. Her crystal turns grey. Or she accompanies Astrid on the delayed train to Narvik and arrives too late.

**neu:** **Threads:** If Vaughan is in Kiruna in 1953, she survives because she remains outside his circle. The other Thaumaturge draws the circle, answers the thing and walks through the rock. She sees him walk through the rock. Since then she draws every warding circle twice. In 1957 she becomes Astrid Solheim’s supervisor, one year after the first Chronomancer came to the Collegium. Vaughan teaches her: “Time is a circle. Whoever leaves it comes back different.” In 1977 Vaughan can be one of the eleven Thaumaturges who read the seventh circle in the canteen above the archive. She knows what happened in 1953. She reads anyway. At 22:10 the Door opens. Vaughan can step through. Her watch stops. Her crystal turns grey. Or she accompanies Astrid on the delayed train to Narvik and arrives too late.

### Zeile 213, Dilys Vaughan, “Schiefer”

**alt:** **Protégé:** Rhodri Vaughan, born 1948. Dilys’ nephew, who plays in the slate quarry as a child. He enters the Collegium in 1965. Dilys trains him as a Thaumaturgist: Thaumaturgy, Ritualism, Occultism. In 1977 Rhodri is an adept of the Third Circle. He stays in Wales and waits for word from Nordlicht. If Dilys steps through the Door, the word never comes.

**neu:** **Protégé:** Rhodri Vaughan, born 1948. Dilys’ nephew, who plays in the slate quarry as a child. He enters the Collegium in 1965. Dilys trains him as a Thaumaturgist: Thaumaturgy, Ritualism, Occultism. In 1977 Rhodri is an adept of the Second Circle. He stays in Wales and waits for word from Nordlicht. If Dilys steps through the Door, the word never comes.

### Zeile 240, Torsten Ekvall, “Zeuge”

**alt:** **Skills 1947:** Investigation 4, Perception 4, Insight 3, Driving 3, Occultism 2, Tracking 2, Dodge 1, Mental Resistance 1, Toughness 1, History 1, Persuasion 1, Stealth 1.

**neu:** **Skills 1947:** Investigation 4, Perception 4, Insight 3, Driving 3, Occultism 3, Tracking 3, Firearms 2, History 2, Persuasion 2, Stealth 2, Dodge 1, Mental Resistance 1, Toughness 1, Academic Knowledge 1, Intimidation 1, Medicine 1, Security Systems 1.

### Zeile 242, Torsten Ekvall, “Zeuge”

**alt:** **Skills 1977:** Investigation 6, Occultism 4, Insight 5, Perception 5, Driving 3, Tracking 3, Dodge 2, Mental Resistance 2, Toughness 1, History 1, Persuasion 1, Stealth 1. From age 60: Athletics or Endurance reduced by 1. Ekvall has both at 0, so the reduction does not apply.

**neu:** **Skills 1977:** Investigation 6, Insight 5, Occultism 5, Perception 5, Tracking 4, Driving 3, Firearms 2, History 2, Persuasion 2, Stealth 2, Dodge 2, Mental Resistance 2, Toughness 1, Academic Knowledge 1, Intimidation 1, Medicine 1, Security Systems 1. From age 60: Athletics or Endurance reduced by 1. Ekvall has both at 0, so the reduction does not apply.

### Zeile 248, Torsten Ekvall, “Zeuge”

**alt:** **Threads:** Ekvall is Hallström’s first man in the Registry. He knows all file colours before they become official. In 1948 he unpacks the Ahnenerbe crate with Hallström. Hallström finds the photo of the circles from 1937 and hangs it on the wall of the Registry. In 1950 Ekvall reads the pharmacist’s report. In the margin is the number 32, not in her hand. Ekvall asks Hallström: “Who wrote the number?” Hallström answers: “I don’t know. And I don’t want to know.” In 1962 Ekvall is present when Britt Holm is identified after the train accident in the Harz. In her bag he finds a note: “Who will fetch her?” He gives it to Hallström. Hallström places it in Notebook Zero. After the Night of Nordlicht the station remains sealed. Until the clearance on 20 February, everyone stays at the wire except one Scientist, who goes in with Wendland. Where Ekvall is that night, in the station or with Astrid on the train, is decided by the player. On the duty roster, Lönn represents the Registry (T1).

**neu:** **Threads:** Ekvall is Hallström’s first man in the Registry. He knows all file colours before they become official. In 1948 he unpacks the Ahnenerbe crate with Hallström. Hallström finds the photo of the circles from 1937 and hangs it on the wall of the Registry. In 1950 Ekvall reads the pharmacist’s report. In the margin is the number 32, not in her hand. Ekvall asks Hallström: “Who wrote the number?” Hallström answers: “I don’t know. And I don’t want to know.” In 1962 Ekvall is present when Britt Holm is identified after the train accident in the Harz. Her briefcase with the file and Hallström’s note is never found. Ekvall reports it to Hallström. Hallström writes in Notebook Zero: “File Holm not arrived.” After the Night of Nordlicht the station remains closed off and is sealed only after the clearance. During the clearance from 20 February, everyone stays at the wire except one Scientist, who goes in with Wendland. Where Ekvall is that night, in the station or with Astrid on the train, is decided by the player. On the duty roster, Lönn represents the Registry (T1).

### Zeile 333, The Thing in the Wall

**alt:** In February 1953, something breaks through in a tunnel without a plan, not a hundred metres from the silent cavity. The Collegium sends two Thaumaturges, Ashgrove leads fourteen men. The Thing in the Wall is a Threshold Guardian standing in the tunnel wall, half in the rock, half in front of it. It wears clothes from different centuries layered over one another, and its face is the face of the one looking at it, only older. Before the first incendiary ammunition in autumn 1953, the Kiruna Rule applies: ordinary weapons cause no damage. Only warding circles, spells and retreat protect. A Thaumaturge draws a warding circle, stays inside it, answers the thing. It turns to him. The Door closes with him on the other side.

**neu:** In February 1953, something breaks through in a tunnel without a plan, not a hundred metres from the silent cavity. The Collegium sends two Thaumaturges, Ashgrove leads fourteen men. The Thing in the Wall is a Threshold Guardian standing in the tunnel wall, half in the rock, half in front of it. It wears clothes from different centuries layered over one another, and its face is the face of the one looking at it, only older. Before the first incendiary ammunition in autumn 1953, the Kiruna Rule applies: ordinary weapons cause no damage. Only warding circles, spells and retreat protect. A Thaumaturge draws a circle that is not a warding circle, stays inside it and answers the thing. It turns to him. The Door closes with him on the other side.

### Zeile 335, The Thing in the Wall

**alt:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: The Threshold Guardian is invulnerable with the Kiruna Rule. The scene is not a fight, but a conversation that a Thaumaturge survives with a warding circle and an answer.)

**neu:** (Stats: “Threshold Guardian of Kiruna”, Mission 4. Deviation from the Threat Atlas: its touch does no damage; whoever is hit goes through the wall. With the Kiruna Rule it is invulnerable. The scene is not a fight, but a conversation that ends with an answer.)

### Zeile 342, Crystal Guardian

**alt:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: The guardians wear, beneath a crust of stone, the clothing of miners who disappeared in the tunnel. Before the first incendiary ammunition in autumn 1953, the Kiruna Rule applies to them as well, but they crumble when the crystal is exhausted.)

**neu:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: The guardians wear, beneath a crust of stone, the clothing of miners who disappeared in the tunnel. Before the first incendiary ammunition in autumn 1953, the Kiruna Rule applies to them as well, but they crumble when the warding circle stands and the thing takes the Thaumaturge (stats: Mission 4).)

### Zeile 354, Riftling, the Spectator

**alt:** In Cornwall in 1957, a small rift opens. Riftlings seep through, small, quick creatures that look like dogs someone has drawn only from memory. At the edge of the rift stands a Spectator: tall, grey, still. He wears a long grey coat that seems like skin, and a hat he does not remove. He observes, notes, disappears. In photographs he is blurred, always, even when everything else is sharp.

**neu:** In Cornwall in 1957, a small rift opens. At the edge of the rift stands a Spectator: tall, grey, still. He wears a long grey coat that seems like skin, and a hat he does not remove. He observes, notes, disappears. In photographs he is blurred, always, even when everything else is sharp.

### Zeile 356, Riftling, the Spectator

**alt:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: Riftlings appear in Cornwall, where the first incendiary ammunition was tested in autumn 1953. The Spectator is photographed by the Institute; the photograph is the first of three that exist.)

**neu:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: In Porthcarn in 1957 only the Spectator shows itself; the rift is the same one at which the first incendiary ammunition was tested in autumn 1953. The Spectator is photographed by the Institute; the photograph is the first of three that exist.)

### Zeile 370, Liaison Officer of a Partner Service

**alt:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: He works with teleprinters, telegrams and dead letter boxes. His weapon is a service pistol in a shoulder holster, but he rarely draws it.)

**neu:** (Stats: Threat Atlas, Game Master’s Book. Era deviation: He works with teleprinters, telegrams and dead letter boxes. His weapon is a service pistol in a shoulder holster, but he rarely draws it. Before the Veil Protocol of 1961 his ability to call off police, border or courts does not apply.)

### Zeile 540, Arsenal

**alt:** Phosphorus incendiary ammunition | before 1947

**neu:** Phosphorus incendiary ammunition | before 1947 | effective against beings from rifts only from autumn 1953 (Kiruna Rule, Chapter 3)

### Zeile 611, Arsenal

**alt:** Soft iron shot | before 1947

**neu:** Soft iron shot | before 1947 | workshop only; in gun shops only after the lead ban

### Zeile 660, Core Rulebook

**alt:** Light armour | from 1953 | Improvised (oven door)

**neu:** Light armour | from 1953 | Improvised (oven door, values in Chapter 3)

### Zeile 684, Core Rulebook

**alt:** EMF detector | from 1960

**neu:** EMF detector | from 1960 | as a rift detector of wood and brass (Chapter 3)

### Zeile 688, Core Rulebook

**alt:** Torch with UV function | before 1947

**neu:** Torch with UV function | before 1947 | torch with filter, limited
