# Horte der Welt DE: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 1 Stellen.

## 01_inseln.md (Sicherung vor_messer_2026-10-10)

### Zeile 33, Geschichte

**alt:** **1955.** Evan Pryce übergibt Ashgrove das erste Messer aus Aschesilber. Ashgrove gibt es in die Waffenkammer von Hort-1, wo es bis heute liegt.

**neu:** **1955.** Evan Pryce übergibt Ashgrove das erste Messer aus Aschesilber. Ashgrove trägt es bis zu seinem Tod; seitdem liegt es in der Waffenkammer von Hort-1.
