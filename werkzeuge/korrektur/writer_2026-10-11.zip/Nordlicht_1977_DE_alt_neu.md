# Nordlicht 1977 DE: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 161 Stellen.

## Stellen mit Gegnerwerten

- 04_gruendung.md:437 (Die Menge)
- 04_gruendung.md:718 (Verbindungsoffizier eines Partnerdienstes)
- 06_kaskade.md:777 (Jäger der Abteilung 13)
- 07_nordlicht.md:523 (Kjell Haugen)

## 00_einf.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 7, Worum es geht

**alt:** Der Satz des Bandes lautet: Was in der Zeitleiste des Spielleiterbuchs steht, geschieht. Wie es geschah, entscheidet der Tisch. Das ist die zentrale Regel. Die festen Punkte der Chronik sind nicht verhandelbar. Der Weg dorthin ist offen. Die Spieler wissen das. Sie spielen nicht gegen die Zeitleiste, sondern in ihr.

**neu:** Der Satz des Bandes lautet: Was in der Chronik des Spielleiterbuchs steht, geschieht. Wie es geschah, entscheidet der Tisch. Das ist die zentrale Regel. Die festen Punkte der Chronik sind nicht verhandelbar. Der Weg dorthin ist offen. Die Spieler wissen das. Sie spielen nicht gegen die Chronik, sondern in ihr.

### Zeile 21, Die dreißig Jahre auf einen Blick

**alt:** 1947 | Erstes Kürzel O.D.I.N., Vertrag über Kristallhoheit, Frachtbrief, Hort-1 London, stiller Hohlraum bei Kiruna (November) | 1: Frachtbrief; 2: Stille (Teil A)

**neu:** 1947 | Erstes Kürzel O.D.I.N., Vertrag über Kristallhoheit, Frachtbrief, Hort-1 London, stiller Hohlraum bei Kiruna (neu: November) | 1: Frachtbrief; 2: Stille (Teil A)

### Zeile 58, Was der Band voraussetzt

**alt:** Zum Spielen braucht die Spielleitung das Grundregelwerk und das Spielleiterbuch. Das Grundregelwerk liefert die Fertigkeiten, Proben und Schadensregeln. Das Spielleiterbuch liefert die Zeitleiste, die Organisation und die offenen Geheimnisse. Ohne diese beiden Bücher fehlt dem Band das Fundament.

**neu:** Zum Spielen braucht die Spielleitung das Grundregelwerk und das Spielleiterbuch. Das Grundregelwerk liefert die Fertigkeiten, Proben und Schadensregeln. Das Spielleiterbuch liefert die Chronik, die Organisation und die offenen Geheimnisse. Ohne diese beiden Bücher fehlt dem Band das Fundament.

## 01_spielweise.md (Sicherung vor_handoutcheck_2026-10-10)

### Zeile 5, Feste Punkte und offene Punkte

**alt:** Der Band spielt von März 1947 bis zum 14. Februar 1977, 22:10 Uhr. In dieser Zeit geschieht alles, was in der Zeitleiste des Spielleiterbuchs steht. Das ist der Satz des Bandes. Er steht über jeder Sitzung, jedem Einsatz, jeder Zwischenjahre-Szene.

**neu:** Der Band spielt von März 1947 bis zum 14. Februar 1977, 22:10 Uhr. In dieser Zeit geschieht alles, was in der Chronik des Spielleiterbuchs steht. Das ist der Satz des Bandes. Er steht über jeder Sitzung, jedem Einsatz, jeder Zwischenjahre-Szene.

### Zeile 17, Feste Punkte und offene Punkte

**alt:** Der Preis. Der Tisch kann das Wie eines festen Punktes ändern, wenn er bereit ist, dafür zu zahlen. Ein Agent, der in Kiruna einen Mann rettet, der eigentlich fallen sollte, rettet ihn. Aber jemand anderes geht an seiner Stelle. Oder der Agent trägt von da an eine Belastung. Oder ein Schützling kommt zu früh zum Einsatz. Der Preis ist nie eine Regelstrafe. Der Preis ist eine Geschichte.

**neu:** Der Preis. Der Tisch kann das Wie eines festen Punktes ändern, wenn er bereit ist, dafür zu zahlen. Ein Agent, der in Kiruna einen Mann rettet, der eigentlich fallen sollte, rettet ihn. Aber jemand anderes geht an seiner Stelle. Oder der Agent trägt von da an eine Belastung. Oder ein Schützling kommt zu früh zum Einsatz. Der Preis ist nie eine Regelstrafe. Der Preis ist eine Geschichte. Nennt ein Einsatz als Preis „Vertrauen“, meint er das Verhältnis zu dieser Figur, nicht den Vertrauenswert der Gruppe.

### Zeile 49, Die Gruppe Frachtbrief

**alt:** Die Verbindungen der Gruppe sind die Figuren der Zeit. Evelyn Marsh gibt die Einsätze des Operativen Zweigs. Sie rekrutiert nach Geschichten, nicht nach Akten. Ashgrove gibt die Einsätze der Eskorte und später des Taktischen Zweigs. Er mag den Spitznamen Hammer nicht, aber er erträgt ihn. Hallström gibt ab 1948 die Einsätze der Registratur, ab 1961 des Ermittlungszweigs. 1947 ist er selbst Ziel von Einsatz 1. Er stellt Fragen, die niemand beantworten will. Marek gibt die Einsätze der Psionen, nur bis 1970. Sie besteht auf der Kappe und sagt nicht, warum. Die Siegelwahrerinnen geben die Einsätze des Kollegiums. Sie sprechen selten, und wenn sie sprechen, dann in Kreisen.

**neu:** Die Verbindungen der Gruppe sind die Figuren der Zeit. Evelyn Marsh gibt die Einsätze des Operativen Zweigs. Sie rekrutiert nach Geschichten, nicht nach Akten. Ashgrove gibt die Einsätze der Eskorte und später des Taktischen Zweigs. Den Spitznamen Hammer, den der Flurfunk ab 1954 seinem Zweig gibt, mag er nicht, aber er erträgt ihn. Hallström gibt ab 1948 die Einsätze der Registratur, ab 1961 des Ermittlungszweigs. 1947 ist er selbst Ziel von Einsatz 1. Er stellt Fragen, die niemand beantworten will. Marek gibt die Einsätze der Psionen, nur bis 1970. Sie besteht auf der Kappe und sagt nicht, warum. Die Siegelwahrerinnen geben die Einsätze des Kollegiums. Sie sprechen selten, und wenn sie sprechen, dann in Kreisen.

### Zeile 63, Zeitsprünge und Zwischenjahre

**alt:** 1950 | Sundqvist kommt; Wendland hängt das Protokoll der Apothekerin auf | Sundqvist fragt nach den Kreisen von Kiruna

**neu:** 1950 | Sundqvist kommt; Wendland hängt das Protokoll der Apothekerin auf | Sundqvist fragt nach den Kreisen von Solberg

### Zeile 73, Zeitsprünge und Zwischenjahre

**alt:** 1968 | Lüttich; Adeyemi; Dorje stirbt; Sonderzug des Uhrmachers; die Erleuchteten | Druckerei lässt hundert Siegelringe anfertigen (GA „Zweites Licht“)

**neu:** 1968 | Lüttich; Adeyemi; Dorje stirbt; Sonderzug des Uhrmachers; die Erleuchteten | Druckerei lässt hundert Siegelringe anfertigen (GA, Akte 8 „Das Zweite Licht“)

### Zeile 98, Das Nachfolger-System

**alt:** III Kaskade | 1969 | 110 | +20 | um 150 | Senior-Agent bis Veteran

**neu:** III Kaskade | 1969 | 110 | +20 | um 150 | Veteran

### Zeile 107, Das Nachfolger-System

**alt:** Übergabe. Der Schützling übernimmt, wenn der Agent stirbt, hinübergeht, ausbrennt, in eine Stille muss, zu den Offenen wechselt, in einer Legende verschwindet oder abtritt. Seine EP sind die gesammelten Schützlings-EP, mindestens aber die Mindest-EP des laufenden Abschnitts. Dazu bekommt er ein Vermächtnis. Das Vermächtnis ist plus 1 auf eine Fertigkeit des Mentors, wenn diese auf 4 oder höher ist. Oder ein Gegenstand: ein Stück Aschesilber, auf dessen Innenseite der Name des Mentors kommt. Ein Notizbuch. Eine Kappe oder ein Helm. Ein Kristall nur mit Zustimmung des Kollegiums. Oder ein Kontakt. Oder, nach Tod oder Ruhestand, der Codename als Reihe, also Salz-2, nach dem Vorbild der Folio-Reihe. Die Übergabe ist eine Szene. Sie wird gespielt, nicht abgehakt.

**neu:** Übergabe. Der Schützling übernimmt, wenn der Agent stirbt, hinübergeht, ausbrennt, in eine Stille muss, zu den Offenen wechselt, in einer Legende verschwindet oder abtritt. Seine EP sind die gesammelten Schützlings-EP, mindestens aber die Mindest-EP des laufenden Abschnitts. Dazu bekommt er ein Vermächtnis. Das Vermächtnis ist plus 1 auf eine Fertigkeit des Mentors, wenn diese auf 4 oder höher ist. Oder ein Gegenstand: ein Stück Aschesilber, auf dessen Innenseite der Name des Mentors kommt. Ein Notizbuch. Eine Kappe oder ein Helm. Ein Kristall nur mit Zustimmung des Kollegiums. Oder ein Kontakt. Oder, nach Tod oder Ruhestand, der Codename als Reihe, also Salz-2, nach dem Vorbild der Folio-Reihe; im Ermittlungszweig wird nur Folio vererbt. Die Übergabe ist eine Szene. Sie wird gespielt, nicht abgehakt.

### Zeile 119, Das Nachfolger-System

**alt:** Thaumaturg | Lehrling des Kollegiums (Kristall nur nach Kristallbuch) | ab 1956 Chronomancer als Schüler Solheims | alle Schulen

**neu:** Thaumaturg | Lehrling des Kollegiums (Kristall nur nach Kristallbuch) | ab 1956 Chronomancer, ab etwa 1960 als Schüler Solheims | alle Schulen

### Zeile 125, Das Nachfolger-System

**neu:** Für neue Agenten und Schützlinge liegen im Heft „Nordlicht 1977: Handouts“ drei leere Vordrucke, je einer für eine Zeit: die Karteikarte von 1948 (Handout N55), der Personalbogen des Rates von 1961 (N56) und der Rechnerausdruck von 1977 (N57).

### Zeile 143, Das Dienstbuch

**alt:** Das Dienstbuch ist kein Regelwerk. Es ist ein Dokument. In der letzten Sitzung liest die Spielleitung daraus vor. Dann entscheidet jeder Spieler, wo seine Figur steht, am Samstag, 12. Februar 1977, nach der Platzhalter-Regel aus Kapitel „Die Nacht“.

**neu:** Das Dienstbuch ist kein Regelwerk. Es ist ein Dokument. In der letzten Sitzung liest die Spielleitung daraus vor. Dann entscheidet jeder Spieler, wo seine Figur steht, am Samstag, 12. Februar 1977, nach der Tauschplatz-Regel aus Kapitel „Die Nacht“.

### Zeile 166, Aufbau eines Einsatzes

**alt:** Die Kanonpunkte, die der Tisch nicht ändert. Bei Elf: Die Eskorte geht mit 14 Mann in den Stollen. Drei überleben. Elf Soldaten kommen nicht zurück. Das Kollegium schickt zwei Thaumaturgen. Einer zieht den Bannkreis, antwortet und bleibt drüben; der andere spricht nie wieder über Kiruna. Die Maske wird gefunden. Am 12. März führt Hallström die Weiße Akte ein. Ashgrove überlebt und schreibt die Namen nicht auf.

**neu:** Die Kanonpunkte, die der Tisch nicht ändert. Bei Elf: Die Eskorte geht mit 14 Mann in den Stollen. Drei überleben. Elf Soldaten kommen nicht zurück. Das Kollegium schickt zwei Thaumaturgen. Einer zieht einen Kreis, der kein Bannkreis ist, antwortet dem Ding in der Wand und bleibt drüben; der andere spricht nie wieder über Kiruna. Die Maske wird gefunden. Am 12. März führt Hallström die Weiße Akte ein. Ashgrove überlebt und schreibt die Namen nicht auf.

### Zeile 177, Regeln am Tisch

**alt:** Proben werden immer genannt als Fertigkeit gegen Schwierigkeit, mit einer Zahl in Klammern. Die Namen kommen aus dem Grundregelwerk. Die Schwierigkeiten sind Stufen von Einfach (1) bis Unmöglich (5). Wahrnehmung gegen Machbar (2). Athletik gegen Schwer (3). Okkultismus gegen Sehr schwer (4). Keine neuen Regeln.

**neu:** Proben werden immer genannt als Fertigkeit gegen Schwierigkeit, mit einer Zahl in Klammern. Die Namen kommen aus dem Grundregelwerk. Die Schwierigkeiten sind Stufen von Einfach (1) bis Unmöglich (5). Wahrnehmung gegen Machbar (2). Athletik gegen Schwer (3). Okkultismus gegen Sehr schwer (4). Keine neuen Probenregeln.

## 02_epoche.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 25, Ränge und Anrede

**alt:** Für die Spieler heißt das: Im ersten Abschnitt sind sie Kriegsheimkehrer, Wissenschaftler, Psionen, Thaumaturgen. Sie haben Namen, keine Nummern. Im zweiten Abschnitt bekommen sie Titel. Im dritten Abschnitt sind sie Senior-Agenten und Veteranen. Im vierten Abschnitt einzelne Schattenoffiziere.

**neu:** Für die Spieler heißt das: Im ersten Abschnitt sind sie Kriegsheimkehrer, Wissenschaftler, Psionen, Thaumaturgen. Sie haben Namen, keine Nummern. Im zweiten Abschnitt bekommen sie Titel. Im dritten Abschnitt sind sie Veteranen. Im vierten Abschnitt einzelne Schattenoffiziere.

### Zeile 116, Brandmunition ab 1953

**alt:** Vor der ersten Charge im Herbst 1953 gilt die Kiruna-Regel. Danach gibt der Rüstmeister ein Magazin je Einsatz aus. Brandmunition wirkt gegen die Stimme, nicht gegen Tote oder Fremde. Gegen Tote hilft sie so wenig wie gewöhnliche Munition. Gegen Fremde hilft nur, was die Spielleitung für den einzelnen Fremden festlegt.

**neu:** Vor der ersten Charge im Herbst 1953 gilt die Kiruna-Regel. Danach gibt der Rüstmeister ein Magazin je Einsatz aus. Brandmunition wirkt gegen die Stimme, nicht gegen Tote oder Fremde. Gegen Tote hilft sie so wenig wie gewöhnliche Munition. Gegen Fremde wirken gewöhnliche Waffen voll; Brandmunition hilft nicht besser.

### Zeile 119, Brandmunition ab 1953

**alt:** Vor der ersten Charge Brandmunition im Herbst 1953 verursachen gewöhnliche Waffen gegen Wesen aus Rissen keinen Schaden. Schutz bieten nur Bannkreise, Zauber und Rückzug. Salz hält vielleicht auf. Niemand weiß, ob es nicht doch geholfen hat. Wer in Kiruna dabei war, sagt nichts. Wer überlebt hat, zählt die Namen.

**neu:** Vor der ersten Charge Brandmunition im Herbst 1953 verursachen gewöhnliche Waffen gegen Wesen aus Rissen keinen Schaden. Schutz bieten nur Bannkreise, Zauber und Rückzug. Salz hält vielleicht auf. Niemand weiß, ob es nicht doch geholfen hat. Wer in Kiruna dabei war, sagt nichts. Wer überlebt hat, zählt die Namen. Ab Herbst 1953 gelten für gewöhnliche Waffen die Werte des Bedrohungsatlas.

### Zeile 132, Subklassen nach Jahr

**alt:** Agent | Infiltrator, Negotiator, Assassin, Spy, Saboteur | Keine neuen Subklassen im Band

**neu:** Agent | Infiltrator, Negotiator, Assassin, Spy; Saboteur ab 1957 (Werkstatt Graz) | Keine neuen Subklassen im Band

### Zeile 145, Subklassen nach Jahr

**alt:** Fertigkeiten: +1 Schusswaffen, +1 Ausdauer, +1 Taktik.

**neu:** Fertigkeiten: +2 Schusswaffen, +1 Ausdauer, +1 Taktik.

### Zeile 163, Tauschliste für die Startausrüstung

**neu:** Sturmgewehr, Kampfanzug mit Helm, Hochexplosiv-Granaten | Karabiner oder Maschinenpistole, Stahlhelm, Handgranaten der Zeit | Sturmgewehre erst 1977

**neu:** Leichte Rüstung, Schleichrüstung | Wie Schutzweste | Je nach Jahr

**neu:** Bio-Scanner, tragbarer Scanner | Mikroskop, Lupe, Spurensicherungskoffer | Kein Scanner im Feld

**neu:** Dokumentenscanner | Minox oder Kleinbildkamera | Fotografiert auf Film

**neu:** Verstärktes Kommunikationsgerät | Feldtelefon oder Kurzwellenfunk | Je nach Einsatzort

**neu:** Vorhersagegerät, Datenkristall | Entfällt | Existiert vor 1977 nicht

### Zeile 191, Tauschliste für die Startausrüstung

**alt:** Mental-Fokusgerät | Kappe oder Helm | Je nach Jahr

**neu:** Mental-Fokusgerät, Neuro-Helm | Vor 1949 keiner, jede Psi-Probe ist dann eine Stufe schwerer; ab 1949 Kappe, ab 1963 Mk. I, ab 1972 Mk. II | Die Kappe schützt nicht gegen psionische Angriffe

### Zeile 206, Geld und Spesen

**alt:** Sold und Spesen folgen den Regeln des Grundregelwerks, angepasst an die Zeit. Vor 1961 gibt es keine Rangleiter, der Sold richtet sich nach Abschnitt: im ersten Abschnitt der Sold eines Agenten, 4.500 Euro im Monat, im zweiten bis 1961 der eines Senior-Agenten, 6.000 Euro. Ab 1961 gilt der Sold nach Rang wie im Grundregelwerk. Spesen gibt kein Führungsoffizier frei, sondern Marsh, Ashgrove, Hallström oder der Rat. Spesen für eine Weiße Akte betragen 500 Euro, für eine Graue 2.000, für eine Rote 10.000. Für eine Schwarze Akte gilt: So viel wie nötig. Jede Quittung landet bei der Revision.

**neu:** Sold und Spesen folgen den Regeln des Grundregelwerks, angepasst an die Zeit. Vor 1961 gibt es keine Rangleiter, der Sold richtet sich nach Abschnitt: im ersten Abschnitt der Sold eines Agenten, 4.500 Euro im Monat, im zweiten bis 1961 der eines Senior-Agenten, 6.000 Euro. Ab 1961 gilt der Sold nach Rang wie im Grundregelwerk. Freigaben und Anforderungen richten sich auch vor 1961 nach den gesammelten EP wie im Grundregelwerk; es fehlen nur Titel und Anrede. Spesen gibt kein Führungsoffizier frei, sondern Marsh, Ashgrove, Hallström oder der Rat. Spesen für eine Weiße Akte betragen 500 Euro, für eine Graue 2.000, für eine Rote 10.000. Für eine Schwarze Akte gilt: So viel wie nötig. Jede Quittung landet bei der Revision.

## 03_figuren.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 51, Viktor Hallström

**alt:** Hallström ist ein Mann der Akten. Er trägt graue Anzüge, eine Lupe in der Brusttasche, eine Salzdose in der Manteltasche. Seine Hände sind ruhig. Seine Stimme ist leise und präzise. Er stellt Fragen, auf die er die Antwort schon kennt. Er hört zu, ohne zu unterbrechen. Er notiert in schwarze Wachstuchhefte, einundsechzig Stück bis 1979. Er weigert sich, einen Computer anzufassen. Sein Stahlschrank hat zwei Schlösser und zwei Fächer. Im zweiten liegen Notizbuch null, die Seite von 1871, die Schwarze Akte Nordlicht mit dem Vergleich der beiden Uhrzeiten, Sanders Brief von 1957.

**neu:** Hallström ist ein Mann der Akten. Er trägt graue Anzüge, eine Lupe in der Brusttasche, eine Salzdose in der Manteltasche. Seine Hände sind ruhig. Seine Stimme ist leise und präzise. Er stellt Fragen, auf die er die Antwort schon kennt. Er hört zu, ohne zu unterbrechen. Er notiert in schwarze Wachstuchhefte, einundsechzig Stück, von 1938 bis 1985. Er weigert sich, einen Computer anzufassen. Sein Stahlschrank hat zwei Schlösser und zwei Fächer. Im zweiten liegen Notizbuch null, die Seite von 1871, die Schwarze Akte Nordlicht mit dem Vergleich der beiden Uhrzeiten, Sanders Brief von 1957.

### Zeile 83, Thomas Ashgrove

**alt:** Ashgrove ist ein Mann des Befehls. Er trägt Uniform, auch wenn es keine gibt. Seine Stimme ist ruhig, tief, ohne Eile. Er spricht selten über Gefühle, nie über Angst. Er nennt die Männer beim Namen, nicht beim Rang. Er isst mit ihnen, schläft neben ihnen, trägt die Verwundeten selbst. Er mag den Spitznamen „Hammer“ nicht. Er sagt: „Ein Hammer zerbricht. Ich will nicht zerbrechen.“ 1955 bekommt er das Messer Nr. 1 aus Aschesilber. Er trägt es bis 1988. Er sagt, es ist warm. Er sagt, das gibt sich. Es hat sich nicht gegeben.

**neu:** Ashgrove ist ein Mann des Befehls. Er trägt Uniform, auch wenn es keine gibt. Seine Stimme ist ruhig, tief, ohne Eile. Er spricht selten über Gefühle, nie über Angst. Er nennt die Männer beim Namen, nicht beim Rang. Er isst mit ihnen, schläft neben ihnen, trägt die Verwundeten selbst. Er mag den Spitznamen nicht, den der Flurfunk ab 1954 seinem Zweig gibt: „Hammer“. Er sagt: „Ein Hammer kennt nur ein Problem.“ 1955 bekommt er das Messer Nr. 1 aus Aschesilber. Er trägt es bis 1988. Er sagt, es ist warm. Er sagt, das gibt sich. Es hat sich nicht gegeben.

### Zeile 117, Evelyn Marsh

**alt:** Marsh gibt der Gruppe die Tarnung. Sie zeigt, wie man verschwindet, wie man lügt, wie man überlebt. Sie nimmt den Spielern die Naivität, indem sie zeigt, was Tarnung kostet. Sie nimmt ihnen die Sicherheit, indem sie zeigt, dass niemand die ganze Wahrheit kennt. Sie tritt auf in den Einsätzen 1, 3, 7, 8, 9 und 11. Meist als Stimme, als Brief, als Frau, die am Rand steht und zuschaut.

**neu:** Marsh gibt der Gruppe die Tarnung. Sie zeigt, wie man verschwindet, wie man lügt, wie man überlebt. Sie nimmt den Spielern die Naivität, indem sie zeigt, was Tarnung kostet. Sie nimmt ihnen die Sicherheit, indem sie zeigt, dass niemand die ganze Wahrheit kennt. Sie tritt auf in den Einsätzen 1, 3, 7, 8, 9, 10 und 11. Meist als Stimme, als Brief, als Frau, die am Rand steht und zuschaut.

### Zeile 217, Astrid Solheim

**alt:** 1947 ist Astrid dreizehn. Sie lebt in Bergen, lernt das Uhrmacherhandwerk. 1954 findet sie den Kristall. 1956 tritt sie ins Kollegium ein. Penhallow stellt die Regel auf: jeder Chronomancer nur unter Aufsicht eines zweiten. Astrid hält sich daran, meistens. In den Sechzigern wird sie zur Lehrerin. Sie bildet eine Handvoll Schüler aus, alle Chronomancer. Sie entwirft die Zeitmessanlage für Nordlicht. Sie arbeitet für den Stützpunkt, ist aber nicht stationiert. Sie steht nicht auf dem Dienstplan. 1977, am 14. Februar, sitzt sie mit Ingrid im verspäteten Zug nach Narvik. Um 22:10 läuft Ingrids Taschenuhr in unter einer Minute eine ganze Nacht ab. Astrid kommt gut drei Stunden zu spät.

**neu:** 1947 ist Astrid dreizehn. Sie lebt in Bergen, lernt das Uhrmacherhandwerk. 1954 findet sie den Kristall. 1956 tritt sie ins Kollegium ein. Penhallow stellt die Regel auf: jeder Chronomancer nur unter Aufsicht eines zweiten. Astrid hält sich daran, meistens. In den Sechzigern wird sie zur Lehrerin. Sie bildet eine Handvoll Schüler aus, alle Chronomancer. Sie entwirft die Zeitmessanlage für Nordlicht. Sie arbeitet für den Stützpunkt, ist aber nicht stationiert. Sie steht nicht auf dem Dienstplan. 1977, am 14. Februar, sitzt sie mit Ingrid im verspäteten Zug nach Narvik. Um 22:10 läuft die Taschenuhr in Ingrids Hand in unter einer Minute eine ganze Nacht ab. Astrid kommt gut drei Stunden zu spät.

### Zeile 239, Weitere Figuren

**alt:** [table Name | Rolle | Einsätze @ 30 40 30]

**neu:** [table Name | Rolle | Passt in Einsatz @ 30 40 30]

### Zeile 249, Weitere Figuren

**alt:** Martin Hofer | Ingenieur, baut Prototyp 0417 | 9, 10, 11, 12

**neu:** Dr. Martin Hofer | Physicist des Instituts, baut den Detektor 0417 | 9, 10, 11, 12

### Zeile 272, Weitere Figuren

**alt:** Diese Figuren sind keine festen Größen wie die Porträts. Sie können in den Einsätzen auftreten, Informationen geben, die Gruppe begleiten oder behindern. Ihre Schicksale stehen im Kanon. Die Spielleitung nutzt sie als Nebenfiguren, als Zeugen, als Stimmen am Rand. Sie füllen die Welt, ohne sie zu tragen.

**neu:** Diese Figuren sind keine festen Größen wie die Porträts. Sie können in den Einsätzen auftreten, Informationen geben, die Gruppe begleiten oder behindern. Ihre Schicksale stehen im Kanon. Die Spielleitung nutzt sie als Nebenfiguren, als Zeugen, als Stimmen am Rand. Sie füllen die Welt, ohne sie zu tragen. Die Spalte nennt Einsätze, in die eine Figur passt; in den Einsatztexten steht sie nicht immer.

## 04_gruendung.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 51, Was wirklich geschah

**alt:** - **Der Frachtbrief mit dem Kürzel O.D.I.N. existiert und kommt quittiert nach London zurück.** Die Spielleitung hält das, indem der Brief nach der Quittung durch einen Boten nach London geht, egal ob die Gruppe zusieht oder nicht. Wenn die Gruppe den Brief verliert, taucht eine Kopie auf, die jemand in Stockholm anfertigte. Der Preis: Marsh verliert Vertrauen, die Gruppe bekommt für den nächsten Einsatz weniger Vorschuss.

**neu:** - **Der Frachtbrief mit dem Kürzel O.D.I.N. existiert und kommt quittiert nach London zurück.** Die Spielleitung hält das, indem der Brief nach der Quittung durch einen Boten nach London geht, egal ob die Gruppe zusieht oder nicht. Wenn die Gruppe den Brief verliert, taucht eine Kopie auf, die jemand in Stockholm anfertigte. Der Preis: Marsh traut der Gruppe weniger, und sie bekommt für den nächsten Einsatz weniger Vorschuss.

### Zeile 60, Was wirklich geschah

**alt:** - **Wie die Kiste reist.** Per Lastwagen, Schiff oder Zug. Entscheidet die Gruppe, den Landweg über Dänemark und Schweden zu nehmen, mit der Fähre von Harwich nach Esbjerg, verlängert sich der Einsatz und der Sammler hat mehr Chancen. Entscheidet sie die Seeroute, spielt die Überfahrt über Nordsee und Skagerrak. Dienstbucheintrag: Transportweg, Zwischenfälle.

**neu:** - **Wie die Kiste reist.** Per Lastwagen, Schiff oder Zug. Entscheidet die Gruppe, den Landweg über Dänemark und Schweden zu nehmen, mit der Fähre von Harwich nach Esbjerg, verlängert sich der Einsatz und der Sammler hat mehr Chancen. Beim Landweg spielt Knoten 4 auf der Fähre nach Esbjerg, den Zollbegleitschein (N4) stellt der schwedische Zoll in Helsingborg aus, und die Konfrontation findet nachts im Fährhafen von Helsingborg statt. Entscheidet sie die Seeroute, spielt die Überfahrt über Nordsee und Skagerrak. Dienstbucheintrag: Transportweg, Zwischenfälle.

### Zeile 81, Viktor Hallström, 46

**alt:** Kriminalinspektor aus Stockholm, seit 1938 mit Akte Null. Will wissen, wer hinter O.D.I.N. steckt. Weiß, dass es das Haus ohne Nummer gibt, verschweigt, dass er seit acht Jahren eine private Akte führt. Redet schwedisch-schweres Englisch, stellt Fragen, die er selbst beantwortet.

**neu:** Kriminalinspektor aus Stockholm, seit 1938 mit Akte Null. Will wissen, wer hinter O.D.I.N. steckt. Weiß, dass es das Haus ohne Nummer gibt, verschweigt, dass er seit neun Jahren eine private Akte führt. Redet schwedisch-schweres Englisch, stellt Fragen, die er selbst beantwortet.

### Zeile 179, Eskalation

**alt:** Bekommt der Sammler die Kiste, öffnet er sie nicht. Er will sie nach Zürich bringen, in eine Villa mit Vitrinen. So weit kommt er nicht, denn der feste Punkt hält: Am Dienstag steht der junge Mann im grauen Mantel an der Centralstation, am Zug nach Süden, und nimmt die Kiste an sich, ohne dass die Gruppe sieht, wie (Umweg aus dem Kasten WAS FESTSTEHT). Den Frachtbrief findet die Gruppe am nächsten Morgen quittiert in ihrem Postlager. Der Preis: Marsh verliert Vertrauen, und der Sammler weiß jetzt, wofür er in späteren Jahren bietet.

**neu:** Bekommt der Sammler die Kiste, öffnet er sie nicht. Er will sie nach Zürich bringen, in eine Villa mit Vitrinen. So weit kommt er nicht, denn der feste Punkt hält: Am Dienstag steht der junge Mann im grauen Mantel an dem Bahnhof, an dem der Sammler den Zug nach Süden besteigt, und nimmt die Kiste an sich, ohne dass die Gruppe sieht, wie (Umweg aus dem Kasten WAS FESTSTEHT). Den Frachtbrief findet die Gruppe am nächsten Morgen quittiert in ihrem Postlager. Der Preis: Marsh verliert Vertrauen, und der Sammler weiß jetzt, wofür er in späteren Jahren bietet.

### Zeile 196, Lösungen

**alt:** - **Ohne Kampf:** Ein Agent mit Verhandeln oder Täuschung gegen Schwer (3) überzeugt den Sammler, dass die Kiste wertlos ist, eine Falle, ein leeres Blei. Er vergleicht seine Würfel mit dem Überzeugen und der Täuschung des Sammlers (5 + 4). Gelingt die Probe, lacht der Sammler leise, zieht seinen Mantel zurecht und geht. Er sagt: „Wir sehen uns wieder.“ Die Söldner folgen ihm in den Nebel. Die Gruppe verliert eine Stunde, weil sie einen anderen Weg zum Lastwagen nehmen muss.

**neu:** - **Ohne Kampf:** Ein Agent legt eine vergleichende Probe mit Verhandeln oder Täuschung gegen Überzeugen und Täuschung des Sammlers (5 + 4) ab und überzeugt ihn, dass die Kiste wertlos ist, eine Falle, ein leeres Blei. Gelingt die Probe, lacht der Sammler leise, zieht seinen Mantel zurecht und geht. Er sagt: „Wir sehen uns wieder.“ Die Söldner folgen ihm in den Nebel. Die Gruppe verliert eine Stunde, weil sie einen anderen Weg zum Lastwagen nehmen muss.

### Zeile 202, Söldner des Sammlers

**alt:** [entry - | Söldner des Sammlers | Profi · Menschen]

**neu:** [entry - | Söldner des Sammlers | Handlanger · Menschen]

### Zeile 339, Knoten 1: Die Grube und der Hohlraum

**alt:** November 1947, Polarnacht. Ein Förderkorb fährt in die Tiefe, der Grubenleiter führt die Gruppe durch nasse Strecken zu Sohle 5, Ort 12 (Karte K3). In seinen Papieren liegt die Meldung an das Bergamt (Handout N5). Bergleute mit Karbidlampen warten vor dem Hohlraum, ein Grubenhund liegt davor. Dahinter eine runde Höhle mit mattgrauen Wänden, auf einem Stein eine stehengebliebene Taschenuhr.

**neu:** November 1947, kurz vor der Polarnacht. Ein Förderkorb fährt in die Tiefe, der Grubenleiter führt die Gruppe durch nasse Strecken zu Sohle 5, Ort 12 (Karte K3). In seinen Papieren liegt die Meldung an das Bergamt (Handout N5). Bergleute mit Karbidlampen warten vor dem Hohlraum, ein Grubenhund liegt davor. Dahinter eine runde Höhle mit mattgrauen Wänden, auf einem Stein eine stehengebliebene Taschenuhr.

### Zeile 342, Knoten 1: Die Grube und der Hohlraum

**alt:** - **Hinweis:** Die Bergleute erzählen, dass das Funkgerät im Hohlraum nur rauscht und dass der Grubenhund nicht der erste Hund ist, der sich dort hingelegt hat. Agent: Menschenkenntnis gegen Machbar (2). (führt zu: Der Hohlraum ist eine Anomalie)

**neu:** - **Hinweis:** Die Bergleute erzählen, dass das Funkgerät im Hohlraum nicht einmal rauscht und dass der Grubenhund nicht der erste Hund ist, der sich dort hingelegt hat. Agent: Menschenkenntnis gegen Machbar (2). (führt zu: Der Hohlraum ist eine Anomalie)

### Zeile 397, Eskalation

**alt:** Betritt jemand den Hohlraum, verlangt die Spielleitung eine Grauen-Probe gegen Unheimlich (1). Wer die Probe verpatzt, erleidet Belastung und will den Raum sofort verlassen. Wer länger als eine Minute bleibt, würfelt Konzentration gegen Sehr schwer (4). Misslingt die Probe, legt sich der Charakter hin und atmet kaum noch. Die anderen holen ihn mit einem Seil heraus, ohne selbst hineinzugehen. Draußen atmet er nach einigen Sekunden wieder tief, die Uhr am Handgelenk läuft weiter, als wäre nichts geschehen.

**neu:** Betritt jemand den Hohlraum, verlangt die Spielleitung eine Grauen-Probe gegen Unheimlich (1). Wer die Probe nicht besteht, erleidet Belastung und will den Raum sofort verlassen. Wer länger als eine Minute bleibt, würfelt Konzentration gegen Sehr schwer (4). Misslingt die Probe, legt sich der Charakter hin und atmet kaum noch. Die anderen holen ihn mit einem Seil heraus, ohne selbst hineinzugehen. Draußen atmet er nach einigen Sekunden wieder tief, die Uhr am Handgelenk läuft weiter, als wäre nichts geschehen.

### Zeile 413, Ablauf

**alt:** 3. Die Menge dreht sich im selben Augenblick. Die Spielleitung verlangt eine Grauen-Probe gegen Verstörend (2) für jeden, der es sieht. Wer die Probe verpatzt, erleidet Belastung und will nur noch fort.

**neu:** 3. Die Menge dreht sich im selben Augenblick. Die Spielleitung verlangt eine Grauen-Probe gegen Verstörend (2) für jeden, der es sieht. Wer die Probe nicht besteht, erleidet Belastung und will nur noch fort.

### Zeile 437, Die Menge

**alt:** **Grauen** | Unheimlich (1), wenn sie sich alle gleichzeitig umdrehen

**neu:** **Grauen** | Verstörend (2), wenn sie sich alle gleichzeitig umdrehen

### Zeile 460, Nachspiel

**alt:** **Bis zum nächsten Einsatz:** 1950 kommt Greta Sundqvist in die Registratur und fragt nach den Kreisen von Kiruna; Marek schreibt Wendland: „Wir bauen ihnen keine Käfige …“ 1951 tötet Lerche in Göteborg drei Männer eines fremden Dienstes, ab Sommer bekommt jeder Psion einen Beobachter. 1952 trägt Lerche den ersten Sperrhelm. Legendenbüro und Hundemeldung folgen erst in Einsatz 3 und danach. Jede dieser Szenen ist ein kurzes Zwischenspiel, keine eigene Mission.

**neu:** **Bis zum nächsten Einsatz:** 1950 kommt Greta Sundqvist in die Registratur und fragt nach den Kreisen von Solberg; Marek schreibt Wendland: „Wir bauen ihnen keine Käfige …“ 1951 tötet Lerche in Göteborg drei Männer eines fremden Dienstes, ab Sommer bekommt jeder Psion einen Beobachter. 1952 trägt Lerche den ersten Sperrhelm. Legendenbüro und Hundemeldung folgen erst in Einsatz 3 und danach. Jede dieser Szenen ist ein kurzes Zwischenspiel, keine eigene Mission.

### Zeile 613, Knoten 3: Der Hof in Leipzig

**alt:** - **Hinweis:** Der Schuster trägt einen Lederbeutel um den Hals, der bei Berührung warm ist. Ein Scientist erkennt mit Physik gegen Schwer (3), dass der Splitter darin leichter ist, als er sein dürfte. (führt zu: der verlorene Kristall des Kollegiums)

**neu:** - **Hinweis:** Der Schuster trägt einen Lederbeutel um den Hals, der bei Berührung warm ist. Ein Scientist erkennt mit Physik gegen Schwer (3), dass der Splitter darin leichter ist, als er sein dürfte. (führt zu: der verlorene Kristall des Kollegiums; Der Splitter hält den Namensfresser)

### Zeile 636, Knoten 5: Die junge Staatssicherheit

**alt:** - **Hinweis:** In seiner Kartei liegt ein Foto der Gruppe, aufgenommen vom Beobachtungsposten. (führt zu: der Beobachtungsposten) Ein Agent findet das mit Wahrnehmung gegen Schwer (3).

**neu:** - **Hinweis:** In seiner Kartei liegt ein Foto der Gruppe, aufgenommen vom Beobachtungsposten. (führt zu: Die junge Staatssicherheit beobachtet den Hof) Ein Agent findet das mit Wahrnehmung gegen Schwer (3).

### Zeile 646, Knoten 6: Westberlin, Notaufnahmestelle

**alt:** - **Hinweis:** Der Onkel aus Salzgitter hat einen Vordruck für neue Papiere bei sich. Das Feld für den Namen ist noch leer. (führt zu: der Name wird abgelegt) Ein Agent findet das mit Wahrnehmung gegen Schwer (3) oder mit Fingerfertigkeit gegen Schwer (3), ein Investigator mit Wahrnehmung gegen Machbar (2).

**alt:** - **Hinweis:** Die Frau am Schalter sagt: „Die Familie ist nach Niedersachsen geschickt worden. Wohin genau, steht nicht in meiner Kartei.“ (führt zu: die Spur endet) Ein Agent findet das mit Überzeugen gegen Machbar (2).

**neu:** - **Hinweis:** Der Onkel aus Salzgitter hat einen Vordruck für neue Papiere bei sich. Das Feld für den Namen ist noch leer. (führt zu: Die Spur des Mädchens endet in Westberlin) Ein Agent findet das mit Wahrnehmung gegen Schwer (3) oder mit Fingerfertigkeit gegen Schwer (3), ein Investigator mit Wahrnehmung gegen Machbar (2).

**neu:** - **Hinweis:** Die Frau am Schalter sagt: „Die Familie ist nach Niedersachsen geschickt worden. Wohin genau, steht nicht in meiner Kartei.“ (führt zu: Die Spur des Mädchens endet in Westberlin) Ein Agent findet das mit Überzeugen gegen Machbar (2).

### Zeile 655, Knoten 6: Westberlin, Notaufnahmestelle

**neu:** - **Der Splitter hält den Namensfresser im Hof; in Blei verschlossen, verliert er den Halt.** Hinweise: Der Schuster trägt einen warmen Splitter im Lederbeutel (Knoten 3). Die Schusterkinder, die dem Beutel am nächsten sind, verloren ihre Namen zuerst (Knoten 3). Marsh gibt das Bleikästchen „für alles, was flüstert“ mit (Briefing).

### Zeile 667, Eskalation

**alt:** **Stufe 3: Vorladung.** Der Verbindungsoffizier der jungen Staatssicherheit lädt die Gruppe in sein Büro in der Leipziger Innenstadt, Tür ohne Schild, zwei Stockwerke, ein Raum mit Kartei. Er fragt nach dem Zweck der Reise, dem Interesse am Hof, der Familie. Wer sich in Widersprüche verwickelt, bleibt 48 Stunden in einer Zelle im Polizeipräsidium. Danach wird die Gruppe ausgewiesen. Die Kamera und die Filme sind beschlagnahmt. Das Foto gibt es trotzdem: Ein Agent hat den ersten Film nach dem ersten Besuch aus der Leica genommen und im Mantelfutter versteckt, die Volkspolizei findet nur den zweiten (Umweg).

**neu:** **Stufe 3: Vorladung.** Der Verbindungsoffizier der jungen Staatssicherheit lädt die Gruppe in sein Büro in der Leipziger Innenstadt, Tür ohne Schild, zwei Stockwerke, ein Raum mit Kartei. Er fragt nach dem Zweck der Reise, dem Interesse am Hof, der Familie. Wer sich in Widersprüche verwickelt, bleibt 48 Stunden in einer Zelle im Polizeipräsidium. Danach wird die Gruppe mit der Auflage entlassen, die DDR binnen einer Woche zu verlassen; ausgewiesen wird sie erst nach der Konfrontation im Hof. Die Kamera und die Filme sind beschlagnahmt. Das Foto gibt es trotzdem: Ein Agent hat den ersten Film nach dem ersten Besuch aus der Leica genommen und im Mantelfutter versteckt, die Volkspolizei findet nur den zweiten (Umweg).

### Zeile 700, Namensfresser

**alt:** Ein Wesen der Stimme, das dem Ton Elsters nach Leipzig gefolgt ist und sich im Hinterhof festgesetzt hat, weil der Splitter des Kollegiums es anzieht wie ein offenes Fenster. Es frisst zuerst die Namen der Schusterkinder. Es spricht Menschen mit ihren eigenen Stimmen an. Es hat kein Gesicht, das man behalten kann.

**neu:** Ein Wesen der Stimme, das in Leipzig dem Ton Elsters gefolgt ist und sich im Hinterhof festgesetzt hat, weil der Splitter des Kollegiums es anzieht wie ein offenes Fenster. Es frisst zuerst die Namen der Schusterkinder. Es spricht Menschen mit ihren eigenen Stimmen an. Es hat kein Gesicht, das man behalten kann.

### Zeile 718, Verbindungsoffizier eines Partnerdienstes

**alt:** **Initiative** | 4

**neu:** **Initiative** | 3

### Zeile 766, Nachspiel

**alt:** - N11: Legendenblatt „Renate Albers“ mit Passvordruck, Fundort: im Schrank des Kinderzimmers, Knoten 1.

**neu:** - N11: Legendenblatt „Renate Albers“ mit Passvordruck. Es ist das Leben, das das Kinderzimmer für das Mädchen aus Leipzig schreibt, keine Legende für die Gruppe. Fundort: im Schrank des Kinderzimmers, Knoten 1, erst wenn die Gruppe nach dem ersten Besuch wieder in Zürich ist.

### Zeile 852, Briefing

**alt:** **Was die Gruppe bekommt:** Einen Zugpass nach Kiruna, eine Karte der Grube, die den Stollen nicht zeigt (Karte K3), Spesen in schwedischen Kronen.

**neu:** **Was die Gruppe bekommt:** Einen Zugpass nach Kiruna, eine Karte der Grube, die den Stollen nicht zeigt (von Karte K3 zeigt die Spielleitung nur Förderkorb, Hauptstollen und Hohlraum), Spesen in schwedischen Kronen.

### Zeile 987, Hybridhunde von Kiruna

**alt:** **Besonderheit** | Rudel von 4 bis 6, als Trupp nach den Regeln des Grundregelwerks. Regenerieren 1 LP pro Runde. Riechen Blut über einen Kilometer

**neu:** **Besonderheit** | Rudel von 3 bis 6, als Trupp nach den Regeln des Grundregelwerks. Regenerieren 1 LP pro Runde. Riechen Blut über einen Kilometer

### Zeile 1016, Kristallwächter von Kiruna

**alt:** **Schwäche** | Gewöhnliche Waffen verursachen keinen Schaden (Kiruna-Regel). Die Stimmgabel von Wales lässt sie für eine Runde erstarren

**neu:** **Schwäche** | Gewöhnliche Waffen verursachen keinen Schaden (Kiruna-Regel). Die Stimmgabel von Wales lässt sie für eine Runde erstarren; sie liegt 1953 in der Kammer und kommt nur mit, wenn ein Thaumaturg sie beim Kollegium anfordert (Preis: jeder Psion in 100 m erleidet 2 Belastung)

### Zeile 1029, Nachspiel

**alt:** **Erfahrung:** Rote Akte: 5 EP, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, plus 1 für jeden aufgenommenen Faden. Dauer: zwei bis drei Sitzungen.

**neu:** **Erfahrung:** Rote Akte: 5 EP, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, plus 1 für jeden aufgenommenen Faden. Aufgenommene Fäden sind: die Maske, Ashgroves Kompass, der Name Solheim (Narvik). Dauer: zwei bis drei Sitzungen.

### Zeile 1033, Nachspiel

**alt:** **Übergabe:** Jeder Spieleragent, der drüben ist, ist aus dem Spiel. Sein Schützling übernimmt mit den gesammelten Schützlings-EP, mindestens aber mit den Mindest-EP des laufenden Abschnitts, und mit einem Vermächtnis nach den Regeln des Kampagnenplans.

**neu:** **Übergabe:** Jeder Spieleragent, der drüben ist, ist aus dem Spiel. Sein Schützling übernimmt mit den gesammelten Schützlings-EP, mindestens aber mit den Mindest-EP des laufenden Abschnitts, und mit einem Vermächtnis nach den Regeln des Nachfolger-Systems (Kapitel 2).

### Zeile 1071, 1950: Sundqvist und das Protokoll

**alt:** Sundqvist fragt nach den Kreisen von Kiruna. Sie will wissen, ob die Anordnung der Plättchen auf der Kappe mit den Kreisen an der Wand von Solberg übereinstimmt.

**neu:** Sundqvist fragt nach den Kreisen von Solberg. Sie will wissen, ob die Anordnung der Plättchen auf der Kappe mit den Kreisen an der Wand von Solberg übereinstimmt.

## 05_silber.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 145, Knoten 7: Der alte Bruch, nachts

**alt:** 3. Aschesilber berührt die Toten, aber nur mit einem Namen auf der Innenseite. (Hinweise: N18 Randnotiz „Name hält“, das Stück wird ruhig mit eingeritztem Namen, Ashgrove bemerkt die Unruhe ohne Namen)

**neu:** 3. Aschesilber berührt die Toten, aber nur mit einem Namen auf der Innenseite. (Hinweise: N18 Randnotiz „Name hält“, das Stück wird ruhig mit eingeritztem Namen, Knoten 4: das Stück wird ohne Namen unruhig und mit eingeritztem Namen ruhig, Knoten 7: das Stück mit Namen bleibt am Bruch gleichmäßig warm)

### Zeile 151, Eskalation

**alt:** Wenn die Gruppe zu langsam ist, passiert nichts Spektakuläres. Die Wartende wartet. Aber die Rufer werden lauter. Jede Nacht, die die Gruppe im Tal verbringt, erhöht den Druck: Alle Agenten, die den Ruf hören, machen eine Grauen-Probe gegen **Unheimlich (1)**. Wer antwortet, erleidet 1 Belastung und hört eine Woche lang den eigenen Namen im Schlaf.

**neu:** Wenn die Gruppe zu langsam ist, passiert nichts Spektakuläres. Die Wartende wartet. Aber die Rufer werden lauter. Jede Nacht, die die Gruppe im Tal verbringt, erhöht den Druck: Wer die Rufer zum ersten Mal hört, macht eine Grauen-Probe gegen **Unheimlich (1)**. Jede weitere Nacht verlangt von jedem, der den Ruf hört, WK + Geistige Widerstandskraft gegen Machbar (2), sonst 1 Belastung. Wer antwortet, erleidet 1 Belastung und hört eine Woche lang den eigenen Namen im Schlaf.

### Zeile 170, Ablauf in nummerierten Schritten

**alt:** 6. Das Silberstück bleibt warm und ruhig. Es trägt fortan den Namen des Toten.

**neu:** 6. Das Silberstück bleibt warm und ruhig. Einen Namen trägt es nur, wenn die Gruppe ihn selbst einritzt.

### Zeile 228, Nachspiel

**alt:** Wenn Vaughan am Tisch ist: Ihre Großmutter hielt 1909 in Cwm Llwyd Wache. Vaughan kennt die Geschichten der Toten und der Wartenden aus Erzählungen. Die Spielleitung gibt ihr diesen Faden als persönliche Belastung, nicht als Handout.

**neu:** Wenn Vaughan am Tisch ist: Ihre Großmutter hielt 1909 in Cwm Llwyd Wache. Vaughan kennt die Geschichten der Toten und der Wartenden aus Erzählungen. Die Spielleitung gibt ihr diese Geschichte als persönlichen Hintergrund, nicht als Belastungspunkte und nicht als Handout.

### Zeile 233, Nachspiel

**alt:** - Keine Karte.

**neu:** - Karte K2 (Die Kammer in Wales) gehört zu Einsatz 8; für das Tal gibt es keine Karte.

### Zeile 295, Walter Gysin, 42

**alt:** Mitarbeiter des Instituts, Chemiker. Trägt den Messkoffer, hält die Protokolle, misst dreimal nach. Will, dass die Messung fehlerfrei ist. Weiß, dass der Koffer nicht für lange Messungen gebaut ist. Verschweigt, dass er den Ozonwert vom 3. September nachträglich korrigieren wollte, weil er ihm zu hoch erschien, und es dann doch nicht tat. Redet in kurzen Sätzen, mit einem Schweizer Akzent. Sagt „Protokoll“ und „Abweichung“.

**neu:** Mitarbeiter des Instituts, Elektrotechniker aus Zürich; er hat den Messkoffer gebaut. Trägt den Messkoffer, hält die Protokolle, misst dreimal nach. Will, dass die Messung fehlerfrei ist. Weiß, dass der Koffer nicht für lange Messungen gebaut ist. Verschweigt, dass er den Ozonwert vom 3. September nachträglich korrigieren wollte, weil er ihm zu hoch erschien, und es dann doch nicht tat. Redet in kurzen Sätzen, mit einem Schweizer Akzent. Sagt „Protokoll“ und „Abweichung“.

### Zeile 337, Knoten 2: Der Strand und die Bucht

**neu:** - **Hinweis:** Pennington beschriftet am Strand ein Etikett von Hand: K-1957-003 (Handout N21). (führt zu Knoten 5)

### Zeile 366, Knoten 6: Uppsala, Dezember 1957

**alt:** Ein Kellerraum unter einem Haus in Uppsala, das der Loge gehört. Hallström führt den Investigator nachts dorthin. Was dort ist: ein Mann im weißen Kittel, eine runde Brille, ein Besucherbuch.

**neu:** Ein Kellerraum im Landesarchiv Uppsala, dort, wo das Kirchenbuch von Solberg liegt. Hallström führt den Investigator nachts dorthin. Was dort ist: ein Mann im weißen Kittel, eine runde Brille, das Besucherbuch des Landesarchivs.

### Zeile 438, Der Zuschauer

**alt:** Für andere Nichtspielercharaktere gelten die Werte aus dem Bedrohungsatlas oder dem Grundregelwerk. Wendland, Pennington, Gysin, Astrid und die Dorfbewohner sind keine Kampfgegner. Sollte es zu Handgreiflichkeiten mit Constables kommen, verwendet die Spielleitung die Werte für gewöhnliche Polizisten aus dem Grundregelwerk.

**neu:** Für andere Nichtspielercharaktere gelten die Werte aus dem Bedrohungsatlas oder dem Grundregelwerk. Wendland, Pennington, Gysin, Astrid und die Dorfbewohner sind keine Kampfgegner. Sollte es zu Handgreiflichkeiten mit Constables kommen, verwendet die Spielleitung für die Constables Handlanger-Werte nach der Faustregel des Grundregelwerks: Initiative 3, Schlagstock 2 + 2, Schaden 2, Verteidigung / Rüstung / LP 1 / 0 / 5.

### Zeile 545, Briefing

**alt:** **Was die Gruppe bekommt:** einen Dienstwagen (grauer Peugeot 403, Papiere auf eine Scheinfirma), Bargeld, am Tisch 25.000 Francs (intern umgerechnet 600 Euro), eine Karte der Vogesen, die Nummer des Hotelzimmers in Reims, eine Minox.

**neu:** **Was die Gruppe bekommt:** einen Dienstwagen (grauer Peugeot 403, Papiere auf eine Scheinfirma), Bargeld, am Tisch 25.000 Francs, eine Karte der Vogesen, die Nummer des Hotelzimmers in Reims, eine Minox.

### Zeile 547, Briefing

**alt:** **Spesen:** am Tisch in Francs, intern in Euro.

**neu:** **Spesen:** am Tisch in Francs, intern wie jede Rote Akte 10.000 Euro.

### Zeile 731, Nachspiel

**alt:** **Übergabe:** Wer stirbt, hinübergeht, ausbrennt, überläuft oder abtritt, wird durch einen Schützling ersetzt. Die Übergabe ist eine Szene nach den Regeln des Kampagnenplans. In diesem Einsatz stirbt niemand zwangsläufig, aber der Wald kann jemanden für Stunden oder Tage verschlucken. Ein Agent, der fehlt, ohne tot zu sein, gibt Anlass für einen Eintrag ins Dienstbuch.

**neu:** **Übergabe:** Wer stirbt, hinübergeht, ausbrennt, überläuft oder abtritt, wird durch einen Schützling ersetzt. Die Übergabe ist eine Szene nach den Regeln des Nachfolger-Systems (Kapitel 2). In diesem Einsatz stirbt niemand zwangsläufig, aber der Wald kann jemanden für Stunden oder Tage verschlucken. Ein Agent, der fehlt, ohne tot zu sein, gibt Anlass für einen Eintrag ins Dienstbuch.

### Zeile 1009, Nachspiel

**alt:** **Erfahrung:** Schwarze Akte: 7 EP, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, dazu +1 je aufgenommenem Faden. Die Fäden: die zwölfte Partei (offen), Holloways Brief (offen), die Zahlenstation (offen).

**neu:** **Erfahrung:** Einmal für beide Teile, nach der höheren Farbe: Schwarze Akte: 7 EP, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, dazu +1 je aufgenommenem Faden. Die Fäden: die zwölfte Partei (offen), Holloways Brief (offen), die Zahlenstation (offen).

### Zeile 1017, Nachspiel

**alt:** **Bis zum nächsten Einsatz:** 1960: Von den Einunddreißig leben noch 22. Die Lavigne, die sich Margot nennt, heiratet. 1961: Die Setzerin beginnt im Kinderzimmer. Hort-4 Oxford entsteht. Im September springen in Lima die ersten Shadow Paratroopers („Ich will Männer, die fallen können.“). Ekberg verlässt das Institut ohne Abschied. 1962: Nachtigall in Wien, Britt Holm fährt am 21. Dezember in den Harz und kommt nicht zurück. 1963: Berglund, Neuro-Helm Mk. I, Helmtag. 1964 bis 1966: Hort-5 Wien, Lehrhelm, Hort-6 Lagos. 1968: Lüttich, Adeyemi, Dorje stirbt. 1969: Einsatz 9, „Elster“.

**neu:** **Bis zum nächsten Einsatz:** 1960: Von den Einunddreißig leben noch 22. Die Lavigne, die sich Margot nennt, heiratet. 1961: Die Setzerin beginnt im Kinderzimmer. Hort-4 Oxford entsteht. Im September braucht ein Trupp bei Lima drei Tage zu Fuß zu einem Riss, der danach zu ist; Ashgrove schreibt: „Ich will Männer, die fallen können.“ Noch 1961 bildet der Zweig die ersten Shadow Paratroopers aus. Ekberg verlässt das Institut ohne Abschied. 1962: Nachtigall in Wien, Britt Holm fährt am 21. Dezember in den Harz und kommt nicht zurück. 1963: Berglund, Neuro-Helm Mk. I, Helmtag. 1964 bis 1966: Hort-5 Wien, Lehrhelm, Hort-6 Lagos. 1968: Lüttich, Adeyemi, Dorje stirbt. 1969: Einsatz 9, „Elster“.

### Zeile 1033, 1954

**alt:** In Lissabon findet eine geschlossene Auktion statt. Kein Auktionshaus. Keine Kataloge. Ein Saal in einem Privathaus, drei Dolmetscher, zehn Bieter aus sechs Ländern. Angeboten werden drei Kristalle aus altem europäischem Privatbesitz. Das Kollegium hat die Gruppe gebeten, für es zu bieten. Die Beteiligten nennen die Veranstaltung nur „der Abend“.

**neu:** In Lissabon findet eine geschlossene Auktion statt. Kein Auktionshaus. Keine Kataloge. Ein Saal im Hinterhaus eines Antiquitätenhändlers, nach Einbruch der Dunkelheit, drei Bieter: zwei Privatsammler und ein Agent der Gruppe, der für das Kollegium bietet. Angeboten werden drei Kristalle aus Anatolien. Weil die Versteigerung erst nach Einbruch der Dunkelheit beginnt, nennt der Händler sie „den Abend“.

### Zeile 1035, 1954

**alt:** Mögliche Szene: Ein Agent der Gruppe sitzt im Saal. Er trägt einen unauffälligen Anzug und eine Nummer aus Pappe. Die Kristalle liegen in Bleikästen auf einem Tisch aus Nussbaum. Der Auktionator spricht leise. Die Gebote steigen in kleinen Schritten. Bei einem Kristall bleibt der Raum still. Er ist milchig und klein. Zwei Bieter heben die Hand. Ob der Agent der Gruppe den Zuschlag bekommt, entscheidet der Tisch. Was er auf dem Weg zum Hafen erlebt und wem er den Koffer übergibt, erzählt der Spieler.

**neu:** Mögliche Szene: Ein Agent der Gruppe sitzt im Saal. Er trägt einen unauffälligen Anzug und eine Nummer aus Pappe. Die Kristalle liegen in Bleikästen auf einem Tisch aus Nussbaum. Der Auktionator spricht leise. Die Gebote steigen in kleinen Schritten. Bei einem Kristall bleibt der Raum still. Er ist milchig und klein. Zwei Bieter heben die Hand. Jeder der drei Bieter bekommt einen Stein; welchen der Agent ersteigert und was er dafür zahlt, entscheidet der Tisch. Was er auf dem Weg zum Hafen erlebt und wem er den Koffer übergibt, erzählt der Spieler.

### Zeile 1041, 1956

**alt:** Die Legende „Ferdinand Aigner“ entsteht. Es ist eine einzige Legende, die von 1956 bis 1991 nacheinander von vier Agenten des Operativen Zweigs getragen wird. Der erste ist ein Agent der Gruppe. Ferdinand Aigner ist Nähmaschinenvertreter aus Graz, Jahrgang 1919. Er fährt einen grauen Opel. Er raucht Zigarillos. Er hat drei Geschichten, die er auf Verlangen erzählt: eine über die Straßen der Steiermark, eine über eine Witwe in Wiener Neustadt, eine über einen Zollbeamten in Salzburg. Er hat eine Hutregel: Beim Betreten eines Geschäfts nimmt er den Hut ab, beim Betreten einer Wohnung behält er ihn auf, bis ihm eine Frau die Hand gibt. Die Druckerei in Zürich hat keine Brieftasche mit einem Foto vorbereitet. Aigner hat keine Frau, kein Kind, keine Geschwister. Wer ihn trägt, lernt den Namen, die Biografie, die Unterschrift. Er übt den Gang, die Stimme, die Art, eine Landkarte zu falten. Eine Legende ist kein Kostüm. Sie ist ein zweites Gedächtnis.

**neu:** Die Legende „Ferdinand Aigner“ entsteht. Es ist eine einzige Legende, die von 1956 bis 1991 nacheinander von vier Agenten des Operativen Zweigs getragen wird. Der erste ist ein Agent der Gruppe. Ferdinand Aigner ist Nähmaschinenvertreter aus Graz, Jahrgang 1919. Er fährt einen grauen Opel. Er raucht Zigarillos. Er hat drei Geschichten, die er auf Verlangen erzählt: eine über die Straßen der Steiermark, eine über eine Witwe in Wiener Neustadt, eine über einen Zollbeamten in Salzburg. Er hat eine Gewohnheit mit dem Hut: Beim Betreten eines Geschäfts nimmt er den Hut ab, beim Betreten einer Wohnung behält er ihn auf, bis ihm eine Frau die Hand gibt. Die Druckerei in Zürich hat keine Brieftasche mit einem Foto vorbereitet. Aigner hat keine Frau, kein Kind, keine Geschwister. Wer ihn trägt, lernt den Namen, die Biografie, die Unterschrift. Er übt den Gang, die Stimme, die Art, eine Landkarte zu falten. Eine Legende ist kein Kostüm. Sie ist ein zweites Gedächtnis.

### Zeile 1061, 1962

**alt:** Nachtigall liest in Wien hundertvierzig Gäste. Sie trägt ein schwarzes Kleid. Sie spricht nicht. Sie steht am Rand des Saals und hört. Danach schreibt sie vierzehn Seiten. Der Ermittlungszweig schickt die Gruppe. Ein Agent liest die Seiten. Sie enthalten Namen, Ängste, Lügen. Ein Name ist dreimal unterstrichen. Der Agent fragt nicht, wer ihn unterstrichen hat. Er legt die Seiten in einen grauen Umschlag. Der Umschlag geht an Hallström. Im Institut beginnt die Beryllium-Isolierung. Greta Sundqvist beendet nach zwölf Jahren ihre Arbeit an den Kreisen: kein Code, sondern eine Sprache.

**neu:** Nachtigall liest auf einem Botschaftsempfang in Wien hundertvierzig Gäste. Sie trägt ein schwarzes Kleid und sitzt als Pianistin am Flügel, zwischen Chopin und Schubert. Sie spricht nicht. Sie spielt und hört. Danach schreibt sie vierzehn Seiten. Der Ermittlungszweig schickt die Gruppe. Ein Agent liest die Seiten. Sie enthalten Namen, Ängste, Lügen. Ein Name ist dreimal unterstrichen. Der Agent fragt nicht, wer ihn unterstrichen hat. Er legt die Seiten in einen grauen Umschlag. Der Umschlag geht an Hallström. Im Institut beginnt die Beryllium-Isolierung. Greta Sundqvist beendet nach zwölf Jahren ihre Arbeit an den Kreisen: kein Code, sondern eine Sprache.

### Zeile 1063, 1962

**alt:** Am 20. Dezember 1962 fährt Britt Holm von Stockholm aus in den Harz. Sie ist Sekretärin der Registratur. Sie trägt einen Mantel und eine kleine Tasche. Hallström hat ihr den Auftrag gegeben: „Wer holt sie? Frag nicht Marek. Frag die Druckerei.“ Es geht um ein Harzdorf mit singenden Kindern. Die Gruppe bringt sie in Stockholm zum Zug. Ein Agent hebt ihre Tasche in das Abteil. Ein anderer reicht ihr eine Thermoskanne. Sie lächelt. Sie sagt: „Ich komme wieder.“ Der Zug fährt ab. Am 21. Dezember 1962 entgleist er im Harz. Sechsunddreißig Tote. Britt Holms Name steht auf der Liste.

**neu:** Am 20. Dezember 1962 fährt Britt Holm von Stockholm aus mit dem Nachtzug nach Hamburg; am 21. Dezember steigt sie dort in den Zug in den Harz. Sie ist Sekretärin der Registratur. Sie trägt einen Mantel und eine kleine Tasche. Hallström hat ihr den Auftrag gegeben: „Wer holt sie? Frag nicht Marek. Frag die Druckerei.“ Es geht um ein Harzdorf mit singenden Kindern. Die Gruppe bringt sie in Stockholm zum Zug. Ein Agent hebt ihre Tasche in das Abteil. Ein anderer reicht ihr eine Thermoskanne. Sie lächelt. Sie sagt: „Ich komme wieder.“ Der Zug fährt ab. Am 21. Dezember 1962 entgleist ihr Anschlusszug aus Hamburg im Harz. Sechsunddreißig Tote. Britt Holms Name steht auf der Liste.

### Zeile 1087, 1968

**alt:** Dorje stirbt. Er war einer der Gründer des Kollegiums. Er hat 1923 Kristalle im Himalaya gefunden. Er hat 1940 „rufen können“. Jetzt ist er tot. Die Kammer schweigt einen Tag. Dann lesen die Archivare die Kreise weiter. Das Kollegium trauert nicht. Es arbeitet. Das ist seine Trauer.

**neu:** Dorje stirbt. Er hatte den Kristall aus dem verlassenen Kloster im Himalaya nach London gebracht, an dem das Kollegium begann. Er hat 1940 „rufen können“. Jetzt ist er tot. Die Kammer schweigt einen Tag. Dann lesen die Archivare die Kreise weiter. Das Kollegium trauert nicht. Es arbeitet. Das ist seine Trauer.

## 06_kaskade.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 53, Was wirklich geschah

**alt:** **Der offene Faden:** Die Gruppe kann herausfinden, dass die Zahlen Antworten sind, nicht Fragen. Wer die Fünfergruppen mit den alten Mitschriften von 1961 vergleicht, sieht, dass sie sich ändern, wenn jemand an das Haus ohne Nummer schreibt. Das führt nach 1971, als die Sendung endet, und nach 2026, wenn die Grauen Akten Kessler und die Tür M7 Basel Elsters Code brauchen.

**neu:** **Der offene Faden:** Die Gruppe kann herausfinden, dass die Zahlen Antworten sind, nicht Fragen. Wer die Fünfergruppen mit den alten Mitschriften von 1961 vergleicht, sieht, dass sie sich ändern, wenn jemand an das Haus ohne Nummer schreibt. Das führt nach 1971, als die Sendung endet, und nach 2026, wenn Elster in der Grauen Akte Kessler und in der Tür, M7 Basel, wieder auftaucht.

### Zeile 86, Ilse Marek, 58

**alt:** Leiterin des Psionik-Kerns, letzter Auftritt im Band. Sie ist in Berlin, weil die Hörer sie an die Kinder von Solberg erinnern. Sie will die Gruppe nicht einmischen, aber sie will die Psionen schützen, die zuhören. Sie weiß, dass die Sendung keine Stimme ist. Sie verschweigt, dass sie selbst die Fünfergruppen für eine Sprache hält, nicht für einen Code. Sie spricht mütterlich, aber mit einer Härte, die aus der Nacht von Solberg kommt.

**neu:** Leiterin des Psionik-Kerns, letzter Einsatz im Band; ihren Abschied 1970 erzählen die Zwischenjahre. Sie ist in Berlin, weil die Hörer sie an die Kinder von Solberg erinnern. Sie will die Gruppe nicht einmischen, aber sie will die Psionen schützen, die zuhören. Sie weiß, dass die Sendung keine Stimme ist. Sie verschweigt, dass sie selbst die Fünfergruppen für eine Sprache hält, nicht für einen Code. Sie spricht mütterlich, aber mit einer Härte, die aus der Nacht von Solberg kommt.

### Zeile 117, Knoten 1: Das Westberliner Fernamt

**alt:** - **Hinweis für Psion:** Ein Psion mit Neuro-Helm Mk. I hört die Sendung in der Vermittlung nicht, bis er den Helm abnimmt. Dann hört er sie doppelt. Probe: Telepathie gegen Machbar (2), um zu verstehen: Die Sendung ist für ungeschützte Ohren. (führt zu K3)

**neu:** - **Hinweis für Psion:** Ein Psion mit Neuro-Helm Mk. I hört die Sendung in der Vermittlung nicht, bis er den Helm abnimmt. Dann hört er sie doppelt. Probe: Telepathie gegen Machbar (2), ohne Helm also Schwer (3), um zu verstehen: Die Sendung ist für ungeschützte Ohren. (führt zu K3)

### Zeile 128, Knoten 2: Elsters Wohnung in Charlottenburg

**alt:** - **Hinweis:** Ihre Wohnungstür ist mit Salz bestrichen, das sie nicht selbst dorthin getan hat. Probe: Okkultismus gegen Einfach (1), um zu erkennen: Jemand schützt sie, die Telefonistin, die die Zahlen an ihre eigene Tür schreibt. (führt zu K4, Schlussfolgerung 2)

**neu:** - **Hinweis:** Auf Elsters Türschwelle liegt Salz, das sie nicht gestreut hat. Probe: Okkultismus gegen Einfach (1). Elster sagt, ihre Kollegin, die Hörerin, war nachts hier, streute es und schrieb dieselben Zahlen an ihre eigene Tür, ohne sich zu erinnern. (führt zu K4, Schlussfolgerung 2)

### Zeile 171, Knoten 6: Marshs Hotelzimmer am Zoo

**alt:** - **Hinweis:** Hallströms Mitschrift von 1961 liegt auf dem Tisch. Probe: Kryptografie gegen Machbar (2), um zu erkennen: Die Sendung antwortet, nicht fragt. (führt zum offenen Faden „Zahlenstation: Antworten, keine Fragen“)

**neu:** - **Hinweis:** Fragt die Gruppe Hallström nach 1961, legt er seine Mitschrift auf den Tisch. Probe: Kryptografie gegen Machbar (2), um zu erkennen: Die Sendung antwortet, nicht fragt. (führt zum offenen Faden „Zahlenstation: Antworten, keine Fragen“)

### Zeile 200, Der Schauplatz

**alt:** Die Gruppe braucht eine Legende, um nach Ostberlin zu kommen. Der Hinweg führt über die Grenzübergangsstelle im Bahnhof Friedrichstraße oder über den Checkpoint Charlie. Der Rückweg führt durch den Tränenpalast, die Ausreisehalle von Ost nach West.

**neu:** Die Gruppe braucht eine Legende, um nach Ostberlin zu kommen. Der Hinweg führt über die Grenzübergangsstelle im Bahnhof Friedrichstraße oder über den Checkpoint Charlie. Der Rückweg führt über denselben Übergang; wer über den Bahnhof Friedrichstraße kam, geht durch den Tränenpalast, die Ausreisehalle von Ost nach West.

### Zeile 215, Lösungen

**alt:** **Mit Rückzug:** Die Gruppe nimmt Elster und verschwindet, bevor die Verstärkung kommt. Die Abhörstelle bleibt bestehen. Elster ist in Sicherheit. Die Sendung läuft weiter bis 1971.

**neu:** **Mit Rückzug:** Die Gruppe bricht ab, bevor die Verstärkung kommt, und bringt Elster in Westberlin in Sicherheit. Die Abhörstelle bleibt bestehen. Elster ist in Sicherheit. Die Sendung läuft weiter bis 1971.

### Zeile 265, Nachspiel

**alt:** Die Zahlen sind Antworten. Wer an das Haus ohne Nummer schreibt, bekommt eine Sendung. Das führt nach Einsatz 10, wenn die letzte Sendung läuft, und nach 2026, wenn die Graue Akte Kessler und die Tür M7 Basel Elsters Code brauchen.

**neu:** Die Zahlen sind Antworten. Wer an das Haus ohne Nummer schreibt, bekommt eine Sendung. Das führt nach Einsatz 10, wenn die letzte Sendung läuft, und nach 2026, wenn Elster in der Grauen Akte Kessler und in der Tür, M7 Basel, wieder auftaucht.

### Zeile 303, Was wirklich geschah

**alt:** Im September 1971 schreibt Uhrwerk, eine Präkognitive mit Neuro-Helm Mk. II in Wien, eine Warnung auf eine Karteikarte. Sie schickt sie an den Kern. Kantor liest sie und legt sie beiseite. Er hält Uhrwerk für eine Frau, die nie im Kreis saß und deshalb nicht versteht, was der Kreis bedeutet.

**neu:** Im September 1971 schreibt Uhrwerk, eine Präkognitive mit Neuro-Helm Mk. I in Wien, eine Warnung auf eine Karteikarte. Sie schickt sie an den Kern. Kantor liest sie und legt sie beiseite. Er hält Uhrwerk für eine Frau, die nie im Kreis saß und deshalb nicht versteht, was der Kreis bedeutet.

### Zeile 313, Was wirklich geschah

**alt:** **Der offene Faden:** Die Zahlenstation verstummt am 14. Oktober 1971 um 3 Uhr. Die letzte Mitschrift ist ein Dokument, das die Gruppe in den Händen halten kann. Die Röhre eines Kurzwellensenders wird am 20. Oktober in einem ausgebrannten Bauernhaus in Schweden gefunden. Das Haus steht, die Nummer fehlt. Dieser Faden führt zu den späteren Einsätzen und nach 2026 zu „Die Tür“ und „Graue Akten“.

**neu:** **Der offene Faden:** Die Zahlenstation verstummt am 14. Oktober 1971 um 3 Uhr. Die letzte Mitschrift ist ein Dokument, das die Gruppe in den Händen halten kann. Die Röhre eines Kurzwellensenders wird im Oktober in einem ausgebrannten Bauernhaus in Schweden gefunden. Am 20. Oktober geht Hallström in Vasastan an dem Haus vorbei, an das Kantor geschrieben hat: Das Haus steht, die Nummer fehlt. Dieser Faden führt zu den späteren Einsätzen und nach 2026 zu „Die Tür“ und „Graue Akten“.

### Zeile 349, Uhrwerk, 41

**alt:** Ottilie Brandauer, geboren 1930. Sie lebt in Wien und ist eine Präkognitive des Chors mit Neuro-Helm Mk. II. Sie hat die Warnung geschrieben, weil sie eine Vorahnung hatte: drei Tote, sieben Ausgebrannte, einen Satz. Sie will die Kaskade verhindern, aber sie hat keine Beweise. Sie verschweigt, dass sie seit der Vorahnung kaum schläft. Sie redet präzise, wie jemand, der gewohnt ist, Datum und Uhrzeit zu notieren. Sprache der Zeit: „Die Stimme lügt nicht. Sie wiederholt nur, was sie hört.“

**neu:** Ottilie Brandauer, geboren 1930. Sie lebt in Wien und ist eine Präkognitive des Chors mit Neuro-Helm Mk. I. Sie hat die Warnung geschrieben, weil sie eine Vorahnung hatte: drei Tote, sieben Ausgebrannte, einen Satz. Sie will die Kaskade verhindern, aber sie hat keine Beweise. Sie verschweigt, dass sie seit der Vorahnung kaum schläft. Sie redet präzise, wie jemand, der gewohnt ist, Datum und Uhrzeit zu notieren. Sprache der Zeit: „Die Stimme lügt nicht. Sie wiederholt nur, was sie hört.“

### Zeile 400, Knoten 2: Stockholm, Ermittlungszweig, Hallströms Büro

**alt:** - **Hinweis:** Hallström zeigt der Gruppe die Mitschriften der Sommersendungen und erklärt, wie die Zahlen Koordinaten sind. Die letzte Sendung vom 14. Oktober lässt er der Gruppe durch einen Kurier nach Wales bringen. (führt zu: Schlussfolgerung 2)

**neu:** - **Hinweis:** Hallström zeigt der Gruppe die Mitschriften der Sommersendungen und erklärt, wie die Zahlen Koordinaten sind. Die letzte Sendung vom 14. Oktober lässt er der Gruppe durch einen Kurier nach Wales bringen. Der Agent, der 1961 die erste Sendung mitschrieb (Handout N27), erkennt die letzte als Erster, ohne Probe: Er legt N27 neben N33 und sieht, dass die Stimme verstummt, wo sie damals begann. (führt zu: Schlussfolgerung 2)

### Zeile 407, Knoten 3: Wien, Uhrwerks Wohnung

**alt:** Eine kleine Wohnung in der Nähe des Westbahnhofs. Überall liegen Karteikarten, mit Bleistift beschrieben, jede mit Datum und Uhrzeit. Uhrwerk sitzt an einem Tisch, den Mk. II neben sich, und schreibt ihre Vorahnungen auf.

**neu:** Eine kleine Wohnung in der Nähe des Westbahnhofs. Überall liegen Karteikarten, mit Bleistift beschrieben, jede mit Datum und Uhrzeit. Uhrwerk sitzt an einem Tisch, den Mk. I neben sich, und schreibt ihre Vorahnungen auf.

### Zeile 501, Psion des Kreises

**alt:** Für Kantor, Rees, Ashgrove, Pryce, Hallström und Uhrwerk gilt: Sie sind in diesem Einsatz keine Kämpfer. Kantor ist bewusstlos. Rees trägt, Ashgrove sichert, Pryce wartet in der Werkstatt. Sie brauchen keine Werte. Uhrwerk ist eine Präkognitive mit Mk. II und bleibt in Wien.

**neu:** Für Kantor, Rees, Ashgrove, Pryce, Hallström und Uhrwerk gilt: Sie sind in diesem Einsatz keine Kämpfer. Kantor ist bewusstlos. Rees trägt, Ashgrove sichert, Pryce wartet in der Werkstatt. Sie brauchen keine Werte. Uhrwerk ist eine Präkognitive mit Mk. I und bleibt in Wien.

### Zeile 509, Nachspiel

**alt:** **Erfahrung:** Rote Akte: 5 EP, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, plus 1 EP für jeden aufgenommenen Faden. Mögliche Fäden: die Tonbänder, Uhrwerks Warnung, die einundvierzigste Stimme, die Frage nach Märta, die letzte Mitschrift der Zahlenstation.

**neu:** **Erfahrung:** Rote Akte, die schwarz wird: 7 EP wie eine Schwarze Akte, +1 für das erreichte Ziel, höchstens +1 persönlicher Bonus, plus 1 EP für jeden aufgenommenen Faden. Mögliche Fäden: die Tonbänder, Uhrwerks Warnung, die einundvierzigste Stimme, die Frage nach Märta, die letzte Mitschrift der Zahlenstation.

### Zeile 521, Nachspiel

**alt:** - N33: Letzte Mitschrift der Zahlenstation, 14. Oktober 1971, 3 Uhr. Handschriftliche Mitschrift, 26 Fünfergruppen, Tippfehler „RUHIG“. Ein Kurier des Ermittlungszweigs bringt sie am 14. Oktober nach Wales.

**neu:** - N33: Letzte Mitschrift der Zahlenstation, 14. Oktober 1971, 3 Uhr. Handschriftliche Mitschrift, 26 Fünfergruppen, Schreibfehler „RUHIG“. Ein Kurier des Ermittlungszweigs bringt sie am 14. Oktober nach Wales.

### Zeile 649, Knoten 3: Der alte Weinkeller in Wien

**alt:** Ein Keller unter dem Nachbarhaus von Hort-5. Feucht, dunkel, Stimmen von irgendwo. Die Wände sind mit Salz bestrichen. Keine Betten, keine Kinder. Nur Stimmen, die im Schlaf singen.

**neu:** Ein alter Weinkeller zwei Häuser weiter, nicht der Botschaftskeller von Hort-5. Feucht, dunkel, Stimmen von irgendwo. Die Wände sind mit Salz bestrichen. Keine Betten, keine Kinder. Nur Stimmen, die im Schlaf singen.

### Zeile 671, Zwischenspiel: Dezember 1974 bis Februar 1976

**alt:** Zwischen Teil A und Teil B liegt ein Zwischenjahr. Es verbindet die beiden Teile, einen Hinweis auf das Kloster gibt es darin nicht. Jeder Spieler erzählt eine Sache, die sein Agent in dieser Zeit tat; die Spielleitung erzählt die festen Ereignisse. Danach Alterung und Übergaben nach Kapitel 2.

**neu:** Zwischen Teil A und Teil B liegt ein Zwischenjahr. Es verbindet die beiden Teile, einen Hinweis auf das Kloster gibt es darin nicht. Jeder Spieler erzählt eine Sache, die sein Agent in dieser Zeit tat; die Spielleitung erzählt die festen Ereignisse. Danach Übergaben nach Kapitel 2. Die Alterung gilt erst zu Beginn von Abschnitt IV.

### Zeile 732, Ablauf

**alt:** 4. Mercier gibt das Zeichen. Die Geräte schalten sich ein. Ein tiefer Ton, der nicht laut ist, aber alle im Raum spüren. Die Offenen fallen in Ohnmacht, einer nach dem anderen, ohne Schuss, ohne Gegenwehr. Der Fünfzehnjährige sieht Mercier an, bevor er umfällt. Ein Spielerpsion mit Mk. II wird von der Überlagerung mit getroffen: Er würfelt WK + Geistige Widerstandskraft gegen Schwer (3), sonst verliert er eine Runde das Bewusstsein.

**neu:** 4. Mercier gibt das Zeichen. Die Geräte schalten sich ein. Ein tiefer Ton, der nicht laut ist, aber alle im Raum spüren. Die Offenen fallen in Ohnmacht, einer nach dem anderen, ohne Schuss, ohne Gegenwehr. Der Fünfzehnjährige sieht Mercier an, bevor er umfällt. Ein Spielerpsion mit Mk. II wird von der Überlagerung mit getroffen: Vorgewarnt würfelt er drei Runden lang alle Psi-Proben mit −1 Würfel.

### Zeile 747, Kantor, 1974

**alt:** [entry - | Kantor, 1976 | Elite · Stimme]

**alt:** Ein ehemaliger Leiter des Psionik-Kerns, der 1974 verschwand und die Offenen gründete. Er tritt in Teil A an der Grenze auf. Er kämpft nicht. Er redet.

**neu:** [entry - | Kantor, 1974 | Elite · Stimme]

**neu:** Ein ehemaliger Leiter des Psionik-Kerns, der 1974 verschwindet und danach die Offenen gründet. Er tritt in Teil A an der Grenze auf. Er kämpft nicht. Er redet.

### Zeile 777, Jäger der Abteilung 13

**alt:** **Angriff** | Sturmgewehr 4 + 4, Schaden 4, oder Nahkampf 4 + 3, Schaden 3

**alt:** **Verteidigung / Rüstung / LP** | 3 / 2 / 12

**neu:** **Angriff** | AKM mit Schalldämpfer 4 + 4, Schaden 4, Leise, oder Nahkampf 4 + 3, Schaden 3

**neu:** **Verteidigung / Rüstung / LP** | 3 / 3 / 12

### Zeile 845, 1972: Brief der sieben Ausgebrannten

**alt:** Die Spieler erzählen, was ihre Agenten in den zwei Jahren seit der Kaskade getan haben. Eine Sache jeder. Eine Reise. Ein Gespräch. Ein Bericht. Ein Schützling, der eine Prüfung bestanden hat.

**neu:** Die Spieler erzählen, was ihre Agenten in dem Jahr seit der Kaskade getan haben. Eine Sache jeder. Eine Reise. Ein Gespräch. Ein Bericht. Ein Schützling, der eine Prüfung bestanden hat.

## 07_nordlicht.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 9, Der Stützpunkt

**alt:** Wenn die Gruppe am 7. Februar ankommt, sieht sie zuerst den Dienstplan. 41 Namen, mit Bleistift, in ordentlichen Spalten. Die Spalte für den 14. Februar ist noch leer. Die Spielleitung zeigt das Handout N42; die Radierspuren gibt es erst ab Samstag, die Haken erst beim Appell am 14. Februar. Die Agenten sehen die Kantine mit der Wanduhr und dem Küchenradio auf der Durchreiche. Sie sehen die Werkstatt, in der Gunnar einen Generator repariert, der nicht fertig wird. Sie sehen die Krankenstation mit dem Zettel: Aspirin wird knapp. Sie sehen die Stahltür im Keller mit zwei Schlüsseln. Hat der Scientist der Gruppe im Januar die Sonde aufgestellt, sehen sie die Sonde am Treppenabgang. Sie sehen 212 Bleikästchen. Sie hören das Flüstern. Mehr nicht.

**neu:** Wenn die Gruppe am 7. Februar ankommt, sieht sie zuerst den Dienstplan. 41 Namen, mit Bleistift, in ordentlichen Spalten. Die Spalte für den 14. Februar ist noch leer. Die Spielleitung zeigt das Handout N42; die Radierspuren gibt es erst ab Samstag, die Haken erst beim Appell am 14. Februar. Die Agenten sehen die Kantine mit der Wanduhr und dem Küchenradio auf der Durchreiche. Sie sehen die Werkstatt, in der Gunnar einen Generator repariert, der nicht fertig wird. Sie sehen die Krankenstation mit dem Zettel: Aspirin wird knapp. Sie sehen die Stahltür im Keller mit zwei Schlüsseln. Sie sehen die Sonde am Treppenabgang, die das Institut seit Dezember betreibt. Sie sehen 212 Bleikästchen. Sie hören das Flüstern. Mehr nicht.

### Zeile 26, So spielt man den Abschnitt

**alt:** Beim Appell am 14. Februar 1977 um sieben Uhr bekommen alle 41 Namen auf dem Dienstplan ihren Haken. Am 14. Februar 1977 um 22:10 Uhr öffnet sich im Stützpunkt Nordlicht eine Tür. Die elf Thaumaturgen lesen den siebten Kreis. Alle 212 Steine sprechen gleichzeitig. Die 41 Menschen gehen hindurch. Alle Uhren im Stützpunkt bleiben stehen. Alle 212 Kristalle sind danach grau wie Schiefer. Gunnar Solheim ist unter den 41. Astrid Solheim kommt zu spät. Ihr Zug steht um 22:10 hinter Kiruna. Ingrids Taschenuhr läuft eine ganze Nacht ab. Der Suchtrupp unter Leutnant Kjell Haugen landet am 15. Februar um 6:40. Er findet die Tür unverschlossen, die Heizung an, das Radio an, elf Tassen auf dem Tisch, zehn halb voll und warm. Haugens Uhr steht auf 22:10. Das Radio spielt einen Chor. Haugen lässt den Chor aus dem Bericht. Die Druckerei erfindet 41 Tode über ein halbes Jahr in drei Ländern. Der Funklog um 22:08 lautet: „Alles ruhig. Schnee.“ Bei jedem Chronomancer bleiben um 22:10 die Uhren stehen und der Stein wird grau. Im Kristallbuch steht bei allen Nordlicht-Einträgen die Erschöpfungszeit 22:10. Kein Spieleragent ändert diese Fakten.

**neu:** Beim Appell am 14. Februar 1977 um sieben Uhr bekommen alle 41 Namen auf dem Dienstplan ihren Haken. Am 14. Februar 1977 um 22:10 Uhr öffnet sich im Stützpunkt Nordlicht eine Tür. Die elf Thaumaturgen lesen den siebten Kreis. Alle 212 Steine sprechen gleichzeitig. Die 41 Menschen gehen hindurch. Alle Uhren im Stützpunkt bleiben stehen. Alle 212 Kristalle sind danach grau wie Schiefer. Gunnar Solheim ist unter den 41. Astrid Solheim kommt zu spät. Ihr Zug steht um 22:10 hinter Kiruna. Die Taschenuhr in Ingrids Hand läuft eine ganze Nacht ab. Der Suchtrupp unter Leutnant Kjell Haugen landet am 15. Februar um 6:40. Er findet die Tür unverschlossen, die Heizung an, das Radio an, elf Tassen auf dem Tisch, zehn halb voll und warm. Haugens Uhr steht auf 22:10. Das Radio spielt einen Chor. Haugen lässt den Chor aus dem Bericht. Die Druckerei erfindet 41 Tode über ein halbes Jahr in drei Ländern. Der Funklog um 22:08 lautet: „Alles ruhig. Schnee.“ Bei jedem Chronomancer bleiben um 22:10 die Uhren stehen und der Stein wird grau. Im Kristallbuch steht bei allen Nordlicht-Einträgen die Erschöpfungszeit 22:10. Kein Spieleragent ändert diese Fakten.

### Zeile 61, Was wirklich geschah

**alt:** Der Plan der Abteilung ist nicht, die Steine zu zerstören. Sie will sie haben. Elf Kisten, ein Dutzend Kristalle, genug für die Tunguska-Stücke, die in einem Keller in Leningrad liegen und seit 1957 nicht sprechen. Der Befehl lautet: den Zug anhalten, die Bleikisten nehmen, keine Zeugen. Die Jäger kennen die Strecke. Sie wissen, dass zwischen Abisko und Riksgränsen das Funkloch liegt und der Schnee hoch steht.

**neu:** Der Plan der Abteilung ist nicht, die Steine zu zerstören. Sie will sie haben. Elf Kisten, ein Dutzend Kristalle, genug für die Tunguska-Splitter, die seit 1957 summen, aber nicht sprechen. Der Befehl lautet: den Zug anhalten, die Bleikisten nehmen, keine Zeugen. Die Jäger kennen die Strecke. Sie wissen, dass zwischen Abisko und Riksgränsen das Funkloch liegt und der Schnee hoch steht.

### Zeile 84, Was wirklich geschah

**alt:** - **Ob der Scientist der Gruppe im Januar die Nordlicht-Sonde aufstellt.** Folge: Rask oder ein Scientist-Spieler darf die Sonde im Januar testen. Wer sie aufstellt, schreibt den Messstreifen vom 14. Februar mit. Wer sie nicht aufstellt, kommt zu spät und sieht nur den Ausdruck.

**alt:** - **Was die Gruppe Gunnar über seinen Vater sagt.** Folge: Gunnar trägt es in die Nacht. Haugen kennt später zwei Namen: Rønning und Gunnar. Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, ersetzt er einen der beiden.

**neu:** - **Ob der Scientist der Gruppe im Januar an der Nordlicht-Sonde mitarbeitet.** Folge: Rask oder ein Scientist-Spieler darf die Sonde im Januar testen. Wer mitgearbeitet hat und bleibt, steht am 14. Februar an der Sonde. Wer fährt, sieht später nur den Ausdruck.

**neu:** - **Was die Gruppe Gunnar über seinen Vater sagt.** Folge: Gunnar trägt es in die Nacht. Haugen kennt später zwei Namen: Rønning und Gunnar. Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, ersetzt er Rønning.

### Zeile 155, Knoten 3: Stockholm

**neu:** - **Hinweis:** Haugen lässt neben den 26 Kisten weitere, gleich schwere Kisten verladen. (führt zur Konfrontation)

### Zeile 159, Knoten 4: Der Nachtzug auf der Erzbahn

**alt:** #### Knoten 4: Der Nachtzug auf der Ofotbanen

**neu:** #### Knoten 4: Der Nachtzug auf der Erzbahn

### Zeile 203, Eskalation

**alt:** Wenn ein Agent in Kiruna aussteigt und den Stimmen folgt, verpasst er den Zug. Die Ofotbanen wartet nicht. Eine Straße von Kiruna nach Narvik gibt es nicht. Er nimmt den nächsten Zug oder einen Erzzug, um in Narvik wieder zur Gruppe zu stoßen. Die Stimmen wollen ihn nicht aufhalten. Sie rufen ihn an. Wer bleibt, hört länger, als er wollte.

**neu:** Wenn ein Agent in Kiruna aussteigt und den Stimmen folgt, verpasst er den Zug. Die Erzbahn wartet nicht. Eine Straße von Kiruna nach Narvik gibt es nicht. Er nimmt den nächsten Zug oder einen Erzzug, um in Narvik wieder zur Gruppe zu stoßen. Die Stimmen wollen ihn nicht aufhalten. Sie rufen ihn an. Wer bleibt, hört länger, als er wollte.

### Zeile 217, Der Schauplatz

**alt:** Der Nachtzug auf der Ofotbanen, zwischen Abisko und Riksgränsen. Polarnacht, Schnee, Wind. Die Kisten stehen im Güterwagen, Haugen und die Gruppe im Personenwagen dahinter. Die Jäger kommen mit Schneemobilen von der Seite, vier Mann, Elite, Sturmgewehre mit Schalldämpfern. Der Zug fährt langsam, weil ein Signal auf Rot steht. Die Strecke ist ein Funkloch. Kein Anruf, keine Verstärkung, kein Zeuge.

**neu:** Der Nachtzug auf der Erzbahn, zwischen Abisko und Riksgränsen. Polarnacht, Schnee, Wind. Die Kisten stehen im Güterwagen, Haugen und die Gruppe im Personenwagen dahinter. Die Jäger kommen mit Schneemobilen von der Seite, vier Mann, Elite, Sturmgewehre mit Schalldämpfern. Der Zug fährt langsam, weil ein Signal auf Rot steht. Die Strecke ist ein Funkloch. Kein Anruf, keine Verstärkung, kein Zeuge.

### Zeile 221, Der Schauplatz

**alt:** Die Strecke zeigt die Karte der Ofotbanen (Karte K10).

**neu:** Die Strecke zeigt Karte K10.

### Zeile 236, Lösungen

**alt:** **Ohne Kampf:** Die Gruppe lässt die Jäger die Kisten nehmen und verfolgt sie. Die Kisten sind nicht die echten. Ashgrove hat in Stockholm Scheinkisten mit Sand und Gewichten verladen lassen, die auf den Frachtpapieren stehen. Die echten Kisten stehen in einem zweiten Wagen, der in Kiruna umgeladen wurde. Die Gruppe fährt weiter nach Narvik und holt die echten Kisten aus dem Lagerhaus. Haugen lernt, dass Rückzug kein Verlust ist. Der Preis: Die Abteilung weiß jetzt, dass O.D.I.N. sie erwartet hat. Der nächste Versuch wird leiser.

**neu:** **Ohne Kampf:** Die Gruppe lässt die Jäger die Kisten nehmen und verfolgt sie. Die Kisten sind nicht die echten. Auf Ashgroves Anweisung hat Haugen in Stockholm Scheinkisten mit Sand und Gewichten in den Güterwagen stellen lassen; sie stehen so auf den Frachtpapieren. Die echten Kisten laufen in einem zweiten Güterwagen, den Haugen in Kiruna abhängen ließ und der mit dem nächsten Erzzug nach Narvik kommt. Die Gruppe fährt weiter und holt die echten Kisten am nächsten Tag aus dem Lagerhaus. Greift Abteilung 13 schon vor Kiruna an, entfällt diese Lösung. Haugen lernt, dass Rückzug kein Verlust ist. Der Preis: Die Abteilung weiß jetzt, dass O.D.I.N. sie erwartet hat. Der nächste Versuch wird leiser.

### Zeile 293, Nachspiel

**alt:** **Dienstbuch:** Wer in Kiruna ausstieg, wer antwortete, wer den Überfall überlebte und wie, wer Gunnar was sagte. Die Spielleitung notiert, welche zwei Namen Haugen später auf dem Dienstplan kennt: Rønning und Gunnar, oder Rønning und ein Spieleragent, der blieb. Ohne Spieleragenten kennt Haugen immer Rønning und Gunnar, unabhängig davon, was die Gruppe Gunnar erzählt. Die Bekanntschaft zwischen Haugen und Gunnar zeigt Knoten 6: Gunnar holt die Kisten mit dem Wagen des Stützpunkts am Lagerhaus in Narvik ab, und die beiden reden beim Umladen über den Generator.

**neu:** **Dienstbuch:** Wer in Kiruna ausstieg, wer antwortete, wer den Überfall überlebte und wie, wer Gunnar was sagte. Die Spielleitung notiert, welche zwei Namen Haugen später auf dem Dienstplan kennt: Rønning und Gunnar, oder Gunnar und ein Spieleragent, der blieb. Ohne Spieleragenten kennt Haugen immer Rønning und Gunnar, unabhängig davon, was die Gruppe Gunnar erzählt. Die Bekanntschaft zwischen Haugen und Gunnar zeigt Knoten 6: Gunnar holt die Kisten mit dem Wagen des Stützpunkts am Lagerhaus in Narvik ab, und die beiden reden beim Umladen über den Generator.

### Zeile 295, Nachspiel

**alt:** **Übergabe:** Ein Soldier-Schützling, der in Einsatz 12 dabei war, übernimmt die Armschiene Nr. 114, wenn sein Mentor abtritt. Ein Thaumaturg-Schützling, der das Kristallbuch geführt hat, trägt in Nordlicht die Eingänge mit ein und kennt danach jede Position bis 212.

**neu:** **Übergabe:** Haugen behält die Armschiene Nr. 114; sie geht erst 1990 weiter. Ein Soldier-Schützling, der in Einsatz 12 dabei war, kennt danach Haugen und die Strecke. Ein Thaumaturg-Schützling, der das Kristallbuch geführt hat, trägt in Nordlicht die Eingänge mit ein und kennt danach jede Position bis 212.

### Zeile 297, Nachspiel

**alt:** **Der offene Faden:** Die Männer im Berg und die Frage, ob man sie zurückholen kann. Für die Spielleitung, die „Die Tür“ spielt: Einer der Steine aus den Vogesen, eine gewöhnliche Position im Kristallbuch, wird Jahrzehnte später aus Nordlicht gestohlen und kommt über einen Nachlass in Tromsø auf eine Auktion (Tür, Mission 3).

**neu:** **Der offene Faden:** Die Männer im Berg und die Frage, ob man sie zurückholen kann. Für die Spielleitung, die „Die Tür“ spielt: Einer der Steine aus den Vogesen, eine gewöhnliche Position im Kristallbuch, kommt nach der Räumung in eines der Archive, auf die das Kollegium die Nordlichtsteine verteilt, wird Jahrzehnte später dort gestohlen und kommt über einen Nachlass in Tromsø auf eine Auktion (Tür, Mission 3).

### Zeile 305, Nachspiel

**alt:** Karte: K10, die Ofotbanen von Stockholm über Kiruna nach Narvik.

**neu:** Karte: K10, der Nachtzug von Stockholm über Kiruna nach Narvik.

### Zeile 326, Worum es geht

**alt:** Die Gruppe findet einen Stützpunkt mit 41 Menschen, einem Küchenradio, das Schlager spielt, einer Wanduhr, die richtig geht, und 212 Steinen im Keller, die in dieser Woche lauter flüstern als sonst. Die elf Thaumaturgen bereiten etwas vor, aber sie bitten erst am Samstag darum, die Kantine am Montagabend frei zu halten. Am Samstag muss die Gruppe nach der Platzhalter-Regel entscheiden, wer am Sonntag nach Stockholm fliegt, um Astrid Solheim und die Teile der Zeitmessanlage abzuholen. Wer bleibt, übernimmt einen Tauschplatz auf dem Dienstplan. Wer fährt, kommt mit Astrid zu spät. Die Entscheidung ist zweiwertig: Wer in der Nacht im Stützpunkt ist, geht mit. Wer fährt, wird alt.

**neu:** Die Gruppe findet einen Stützpunkt mit 41 Menschen, einem Küchenradio, das Schlager spielt, einer Wanduhr, die richtig geht, und 212 Steinen im Keller, die in dieser Woche lauter flüstern als sonst. Die elf Thaumaturgen bereiten etwas vor, aber sie bitten erst am Samstag darum, die Kantine am Montagabend frei zu halten. Am Samstag muss die Gruppe nach der Tauschplatz-Regel entscheiden, wer am Sonntag nach Stockholm fliegt, um Astrid Solheim und die Teile der Zeitmessanlage abzuholen. Wer bleibt, übernimmt einen Tauschplatz auf dem Dienstplan. Wer fährt, kommt mit Astrid zu spät. Die Entscheidung ist zweiwertig: Wer in der Nacht im Stützpunkt ist, geht mit. Wer fährt, wird alt.

### Zeile 336, Was wirklich geschah

**alt:** **Der offene Faden:** Die elf Thaumaturgen gehören zu den 41. Ihre elf Akten tauchen 2014 in Stockholm auf und verschwinden. Die Schulklasse, die am Donnerstag im Tal ist, hört die Melodie. Die Registratur-Akte über den Jungen, der nach dem Lied fragt, wird nie geschlossen. Der Brief der Frau des Funkers aus Tromsø wird nach 1977 jedes Jahr im Februar beantwortet. Die Witwe schreibt an die Scheinfirma des Stützpunkts. Dieselbe Agentin antwortet seit 1978. Der Junge aus der Schulklasse ist 2027 ein Mann, der die Melodie noch immer hört.

**neu:** **Der offene Faden:** Die elf Thaumaturgen gehören zu den 41. Ihre elf Akten tauchen 2014 in Stockholm auf und verschwinden. Die Schulklasse, die seit Donnerstag im Tal ist, hört in der Nacht die Melodie. Die Registratur-Akte über den Jungen, der nach dem Lied fragt, wird nie geschlossen. Der Brief der Frau des Funkers aus Tromsø wird nach 1977 jedes Jahr im Februar beantwortet. Die Witwe schreibt an die Scheinfirma des Stützpunkts. Dieselbe Agentin antwortet seit 1978. Der Junge aus der Schulklasse ist 2027 ein Mann, der die Melodie noch immer hört.

### Zeile 416, Knoten 1: Büro des Stationsleiters (Dienstplan)

**alt:** Proben: Ermittlung, Heimlichkeit, Menschenkenntnis, Wahrnehmung. Klassen: Investigator, Agent, Soldier.

**neu:** Proben: Ermittlung, Heimlichkeit, Taktik, Wahrnehmung. Klassen: Investigator, Agent, Soldier.

### Zeile 428, Knoten 2: Kantine mit Küche und Durchreiche

**alt:** Proben: Ritualismus, Telepathie, Menschenkenntnis, Wahrnehmung. Klassen: Thaumaturg, Psion, Agent, Scientist.

**neu:** Proben: Ritualismus, Telepathie, Menschenkenntnis, Wahrnehmung, Überzeugen. Klassen: Thaumaturg, Psion, Agent, Scientist.

### Zeile 468, Knoten 6: Krankenstation und Post

**alt:** - **Hinweis:** Der Brief der Frau des Funkers aus Tromsø: Sie fragt, wann er nach Hause kommt. Sie kennt nur die Wetterstation einer Firma mit Briefkasten in Oslo. (führt zu: die 41) Ein Agent liest ihn mit Fingerfertigkeit gegen Einfach (1).

**alt:** - **Hinweis:** Ingrids Zeichnung „Ingrid, 3 Jahre. Für Papa.“ liegt auf dem Tisch. (führt zu: Gunnar Solheim) Ein Soldier sieht sie mit Wahrnehmung gegen Einfach (1).

**neu:** - **Hinweis:** Der Brief der Frau des Funkers aus Tromsø: Sie fragt, wann er nach Hause kommt. Sie kennt nur die Wetterstation einer Firma mit Briefkasten in Oslo. (Handout N43, führt zu: die 41) Ein Agent liest ihn mit Fingerfertigkeit gegen Einfach (1).

**neu:** - **Hinweis:** Ingrids Zeichnung „Ingrid, 3 Jahre. Für Papa.“ liegt auf dem Tisch. (Handout N44, führt zu: Gunnar Solheim) Ein Soldier sieht sie mit Wahrnehmung gegen Einfach (1).

### Zeile 486, Eskalation

**alt:** - **Donnerstag, 10. Februar:** Die Schulklasse im Tal. Ein Junge fragt nach dem Lied, das er nachts gehört hat. Wenn die Gruppe nicht da ist, hört sie am Freitag davon. Grauen-Probe: Verstörend (2), wenn sie erkennt, dass das Lied nicht von hier ist.

**neu:** - **Donnerstag, 10. Februar:** Eine deutsche Schulklasse bezieht die Hütte im Tal. Ein Junge fragt nach der Station mit den Antennen. Wenn die Gruppe nicht da ist, hört sie am Freitag davon.

### Zeile 495, Der Schauplatz

**alt:** Die Kantine von Nordlicht, Montag, 14. Februar 1977, 21:45 bis 22:10 Uhr. Der lange Tisch, die elf Thaumaturgen, der Kreidekreis auf der Platte, elf Tassen Kaffee. Das Küchenradio spielt Schlager. Die Wanduhr über der Tür. Für alle, die fahren: der Nachtzug von Stockholm nach Narvik, hinter Kiruna, um 22:10 Uhr. (Karte K12)

**neu:** Die Kantine von Nordlicht, Montag, 14. Februar 1977, 21:45 bis 22:10 Uhr. Der lange Tisch, die elf Thaumaturgen, der Kreidekreis auf der Platte, elf Tassen Kaffee. Das Küchenradio spielt Schlager. Die Wanduhr über der Tür (Karte K12). Für alle, die fahren: der Nachtzug von Stockholm nach Narvik, hinter Kiruna, um 22:10 Uhr.

### Zeile 504, Ablauf

**alt:** 7. **22:10 Uhr, Nachtzug.** Alle Uhren im Zug stehen, nur Ingrids Taschenuhr läuft in unter einer Minute eine ganze Nacht ab. Astrids Kristall wird kalt und grau von der Mitte her; das Flüstern, das sie 23 Jahre hörte, verstummt. Der Zug steht hinter Kiruna in Sichtweite der Grube, gut drei Stunden vom Stützpunkt.

**neu:** 7. **22:10 Uhr, Nachtzug.** Alle Uhren im Zug stehen, nur die Taschenuhr in Ingrids Hand läuft in unter einer Minute eine ganze Nacht ab. Astrids Kristall wird kalt und grau von der Mitte her; das Flüstern, das sie 23 Jahre hörte, verstummt. Der Zug steht hinter Kiruna in Sichtweite der Grube, gut drei Stunden vom Stützpunkt.

### Zeile 518, Kjell Haugen

**alt:** [entry - | Kjell Haugen | Profi · Menschen]

**neu:** [entry - | Kjell Haugen | Elite · Menschen]

### Zeile 523, Kjell Haugen

**alt:** **Verteidigung / Rüstung / LP** | 3 / 2 / 15

**alt:** **Grauen** | Verstörend (2), wenn er den Chor im Radio hört

**neu:** **Verteidigung / Rüstung / LP** | 3 / 2 / 14

**neu:** **Grauen** | Keines. Hört er den Chor im Radio, legt er selbst eine Grauen-Probe gegen Verstörend (2) ab

### Zeile 536, Nachspiel

**alt:** **Was O.D.I.N. bekommt:** Haugens Bericht SA-1977-02. Die Wanduhr aus der Kantine, stehen geblieben um 22:10 Uhr. Das Küchenradio, das am Morgen einen Chor spielt. Die 212 grauen Kristalle. Die Sonde, die 41 Menschen drüben misst. Die elf Akten des Nachtarbeiters. Die Schwarze Akte Nordlicht.

**neu:** **Was O.D.I.N. bekommt:** Haugens Bericht SA-1977-02. Die Wanduhr aus der Kantine, stehen geblieben um 22:10 Uhr. Das Küchenradio, das am Morgen einen Chor spielt. Die 212 grauen Kristalle. Die Sonde, die 41 Menschen drüben misst. Die Personalakten der elf Thaumaturgen (2014 die elf Akten des Nachtarbeiters). Die Schwarze Akte Nordlicht.

### Zeile 553, Nachspiel

**alt:** - Karte K12: Stützpunkt Nordlicht, Grundriss Erdgeschoss und Keller: Kantine über dem Archiv, Sonde am Treppenabgang, Werkstatt im Erdgeschoss, Wellblechschuppen als eigener Bau, elf Schlafräume zu vier Betten mit Zuordnung nach Dienstplan, ein Gästezimmer für die Gruppe.

**neu:** - Karte K11: Stützpunkt Nordlicht, Lageplan: Hauptbau, Wellblechschuppen, Landeplatz, Straße nach Narvik.

**neu:** - Karte K12: Stützpunkt Nordlicht, Grundriss Erdgeschoss und Keller: Kantine über dem Archiv, Sonde am Treppenabgang, Werkstatt im Erdgeschoss, Wellblechschuppen als eigener Bau, zehn Schlafräume zu vier Betten und eine Kammer für den Stationsleiter, mit Zuordnung nach Dienstplan, ein Gästezimmer für die Gruppe.

## 08_nacht.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 63, Der Dienstplan

**alt:** **Wie ein Spieleragent auf den Plan kommt.** Am Samstag, 12. Februar, entscheidet jeder Spieler einzeln, ob sein Agent bleibt oder fährt. Wer bleibt, übernimmt einen Tauschplatz passender Funktion: T1 Verbindung, T2 Thaumaturg, T3 Archivgehilfin, T4 Physiker, T5 Funkerin, T6 Wache, T7 Horcherin. Ein Spielerthaumaturg auf T2 gehört zu den elf und liest mit. Wer bleiben, aber nicht lesen will, nimmt T3. Stehen mehr Spieleragenten derselben Funktion bereit als Tauschplätze, ersetzen sie weitere Namen passender Funktion. Die Zahl 41 bricht nicht.

**neu:** **Wie ein Spieleragent auf den Plan kommt.** Am Samstag, 12. Februar, entscheidet jeder Spieler einzeln, ob sein Agent bleibt oder fährt. Wer bleibt, übernimmt einen Tauschplatz passender Funktion: T1 Verbindung, T2 Thaumaturg, T3 Archivgehilfin, T4 Physiker, T5 Funkerin, T6 Wache, T7 Horcherin. Ein Spielerthaumaturg auf T2 gehört zu den elf und liest mit. Wer bleiben, aber nicht lesen will, nimmt T3. Stehen mehr Spieleragenten derselben Funktion bereit als Tauschplätze, ersetzen sie weitere Namen passender Funktion, nie aber Einar Vatne und Arne Kvalvik. Die Zahl 41 bricht nicht.

### Zeile 178, 14. Februar, tagsüber

**alt:** In diesen Stunden hat jeder Agent im Zug eine Szene mit Astrid oder Ingrid. Astrid erzählt von der Werkstatt in Bergen und von Gunnars Plänen für den Sommer. Wer sie nach ihrem Stein fragt, hört, dass er flüstert wie immer: als Takt. Ingrid zeigt jedem ihre Taschenuhr und lässt sie nicht los.

**neu:** In diesen Stunden hat jeder Agent im Zug eine Szene mit Astrid oder Ingrid. Astrid erzählt von der Werkstatt in Bergen und von Gunnars Plänen für den Sommer. Wer sie nach ihrem Stein fragt, hört, dass er flüstert wie immer: als Takt. Ingrid zeigt jedem die Taschenuhr ihrer Mutter und lässt sie nicht los.

### Zeile 190, 22:10 Uhr, hinter Kiruna

**alt:** Alle Uhren im Zug stehen. Nur Ingrids Taschenuhr läuft in unter einer Minute eine ganze Nacht ab. Astrids Kristall wird kalt und grau von der Mitte her. Das Flüstern, das sie 23 Jahre hörte, verstummt. Der Zug steht hinter Kiruna in Sichtweite der Grube, gut drei Stunden vom Stützpunkt.

**neu:** Alle Uhren im Zug stehen. Nur die Taschenuhr in Ingrids Hand läuft in unter einer Minute eine ganze Nacht ab. Astrids Kristall wird kalt und grau von der Mitte her. Das Flüstern, das sie 23 Jahre hörte, verstummt. Der Zug steht hinter Kiruna in Sichtweite der Grube, gut drei Stunden vom Stützpunkt.

### Zeile 194, 22:10 Uhr, hinter Kiruna

**alt:** Ingrid schläft. Sie wacht nicht auf.

**neu:** Ingrid schläft weiter. Sie merkt nichts.

### Zeile 210, 4:00 Uhr, Bahnhof Narvik

**alt:** Astrid steckt Ingrids Taschenuhr in ihre Manteltasche und fragt niemanden mehr nach der Zeit. Danach repariert sie nie wieder eine Uhr. Ihre Werkstatt in Bergen bleibt geschlossen.

**neu:** Astrid steckt die Taschenuhr in ihre Manteltasche und fragt niemanden mehr nach der Zeit. Danach repariert sie nie wieder eine Uhr. Ihre Werkstatt in Bergen bleibt geschlossen.

### Zeile 226, Im Stützpunkt

**alt:** Haugen zählt seine Rücken zweimal. Im Büro des Stationsleiters liest er den Dienstplan, die 41 Namen, einen nach dem anderen, jeden mit Haken. Zwei kennt er: Magnus Rønning aus dem Lager Ashgrove und Gunnar Solheim aus Narvik, Dezember 1976. Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, steht dessen Name an der Stelle eines der beiden.

**neu:** Haugen zählt seine Rücken zweimal. Im Büro des Stationsleiters liest er den Dienstplan, die 41 Namen, einen nach dem anderen, jeden mit Haken. Zwei kennt er: Magnus Rønning aus dem Lager Ashgrove und Gunnar Solheim aus Narvik, Dezember 1976. Blieb ein Spieleragent, den Haugen in Einsatz 12 kennenlernte, steht dessen Name an der Stelle Rønnings.

## 09_nach.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 3, 

**alt:** Am 15. Februar 1977 landet der Suchtrupp des Taktischen Zweigs um 6:40 Uhr vor Nordlicht. Die Tür ist unverschlossen. Die Heizung läuft. Im Radio spielt ein norwegischer Schlager. Auf dem Küchentisch stehen elf Kaffeetassen, zehn halb voll und warm. Die Betten sind gemacht. In der Krankenstation liegt ein Zettel: Aspirin wird knapp. Im Archiv liegen 212 Kristalle, grau wie Schiefer, verzeichnet, verpackt, an ihren Plätzen. Leutnant Kjell Haugen meldet: Stützpunkt unversehrt, 41 Personen vermisst, eigene Verluste keine. Der Rat antwortet: Empfehlung angenommen. Versiegelung nach der Räumung durch Institut und Kollegium.

**neu:** Am 15. Februar 1977 landet der Suchtrupp des Taktischen Zweigs um 6:40 Uhr vor Nordlicht. Die Tür ist unverschlossen. Die Heizung läuft. Im Radio spielt ein norwegischer Schlager. Auf dem langen Tisch in der Kantine stehen elf Kaffeetassen, zehn halb voll und warm. Die Betten sind gemacht. In der Krankenstation liegt ein Zettel: Aspirin wird knapp. Im Archiv liegen 212 Kristalle, grau wie Schiefer, verzeichnet, verpackt, an ihren Plätzen. Leutnant Kjell Haugen meldet: Stützpunkt unversehrt, 41 Personen vermisst, eigene Verluste keine. Der Rat antwortet: Empfehlung angenommen. Versiegelung nach der Räumung durch Institut und Kollegium.

### Zeile 17, Hallström, 16. Februar 1977

**alt:** Wer als Spieleragent in der Registratur arbeitet, kann in dieser Szene anwesend sein. Hallström erklärt nichts. Wer fragt, bekommt die Antwort: „Schreiben Sie auf, was Sie gesehen haben. In Ihren eigenen Worten. Nicht für die Akte.“ Das ist die einzige Probe der Szene: keine Fertigkeit, nur die Entscheidung, was der Agent aufschreibt und was nicht.

**neu:** Wer als Spieleragent in der Registratur arbeitet und zu spät kam, erlebt die Szene nach der Rückkehr aus dem Norden: Hallström hat die Seite noch aufgeschlagen, als der Agent sein Büro betritt. Hallström erklärt nichts. Wer fragt, bekommt die Antwort: „Schreiben Sie auf, was Sie gesehen haben. In Ihren eigenen Worten. Nicht für die Akte.“ Das ist die einzige Probe der Szene: keine Fertigkeit, nur die Entscheidung, was der Agent aufschreibt und was nicht.

## 10_anhang.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 11, Anhang A: Sechs fertige Agenten

**alt:** Die hier aufgeführten Schützlinge sind die späten, die 1977 an der Seite der Agenten stehen. Ab Einsatz 2 hat jeder Agent einen Schützling, vor Einsatz 4 im Jahr 1953 sollte jeder einen haben. Frühere Vorschläge: Für Ness ein Rekrut der Eskorte aus dem ersten Transport, etwa ein junger Norweger aus der Kompanie Linge (1949 benannt, fällt 1953 in Kiruna, Nachfolger wird Tove). Für Marchais eine Rekrutin aus Marshs Netz in Lyon (1949 benannt, geht 1958 mit dem Konvoi, Nachfolger wird Arnaud). Für Rask ein Mitarbeiter des Instituts aus der ersten Stunde (1949 benannt, bleibt in Bern, Nachfolgerin wird Lindqvist). Für Ozola eine andere von den Einunddreißig (1949 benannt, geht 1971 in die Stille, Nachfolgerin wird Sula). Für Vaughan ein Lehrling des Kollegiums (1949 benannt, geht 1959 mit Holloway durch die Tür, Nachfolger wird Rhodri). Für Ekvall ein Sekretär der Registratur (1949 benannt, stirbt 1962 in Bad Grund, Nachfolgerin wird Lönn).

**neu:** Die hier aufgeführten Schützlinge sind die späten, die 1977 an der Seite der Agenten stehen. Ab Einsatz 2 hat jeder Agent einen Schützling, vor Einsatz 4 im Jahr 1953 sollte jeder einen haben. Frühere Vorschläge: Für Ness ein Rekrut der Eskorte aus dem ersten Transport, etwa ein junger Norweger aus der Kompanie Linge (1949 benannt, fällt 1953 in Kiruna, Nachfolger wird Tove). Für Marchais eine Rekrutin aus Marshs Netz in Lyon (1949 benannt, geht 1958 mit dem Konvoi, Nachfolger wird Arnaud). Für Rask ein Mitarbeiter des Instituts aus der ersten Stunde (1949 benannt, bleibt in Bern, Nachfolgerin wird Lindqvist). Für Ozola eine andere von den Einunddreißig (1949 benannt, geht 1971 in die Stille, Nachfolgerin wird Sula). Für Vaughan ein Lehrling des Kollegiums (1949 benannt, hält 1959 mit der Gruppe Wache, als Holloway geht, und verlässt danach das Kollegium; Nachfolger wird Rhodri). Für Ekvall ein Sekretär der Registratur (1949 benannt, stirbt 1962 in Bad Grund, Nachfolgerin wird Lönn).

### Zeile 51, Harald Ness, „Salz“

**alt:** **Fertigkeiten 1947:** Schusswaffen 4, Ausdauer 4, Taktik 3, Überleben 3, Athletik 2, Nahkampf 2, Wahrnehmung 2, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 2, Fahren 1, Handwerk 1, Heimlichkeit 1, Medizin 1.

**neu:** **Fertigkeiten 1947:** Schusswaffen 5, Ausdauer 4, Taktik 3, Überleben 3, Athletik 2, Nahkampf 3, Wahrnehmung 3, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 2, Heimlichkeit 2, Medizin 2, Fahren 1, Handwerk 1.

### Zeile 53, Harald Ness, „Salz“

**alt:** **Fertigkeiten 1977:** Schusswaffen 5, Taktik 5, Ausdauer 4, Überleben 4, Wahrnehmung 3, Geistige Widerstandskraft 3, Ausweichen 3, Zähigkeit 2, Athletik 2, Nahkampf 2, Führung 4, Fahren 1, Handwerk 1, Heimlichkeit 1, Medizin 1.

**neu:** **Fertigkeiten 1977:** Schusswaffen 6, Taktik 5, Ausdauer 4, Überleben 4, Wahrnehmung 4, Führung 4, Geistige Widerstandskraft 3, Ausweichen 3, Nahkampf 3, Zähigkeit 2, Athletik 2, Heimlichkeit 2, Medizin 2, Fahren 1, Handwerk 1.

### Zeile 88, Colette Marchais, „Garn“

**alt:** **Fertigkeiten 1947:** Täuschung 4, Verkleidung 3, Etikette 3, Heimlichkeit 3, Wahrnehmung 2, Schusswaffen 2, Überzeugen 2, Ausweichen 1, Geistige Widerstandskraft 1, Menschenkenntnis 2, Fahren 1, Kryptografie 1, Auftreten 1, Hacking 1 (Subklassenbonus, im Band ohne Nutzen).

**neu:** **Fertigkeiten 1947:** Täuschung 4, Menschenkenntnis 4, Verkleidung 3, Etikette 3, Heimlichkeit 3, Überzeugen 3, Schusswaffen 3, Wahrnehmung 2, Fingerfertigkeit 2, Kryptografie 2, Fahren 2, Ausweichen 1, Geistige Widerstandskraft 1, Auftreten 1, Hacking 1 (Subklassenbonus, im Band ohne Nutzen).

### Zeile 90, Colette Marchais, „Garn“

**alt:** **Fertigkeiten 1977:** Täuschung 6, Menschenkenntnis 4, Kryptografie 3, Verkleidung 4, Etikette 4, Heimlichkeit 4, Wahrnehmung 3, Ausweichen 2, Geistige Widerstandskraft 2, Schusswaffen 2, Überzeugen 2, Fahren 1, Auftreten 1, Hacking 1.

**neu:** **Fertigkeiten 1977:** Täuschung 6, Menschenkenntnis 6, Kryptografie 4, Verkleidung 4, Etikette 4, Heimlichkeit 4, Wahrnehmung 3, Überzeugen 3, Schusswaffen 3, Fingerfertigkeit 2, Fahren 2, Ausweichen 2, Geistige Widerstandskraft 2, Auftreten 1, Hacking 1.

### Zeile 98, Colette Marchais, „Garn“

**alt:** **Schützling:** Jean-Luc Arnaud, geboren 1944. Ein ehemaliger Fremdenlegionär, der 1968 in Paris desertiert. Marsh findet ihn in einem Hinterzimmer in Marseille, wo er Karten spielt. Er ist kein Spion, aber er kann reden. Marchais bildet ihn als Negotiator aus: Verhandeln, Menschenkenntnis, Führung. Arnaud hat 1977 seine ersten Einsätze hinter sich. Er spricht vier Sprachen, trägt immer einen Füller bei sich und schreibt Briefe, die nie abgeschickt werden.

**neu:** **Schützling:** Jean-Luc Arnaud, geboren 1944. Ein ehemaliger Fremdenlegionär, der 1968 in Paris desertiert. Marsh findet ihn in einem Hinterzimmer in Marseille, wo er Karten spielt. Er ist kein Spion, aber er kann reden. Marchais bildet ihn als Negotiator aus: Menschenkenntnis, Täuschung, Etikette. Arnaud hat 1977 seine ersten Einsätze hinter sich. Er spricht vier Sprachen, trägt immer einen Füller bei sich und schreibt Briefe, die nie abgeschickt werden.

### Zeile 125, Dr. Ingeborg Rask, „Lot“

**alt:** **Fertigkeiten 1947:** Physik 4, Technik 3, Akademisches Wissen 3, Navigation 2, Wahrnehmung 2, Chemie 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Ingenieurwesen 2, Energiemanipulation 1, Handwerk 1.

**neu:** **Fertigkeiten 1947:** Physik 4, Technik 4, Akademisches Wissen 4, Chemie 3, Ingenieurwesen 3, Navigation 3, Wahrnehmung 3, Energiemanipulation 2, Medizin 2, Handwerk 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Ermittlung 1, Fahren 1.

### Zeile 127, Dr. Ingeborg Rask, „Lot“

**alt:** **Fertigkeiten 1977:** Physik 6, Technik 5, Energiemanipulation 3, Akademisches Wissen 4, Navigation 3, Chemie 3, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Ingenieurwesen 3, Handwerk 1, Wahrnehmung 3.

**neu:** **Fertigkeiten 1977:** Physik 6, Technik 6, Akademisches Wissen 5, Energiemanipulation 4, Chemie 4, Ingenieurwesen 4, Navigation 4, Wahrnehmung 4, Medizin 2, Handwerk 2, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Ermittlung 1, Fahren 1.

### Zeile 135, Dr. Ingeborg Rask, „Lot“

**alt:** **Schützling:** Beate Lindqvist, geboren 1946. Eine Ingenieurin aus Göteborg, die 1969 ins Institut kommt. Rask bildet sie als Engineer aus: Ingenieurwesen, Technik, Handwerk. Lindqvist baut 1976 die Verkabelung der Sonde. Sie ist diejenige, die den Ausdruck der Sonde in den Keller bringt. 1977 wartet sie in Bern auf Rasks Rückkehr. Kommt Rask zurück, fragt Lindqvist: „Was hat die Sonde gezählt?“ Rask antwortet: „Menschen. Hoffentlich.“

**neu:** **Schützling:** Beate Lindqvist, geboren 1946. Eine Ingenieurin aus Göteborg, die 1969 ins Institut kommt. Rask bildet sie als Engineer aus: Technik, Ingenieurwesen, Physik. Lindqvist baut 1976 die Verkabelung der Sonde. Sie ist diejenige, die den Ausdruck der Sonde in den Keller bringt. 1977 wartet sie in Bern auf Rasks Rückkehr. Kommt Rask zurück, fragt Lindqvist: „Was hat die Sonde gezählt?“ Rask antwortet: „Menschen. Hoffentlich.“

### Zeile 164, Ilga Ozola, „Möwe“

**alt:** **Fertigkeiten 1947:** Telepathie 5, Menschenkenntnis 4, Konzentration 3, Geistige Widerstandskraft 3, Wahrnehmung 2, Ausweichen 1, Psi-Kampf 1, Überzeugen 1, Heimlichkeit 1, Medizin 1.

**neu:** **Fertigkeiten 1947:** Telepathie 5, Menschenkenntnis 4, Konzentration 4, Geistige Widerstandskraft 3, Überzeugen 3, Wahrnehmung 3, Täuschung 2, Psi-Kampf 2, Heimlichkeit 2, Medizin 2, Ausweichen 1, Etikette 1, Akademisches Wissen 1, Geschichte 1, Fahren 1.

### Zeile 166, Ilga Ozola, „Möwe“

**alt:** **Fertigkeiten 1977:** Telepathie 6, Konzentration 5, Psi-Kampf 3, Menschenkenntnis 5, Geistige Widerstandskraft 4, Wahrnehmung 3, Ausweichen 2, Überzeugen 1, Heimlichkeit 1, Medizin 1.

**neu:** **Fertigkeiten 1977:** Telepathie 6, Konzentration 6, Menschenkenntnis 5, Psi-Kampf 4, Geistige Widerstandskraft 4, Wahrnehmung 4, Überzeugen 3, Täuschung 2, Heimlichkeit 2, Medizin 2, Ausweichen 2, Etikette 1, Akademisches Wissen 1, Geschichte 1, Fahren 1.

### Zeile 203, Dilys Vaughan, „Schiefer“

**alt:** **Fertigkeiten 1947:** Thaumaturgie 4, Ritualismus 4, Okkultismus 4, Konzentration 3, Akademisches Wissen 2, Ausweichen 1, Geistige Widerstandskraft 1, Wahrnehmung 1, Alchemie 1, Geschichte 1.

**neu:** **Fertigkeiten 1947:** Thaumaturgie 4, Ritualismus 4, Okkultismus 4, Konzentration 4, Akademisches Wissen 4, Alchemie 3, Geschichte 3, Menschenkenntnis 2, Wahrnehmung 2, Ausweichen 1, Geistige Widerstandskraft 1, Überzeugen 1, Medizin 1, Handwerk 1.

### Zeile 205, Dilys Vaughan, „Schiefer“

**alt:** **Fertigkeiten 1977:** Thaumaturgie 6, Ritualismus 6, Okkultismus 5, Konzentration 4, Akademisches Wissen 3, Ausweichen 2, Geistige Widerstandskraft 2, Wahrnehmung 2, Alchemie 1, Geschichte 1.

**neu:** **Fertigkeiten 1977:** Thaumaturgie 6, Ritualismus 6, Okkultismus 5, Konzentration 5, Akademisches Wissen 5, Alchemie 3, Geschichte 3, Wahrnehmung 3, Menschenkenntnis 2, Ausweichen 2, Geistige Widerstandskraft 2, Überzeugen 1, Medizin 1, Handwerk 1.

### Zeile 211, Dilys Vaughan, „Schiefer“

**alt:** **Fäden:** Ist Vaughan 1953 in Kiruna, überlebt sie, weil sie außerhalb des Bannkreises bleibt. Der andere Thaumaturg zieht den Kreis, antwortet dem Ding und geht durch den Fels. Sie sieht ihn durch den Fels gehen. Seitdem zeichnet sie jeden Bannkreis zweimal. 1957 wird sie Astrid Solheims Aufsicht, ein Jahr nachdem die erste Chronomancerin ins Kollegium kam. Vaughan bringt ihr bei: „Zeit ist ein Kreis. Wer ihn verlässt, kommt anders zurück.“ 1977 kann Vaughan eine der elf Thaumaturgen sein, die in der Kantine über dem Archiv den siebten Kreis lesen. Sie weiß, was 1953 passiert ist. Sie liest trotzdem. Um 22:10 öffnet sich die Tür. Vaughan kann hindurchgehen. Ihre Uhr bleibt stehen. Ihr Kristall wird grau. Oder sie begleitet Astrid im verspäteten Zug nach Narvik und kommt zu spät.

**neu:** **Fäden:** Ist Vaughan 1953 in Kiruna, überlebt sie, weil sie außerhalb seines Kreises bleibt. Der andere Thaumaturg zieht den Kreis, antwortet dem Ding und geht durch den Fels. Sie sieht ihn durch den Fels gehen. Seitdem zeichnet sie jeden Bannkreis zweimal. 1957 wird sie Astrid Solheims Aufsicht, ein Jahr nachdem die erste Chronomancerin ins Kollegium kam. Vaughan bringt ihr bei: „Zeit ist ein Kreis. Wer ihn verlässt, kommt anders zurück.“ 1977 kann Vaughan eine der elf Thaumaturgen sein, die in der Kantine über dem Archiv den siebten Kreis lesen. Sie weiß, was 1953 passiert ist. Sie liest trotzdem. Um 22:10 öffnet sich die Tür. Vaughan kann hindurchgehen. Ihre Uhr bleibt stehen. Ihr Kristall wird grau. Oder sie begleitet Astrid im verspäteten Zug nach Narvik und kommt zu spät.

### Zeile 213, Dilys Vaughan, „Schiefer“

**alt:** **Schützling:** Rhodri Vaughan, geboren 1948. Dilys’ Neffe, der als Kind im Schieferbruch spielt. Er tritt 1965 ins Kollegium ein. Dilys bildet ihn als Thaumaturgisten aus: Thaumaturgie, Ritualismus, Okkultismus. Rhodri ist 1977 Adept des dritten Kreises. Er bleibt in Wales und wartet auf Nachricht aus Nordlicht. Geht Dilys durch die Tür, kommt die Nachricht nie.

**neu:** **Schützling:** Rhodri Vaughan, geboren 1948. Dilys’ Neffe, der als Kind im Schieferbruch spielt. Er tritt 1965 ins Kollegium ein. Dilys bildet ihn als Thaumaturgisten aus: Thaumaturgie, Ritualismus, Okkultismus. Rhodri ist 1977 Adept des zweiten Kreises. Er bleibt in Wales und wartet auf Nachricht aus Nordlicht. Geht Dilys durch die Tür, kommt die Nachricht nie.

### Zeile 240, Torsten Ekvall, „Zeuge“

**alt:** **Fertigkeiten 1947:** Ermittlung 4, Wahrnehmung 4, Menschenkenntnis 3, Fahren 3, Okkultismus 2, Spurenlesen 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Geschichte 1, Überzeugen 1, Heimlichkeit 1.

**neu:** **Fertigkeiten 1947:** Ermittlung 4, Wahrnehmung 4, Menschenkenntnis 3, Fahren 3, Okkultismus 3, Spurenlesen 3, Schusswaffen 2, Geschichte 2, Überzeugen 2, Heimlichkeit 2, Ausweichen 1, Geistige Widerstandskraft 1, Zähigkeit 1, Akademisches Wissen 1, Einschüchtern 1, Medizin 1, Sicherheitssysteme 1.

### Zeile 242, Torsten Ekvall, „Zeuge“

**alt:** **Fertigkeiten 1977:** Ermittlung 6, Okkultismus 4, Menschenkenntnis 5, Wahrnehmung 5, Fahren 3, Spurenlesen 3, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Geschichte 1, Überzeugen 1, Heimlichkeit 1. Ab 60: Athletik oder Ausdauer um 1 gesenkt. Ekvall hat beide auf 0, der Abzug entfällt.

**neu:** **Fertigkeiten 1977:** Ermittlung 6, Menschenkenntnis 5, Okkultismus 5, Wahrnehmung 5, Spurenlesen 4, Fahren 3, Schusswaffen 2, Geschichte 2, Überzeugen 2, Heimlichkeit 2, Ausweichen 2, Geistige Widerstandskraft 2, Zähigkeit 1, Akademisches Wissen 1, Einschüchtern 1, Medizin 1, Sicherheitssysteme 1. Ab 60: Athletik oder Ausdauer um 1 gesenkt. Ekvall hat beide auf 0, der Abzug entfällt.

### Zeile 248, Torsten Ekvall, „Zeuge“

**alt:** **Fäden:** Ekvall ist Hallströms erster Mann in der Registratur. Er kennt alle Aktenfarben, bevor sie offiziell werden. 1948 packt er mit Hallström die Ahnenerbe-Kiste aus. Hallström findet das Foto der Kreise von 1937 und hängt es an die Wand der Registratur. 1950 liest Ekvall das Protokoll der Apothekerin. Am Rand steht die Zahl 32, nicht von ihr. Ekvall fragt Hallström: „Wer hat die Zahl geschrieben?“ Hallström antwortet: „Ich weiß es nicht. Und ich will es nicht wissen.“ 1962 ist Ekvall dabei, als Britt Holm nach dem Zugunglück im Harz identifiziert wird. Er findet in ihrer Tasche eine Notiz: „Wer holt sie?“ Er gibt sie Hallström. Hallström legt sie in Notizbuch null. Nach der Nacht von Nordlicht bleibt der Stützpunkt versiegelt. Bis zur Räumung am 20. Februar bleiben alle außer einem Scientist mit Wendland am Draht. Wo Ekvall in der Nacht ist, im Stützpunkt oder mit Astrid im Zug, entscheidet der Spieler. Auf dem Dienstplan vertritt Lönn die Registratur (T1).

**neu:** **Fäden:** Ekvall ist Hallströms erster Mann in der Registratur. Er kennt alle Aktenfarben, bevor sie offiziell werden. 1948 packt er mit Hallström die Ahnenerbe-Kiste aus. Hallström findet das Foto der Kreise von 1937 und hängt es an die Wand der Registratur. 1950 liest Ekvall das Protokoll der Apothekerin. Am Rand steht die Zahl 32, nicht von ihr. Ekvall fragt Hallström: „Wer hat die Zahl geschrieben?“ Hallström antwortet: „Ich weiß es nicht. Und ich will es nicht wissen.“ 1962 ist Ekvall dabei, als Britt Holm nach dem Zugunglück im Harz identifiziert wird. Ihre Aktentasche mit der Akte und Hallströms Zettel wird nie gefunden. Ekvall meldet es Hallström. Hallström schreibt in Notizbuch null: „Akte Holm nicht angekommen.“ Nach der Nacht von Nordlicht bleibt der Stützpunkt gesperrt und wird erst nach der Räumung versiegelt. Während der Räumung ab dem 20. Februar bleiben alle außer einem Scientist mit Wendland am Draht. Wo Ekvall in der Nacht ist, im Stützpunkt oder mit Astrid im Zug, entscheidet der Spieler. Auf dem Dienstplan vertritt Lönn die Registratur (T1).

### Zeile 333, Das Ding in der Wand

**alt:** Im Februar 1953 bricht in einem Stollen ohne Plan, keine hundert Meter vom stillen Hohlraum entfernt, etwas durch. Das Kollegium schickt zwei Thaumaturgen, Ashgrove führt vierzehn Mann. Das Ding in der Wand ist ein Schwellenhüter, der in der Wand des Stollens steht, halb im Fels, halb davor. Es trägt Kleider aus verschiedenen Jahrhunderten übereinander, und sein Gesicht ist das Gesicht dessen, der es ansieht, nur älter. Vor der ersten Brandmunition im Herbst 1953 gilt die Kiruna-Regel: Gewöhnliche Waffen verursachen keinen Schaden. Nur Bannkreise, Zauber und Rückzug schützen. Ein Thaumaturg zieht einen Bannkreis, bleibt darin, antwortet dem Ding. Es wendet sich ihm zu. Die Tür schließt sich mit ihm drüben.

**neu:** Im Februar 1953 bricht in einem Stollen ohne Plan, keine hundert Meter vom stillen Hohlraum entfernt, etwas durch. Das Kollegium schickt zwei Thaumaturgen, Ashgrove führt vierzehn Mann. Das Ding in der Wand ist ein Schwellenhüter, der in der Wand des Stollens steht, halb im Fels, halb davor. Es trägt Kleider aus verschiedenen Jahrhunderten übereinander, und sein Gesicht ist das Gesicht dessen, der es ansieht, nur älter. Vor der ersten Brandmunition im Herbst 1953 gilt die Kiruna-Regel: Gewöhnliche Waffen verursachen keinen Schaden. Nur Bannkreise, Zauber und Rückzug schützen. Ein Thaumaturg zieht einen Kreis, der kein Bannkreis ist, bleibt darin und antwortet dem Ding. Es wendet sich ihm zu. Die Tür schließt sich mit ihm drüben.

### Zeile 335, Das Ding in der Wand

**alt:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Der Schwellenhüter ist mit der Kiruna-Regel unverwundbar. Die Szene ist kein Kampf, sondern ein Gespräch, das ein Thaumaturg mit einem Bannkreis und einer Antwort überlebt.)

**neu:** (Werte: „Schwellenhüter von Kiruna“, Einsatz 4. Abweichung vom Bedrohungsatlas: Seine Berührung macht keinen Schaden, wer getroffen wird, geht durch die Wand hinüber. Mit der Kiruna-Regel ist er unverwundbar. Die Szene ist kein Kampf, sondern ein Gespräch, das mit einer Antwort endet.)

### Zeile 342, Kristallwächter

**alt:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Die Wächter tragen die Kleidung von Bergleuten, die im Stollen verschwunden sind, unter einer Kruste aus Stein. Vor der ersten Brandmunition im Herbst 1953 gilt die Kiruna-Regel auch für sie, aber sie zerfallen, wenn der Kristall erschöpft wird.)

**neu:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Die Wächter tragen die Kleidung von Bergleuten, die im Stollen verschwunden sind, unter einer Kruste aus Stein. Vor der ersten Brandmunition im Herbst 1953 gilt die Kiruna-Regel auch für sie, aber sie zerfallen, wenn der Bannkreis steht und das Ding den Thaumaturgen nimmt (Werte: Einsatz 4).)

### Zeile 354, Rissling, Der Zuschauer

**alt:** In Cornwall öffnet sich 1957 ein kleiner Riss. Risslinge sickern durch, kleine, flinke Wesen, die aussehen wie Hunde, die jemand nur aus der Erinnerung gezeichnet hat. Am Rand des Risses steht ein Zuschauer: hochgewachsen, grau, still. Er trägt einen langen grauen Mantel, der wie Haut wirkt, und einen Hut, den er nicht abnimmt. Er beobachtet, notiert, verschwindet. Auf Fotos ist er verwackelt, immer, auch wenn alles andere scharf ist.

**neu:** In Cornwall öffnet sich 1957 ein kleiner Riss. Am Rand des Risses steht ein Zuschauer: hochgewachsen, grau, still. Er trägt einen langen grauen Mantel, der wie Haut wirkt, und einen Hut, den er nicht abnimmt. Er beobachtet, notiert, verschwindet. Auf Fotos ist er verwackelt, immer, auch wenn alles andere scharf ist.

### Zeile 356, Rissling, Der Zuschauer

**alt:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Risslinge treten in Cornwall auf, wo die erste Brandmunition im Herbst 1953 getestet wurde. Der Zuschauer wird vom Institut fotografiert, das Foto ist das erste von dreien, die es gibt.)

**neu:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: In Porthcarn 1957 zeigt sich nur der Zuschauer; der Riss ist derselbe, an dem im Herbst 1953 die erste Brandmunition getestet wurde. Der Zuschauer wird vom Institut fotografiert, das Foto ist das erste von dreien, die es gibt.)

### Zeile 370, Verbindungsoffizier eines Partnerdienstes

**alt:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Er arbeitet mit Fernschreibern, Telegrammen und toten Briefkästen. Seine Waffe ist eine Dienstpistole im Schulterhalfter, aber er zieht sie selten.)

**neu:** (Werte: Bedrohungsatlas, Spielleiterbuch. Abweichung der Zeit: Er arbeitet mit Fernschreibern, Telegrammen und toten Briefkästen. Seine Waffe ist eine Dienstpistole im Schulterhalfter, aber er zieht sie selten. Vor dem Schleierprotokoll 1961 entfällt seine Besonderheit, Polizei, Grenze oder Justiz zurückzupfeifen.)

### Zeile 540, Arsenal

**alt:** Phosphorbrandmunition | vor 1947

**neu:** Phosphorbrandmunition | vor 1947 | gegen Wesen aus Rissen erst ab Herbst 1953 wirksam (Kiruna-Regel, Kapitel 3)

### Zeile 611, Arsenal

**alt:** Weicheisenschrot | vor 1947

**neu:** Weicheisenschrot | vor 1947 | nur über die Werkstatt, im Jagdgeschäft erst nach dem Bleiverbot

### Zeile 660, Grundregelwerk

**alt:** Leichte Rüstung | ab 1953 | Behelf (Ofentür)

**neu:** Leichte Rüstung | ab 1953 | Behelf (Ofentür, Werte Kapitel 3)

### Zeile 684, Grundregelwerk

**alt:** EMF-Detektor | ab 1960

**neu:** EMF-Detektor | ab 1960 | als Rissdetektor aus Holz und Messing (Kapitel 3)

### Zeile 688, Grundregelwerk

**alt:** Taschenlampe mit UV-Funktion | vor 1947

**neu:** Taschenlampe mit UV-Funktion | vor 1947 | Taschenlampe mit Filter, eingeschränkt
