# Horte der Welt EN: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 1 Stellen.

## 01_inseln.md (Sicherung vor_messer_2026-10-10)

### Zeile 33, History

**alt:** **1955.** Evan Pryce hands Ashgrove the first knife made of ashsilver. Ashgrove places it in the armoury of Hold-1, where it lies to this day.

**neu:** **1955.** Evan Pryce hands Ashgrove the first knife made of ashsilver. Ashgrove carries it until his death; since then it has lain in the armoury of Hold-1.
