# Graue Akten EN: Änderungen alt → neu

Stand 11.10.2026, ODIN Writer. Erzeugt aus den Quelltexten: jede geänderte Stelle mit Datei, Zeile in der neuen Fassung und nächster Überschrift. Vergleichsstand ist die Sicherung vor der ersten Änderung am 10./11.10. 131 Stellen.

## Stellen mit Gegnerwerten

- 03_nummer341.md:174 (Owen Gwynne)
- 03_nummer341.md:188 (Alistair Vane)
- 03_nummer341.md:200 (Mr Hartley)
- 03_nummer341.md:202 (Mr Hartley)
- 03_nummer341.md:214 (Daniel Keane)
- 03_nummer341.md:216 (Daniel Keane)
- 03_nummer341.md:230 (Rhys Bowen)
- 05_zweiter_kreis.md:219 (Thomas Leitner, alias Thomas Lechner)

## 00_einfuehrung.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 31, The Eight Files

**alt:** 3 | Number 341 | Cardiff, Grangetown | The Dead, Humans | Grey

**neu:** 3 | Number 341 | Cardiff, Grangetown | The Dead, Humans | Grey, can turn red

### Zeile 36, The Eight Files

**alt:** 8 | The Second Light | Brussels, Anderlecht | Humans, The Voice | Grey

**neu:** 8 | The Second Light | Brussels, Anderlecht | Humans, The Voice | Grey, can turn red

### Zeile 45, The Eight Files

**alt:** **File 4: Kessler.** A quiet accountant has been working at a Basel foundation for four years. Six months ago he fell ill, now he is back, and a colleague does not believe his memory gaps. The cell is to discreetly find out who the man calling himself Martin Kessler is.

**neu:** **File 4: Kessler.** A quiet accountant worked at a Basel foundation for four years. In March 2025 he fell ill, in January he came back, and a colleague does not believe his memory gaps. The cell is to discreetly find out who the man calling himself Martin Kessler is.

### Zeile 63, Connecting Files

**alt:** Some files share open threads. The children’s song appears in Files 5, 6 and 7. The time 22:10 appears in Files 2 and 3. The unknown abbreviation in the Crystal Ledger connects File 1 to File 2. The game master can pick up these threads when weaving the files into a campaign. Each file also works on its own.

**neu:** Some files share open threads. The children’s song appears in Files 5, 6 and 7. The time 22:10 appears in Files 2, 3 and 6. The unknown abbreviation in the Crystal Ledger connects File 1 to File 2. The game master can pick up these threads when weaving the files into a campaign. Each file also works on its own.

## 01_pflegefall.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 22, What Really Happened

**alt:** For a few weeks, Linus has been hearing a hum that is getting louder. He sleeps badly, eats little, and when he concentrates, things become warm. Three weeks ago, he found a small, milky crystal on the banks of the Elbe that dampened the hum when he held it tight. He took it home and hid it under the mattress. Last night he was at the Kowalskis’ to watch the fish swim. He thought of nothing, only of the water, and the water began to boil. Linus ran home, packed his rucksack and disappeared. He does not want his parents to get into trouble because of him. He went on foot towards the S-Bahn, then into the city centre, and is looking for a place where it is quiet. He has hidden in the old Elbe Tunnel, in the east tube, where the hum is quieter.

**neu:** For a few weeks, Linus has been hearing a hum that is getting louder. He sleeps badly, eats little, and when he concentrates, things become warm. Three weeks ago, he found a small, milky crystal on the banks of the Elbe that dampened the hum as long as he held it tight. When he let go, the hum came back louder: the stone feeds the gift. Linus took it home and hid it under the mattress. Last night he was at the Kowalskis’ to watch the fish swim. He thought of nothing, only of the water, and the water began to boil. Linus ran home, packed his rucksack and disappeared. He does not want his parents to get into trouble because of him. He went on foot towards the S-Bahn, then into the city centre, and is looking for a place where it is quiet. He has hidden in the old Elbe Tunnel, in the east tube, where the hum is quieter.

### Zeile 44, Mr Kowalski, 52

**alt:** Neighbour, insurance salesman. Wants peace and an explanation for the dead aquarium. Knows nothing about the supernatural, suspects a former tenant. Conceals that he did call the police after all, because he does not trust the Vosses. Speaks loudly, indignantly, repeats himself.

**neu:** Neighbour, insurance salesman. Wants peace and an explanation for the dead aquarium. Knows nothing about the supernatural, suspects a former tenant. Conceals that he did call the police last night after all, because of the aquarium and because he does not trust the Vosses. The patrol came, found nothing and left again. Speaks loudly, indignantly, repeats himself.

### Zeile 83, Node 2: Linus’ Room

**alt:** - **Clue:** The rucksack is missing, the S-Bahn card is gone (leads to Linus’ whereabouts, conclusion 3).

**neu:** - **Clue:** The rucksack is missing, the money box is empty (leads to Linus’ whereabouts, conclusion 3).

### Zeile 100, Node 4: Neugraben S-Bahn Station

**alt:** A small station, a kiosk, a surveillance camera. Linus was last seen here.

**neu:** A small station, a kiosk, four surveillance cameras. Linus was last seen here.

### Zeile 127, Escalation

**alt:** The file turns red if the cell is too slow or if Jonas Vogt notices them. Vogt is not a murderer, but he will not let Linus go without a fight. If the cell enters the old Elbe Tunnel without concealing themselves, Vogt addresses them by name and places himself between them and Linus. Linus’ gift reacts to the tension: the lamps in the tunnel flicker, the water in the puddles begins to steam.

**neu:** The file turns red if the cell is too slow or if Jonas Vogt notices them. The cell is too slow if it visits more than three nodes before setting out for the old Elbe Tunnel. Vogt is not a murderer, but he will not let Linus go without a fight. If the cell enters the old Elbe Tunnel without concealing themselves, Vogt addresses them by name and places himself between them and Linus. Linus’ gift reacts to the tension: the lamps in the tunnel flicker, the water in the puddles begins to steam.

### Zeile 197, Linus Voss

**alt:** The Open Ones as an organisation, their goals and further opponents are in the Threat Atlas. The values of the Open One (Elite) come from the Psion Building Block, the values for Linus from the entry Choir Child in the Threat Atlas. Maren Falk, the Observer, appears only if the cell requests her. She has no combat values, but can give clues on the phone.

**neu:** The Open Ones as an organisation and their goals are in the chapter “The World Behind the Veil” of the Game Master’s Book, further opponents in the Threat Atlas. The values of the Open One (Elite) come from the Psion Building Block, the values for Linus from the entry Choir Child in the Threat Atlas. Maren Falk, the Observer, appears only if the cell requests her. She has no combat values, but can give clues on the phone.

### Zeile 201, Aftermath

**alt:** **The Veil:** The neighbours saw the boiling aquarium, but the police were not called, except by Mr Kowalski, who reported a break-in. An agent can close the file: The Kowalskis get an explanation: a faulty heating element. The Vosses get a new legend for Linus’ disappearance: a boarding school, a cure. The S-Bahn recordings are secured and deleted.

**neu:** **The Veil:** The neighbours saw the boiling aquarium, but the police were not called, except by Mr Kowalski, who reported a break-in two weeks ago and called the patrol last night. An agent can close the file: The Kowalskis get an explanation: a faulty heating element. The Vosses get a new legend for Linus’ disappearance: a boarding school, a cure. The S-Bahn recordings are secured and deleted.

### Zeile 205, Aftermath

**alt:** **Experience:** 5 XP per character. Plus 1 XP for a solution without combat. Plus 1 XP for saving the crystal.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if Linus is safe. At most +1 XP personal bonus, for example for a solution without combat. +1 XP for each thread the cell takes up, for example the abbreviation in the Crystal Ledger.

## 02_fundort.md (Sicherung vor_handoutcheck_2026-10-10)

### Zeile 14, What It Is About

**alt:** There, in the basement of the Hold, according to old building plans, there is a room with the number 4/12. In the official inspections it does not exist. The cell is to find out what is going on with the room without alerting the Hold. The cell’s handler knows nothing of the assignment.

**neu:** There, in the basement of the Hold, according to old building plans, there is a room with the number 4/12. The current floor plan does not show it. The cell is to find out what is going on with the room without alerting the Hold. The cell’s handler knows nothing of the assignment.

### Zeile 20, What Really Happened

**alt:** **The backstory:** Hold-9 in Prague was founded in 1992, in an old vaulted cellar beneath the old town. The building plan from 1991 shows twelve rooms in the basement. Eleven were built. The twelfth room, number 4/12, exists only on paper, but not in reality. That is what the official documents say.

**neu:** **The backstory:** Hold-9 in Prague was founded in 1992, in an old vaulted cellar beneath the old town. The conversion plan from 1991 keeps the numbering of the old air-raid shelter and shows twelve rooms in the basement. Eleven were fitted out. The twelfth room, number 4/12, exists only on paper, but not in reality. That is what the current floor plan says.

### Zeile 30, What Really Happened

**alt:** **The red herring:** The Hold director of Hold-9, Major Pavel Černý, a Soldier of the old school, considers the room to be an artefact of the communist past: a former listening room of the Czechoslovak secret service, which is missing from the plans because it never officially existed. He found the room years ago, but never entered it, because he believes it is a trap. He has fitted the door with a padlock and had the room removed from the current plans. He conceals this because he fears that O.D.I.N. would close the Hold if it became known that there is an unknown room there.

**neu:** **The red herring:** The Hold director of Hold-9, Major Pavel Černý, a Soldier of the old school, considers the room to be an artefact of the communist past: a former listening room of the Czechoslovak secret service, which is missing from the plans because it never officially existed. He found the room years ago, but never entered it, because he believes it is a trap. He has fitted the door with a padlock and had the room removed from the current plans, by a construction company that does not exist, paid from the Hold’s funds. He conceals this because he fears that O.D.I.N. would close the Hold if it became known that there is an unknown room there.

### Zeile 48, Ing. Marta Nováková, 47

**alt:** Civil engineer and Hold technician. She knows the Hold’s plans better than anyone else. She wants the plans to be correct, and it worries her that Room 4/12 is missing from the current plan. She knows that Černý found the room, but she has never entered it. She conceals that she once heard knocking from the room at night, even though it should have been empty. She talks quickly, technically, with lots of numbers.

**neu:** Civil engineer and Hold technician. She knows the Hold’s plans better than anyone else. She wants the plans to be correct, and it worries her that Room 4/12 is missing from the current plan. She knows that Černý found the room, but she has never entered it. She conceals that she once heard knocking from the room at night, even though it should have been empty. Eng. K. Svoboda, who added pencil notes to the old plans and carried out the first inspection in 1992, was her mentor. She knows that he never wanted Room 4/12 opened. She talks quickly, technically, with lots of numbers.

### Zeile 56, Eliška, 12

**alt:** Daughter of an external service provider. Her father maintains the Hold’s heating system, and she sometimes accompanies him to the cellar. She has often explored the Hold. She wants to have adventures and be taken seriously by the agents. She knows that Room 4/12 is sometimes there and sometimes not. She conceals that she once looked through the keyhole and saw that the room is larger inside than outside. She talks quickly, curiously, with childlike directness.

**neu:** Daughter of a civilian employee of the Hold. Her father helps Marta Nováková maintain the heating, and she sometimes accompanies him to the cellar. She has often explored the Hold. She wants to have adventures and be taken seriously by the agents. She knows that Room 4/12 is sometimes there and sometimes not. She conceals that she once looked through the keyhole and saw that the room is larger inside than outside. She talks quickly, curiously, with childlike directness.

### Zeile 74, Briefing

**alt:** **The private favour:** Dr. Brandl contacts the cell before the briefing, via a dead drop or a personal meeting. She gives the cell a note with the abbreviation “silence 4/12” and the reference to Hold-9 (Handout 2.1). She asks the cell to find out what the abbreviation means and report back to her. She offers a favour in return: access to the Crystal Archive in Oxford or a letter of recommendation to the Seal Keepers.

**neu:** **The private favour:** Dr. Brandl contacts the cell before the briefing, via a dead drop or a personal meeting. She gives the cell a note with the abbreviation “silence 4/12” and the reference to Hold-9 (Handout 2.1). She asks the cell to find out what the abbreviation means and report back to her. She offers a favour in return: access to the Crystal Archive in Oxford or a letter of recommendation to the Seal Keepers. If the cell asks for equipment, Brandl gives them a beryllium isolation container from the Hold-7 workshop.

### Zeile 84, Node 1: The Hold Archive

**alt:** - **Clue:** The current ground plan shows eleven rooms, but the construction plan from 1991 shows twelve. (leads to Room 4/12)

**neu:** - **Clue:** The current ground plan shows eleven rooms, but the conversion plan from 1991 shows twelve. (leads to Room 4/12)

### Zeile 86, Node 1: The Hold Archive

**alt:** - **Clue:** An inspection report from 1992 mentions “irregularities in the basement, Room 4/12 not entered” (Handout 2.2). (leads to Černý, Node 2)

**neu:** - **Clue:** An inspection report from 1992 notes: “Room 4/12 not entered. Door locked, key not found.” (Handout 2.2). (leads to Černý, Node 2)

### Zeile 104, Node 3: The Canteen

**alt:** - **Clue:** Eliška tells the cell that the room is sometimes there and sometimes not. (leads to Room 4/12)

**alt:** - **Clue:** Eliška has seen through the keyhole that the room is larger inside than outside. (leads to Room 4/12)

**neu:** - **Clue:** Eliška tells the cell that the room is sometimes there and sometimes not. (leads to Room 4/12, Conclusion 2)

**neu:** - **Clue:** Eliška has seen through the keyhole that the room is larger inside than outside. (leads to Room 4/12, Conclusion 2)

### Zeile 107, Node 3: The Canteen

**alt:** - **Clue:** An Agent finds irregularities in Černý’s service file in the Hold finances: payments to a construction company that does not exist. (leads to Černý, Node 2)

**neu:** - **Clue:** The Hold cook, who also keeps the accounts, wonders about payments to a construction company that never set foot in the Hold. (leads to Černý, Node 2)

### Zeile 115, Node 4: The Basement Corridor Before Room 4/12

**alt:** - **Clue:** A Psion hears a silence near the room that is deeper than any shielding: no thoughts, no hum, nothing. (leads to Room 4/12)

**neu:** - **Clue:** A Psion near the room hears their own thoughts come back a heartbeat too late, as if echoing from another time. (leads to Room 4/12, Conclusion 2)

### Zeile 118, Node 4: The Basement Corridor Before Room 4/12

**alt:** - **Test:** Perception or Telepathy against Hard (3), to sense the silence. Psion with Telepath subclass: Doable (2).

**neu:** - **Test:** Perception or Telepathy against Hard (3), to sense the echo. Psion with Telepath subclass: Doable (2).

### Zeile 127, Node 5: Room 4/12 and the Room Behind the Door

**alt:** - **Clue:** A Scientist with Physics recognises that the room geometry is wrong: the room is 1.2 metres longer on the inside than outside. (leads to Conclusion 4)

**alt:** - **Clue:** A Thaumaturge who touches the stone feels that it is warm and whispers, and that the whisper gets louder when lifted. (leads to Conclusion 4)

**neu:** - **Clue:** A Scientist with Physics recognises that the room geometry is wrong: the room is 1.2 metres longer on the inside than outside, and the geometry warps most around the table with the stone. (leads to Conclusions 2 and 4)

**neu:** - **Clue:** A Thaumaturge who touches the stone feels that it is warm and whispers, and that the whisper gets louder when lifted. Meanwhile the walls of the room warp. (leads to Conclusion 4)

### Zeile 137, Node 5: Room 4/12 and the Room Behind the Door

**alt:** **2. Which origin?** | The Shifted. The room is a fold in the world, created in the night of Nordlicht 1977. | Clues in Node 4, 5

**neu:** **2. Which origin?** | The Shifted. The room is a fold in the world, created in the night of Nordlicht 1977. | Clues in Node 3, 4, 5

### Zeile 165, Sequence

**alt:** 3. The cell must find the anchor: the Nordlicht stone. Whoever touches it hears a man’s voice counting in Norwegian. A Thaumaturge can examine the stone, a Scientist can measure the geometry of the room, a Psion can sense the silence.

**neu:** 3. The cell must find the anchor: the Nordlicht stone. Whoever touches it hears a man’s voice counting in Norwegian. A Thaumaturge can examine the stone, a Scientist can measure the geometry of the room, a Psion can sense the echo.

### Zeile 167, Sequence

**alt:** 5. If the stone is not secured, the countdown counts faster. Shortly before 22:10, the voice breaks off, the door at the end of the corridor flickers open a crack, and behind it is nothing. Then the counter jumps back to sixty, the door closes, and the counting begins again from the start. The stone never reaches the end.

**neu:** 5. If the stone is not secured, the countdown counts faster. Shortly before 22:10, the voice breaks off, the door of the archive room flickers open a crack, and behind it there is no corridor any more, only darkness. Then the counter jumps back to sixty, the door closes, and the counting begins again from the start. The stone never reaches the end.

### Zeile 173, Solutions

**alt:** **With combat:** If the cell cannot secure the stone, the door at the end of the corridor opens, and a Riftling steps out. The cell must fend it off while they secure the stone. The Riftling is a Henchman, but it does not come alone: a group of three, as described in the Threat Atlas.

**neu:** **With combat:** If the cell cannot secure the stone, the door of the archive room opens, and a Riftling steps out of the darkness behind it. The cell must fend it off while they secure the stone. The Riftling is a Henchman, but it does not come alone: a group of three, as described in the Threat Atlas.

### Zeile 177, Solutions

**alt:** **Reward knowledge from the investigation:** Whoever has found the old building plan from 1977 knows that the room was originally a storage room. Whoever knows the open case about Nordlicht recognises the stone as the Nordlicht stone. Whoever has seen the abbreviation “silence 4/12” knows that the room is noted in the Crystal Ledger and that the matter must be significant for the Seal Keepers. None of these clues reveal that the stone is the anchor. The cell must recognise that themselves.

**neu:** **Reward knowledge from the investigation:** Whoever has found the old building plan from 1977 knows that the room was originally a storage room. Whoever knows the open case about Nordlicht recognises the stone as the Nordlicht stone. Whoever has seen the abbreviation “silence 4/12” knows that the room is noted in the Crystal Ledger and that the matter must be significant for the Seal Keepers. Whoever also knows the measurements at the stone from Node 5 recognises it as the anchor.

### Zeile 181, Opponents

**alt:** The fold itself is not a being, but a place. Whoever enters the room fights against time, not against an enemy. If the cell touches the stone, a Riftling can appear (Threat Atlas, Game Master’s Book). It is a Henchman of the Voice and seeps through the door at the end of the corridor, but it is not the actual opponent. A group of Riftlings consists of three beings, as described in the Threat Atlas.

**neu:** The fold itself is not a being, but a place. Whoever enters the room fights against time, not against an enemy. If the cell touches the stone, a Riftling can appear (Threat Atlas, Game Master’s Book). It is a Henchman of the Voice and seeps through the door of the archive room, but it is not the actual opponent. A group of Riftlings consists of three beings, as described in the Threat Atlas.

### Zeile 183, Opponents

**alt:** Major Pavel Černý is not an enemy as long as the cell does not alarm the Hold. If he confronts the cell in the basement, he raises his voice and demands an explanation. He only attacks if the cell opens the room or takes the stone with them. His values are below.

**neu:** Major Pavel Černý is not an enemy as long as the cell does not alarm the Hold. If he confronts the cell in the basement, he raises his voice and demands an explanation. He only attacks if the cell tries to leave the Hold with the stone without telling him what it is. His values are below.

### Zeile 204, Aftermath

**alt:** **Experience:** 5 XP per character. +1 XP for the solution without combat. +1 XP for securing the stone.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the cell has secured the stone. At most +1 XP personal bonus, for example for the solution without combat. +1 XP for each thread the cell takes up, for example the stone that counts backwards.

## 03_nummer341.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 42, Daniel Keane, 44

**alt:** Former Soldier, now a security consultant. Broad-shouldered, leather jacket, boots, a piece of ashsilver on a chain around his neck. Wants to secure the visor for the quartermaster because he owes Idris Pryce a favour. Knows that the visor hums when put on and that it attracts the Dead. Conceals that, since his time in service, he hears voices at night when he touches his silver. Speaks little, observes much, likes to stand in the dark.

**neu:** Former Soldier, now a security consultant. Broad-shouldered, leather jacket, boots, a piece of ashsilver on a chain around his neck, lent to him by Idris Pryce for this job. Wants to secure the visor for the quartermaster because he owes Idris Pryce a favour. Knows that the visor hums when put on and that it attracts the Dead. Conceals that, since his time in service, he hears voices at night when he touches silver. Speaks little, observes much, likes to stand in the dark.

### Zeile 52, Briefing

**alt:** **What the file contains:** Address of the pawnshop, name of the pawnbroker, photo of the visor from an online advert, a short note from the quartermaster: “Piece has been missing since 1989, made by Evan Pryce, the inside bears his name, do not open, do not put on”, a note from the Collegium: “Ashsilver with Echo, secure, wrap in lead, bring to Wales”. **Expenses:** €2,000. **Requisition:** An EMF detector, salt, a beryllium isolation container, a vehicle with false plates. The handler does not say that the quartermaster and the Collegium have already sent their own people.

**neu:** **What the file contains:** Address of the pawnshop, name of the pawnbroker, photo of the visor from an online advert, a short note from the quartermaster: “Piece has been missing since 1989, made by Evan Pryce, the inside bears his name, do not open, do not put on”. **Expenses:** €2,000. **Requisition:** An EMF detector, salt, a beryllium isolation container, a vehicle with false plates. The handler does not say that the quartermaster and the Collegium have already sent their own people.

### Zeile 62, Node 1: The Pawnshop in Grangetown

**alt:** - **Clue:** Gwynne talks about three interested parties: an art dealer from Bath, an antiques dealer from Bristol and a silent man in a leather jacket who came in once and left again (leads to Miriam Hale, Alistair Vane and Daniel Keane).

**neu:** - **Clue:** After Insight against Doable (2), Gwynne talks about three interested parties: an art dealer from Bath, an antiques dealer from Bristol and a silent man in a leather jacket who came in once and left again (leads to Node 4, to Alistair Vane and to Node 3).

### Zeile 66, Node 1: The Pawnshop in Grangetown

**alt:** - **Clue for Investigator:** A comparison of Number 341 with old files of the Investigation Branch shows that the number appears in a list of ashsilver pieces from Hold-2 that were reported sealed in 1989 (leads to Hold-2, to the quartermaster).

**neu:** - **Clue for Investigator:** A comparison of Number 341 with old files of the Investigation Branch shows that the number appears in a list of ashsilver pieces from Hold-2 that were reported missing in 1989 (leads to Hold-2, to the quartermaster).

### Zeile 76, Node 2: Hold-2, the Workshop

**alt:** - **Clue:** The quartermaster confirms that the visor has been missing since 1989 and was forged by his grandfather Evan Pryce (leads to What Really Happened).

**neu:** - **Clue:** The quartermaster confirms that the visor has been missing since 1989 and was forged by his grandfather Evan Pryce (leads to What happened?).

### Zeile 80, Node 2: Hold-2, the Workshop

**alt:** - **Clue for Soldier:** An Echo roll in the workshop shows that the silver in the Hold has been restless since the visor resurfaced. A previous owner warns of a man in a dark coat who wants to lock the piece away (leads to Miriam Hale, to the Collegium).

**neu:** - **Clue:** The quartermaster says the Psionics Core has been reporting a young man in Splott for three days, whose gift has awakened and who hears names at night (leads to Node 5).

**neu:** - **Clue for Soldier:** An Echo roll in the workshop shows that the silver in the Hold has been restless since the visor resurfaced. A previous owner warns of a man in a dark coat who wants to lock the piece away (leads to Node 4, to the art dealer from Bath).

### Zeile 84, Node 2: Hold-2, the Workshop

**alt:** **Tests:** Echo against Hard (3) to sense that the silver in the Hold has been restless since the visor resurfaced. Thaumaturgy against Doable (2) to recognise that the visor is not a dangerous artefact but a carrier. Shining classes: Soldier, Thaumaturge, Investigator.

**neu:** **Tests:** Echo roll, only for Soldiers with Echo: the game master secretly rolls a D6. If the result is equal to or less than the Echo, the Soldier senses that the silver in the Hold has been restless since the visor resurfaced. Thaumaturgy against Doable (2) to recognise that the visor is not a dangerous artefact but a carrier. Shining classes: Soldier, Thaumaturge, Investigator.

### Zeile 90, Node 3: The Street in Front of the Pawnshop

**alt:** - **Clue:** Keane saw a man in a dark coat enter the shop, speak with Gwynne and leave empty-handed (leads to Miriam Hale, to the art dealer from Bath).

**neu:** - **Clue:** Keane saw a man in a dark coat enter the shop, speak with Gwynne and leave empty-handed (leads to Node 4, to the art dealer from Bath).

### Zeile 92, Node 3: The Street in Front of the Pawnshop

**neu:** - **Clue:** Keane says that the quartermasters scatter salt in front of the armoury and leave the light on when the silver hums at night (leads to What works?).

### Zeile 121, Node 5: The Foster Family in Splott

**alt:** **What works?** The visor is not an opponent. It wants to be worn, or it wants to return to those who understand it. Salt, light and silver work against the Echo, but they do not destroy it. An end to the unfinished work: Pryce’s wish that someone wears and understands the piece. Clues in Node 1, 2.

**neu:** **What works?** The visor is not an opponent. It wants to be worn, or it wants to return to those who understand it. Salt, light and silver work against the Echo, but they do not destroy it. An end to the unfinished work: Pryce’s wish that someone wears and understands the piece. Clues in Node 1, 2, 3.

### Zeile 129, Escalation

**alt:** - **After 24 hours:** Alistair Vane increases his offer to £8,000 and has his solicitor call Gwynne. Gwynne becomes nervous and decides to sell the visor that very night, to whoever.

**neu:** - **After 24 hours:** Alistair Vane increases his offer to £8,000 and has his solicitor call Gwynne. Gwynne becomes nervous and summons all interested parties to the shop that very night after closing time: whoever bids the most takes the piece.

### Zeile 167, Owen Gwynne

**alt:** [entry - | Owen Gwynne | Pawnbroker · Human]

**neu:** [entry - | Owen Gwynne | Pawnbroker · Humans]

### Zeile 174, Owen Gwynne

**alt:** **Horror** | Uncanny (1), when the haunting appears

**neu:** **Horror** | None. Rolls against Uncanny (1) themselves when the haunting appears

### Zeile 181, Alistair Vane

**alt:** [entry - | Alistair Vane | Former antiques dealer · Human]

**neu:** [entry - | Alistair Vane | Former antiques dealer · Humans]

### Zeile 188, Alistair Vane

**alt:** **Horror** | Uncanny (1), when the haunting appears

**neu:** **Horror** | None. Rolls against Uncanny (1) themselves when the haunting appears

### Zeile 195, Mr Hartley

**alt:** [entry - | Mr Hartley | Art dealer of the Collegium · Human]

**neu:** [entry - | Mr Hartley | Art dealer of the Collegium · Humans]

### Zeile 200, Mr Hartley

**alt:** **Attack** | Compact pistol 3 + 2, damage 2, concealed, or stun baton 2 + 2, damage 1, stunning

**neu:** **Attack** | Compact pistol 3 + 2, damage 2, concealed, or cosh 2 + 2, damage 2, Stunning, Concealed

### Zeile 202, Mr Hartley

**alt:** **Horror** | Uncanny (1), when the haunting appears

**neu:** **Horror** | None. Rolls against Uncanny (1) themselves when the haunting appears

### Zeile 209, Daniel Keane

**alt:** [entry - | Daniel Keane | Former Soldier, security consultant · Human]

**neu:** [entry - | Daniel Keane | Former Soldier, security consultant · Humans]

### Zeile 214, Daniel Keane

**alt:** **Attack** | Escort blade 4 + 3, damage 3, or service pistol 4 + 3, damage 3

**neu:** **Attack** | Escort blade 4 + 3, damage 2, 3 against creatures from rifts, or service pistol 4 + 3, damage 3

### Zeile 216, Daniel Keane

**alt:** **Horror** | Uncanny (1), when the haunting appears. He has seen worse.

**neu:** **Horror** | None. Rolls against Uncanny (1) themselves when the haunting appears. He has seen worse.

### Zeile 223, Rhys Bowen

**alt:** [entry - | Rhys Bowen | Psion with unopened gift · Human]

**neu:** [entry - | Rhys Bowen | Psion with unopened gift · Humans]

### Zeile 230, Rhys Bowen

**alt:** **Horror** | Uncanny (1), when the haunting appears

**neu:** **Horror** | None. Rolls against Uncanny (1) themselves when the haunting appears

### Zeile 243, Aftermath

**alt:** **Experience:** 5 XP per character, +1 for a solution without combat, +1 for the decision to give the visor to Rhys Bowen or to leave it to the quartermaster.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the visor is secured without two O.D.I.N. offices shooting at each other. At most +1 XP personal bonus, for example for a solution without combat. +1 XP for each thread the cell takes up, for example Rhys Bowen and the name he hears.

### Zeile 245, Aftermath

**alt:** **Skulls:** None, as long as the cell does not destroy the visor or sell it to a collector. If the visor, sealed in lead, goes to the archive in Wales, the Collegium receives a skull for it, because it encloses an artefact that wants to be worn. If the visor goes to Vane, Grey Meridian receives a skull for it, as soon as the resale becomes known.

**neu:** **Skulls:** None, as long as the cell does not destroy the visor or sell it to a collector. If it is destroyed or sold, it counts as a lost piece of ashsilver (one skull for every ten lost pieces, Game Master’s Book). If it goes to Vane and from him to a collector, the Evening receives a skull as soon as the resale becomes known.

## 04_kessler.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 12, What It Is About

**alt:** The “Sammlung und Bewahrung” Foundation in Basel has been buying up crystals for decades to seal them in lead. An elderly lady named Renate Albers sits on the Foundation board. Martin Kessler, a quiet man with a tie with reindeer, has worked in accounting for four years. Six months ago, Kessler became ill, very ill, and no one was allowed to visit him. Now he is back. Sabine from accounting asked him why he doesn’t remember Otto, the caretaker’s dog, which Kessler fed every morning. Kessler smiled and said the illness had taken his memory. Sabine doesn’t believe him. She called the police, and the police passed the call on to an agency that doesn’t exist.

**neu:** The “Sammlung und Bewahrung” Foundation in Basel has been buying up crystals for decades to seal them in lead. An elderly lady named Renate Albers sits on the Foundation board. Martin Kessler, a quiet man with a tie with reindeer, worked in accounting for four years. In March 2025, Kessler became ill, very ill, and no one was allowed to visit him. In January he came back. Sabine from accounting asked him why he doesn’t remember Otto, the caretaker’s dog, which Kessler fed every morning. Kessler smiled and said the illness had taken his memory. In March the Foundation had reported him missing to the police. By January the missing man had become a long-term patient, and the report had been withdrawn. Sabine witnessed both. Sabine doesn’t believe him. She called the police, and the police passed the call on to an agency that doesn’t exist.

### Zeile 22, What Really Happened

**alt:** Elster, who sits on the Foundation board and is in truth the child the Hands did not take in 1952, recognised Kuckuck’s legend after three weeks. She let him work for four years and watched him. Then she had a photo from the summer party placed where an accountant would find it: a photo showing Kuckuck in the role of Martin Kessler, taken at the 2024 summer party. Elster wanted Kuckuck to stumble. She wanted him to ask questions. She wanted him to finish the article about the drowning in the Elbe.

**neu:** Elster, who sits on the Foundation board and is in truth the child the Hands did not take in 1952, recognised Kuckuck’s legend after three weeks. She let him work for four years and watched him. Then she had a folder of photos from the 2024 summer party at the director’s villa put in the Foundation’s cellar, among the restoration files, where an accountant would find it. In one of the pictures she herself stands next to the director. Elster wanted Kuckuck to stumble. She wanted him to ask questions. She wanted him to finish the article about the drowning in the Elbe.

### Zeile 24, What Really Happened

**alt:** Kuckuck found the photo and reported it. His report went up the chain, and because it concerned Elster, it went to Prometheus. A secretary wrote the answer. In Mulhouse, two men of the Hands waited to pick up Kuckuck. He did not arrive in Mulhouse. He came via Constance, and since then someone has been following him.

**neu:** Kuckuck found the picture, took it with him and reported it. His report went up the chain, and because it concerned Elster, it went to Prometheus. A secretary wrote the answer. In Mulhouse, two men of the Hands waited to pick up Kuckuck. He did not arrive in Mulhouse. He came via Constance, and since then someone has been following him.

### Zeile 30, What Really Happened

**alt:** **The red herring:** Viktor Brunner found a file in the foundation about a crystal purchase from 2019, in which the foundation acquired a Nexus crystal from a collector in Geneva. The file is incomplete, and Brunner believes that Elster did not seal the crystal in lead, but wants to keep it for herself. He is right, but that is not the reason the cell is here. The crystal lies in Elster’s house, in a lead box, and it hums softly. Whoever follows it finds a Nexus crystal and an old woman who is not afraid. Whoever mistakes it for the real case loses time.

**neu:** **The red herring:** Viktor Brunner found a file in the foundation about a crystal purchase from 2019, in which the foundation acquired a Nexus crystal from a collector in Geneva. The file is incomplete, and Brunner believes that Elster did not take the crystal to the Foundation’s lead archive, but wants to keep it for herself. He is right, but that is not the reason the cell is here. The crystal lies in Elster’s house, in a lead box, and it hums softly. Whoever follows it finds a Nexus crystal and an old woman who is not afraid. Whoever mistakes it for the real case loses time.

### Zeile 40, Renate Albers, Called Elster

**alt:** 80 years old, white hair, pearl necklace. She sits on the Foundation board and recognises every lie within the first minute. She wants someone from the Branch to see the Nursery with their own eyes. She knows that Brunner is not Kuckuck, and she knows that the Council wants to take her. She conceals that she deliberately placed the photo from the summer party. She speaks politely, patiently, in complete sentences, and she looks everyone in the eye before she answers.

**neu:** 80 years old, white hair, pearl necklace. She sits on the Foundation board and recognises every lie within the first minute. She wants someone from the Branch to see the Nursery with their own eyes. She knows that Brunner is not Kuckuck, and she knows that the Council wants to take her. She conceals that she deliberately had the summer party photos put in the cellar. She speaks politely, patiently, in complete sentences, and she looks everyone in the eye before she answers.

### Zeile 49, Herr Leuenberger

**alt:** Late sixties, director of the Foundation, formerly one of the Hands himself, considered dead since 1990. He buys crystals and locks them in lead. He wants the Foundation to continue its work, and he does not want the Council to get Elster. He knows that Brunner is not Kuckuck, because he observed Kuckuck for four years. He conceals that he has known Elster since 1990. He speaks kindly, thoroughly, and he smiles when he lies.

**neu:** Late sixties, director of the Foundation, formerly one of the Hands himself, considered dead since 1990. He buys crystals and locks them in lead. He wants the Foundation to continue its work, and he does not want the Council to get Elster. He knows that Brunner is not Kuckuck, because he observed Kuckuck for four years. He knows Brunner from his own time with the Hands. He conceals that he has known Elster since 1990. He speaks kindly, thoroughly, and he smiles when he lies.

### Zeile 63, Briefing

**alt:** **What the file contains:** Address of the Foundation, name of the accountant (Sabine Wirz), name of the director (Herr Leuenberger), an older staff photo from Kuckuck’s legend file, taken in 2021 when the legend was taken over. A note: “Kuckuck, Tobias Lenz, legend Martin Kessler, in Basel since 2021. Last report six months ago. Since then ill. Return reported by Sabine Wirz.”

**neu:** **What the file contains:** Address of the Foundation, name of the accountant (Sabine Wirz), name of the director (Herr Leuenberger), an older staff photo from Kuckuck’s legend file, taken in 2021 when the legend was taken over. A note: “Kuckuck, Tobias Lenz, legend Martin Kessler, in Basel since 2021. Last report in March 2025. Since then ill. Return in January 2026, reported by Sabine Wirz.”

### Zeile 78, Node 1: The Foundation

**alt:** - **Clue:** The photo from the 2024 summer party is in a drawer in accounting. An Investigator with Investigation or an Agent with Deception notices the discrepancy. (leads to Node 2)

**neu:** - **Clue:** In the cellar, among the restoration files, stands a folder of photos from the 2024 summer party. One picture is missing, another shows Martin Kessler. An Investigator with Investigation or an Agent with Insight notices the discrepancy. (leads to Node 2)

### Zeile 80, Node 1: The Foundation

**neu:** - **Clue:** Kessler’s personnel file contains not a single doctor’s note for ten months of illness. Sabine has noticed. (leads to Node 5)

**neu:** - **Clue:** Leuenberger recognises Brunner from his time with the Hands. He only says the name Viktor Brunner if the cell promises not to hand Elster over. (leads to Node 3)

### Zeile 85, Node 1: The Foundation

**alt:** **Tests:** Insight against Hard (3), to recognise that Sabine knows more than she says. Investigation against Doable (2), to find the photo. Thought Whisper (WIL + Telepathy), Brunner resists.

**neu:** **Tests:** Insight against Hard (3), to recognise that Sabine knows more than she says. Investigation against Doable (2), to find the folder. Thought Whisper (WIL + Telepathy), Brunner resists.

### Zeile 91, Node 2: The Photo

**alt:** The photo from the 2024 summer party, taken in the courtyard of the Foundation. It shows Martin Kessler with a tie with reindeer, a glass in his hand, a smile that doesn’t quite suit him. The photo is attached as Handout 4.1.

**neu:** The photo from the 2024 summer party, taken in the garden of the director’s villa. It shows Martin Kessler with the tie with reindeer and a smile that doesn’t quite suit him. At the edge, cut off, an old woman with white hair. The photo is attached as Handout 4.1.

### Zeile 93, Node 2: The Photo

**alt:** - **Clue:** An Investigator with Investigation or an Agent with Deception recognises that the man in the photo is not the same as the man who works in the Foundation today. (leads to Node 1)

**alt:** - **Clue:** On the back, written in pencil: “Summer party 2024, Martin Kessler.” The handwriting is not Sabine’s. An Investigator with Investigation or an Agent with Deception recognises that the handwriting is old, very old. (leads to Node 3)

**alt:** - **Clue:** The photo was in a drawer that Kuckuck used every day. An Investigator with Investigation recognises that someone placed it where he would find it. (leads to Node 3)

**neu:** - **Clue:** An Investigator with Investigation or an Agent with Insight recognises that the man in the photo is not the same as the man who works in the Foundation today. (leads to Node 1)

**neu:** - **Clue:** On the back, written in pencil: “Summer party 2024, Martin Kessler.” The handwriting is not Sabine’s. An Investigator with Investigation or an Agent with Perception recognises that the handwriting is old, very old. (leads to Node 3)

**neu:** - **Clue:** The folder stood among files that only accounting needs. An Investigator with Investigation recognises that someone put it where an accountant would find it. (leads to Node 3)

### Zeile 103, Node 3: Elster’s House

**alt:** An old house in the Basel district of Gundeldingen, near Gellert Church, with a garden where roses grow, and a door that is never locked. In the living room stands a lead box in which a crystal hums.

**neu:** An old house in the Basel district of Gundeldingen, near the Church of the Holy Spirit, with a garden where roses grow, and a door that is never locked. In the living room stands a lead box in which a crystal hums.

### Zeile 105, Node 3: Elster’s House

**alt:** - **Clue:** Elster says: “Tell your handler that I have been carrying the legend Renate Albers since 1952. He will know what that means.” (leads to Node 4)

**neu:** - **Clue:** Elster says: “Tell your handler that I have been carrying the legend Renate Albers since 1989 and that it was written for me in 1952. He will know what that means.” (leads to Node 4)

### Zeile 120, Node 4: The Print Shop in Zurich

**alt:** - **Clue:** The file of the Martin Kessler legend is not closed. An Agent or Investigator finds the note: “Transfer to Retrieval, January 2026.” (leads to Node 5)

**neu:** - **Clue:** The file of the Martin Kessler legend is not closed. An Agent or Investigator finds the note: “Transfer to Retrieval, January 2026. New bearer: V. B.” (leads to Node 5)

### Zeile 124, Node 4: The Print Shop in Zurich

**alt:** - **Clue:** The note in the file is enclosed as Handout 4.3.

**neu:** - **Clue:** The Cadet note from Kuckuck’s file, an extract from the Registry, is enclosed as Handout 4.3.

### Zeile 132, Node 5: The Dead Drop

**alt:** A locker at Basel SBB station, which Brunner uses for messages to the Council. An Agent with access to the Branch’s dead drop finds the handwriting of a secretary of Prometheus.

**neu:** A locker at Basel SBB station, which Brunner uses for messages to the Council, and the Branch’s old dead drop in the city park, in the crack of the wall behind the bandstand. Kuckuck reported through it. An Agent with access to the Branch’s papers finds the handwriting of a secretary of Prometheus.

### Zeile 135, Node 5: The Dead Drop

**alt:** - **Clue:** In Mulhouse, two men of the Hands are waiting. A Soldier or Investigator reconstructing Kuckuck’s travel movements finds that he came via Constance, not via Mulhouse. (leads to Node 1)

**alt:** - **Clue:** Brunner has his own dead drop. An Agent with Stealth finds it. (leads to Node 1)

**neu:** - **Clue:** In Mulhouse, two men of the Hands were waiting. A Soldier or Investigator reconstructing Kuckuck’s travel movements finds that he came via Constance, not via Mulhouse. (leads to Node 1)

**neu:** - **Clue:** The messages in the locker are initialled “V. B.” Whoever checks the initials against the old lists of the Hands finds a Viktor Brunner, died 2005. An Agent who follows Brunner with Stealth finds the locker. (leads to Node 1)

### Zeile 179, Solutions

**alt:** **Solution without combat:** The cell confronts Brunner with the photo from the summer party and the missing medical file. An Agent or Negotiator with Persuasion against Hard (3) gets him to call off the men of the Hands. Brunner is no fanatic. He is a professional who knows when a plan has failed. He lowers the weapon, nods to the cell and goes through the back entrance towards the Rhine. The men of the Hands follow him when he tells them that the operation has been aborted. Before that, Brunner demands one thing: that the cell remains silent, towards the Council and towards the Branch. He does not want to be hunted. He only wants to disappear.

**neu:** **Solution without combat:** The cell confronts Brunner with the photo from the summer party and the missing doctor’s notes. An Agent or Negotiator with Persuasion against Hard (3) gets him to call off the men of the Hands. Brunner is no fanatic. He is a professional who knows when a plan has failed. He lowers the weapon, nods to the cell and goes through the back entrance towards the Rhine. The men of the Hands follow him when he tells them that the operation has been aborted. Before that, Brunner demands one thing: that the cell remains silent, towards the Council and towards the Branch. He does not want to be hunted. He only wants to disappear.

### Zeile 209, Aftermath

**alt:** **Experience:** 5 per character, +1 for a solution without combat, +1 for a solution that brings Elster to the Nursery.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the cell finds out who Kessler is. At most +1 XP personal bonus, for example for a solution without combat or one that brings Elster to the Nursery. +1 XP for each thread the cell takes up, for example the Nexus crystal in Elster’s house.

### Zeile 216, Aftermath

**alt:** - Handout 4.1: The photo from the summer party, in Node 2, in a drawer in the Foundation’s accounting office.

**neu:** - Handout 4.1: The photo from the summer party, in Nodes 1 and 2, in the folder in the Foundation’s cellar.

### Zeile 218, Aftermath

**alt:** - Handout 4.3: The note in the file, in Node 4, in the Registry of the Print Shop, in Kuckuck’s file.

**alt:** - Map 4: Die Stiftung Sammlung und Bewahrung, Basel, with all rooms, doors, windows, and paths for the Confrontation.

**neu:** - Handout 4.3: The Cadet note, an extract from the Registry, in Node 4, in the Print Shop’s archive, in Kuckuck’s file.

**neu:** - Map 4: The Foundation in Basel, with all rooms, doors, windows, and paths for the Confrontation.

## 05_zweiter_kreis.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 28, What Really Happened

**alt:** Eva Leitner owns a modified multispectral scanner, which she built from parts from Morrow. The device responded to the signal of the crystal seven days ago. Since then she has driven to Oberwölz every night, parks at the edge of the forest and measures. She wants to recover the crystal before O.D.I.N. or Morrow finds it. On the first night after the signal appeared, Eva brought contaminated water samples into the house to analyse them. Since then, every evening, she has given her children a suppressant she developed, which suppresses the effect of the contamination. The drug is a sedative that causes no permanent damage, but is dangerous enough that the cell must intervene if they learn of it. Eva believes her children are protected. In truth she is risking their health.

**neu:** Eva Leitner owns a modified multispectral scanner, which she built from parts from Morrow. The device responded to the signal of the crystal seven days ago. Since then she has driven to Oberwölz every night, parks at the edge of the forest and measures. She wants to recover the crystal before O.D.I.N. or Morrow finds it. On the first night after the signal appeared, Eva brought contaminated water samples into the house to analyse them. Since then, every evening, she has given her children a suppressant she developed, which suppresses the effect of the contamination. The drug is a sedative that causes no permanent damage, but is dangerous enough that the cell must intervene if they learn of it. Eva believes her children are protected. In truth she is risking the health of both: every further week makes them more sluggish and paler.

### Zeile 30, What Really Happened

**alt:** **The red herring:** The village doctor Dr. Franz Pichler, 58, lost a patient three years ago, a girl with a rare sleep disorder. Since then he believes that behind inexplicable symptoms there is always a psychological cause. He has advised the parents not to wake the children, and recommended to the municipality that the well be cleaned. He conceals that he himself has heard the humming at night for a week, because he drank from the well. He is not a perpetrator, but he steers the investigation in the wrong direction: towards a mass hysteria.

**neu:** **The red herring:** The village doctor Dr. Franz Pichler, 58, lost a patient three years ago, a girl with a rare sleep disorder. Since then he believes that behind inexplicable symptoms there is always a psychological cause. He has advised the parents not to wake the children, and recommended to the municipality that the well be cleaned. He conceals that he himself has heard the humming at night for a week, because he drinks from the well every morning before sunrise. He is not a perpetrator, but he steers the investigation in the wrong direction: towards a mass hysteria.

### Zeile 54, Paul Reiter, 66

**alt:** ### Paul Reiter, 63

**neu:** ### Paul Reiter, 66

### Zeile 74, Node 1: The Anger with the Market Well

**alt:** The central square in Oberwölz, cobblestones, the well from the 17th century with a stone figure of Saint Florian. The water is clear, at the bottom something glitters. All around: the inn, the primary school, the church.

**neu:** The central square in Oberwölz, cobblestones, the well from the 17th century with a stone figure of Saint Florian. The water is clear, at the bottom something glitters: below the basin a bricked shaft leads six metres down to the spring catchment, and down there lies the light. All around: the inn, the primary school, the church.

### Zeile 77, Node 1: The Anger with the Market Well

**alt:** - **Clue:** A Psion with Telepathy or a Paranormal Detective hears a humming near the well that comes from the depths. Test on WIL + Telepathy against Hard (3): It is not a thought, but a rhythm that repeats every four minutes. (leads to node 3)

**neu:** - **Clue:** A Psion with Telepathy hears a humming near the well that comes from the depths, and so does a Paranormal Detective with an EMF detector. Test on WIL + Telepathy or INT + Occultism against Hard (3): It is not a thought, but a rhythm that repeats every four minutes. (leads to node 3)

### Zeile 95, Node 2: The Inn “Zum Goldenen Hirschen”

**alt:** - **Clue:** Paul Reiter hands the cell a photo from 1977 with an inscription on the back. (Handout 5.3)

**neu:** - **Clue:** Whoever notices Reiter’s hesitation with Insight against Hard (3) and asks gets a photo from 1977 from him with an inscription on the back. (Handout 5.3)

### Zeile 107, Node 3: The Laboratory in the Leitners’ House

**alt:** - **Clue:** A Biochemist or Chemist analyses the medicines. Test on Chemistry against Hard (3): It is a suppressant that suppresses the effect of the Contamination. It is not harmless, but causes no permanent damage. (leads to Nodes 4, 5)

**alt:** - **Clue:** A handwritten laboratory log, measurement no. 7, with falling pulse frequency and the recommendation for recovery within 48 hours due to risk of discovery. (Handout 5.2)

**neu:** - **Clue:** A Biochemist or Chemist analyses the medicines. Test on Chemistry against Hard (3): It is a suppressant that suppresses the effect of the Contamination. It is not harmless, but causes no permanent damage if it is stopped soon. (leads to Nodes 4, 5)

**neu:** - **Clue:** A handwritten laboratory log, measurement no. 7, with a falling pulse interval and the recommendation for recovery within 48 hours due to risk of discovery. (Handout 5.2)

### Zeile 128, Node 5: The Market Well at Night

**alt:** - **Clue:** A Psion with Telepathy hears the children’s choir as a single humming that comes from the well. Test on WIL + Telepathy against Very Hard (4): The crystal “sings” through the children, and it wants to be heard. (leads to the Confrontation)

**neu:** - **Clue:** A Psion with Telepathy hears the children’s choir as a single humming that comes from the well. Test on WIL + Telepathy against Very Hard (4): The crystal “sings” through the children, and it wants to be heard. Whoever silences it silences them too. (leads to the Confrontation)

### Zeile 141, Node 5: The Market Well at Night

**alt:** 1. An EMF detector shows pulses in time with Nordlicht, every four minutes. (Nodes 3, 5)

**neu:** 1. An EMF detector shows pulses in time with Nordlicht, every four minutes. (Nodes 1, 3, 5)

### Zeile 143, Node 5: The Market Well at Night

**alt:** 3. The crystal in the well is a rift fragment, clear with a milky core. (Nodes 3, 5)

**neu:** 3. The water sample contains crystal dust, and children singing in their sleep are a known omen of the Voice. (Nodes 1, 2)

### Zeile 200, Dr. Eva Leitner, alias Eva Lechner

**alt:** [entry - | Dr. Eva Leitner, alias Eva Lechner | Non-player character · Scientist]

**neu:** [entry - | Dr. Eva Leitner, alias Eva Lechner | Biochemist · Humans]

### Zeile 213, Thomas Leitner, alias Thomas Lechner

**alt:** [entry - | Thomas Leitner, alias Thomas Lechner | Non-player character · Engineer]

**neu:** [entry - | Thomas Leitner, alias Thomas Lechner | Engineer · Humans]

### Zeile 219, Thomas Leitner, alias Thomas Lechner

**alt:** **Horror** | none

**neu:** **Horror** | None

### Zeile 234, Aftermath

**alt:** **Experience:** 5 per character, +1 for the solution without combat, +1 for the recovery at the right moment.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the crystal is recovered and isolated. At most +1 XP personal bonus, for example for the solution without combat or the recovery at the right moment. +1 XP for each thread the cell takes up, for example Paul Reiter’s night in 1977.

## 06_hauslehrer.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 11, What It Is About

**alt:** At Lake Solberg, a runestone bearing the same circles as on the wall of the manor house is found during construction work. For a week, the children in the village have been singing in their sleep. The cell is sent to find out what is happening before the situation escalates. On site, they find an unsettled site manager, parents who no longer want to wake their children, and a wall in the manor house that is warm beneath the wallpaper. Solberg is a restricted zone. The cell enters with a permit from the Council, disguised as employees of a foundation for monument preservation that is to document the runestone.

**neu:** At Lake Solberg, a runestone bearing the same circles as on the wall of the manor house is found during construction work. For a week, the children in the village have been singing in their sleep. The cell is sent to find out what is happening before the situation escalates. On site, they find an unsettled site manager, parents who no longer want to wake their children, and a wall in the manor house that is warm beneath the wallpaper. The manor house by the lake is a restricted zone, otherwise accessible only with a Black File. The cell enters with a permit from the Council, disguised as employees of a foundation for monument preservation that is to document the runestone.

### Zeile 51, Node 1: The Building Site by the Lake

**alt:** The excavation pit, the runestone under a tarpaulin, construction workers, Jens Harder. The stone lies half in the mud, the circles are clearly visible. At the forest edge the trees stand close together, the ground is churned up.

**neu:** The excavation pit at the forest edge, construction workers, Jens Harder. Next to it lies the runestone under a tarpaulin, half in the mud, where the excavator set it down. The circles are clearly visible. It was found fifty metres further into the forest, in a clearing. The manor house is a kilometre away. At the forest edge the trees stand close together, the ground is churned up.

### Zeile 69, Node 2: The Village and the Children

**neu:** - **Clue:** Dr. Lindqvist tells what the old people in the village teach the children: in the forest you do not whistle, you do not shout, and you take nothing with you (leads to “What works”).

### Zeile 74, Node 3: The Church Register and the Vicarage

**alt:** The old church register of Solberg, Pastor Mattias Berg, a small archive in the vicarage. The church register has an entry from 1871 that breaks off in the middle of a sentence. In the archive there is a box with old papers, including the newspaper article from 1872 (Handout 6.1) and the pastor’s letter (Handout 6.2).

**neu:** Pastor Mattias Berg, a small archive in the vicarage and in it a certified copy of the old church register of Solberg. The original lies in the Uppsala Regional Archive. The entry from 1871 breaks off in the middle of a sentence in the copy too. In the archive there is a box with old papers, including the newspaper article from 1872 (Handout 6.1) and the pastor’s letter (Handout 6.2).

### Zeile 90, Node 4: The Lodge of the Silent Circle

**alt:** - **Clue:** The Antiquarian knows that the Forest Walker keeps agreements literally (leads to “What works”).

**neu:** - **Clue:** The Antiquarian knows that the Forest Walker keeps agreements literally and has three rules: do not whistle, do not shout, take nothing with you (leads to “What works”).

### Zeile 95, Node 5: The Manor House

**alt:** The old manor house, the wall with the circles, behind wallpaper or paint. A caretaker lives in the adjacent building. The house is empty, the air is still. The wall in the dining room is warm, the wallpaper is peeling in one spot.

**neu:** The old manor house, the wall with the circles, behind wallpaper or paint. No one lives here. The house is empty, the air is still. The wall in the dining room is warm, the wallpaper is peeling in one spot.

### Zeile 104, Node 5: The Manor House

**alt:** Test: Thaumaturge or Paranormal Detective, Ritualism against Hard (3), to read the circles.

**neu:** Test: Thaumaturge with Ritualism or Paranormal Detective with Occultism, each against Hard (3), to read the circles.

### Zeile 134, Sequence

**alt:** 3. He demands the stone back. He says: “The stone lies wrong. Bring it back into the forest where it lay, or I’ll take it, and then I’ll also take what you love.” Whoever does not hand over the stone is tested. The Forest Walker looks at each in turn. Whoever withstands his gaze without looking away has passed. Whoever looks away is no longer spoken to.

**neu:** 3. He demands the stone back. He says: “The stone lies wrong. Bring it back into the forest where it lay, or I’ll take it, and then I’ll also take what you love.” Whoever does not hand over the stone is tested. The Forest Walker looks at each in turn. Whoever withstands his gaze without looking away (horror test against Disturbing (2)) has passed. Whoever looks away is no longer spoken to.

### Zeile 170, Non-Player Characters

**alt:** **Alfred Sundberg, antiquarian.** They are old and frail. They carry a heavy walking stick. If the cell exposes them, they become quiet and quote from old books. They can strike with the stick: Attack 2 + 2, damage 2. They are not a fighter, but they are desperate.

**neu:** **Alfred Sundberg, antiquarian.** They are old and frail. They carry a heavy walking stick. If the cell exposes them, they become quiet and quote from old books. In their despair they raise the stick, but they do not strike. They have no attack.

### Zeile 179, Aftermath

**alt:** **What O.D.I.N. gets:** The runestone or a copy of the circles. The stone remains in the forest, but a rubbing of the circles goes to the Registry. The open file from 1871 remains open, with new threads: the missing page, the lodge, the name of the tutor. The red herring around Sundberg is noted. The lodge Zum Schweigenden Kreis is marked as an active organisation.

**neu:** **What O.D.I.N. gets:** A rubbing of the circles for the Registry. The runestone only if the cell does not bring it back, and then the Forest Walker returns every night. The open file from 1871 remains open, with new threads: the missing page, the lodge, the name of the tutor. The red herring around Sundberg is noted. The lodge Zum Schweigenden Kreis is marked as an active organisation.

### Zeile 181, Aftermath

**alt:** **Experience:** 5 per character, +1 for a peaceful solution, +1 for following the trail of the missing page to the family Bible. Additionally +1 for an Investigator who makes the connection between 1871 and the open file from 1938.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the stone is back in the forest and the children are quiet. At most +1 XP personal bonus, for example for a peaceful solution. +1 XP for each thread the cell takes up, for example the trail of the missing page to the family Bible or the connection between 1871 and the open file from 1938.

## 07_vitrine.md (Sicherung vor_spielersicht_2026-10-10)

### Zeile 16, What It Is About

**alt:** The cell comes as a visitor group, as heritage protection officers or as journalists. The handler gives them a thin file: report, newspaper clipping, a photo of the display case. The situation is calm. No one has been hurt yet. But the children sing every night, and for a week the granddaughter Jule, who lives in another town, has also been singing in her sleep.

**neu:** The cell comes as a visitor group, as heritage protection officers or as journalists. The handler gives them a thin file: report, newspaper clipping, a photo of the display case. The situation is calm. No one has been hurt yet. But the children sing every night, and for a week the director’s granddaughter has also been singing in her sleep: Jule, who lives in another town and has been visiting her grandmother for a few days.

### Zeile 20, What Really Happened

**alt:** In December 1938, on the night of the 3rd, a girl named Liese Hartmann, ten years old, died in Bad Grund. She was the daughter of the mine foreman Wilhelm Hartmann, who worked in the “Silberner Hirsch” shaft. On the evening of 2 December her father brought home a crystal he had found in the mine on 1 December: a fist-sized, milky stone, unusually warm. Liese took it to bed with her. That night, when in Solberg the children sang and nineteen adults disappeared, Liese died in her room. The doctor wrote “cardiac arrest”. The father sold the crystal on 6 December to the collector Hermann Wegener and disappeared the same day in the shaft. He was never found.

**neu:** In December 1938, on the night of the 3rd, a girl named Liese Hartmann, ten years old, died in Bad Grund. She was the daughter of the mine foreman Wilhelm Hartmann, who worked in the “Silberner Hirsch” shaft. On the evening of 2 December her father brought home a crystal he had found in the mine on 1 December: a fist-sized, milky stone, unusually warm. Liese took it to bed with her. That night, when in Solberg the children sang and nineteen adults disappeared, Liese died in her room. That same night two more children in Bad Grund died in their sleep. The doctor wrote “cardiac arrest” three times. The father sold the crystal on 6 December to the collector Hermann Wegener and disappeared the same day in the shaft. He was never found.

### Zeile 49, Inge Lorenz, 58

**alt:** Primary school teacher. She wants the children in her class to stop singing in their sleep. She knows that three children from her class are affected, and that all three were in the museum in the week after the exhibition opening. She conceals that she knows the song as an old Bad Grund song from her grandmother, who heard it in 1938 from a girl named Liese. She speaks quickly, worriedly, with many questions. She says: “The children sing the same song. I know it. My grandmother sang it to me.”

**neu:** Primary school teacher. She wants the children in her class to stop singing in their sleep. She knows that three children from her class are affected, and that all three were in the museum in the week after the exhibition opening. She conceals that she knows the song as an old Bad Grund song from her grandmother, who heard it on the night of 3 December 1938 through the wall from the Hartmanns’ house next door, from a girl named Liese. She speaks quickly, worriedly, with many questions. She says: “The children sing the same song. I know it. My grandmother sang it to me.”

### Zeile 62, Briefing

**alt:** **Requisition:** EMF detector, salt, a dictation machine with noise filter, a multispectral scanner, a beryllium isolation container, a vehicle. Common items without delay. A Thaumaturge can additionally requisition a crystal shard from the Hold if they justify it. The multispectral scanner is very rare and requires a Senior Agent with justification or one point of Trust.

**neu:** **Requisition:** EMF detector, salt, a dictation machine with noise filter, a multispectral scanner, a beryllium isolation container, a vehicle. Common items without delay. A Thaumaturge can additionally requisition a crystal shard from the Hold if they justify it. The multispectral scanner is very rare: from Senior Agent, with justification, three days’ waiting time. One point of Trust lowers the rank threshold by one level, another removes the waiting time.

### Zeile 124, Node 5: The City Archive (Bad Grund City Archive)

**alt:** - **Clue:** A file note from the Registry about hauntings: A haunting disappears when one finds what it repeats and puts an end to it. (leads to: What works, Confrontation)

**neu:** - **Clue:** A call to the Registry produces a file note about hauntings: A haunting disappears when one finds what it repeats and puts an end to it. (leads to: What works, Confrontation)

### Zeile 140, Escalation

**alt:** **Second night:** The file turns red. Liese no longer appears only as cold and voice. She shows herself: a girl in a nightgown, barefoot, who walks around the museum and opens the doors. The display case springs open, the crystal lies on the floor. The director is as if in a trance and wants to carry the crystal into the “Silberner Hirsch” shaft, which has been locked since 1945. The cell must stop her.

**neu:** **Second night:** The file turns red. Liese no longer appears only as cold and voice. She shows herself: a girl in a nightgown, nothing but mist below the hem, who walks around the museum and opens the doors. The display case springs open, the crystal lies on the floor. The director is as if in a trance and wants to carry the crystal into the “Silberner Hirsch” shaft, which has been locked since 1945. The cell must stop her.

### Zeile 157, Sequence

**alt:** 1. The cell enters the museum or observes it from outside. The director is in the “Mining and Minerals” room, reading aloud. Her voice is monotonous. Jule stands next to her, holding her hand. The granddaughter is visiting this weekend because her mother brought her to her grandmother for two days.

**neu:** 1. The cell enters the museum or observes it from outside. The director is in the “Mining and Minerals” room, reading aloud. Her voice is monotonous. Jule stands next to her, holding her hand. The granddaughter is still visiting her grandmother.

### Zeile 196, Dr. Marianne Weber

**alt:** [entry - | Dr. Marianne Weber | Non-player character · Museum Director]

**neu:** [entry - | Dr. Marianne Weber | Museum Director · Humans]

### Zeile 220, Aftermath

**alt:** **Experience:** 5 XP per character, +1 for the solution with the truth, +1 for saving the director and the granddaughter.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if Liese is released and the director and granddaughter are unharmed. At most +1 XP personal bonus, for example for the solution with the truth. +1 XP for each thread the cell takes up, for example the second crystal in the shaft.

### Zeile 222, Aftermath

**alt:** **Skulls:** If the cell gives the crystal to O.D.I.N., the foundation in Basel loses a skull, because the stone does not reach the market. If they give it to the Collegium, O.D.I.N. loses a skull, because the Council does not get a Nexus crystal.

**neu:** **Skulls:** If the cell hands the crystal over, to the Council or to the Collegium, the foundation in Basel loses a skull, because the stone does not reach the market. If they give it to the Collegium instead of the Council, the handler gets into trouble: Trust −1.

## 08_zweites_licht.md (Sicherung vor_handoutcheck_2026-10-10)

### Zeile 14, What Really Happened

**alt:** The Enlightened are a legend of the Print Shop, written in 1968 to soak up rumours about O.D.I.N. The Print Shop invented membership lists, rituals, books, later websites. It worked too well. Real people joined the invented secret society, and some began to take the rituals seriously. The ritual “The Second Light” comes from MS Arcana 114, an internal compendium of the Print Shop from 1971. It contains the seventh circle as an ornament, copied from an older manuscript that the Print Shop considered decorative. The seventh circle is no ornament. It is an invocation.

**neu:** The Enlightened are a legend of the Print Shop, written in 1968 to soak up rumours about O.D.I.N. The Print Shop invented membership lists, rituals, books, later websites. It worked too well. Real people joined the invented secret society, and some began to take the rituals seriously. The ritual “The Second Light” is found in an internal compendium of the Print Shop from 1971. It contains the seventh circle as an ornament, copied from MS Arcana 114, a manuscript of the Collegium that the Print Shop considered decorative. The seventh circle is no ornament. It is an invocation.

### Zeile 18, What Really Happened

**alt:** A member of the internet group, Maarten de Vries, 34, an unemployed graphic designer from Anderlecht, read the ritual and then carried it out. He believed the Illuminati would make him “Enlightened”. He invited three other members of the group to his terraced house: Sophie Renard, 28, art history student; Jonas Vermeulen, 41, accountant; and Aylin Demir, 31, nurse. On the night of 17 October 2026, a Saturday, he carried out the ritual in the cellar. He had painted the seventh circle on the floor with chalk and ash and placed a small crystal in the middle, which he had bought on the internet as “charged rock crystal”. The crystal was real.

**neu:** A member of the internet group, Maarten de Vries, 34, an unemployed graphic designer from Anderlecht, read the ritual and then carried it out. He believed the Illuminati would make him “Enlightened”. He invited three other members of the group to his terraced house: Sophie Renard, 28, art history student; Jonas Vermeulen, 41, accountant; and Aylin Demir, 31, nurse. On the night of 17 October 2026, a Saturday, he carried out the ritual in the cellar. He had painted the seventh circle on the floor with chalk and ash and placed a fist-sized crystal in the middle, which he had bought on the internet as “charged rock crystal”. The crystal was real.

### Zeile 34, Jonas Vermeulen, 41

**alt:** Accountant, Freemason, disappeared. He was the most cautious member, had cancelled the lodge evening to drive to Maarten’s. His lodge calendar is the red herring. He knows nothing of the ritual.

**neu:** Accountant, Freemason, disappeared. He was the most cautious member, had cancelled the lodge evening to drive to Maarten’s. His lodge calendar is the red herring. He thought the ritual was a game.

### Zeile 37, Aylin Demir, 31

**alt:** Nurse, disappeared. She had last posted in the group: “The light is not a light. It is an eye.” She suspected something, but too late.

**neu:** Nurse, disappeared. Her last post in the group ends with: “Tell him the light is not a light.” She had dreamt that the light was an eye. She suspected something, but too late.

### Zeile 51, Briefing

**alt:** > “Three missing persons in Brussels, all in the same internet group. On their computers there is a document that comes from our Print Shop. It is a ritual that should never have been written. Find out who used it, and end it before a fourth member disappears. The Belgian police have no trace of the ritual yet. Keep it that way.” || Handler

**neu:** > “Three missing persons in Brussels, all in the same internet group. On their computers there is a document that comes from our Print Shop. It is a ritual that should never have been written. Find out who used it, and end it before a fourth member disappears. The Belgian police think the ritual is a joke. Keep it that way.” || Handler

### Zeile 53, Briefing

**alt:** **What the file contains:** Names and addresses of the three missing persons, printouts from the forum “Illuminati Europa”, the ritual “The Second Light” as a PDF, the address of Maarten de Vries, a photo of the cellar from an online listing of the house. The Observer who intercepted the report has recorded all Belgian members of the group with their addresses and attached them to the file. **Expenses:** €2,000. **Requisition:** An EMF detector, salt, a multispectral scanner. A Thaumaturge can create a warding circle themselves if they have the Ritualism skill. Common items without waiting time.

**neu:** **What the file contains:** Names and addresses of the three missing persons, printouts from the forum “Illuminati Europa”, the ritual “The Second Light” as a PDF. The Observer who intercepted the report has recorded all Belgian members of the group with their addresses and attached them to the file. **Expenses:** €2,000. **Requisition:** An EMF detector, salt, a multispectral scanner. A Thaumaturge can create a warding circle themselves if they have the Ritualism skill. Common items without waiting time.

### Zeile 64, Node 1: The Flats of the Missing Persons

**alt:** - **Clue:** Aylin Demir’s last forum post: “The light is not a light. It is an eye.” An Investigator with Insight recognises that she was the only one who was afraid. (leads to Node 2)

**neu:** - **Clue:** Aylin Demir’s last forum post: “Tell him the light is not light.” An Investigator with Insight recognises that she was the only one who was afraid. (leads to Node 2)

### Zeile 75, Node 2: The Forum “Illuminati Europa”

**neu:** - **Clue:** Nadia shows Maarten’s last private message to her: “It is coming back through me. I am the door.” (leads to Node 5)

### Zeile 83, Node 3: The Terraced House in Anderlecht

**alt:** - **Clue:** A Soldier with Tactics recognises that the cellar has only one entrance but also a window to the garden that is covered with cardboard. (leads to Node 5)

**neu:** - **Clue:** A Soldier with Tactics recognises that the cellar can only be reached by the stairs. The window to the garden is covered with cardboard, but can be opened from outside. (leads to Node 5)

### Zeile 90, Node 4: The Archive of the Print Shop

**alt:** - **Clue:** The ritual “The Second Light” comes from MS Arcana 114, an internal compendium from 1971. A marginal note by the Typesetter: “Decoration. Do not use.” (Handout 8.2) (leads to Node 5)

**neu:** - **Clue:** The ritual “The Second Light” is found in an internal compendium of the Print Shop from 1971, its circle copied from the Collegium’s manuscript MS Arcana 114. A marginal note by the Typesetter: “Decoration. Do not use.” (Handout 8.2) (leads to Node 5)

### Zeile 98, Node 5: The Cellar of the Terraced House

**alt:** The cellar is a rectangular room, about 4 by 5 metres, with a staircase from above. The circle is painted with chalk and ash on the concrete floor, about 2 metres in diameter. In the centre lies a fist-sized crystal. The circle is warm, as if there were a heater underneath.

**neu:** The cellar is a rectangular room, about 4 by 5 metres, with a staircase from above. The circle is painted with chalk and ash on the concrete floor, about 2 metres in diameter. In the centre lies a fist-sized crystal. The circle is warm, as if there were a heater underneath. During the day Maarten sleeps upstairs. Whoever is quiet (Stealth against Doable (2)) can examine the cellar without him noticing.

### Zeile 104, Node 5: The Cellar of the Terraced House

**alt:** - **Test:** A Thaumaturge with Ritualism analyses the circle. Difficulty: Hard (3). A Scientist with Physics measures the heat. Difficulty: Doable (2). A Psion with Telepathy hears the Voice. Difficulty: Hard (3). A Soldier with Tactics recognises that the cellar has only one exit. Difficulty: Easy (1).

**neu:** - **Test:** A Thaumaturge with Ritualism analyses the circle. Difficulty: Hard (3). A Scientist with Physics measures the heat. Difficulty: Doable (2). A Psion with Telepathy hears the Voice. Difficulty: Hard (3). A Soldier with Tactics recognises that apart from the stairs only the garden window leads out. Difficulty: Easy (1).

### Zeile 111, Node 5: The Cellar of the Terraced House

**alt:** **What does it want?** The Voice wants to return through the circle and use Maarten as a gate. Clues in Node 5, 5, 5.

**neu:** **What does it want?** The Voice wants to return through the circle and use Maarten as a gate. Clues in Node 2, 5, 5.

### Zeile 155, Solutions

**neu:** **Without a Thaumaturge.** Whoever takes the crystal out of the circle and puts it in beryllium or salt closes the circle for one night. The Riftlings crumble. The next day the Collegium sends a Thaumaturge who seals it.

### Zeile 196, Aftermath

**alt:** **Experience:** 5 XP per character. +1 XP for the solution without combat. +1 XP for the sealing of the circle.

**neu:** **The three missing:** Sophie Renard, Jonas Vermeulen and Aylin Demir do not come back. If the circle is sealed, Sophie’s voice in the cellar falls silent. Their files remain open at the Registry.

### Zeile 198, Aftermath

**alt:** **Skulls:** The Enlightened lose one skull because the ritual was ended. The Enlightened thereby drop from three to two skulls.

**neu:** **Experience:** 4 XP per character, 5 if the file has turned red. +1 XP if the circle is sealed and Maarten stopped. At most +1 XP personal bonus, for example for the solution without combat. +1 XP for each thread the cell takes up, for example the amateur geologist with the remaining stones.

**neu:** **Skulls:** The Enlightened lose two skulls because their key figure Maarten de Vries has been eliminated, and drop from three to one. After the next mission the game master does not roll for this plan.
